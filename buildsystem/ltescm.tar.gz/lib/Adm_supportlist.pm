#!/apps/public/perl_5.6.1/bin/perl
#############################################################################
#   Copyright Motorola, Inc. 2006-2009
#
#   The copyright notice above does not evidence any
#   actual or intended publication of such source code.
#   The code contains Motorola Confidential Proprietary Information.
#
#  FILE NAME:    Adm_supportlist.pm
#
#  AUTHOR(S):    Kovalevsky Artem (rcft46) from iDEN SCM
#
#  OWNER:        LTE SCM Team
#
#  DATE ADAPTED: 11/20/2008
#
#  DESCRIPTION:  This file contains admin support list for SCM_common.pm
#
#############################################################################
#
#	MODIFICATION HISTORY:
#
# Ver	 Date	  Engineer     CR                     Change
# --- ---------- ---------- --------  ---------------------------------------
# 1.0 01/13/2009 skerr1     01120994  Created initial version.
# 1.1 06/28/2010 skerr1     01313325  Updates for team member changes.
#
#############################################################################
#
#       FILE USAGE:
#  The @ccsupport array contains list of admin support users. To add new or
#  delete old user from list just delete/add its coreID from array. All
#  coreID must be divided from each other by spaces.
#
#
#############################################################################

## CHECKLIST WHEN UPDATING THIS MODULE:
#  -----------------------------------
# 1. Update @EXPORT* if created a function or variable to be exported.
# 2. Update 'our' block if added a global variable to this module or
#    if a variable needs to be exported. 
# 3. Update $VERSION to reflect the new Adm_supportlist.pm version number.
# 4. Update the "MODIFICATION HISTORY" in the prologue.
# 5. Turn Perl warnings (-w) or diagnostics (use diagnostics;) and strict
#    (use strict;) off before release.

package Adm_supportlist;
# Used to setup export methods into calling programs.  Allows the use
# of import(), @ISA, @EXPORT, etc., which allows for different ways 
# of exporting symbols.
require Exporter;

# Allows for faster data access.
# Used as error checking mechanism: does not allow re-declaration of
# the same variable within the same scope.  For testing purposes only.
#use strict;
#use diagnostics;

# Allows use of english names for PERL pre-defined variables
use English;

# standard global symbols
our ($VERSION, @ISA, @EXPORT);

# Version number of this module 
# Usage: use Adm_supportlist 1.1
# This is a pre-defined perl variable.
$VERSION = 1.1;

# Search location for unresolved functions in the current package.
# The search is left to right.
# Exporter is included here because of the import() function.
@ISA = qw(Exporter);

# List of symbols to be exported by :DEFAULT.
@EXPORT = qw(@ccsupport);

# Package of exported global variables.
our (@ccsupport);

#============================================================================
#=====================  Exported Variable Initialization  ===================
#============================================================================
                
# Admin support list
@ccsupport = qw(ajm032 amn002 a24057 jarcham1 pnayak1 qa1854 skerr1 tmh476
               );

1;

# EOF
