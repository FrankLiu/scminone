#!/apps/public/perl_5.8.4/bin/perl
#############################################################################
#   Copyright Motorola, Inc. 2006-2010 . All Rights Reserved.
#
#   The copyright notice above does not evidence any
#   actual or intended publication of such source code.
#   The code contains Motorola Confidential Restricted Information.
#
#  FILE NAME:    SCM_common.pm
#
#  OWNER:        LTE SCM Team
#
#  DATE CREATED: 11/01/2006
#
#  EXIT VALUE:   1; - Mandatory for module to load successfully
#
#  TESTING:	 Automated testing available using:
#		   /vob/ltescm/lib/test/test_SCM_common.pl
#		 New automated test cases should be added to
#                test_SCM_common.pl for any changes made to this Perl module.
#
#  DESCRIPTION:  This perl module contains common functions and variables
#                used for LTE SCM tools.
#
#############################################################################
#
#	MODIFICATION HISTORY:
#		   (Always update $VERSION variable)
#
# Ver    Date     Engineer     CR                     Change
# --- ---------- ---------- --------  ---------------------------------------
# 1.0 01/13/2009 skerr1     01120994  Created initial version based on iDEN
#				      SCM team's SCM_common.pm.
# 1.1 03/02/2010 skerr1     01269590  Fixed trapsig() signal killing.
# 1.2 08/23/2010 skerr1     01348633  Fixed strict (only) issue in trapsig.
#                                     For set_logfile, create parent dir as
#                                     needed.
#
#############################################################################
#
#  FUNCTIONS:
#
#    Local:      # Keep this list in alphabetical order
#       check_env()           - Verifies the development environment
#       check_tool()          - Verifies that the passed tool is r,x for
#                               the current user
#       check_vob_mounts()    - Check to see that passed VOBs are mounted
#       cleanup()             - Cleans up the environment
#	daemonize()           - Turns this process into a daemon
#       default_create_view() - Default command to create a ClearCase view
#       exec_cmd()            - Executes passed command
#       execute_pl()          - Executes, prints and logs the passed
#                               command
#       is_cc_installed()     - Verifies Clearcase is available
#       mail_setup()          - Setup mail server domain
#       print_and_log()       - Prints message to STDOUT and/or to logfile
#       print_support_msg()   - Print the LTE SCM Team support message
#       process_error()       - Error handling routine
#       send_email_update()   - Sends the passed message to the mail_list
#       set_logfile()         - Sets up the logfile
#       trapsig()             - Called when the current process receives a
#                               signal
#       usage_log()           - Records the usage of the current tool
#	write_to_script()     - Write passed command to the passed script
#
#############################################################################

## DEVELOPMENT NOTES:
#  -----------------
# 1. Any variables global to this package must be declared within the
#    'our' directive.  This is because of strict and the __DATA__
#    directive.  Functions under __DATA__ will not have access to 
#    lexically scoped variables, because the functions are compiled via eval.
# 2. Any functions to be exported must be declared under the __DATA__
#    directive.
# 3. Only functions that are used by more than one tool should be added to
#    this module.

## CHECKLIST WHEN UPDATING THIS MODULE:
#  -----------------------------------
# 1. Update @EXPORT* if created a function or variable to be exported.
# 2. Update 'our' block if added a global variable to this module or
#    if a variable needs to be exported. 
# 3. Update $VERSION to reflect the new SCM_common.pm version number.
# 4. Update the "FUNCTIONS" list in the prologue.
# 5. Update the "MODIFICATION HISTORY" in the prologue.
# 6. Turn Perl warnings (-w) or diagnostics (use diagnostics;) and strict
#    (use strict;) off before release.


# Indicates that the entire library's symbol table or namespace is
# labeled as SCM_common.  The compiler will look for any undefined
# symbols, in the calling program, in this package.
package SCM_common;

use 5.8.4;	# Use Perl 5.8.4 or higher (also for debugging purposes)

# Include perl module with list of admin support users
use Adm_supportlist 1.0 qw(:DEFAULT);


# Used to setup export methods into calling programs.  Allows the use
# of import(), @ISA, @EXPORT, etc., which allows for different ways 
# of exporting symbols.
require Exporter;

# Allows for faster data access.
# Used as error checking mechanism: does not allow re-declaration of
# the same variable within the same scope.  For testing purposes only.
# Note: We do not check for strict references in order to access globals from
#       the calling package.
#use strict qw(vars subs);
#use diagnostics;

# Use for some functions to be POSIX compliant, allows access to
# POSIX identifiers.
use POSIX;

# standard global symbols
our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

# Allow functions to be compiled only when invoked - used with __DATA__ 
# directive.
use SelfLoader;  

use File::Basename; # Use for cleanly getting filenames

use Net::Domain qw(hostdomain); # Used to provide the Fully Qualified Domain
                                # Name after the hostname has been removed.

use Mail::Sender; # Used for sending email

use File::Path;   # Used for mkdir -p like behavior

# Version number of this module 
# Usage: use SCM_common <version>
# $VERSION is a pre-defined Perl variable.
$VERSION = 1.2;

# Search location for unresolved functions in the current package.
# The search is left to right.
# Exporter is included here because of the import() function.
@ISA = qw(Exporter);

# List of symbols to be exported by :DEFAULT.
# List functions first, constants, then all other symbols.
@EXPORT = qw(
       check_env
       check_tool
       cleanup
       daemonize
       default_create_view
       exec_cmd
       execute_pl
       mail_setup
       print_and_log
       print_support_msg
       process_error
       send_email_update
       set_logfile
       trapsig
       usage_log
       write_to_script
       
       $TRUE
       $FALSE
       $DOMAIN
       $MACHINE
       $OS_NAME
       $OS_VER
       $SCM_PERL
       $STATUS_OK
       $STATUS_ERROR
       $STATUS_WARNING
       $TIME_STAMP
       $USER
       $USERS_GROUP
       
       $cat
       @ccsupport
       $cp
       $cwd
       $date
       $domain
       $echo
       $grep
       *LOG_FH
       $mail_ccadm
       $mail_from
       $more
       $process_leader
       $smtp_server
       @sup_domains
       %sup_os
       $sup_wg
       $tool
       $touch
       @valid_projs
       @valid_sites
       $VIEWNAME
      );

# List of symbols exported only by request.
# All group symbols should be placed here.
@EXPORT_OK = qw(
       check_vob_mounts
       daemonize
       default_create_view
       is_cc_installed
       write_to_script
       $cc_ver
       $clearmake
       $ct
       $sup_cc_ver
       $sup_vobs
       );

# Setup hash of symbol groups
#
# GROUPS:
#	DEFAULT - Everything in @EXPORT
#	BTOOLS  - Build Tools specific symbols
#	CCTOOLS - ClearCase Tools specific symbols
#
# Note: You should not put globally used symbols in a
#	group.  All group symbols except for the DEFAULT
#	group should be added to @EXPORT_OK to keep them
#	from being exported by default.
#
%EXPORT_TAGS = (
                 BTOOLS  => [qw($clearmake
                            )],
                 CCTOOLS => [qw(check_vob_mounts
                                is_cc_installed
                                $cc_ver
                                $ct
                                $sup_cc_ver
                                $sup_vobs
                            )],
               );
                

# Package of exported global variables.
# List constants first, then all other symbols.
our ($TRUE,
    $FALSE,
    $DOMAIN,
    $MACHINE,
    $OS_NAME,
    $OS_VER,
    $SCM_PERL,
    $STATUS_OK,
    $STATUS_ERROR,
    $STATUS_WARNING,
    $TIME_STAMP,
    $USER,
    $USERS_GROUP,

    $callingPkg,
    $cat,
    @ccsupport,
    $cc_ver,
    $clearmake,
    $cp,
    $ct,
    $cwd,
    $date,
    $echo,
    $grep,
    $mail_ccadm,
    $mail_from,
    $more,
    $process_leader,
    $smtp_server,
    @sup_domains,
    %sup_os,
    $sup_cc_ver,
    $sup_vobs,
    $tool,
    $touch,
    @valid_sites,
    $VIEWNAME,
   );

#============================================================================
#=====================  Exported Variable Initialization  ===================
#============================================================================

# SCM Team Constants

tie $TRUE, 'Constvar', 1;                 # a Perl TRUE value
tie $FALSE, 'Constvar', 0;                # a Perl FALSE value
tie $DOMAIN, 'Constvar', hostdomain();    # current server default domain
tie $MACHINE, 'Constvar', (uname)[1];     # nodename from POSIX
tie $OS_NAME, 'Constvar', (uname)[0];     # operating system name from POSIX
tie $OS_VER, 'Constvar', (uname)[2];      # operating system release from POSIX
tie $SCM_PERL, 'Constvar', '/apps/public/perl_5.8.4/bin/perl';
tie $STATUS_OK, 'Constvar', 0;            # tool exit status: success
tie $STATUS_ERROR, 'Constvar', 1;         # tool exit status: failure
tie $STATUS_WARNING, 'Constvar', 2;       # tool exit status: warning
tie $TIME_STAMP, 'Constvar',
  strftime("%m/%d/%y - %H:%M:%S", localtime); # when script was invoked

# getpwuid is not available in Windows so use the USERNAME env var instead.
# This is required to enable this module to be loaded without errors by the
# Eclipse IDE on Windows.
if ($OS_NAME =~ /Windows/) {
  tie $USER, 'Constvar', $ENV{'USERNAME'}; # user's Windows login ID
} else {
  tie $USER, 'Constvar', (getpwuid($>))[0]; # user's **nix login ID
} # if ($ENV...


# "$)" (EGID) is a space delimited list of Effective Group IDs.
# The EGID variable is a built-in Perl variable (uses 'use English')
# This replaces the original method of resolving a user's group and
# fixes the situation where a user's group change (via newgrp) would
# not show a change since Net::NIS (yp) would only show the user's
# primary group and not their effective group.
tie $USERS_GROUP, 'Constvar', (split " ", $) )[0];


#
# No need to use the 'my' directive since we are using the 'our' directive.
#

# The package "using" this module
$callingPkg = (caller)[0];

# Get tool name
($tool = $0) =~ s@.*/@@;

# Valid sites.
@valid_sites = qw(AH SCH FTW SPB);

# File handle for logging
local *LOG_FH;

# *NIX commands used in some SCM tools
$cat   = "/bin/cat";
$cp    = "/bin/cp";
$date  = "/bin/date";
$echo  = "/bin/echo";
$grep  = "/bin/grep";
$touch = "/bin/touch";
$more  = "/bin/more";

# ClearCase related symbols
$ct = "/usr/atria/bin/cleartool";         # cleartool cmd
$clearmake = "/usr/atria/bin/clearmake";  # clearmake cmd
$cc_ver = "";				  # set by is_cc_installed()

# Variable for user's view name
$VIEWNAME = "";

# If in a view, get view name
if (defined $ENV{'CLEARCASE_ROOT'}) {
  chomp($VIEWNAME = $ENV{'CLEARCASE_ROOT'});
  $VIEWNAME =~ s/\/view\///; # remove prepended /view/
} # if (defined $ENV{'CLEARCASE_ROOT ...


# Other common variables
$cwd = POSIX::getcwd();			# Current Working Directory

$mail_ccadm = "cltescm\@motorola.com";

# Function prototypes
sub check_env (;@);
sub check_tool ($);
sub check_vob_mounts ($);
sub cleanup ();
sub daemonize ($$);
sub default_create_view ($$);
sub exec_cmd ($$$);
sub execute_pl ($);
sub is_cc_installed ();
sub mail_setup ();
sub print_and_log ($$);
sub print_support_msg ();
sub process_error ($$;$$);
sub trapsig ($);
sub send_email_update ($$$);
sub set_logfile (;$);
sub usage_log (\@);
sub write_to_script ($$$$);


#============================================================================
#==============================  Constvar Class  ============================
#============================================================================

# This package defines a Perl class that is used to ensure that the
# "constant" variables defined in SCM_common.pm cannot be modified.
# See "Programming Perl," 3e, page 365; or "Perl Cookbook," 2e, page 48,
# recipe 1.2.1, "Constant Variables," for more information.

package Constvar;

# This method is called when you use "tie" to tie a scalar variable to this
# class.
sub TIESCALAR {
    my ($class, $initval) = @_;
    my $var = $initval;
    return bless \$var => $class;
}

# This method is called when you retrieve a value from a scalar variable tied
# to this class.
sub FETCH {
    my ($selfref) = @_;
    return $$selfref;
}

# This method is called when you attempt to store a new value in a scalar
# variable tied to this class. We don't want to allow users to update
# variables that we consider "constant," so we issue an error here.
sub STORE {
	my($file, $line) = (caller(0))[1,2];
    	SCM_common::process_error("x",
          "Attempt to modify SCM_common.pm constant in $file line $line");
}


#============================================================================
#========================  Re-enter SCM_common Package  =====================
#============================================================================

package SCM_common;

#***The following line MUST be the last line before the __DATA__ line***#
1; # Ensures this perl module is loaded successfully.

# Directive used with the SelfLoader module to compile
# subroutines only when they are called.  This saves time
# when using this package in another package because not
# all functions are needed.  Only the functions called
# within the calling program will be compiled.
# 1. Variable declarations should not be done below this
#    directive unless they are local to a function.
# 2. Only functions to be exported should be below this directive. 
#
__DATA__
  
#============================================================================
#==============================  Functions  =================================
#============================================================================


#----------------------------------------------------------------------------
#                       Function: check_env
#----------------------------------------------------------------------------
# Description:
#	This function will check to make sure the user is in the correct
#	development environment.  This subroutine will call check_env_local()
#       in the caller's scope, if that subroutine is defined.
#
# Argument(s):
#	Array of terms:
#    "os_name"   -  Verify the current Operating System is valid.
#                   Supported OS names are keys of hash %sup_os.
#
#    "os_ver"    -  Verify the current Operating System release is valid.
#                   Valid OS versions are per the specific OS name (key) in
#                   the %sup_os hash.
#
#    "view_set"  -  Verify that User is in a view.  
#
#    "cc_ver"    -  Verify that the ClearCase version is valid.
#                   supported CC versions shall be pointed in $sup_cc_ver
#                   white space delimited.
#
#    "cc"        -  Verify that ClearCase is installed (also sets cc_ver)
#
#    "vobs"      -  Verify that project VOBs and the tools VOB are mounted.
#                   vobs shall be pointed in $sup_vobs; white space delimited
#
#    "domains"   -  Verify the current domain is valid.
#                   supported domains shall be pointed in @sup_domains;
# 		    white space delimited
#
#    "viewowner" -  Verify that User is the owner of the set view
#
#
# Return value:
#	Exits tool with $STATUS_ERROR or function with Empty List, Undefined
#	or Nothing depending on the context
#
# Pre condition(s):
#	The following variables are expected to be set in the calling namespace
#	if the corresponding check is requested:
#   
#       CHECK        VARIABLES
#       os_name      %sup_os
#       os_ver       %sup_os
#       cc_ver       $sup_cc_ver
#       vobs         $sup_vobs
#       domains      @sup_domains
#
# Post condition(s):
#	Terminates execution if the user does not have the proper development
#	environment.
#	No errors if the user has the proper development environment.
#
# Notes:
#	* %sup_os is a hash of arrays.  They key is the OS_name which points to
#     an array of supported versions for that OS.
#	* If no arguments are passed to the function it will default to the 
#     "view_set" and "cc" checks.
# 	* This subroutine will call check_env_local() in the caller's scope, if
#     that subroutine is defined.
#
sub check_env (;@) {

 my (@arguments) = @_;

 @arguments = qw(view_set cc) unless @arguments;

 my $opt = "";
 while ($opt = shift (@arguments)) {

   case:{
     ($opt =~ /^os_name$/) && do {

         # Verify the current Operating System is valid.
         (grep(/^$OS_NAME$/,keys(%sup_os)) < 1) &&
            process_error("x",
            "This machine is not running a supported operating system:".
            join(" or ",keys(%sup_os)) . " (your OS is $OS_NAME).");

         last case;
     };
     ($opt =~ /^os_ver$/) && do {

         # Verify the current Operating System release is valid.
         (grep(/^$OS_VER$/,@{$sup_os{"$OS_NAME"}}) < 1) &&
            process_error("w",
            "This machine is not running a supported version of $OS_NAME".
            " (your OS version is $OS_VER).\n  $OS_NAME version(s) ".
            join(" and ",@{$sup_os{"$OS_NAME"}}) . " is/are supported.");

         last case;
     };
     ($opt =~ /^view_set$/) && do {

         # User must be in a view. 
         (! defined $VIEWNAME || $VIEWNAME =~ /^\s*$/) &&
            process_error("x","You must be in a view to use the $tool tool.");

         last case;
     };
     ($opt =~ /^cc_ver$/) && do {
         # Verify that ClearCase is installed (also sets cc_ver)
         is_cc_installed() || process_error("x",
           "Clearcase must be installed to use $tool tool.");
         
         #Make an array from the string
         my(@sup_cc_vers)=split(' ',$sup_cc_ver);

         # Check that the ClearCase version is valid.
         (grep(/^$cc_ver$/,@sup_cc_vers)<1) && process_error("x",
            "This machine is not running the proper version of ClearCase".
            " ($cc_ver).\n  ClearCase versions: (".join(" and ",@sup_cc_vers).
            ") are supported.");

         last case;
     };
     ($opt =~ /^cc$/) && do {

         # Verify that ClearCase is installed (also sets cc_ver)
         is_cc_installed() || process_error("x",
           "Clearcase must be installed to use $tool tool.");

         last case;
     };
     ($opt =~ /^vobs$/) && do {

         # Check to make sure project VOBs and the tools VOB are mounted.
         check_vob_mounts($sup_vobs);
         ($? > 0) && process_error("x","VOBs must be mounted, exiting...");

         last case;
     };
     ($opt =~ /^domains$/) && do {

         # Verify the current domain is valid.
         (grep(/^$DOMAIN$/,@sup_domains) < 1) &&
           process_error("x", "You are executing ${tool} from an unsupported".
           " domain ($DOMAIN).\
	         \r  Supported domains include ".join(" and ",@sup_domains).".");

         last case;
     };
     ($opt =~ /^viewowner$/) && do {

         # The user must be the owner of the set-in view because the view's 
	 # config spec and permissions of the config spec file are modified by 
	 # this tool. "ct lsview" does not allow using "-fmt" therefore 
	 # the owner of the view must be extracted from the output of the 
	 # "ct lsview -properties" for the set in view.

         my @view_prop = `$ct lsview -properties $VIEWNAME`;
         (($? >> 8) > 0) && process_error("x",
                 "System command \"ct lsview -properties $VIEWNAME\" failed.");

         foreach my $prop_line (@view_prop) {
            
          if ($prop_line =~ /^Owner:/) {
            
            chomp(my $view_owner = $prop_line);
            # The line containing the owner name looks like the following:
            #     Owner: cig.mot.com/cid010 : rwx (all)
            # Remove everything up to the slash (and including)
            $view_owner =~ s/^.*\///;
            # Remove everything after the space (and including)
            $view_owner =~ s/\s+.*//;
            ($USER ne $view_owner) && process_error("x",
            "You must be the owner of the set-in view to use the $tool tool.");
            last;
         } # end if ($line ...
       } # end while

         last case;
     };
     
     ($opt =~ /.*/) && do {
        process_error("x", "Check_env: wrong argument ($opt)");
     };
   } # end case
 }# end while
 
 # If a tool shall process another checks, it shall be located in function 
 # "check_env_local" in caller's scope
 (defined &{"${callingPkg}::check_env_local"}) 
   && &{"${callingPkg}::check_env_local"}(@_);
   
 return;
 
} # end sub check_env

#----------------------------------------------------------------------------
#                       Function: check_tool
#----------------------------------------------------------------------------
# Description:
#	This function will verify that the current user has the correct
#	permissions to execute the passed tool.  Also, the tool must have
#	some content (size > 0).
#
# Argument(s):
#	tool_name		- The name of the tool to verify
#
# Return value:
#	Exits tool with $STATUS_ERROR or Empty List, Undefined or Nothing
#       depending on the context
#
# Pre condition(s):
#	None
#
# Post condition(s):
#	We know the passed tool should be usable for the current user.
#
# Underscore "_" refers to the previous stat results.
#
sub check_tool ($) {

  my ($tool_name) = @_;   # the name of the tool to verify
  my $failure = 0;	  # was there a valid tool criteria failure.
                          # (Default is false)

  # This next line makes sure that a tool was passed
  (!defined($tool_name) || $tool_name =~ /^\s*$/ ) && process_error("x",
	"(Internal) Invalid tool name passed to sub 'check_tool'.");

  (! -f $tool_name) && do {
    process_error("e", "$tool_name is not a plain file.");
    $failure = 1;
  };

  (! -x _) && do {
    process_error("e", "$tool_name is not executable.");
    $failure = 1;
  };

  (-z _) && do {
    process_error("e",
      "$tool_name file is empty.  If this is a VOB element, check your\
      \r configuration specification.");
    $failure = 1;
  };

  ($failure) && process_error("x",
      "You cannot execute $tool_name for the above reasons.");

  return;
  
} # end sub check_tool

#----------------------------------------------------------------------------
#                        Function: check_vob_mounts
#----------------------------------------------------------------------------
# Description:
#   This function verifies that the passed VOBs are mounted.
#
#   Example:
#   check_vob_mounts $CLEARCASE_AVOBS
#
# Argument(s):
#       $vobs           - A string of VOBs
#               e.g. "/vob/lteenb /vob/lte_cots"
#
# Return value(s):
#   0 - Vobs are mounted
#   1 - Vobs are not mounted
#
# Pre condition(s):
#   None
#
# Post condition(s):
#   If $ct lsvob fails, call process_error() and terminate.
#
sub check_vob_mounts ($) {
  my ($vobs) = @_;		          # passed string VOBs list
  my @vobs = split(/\s+/, $vobs); # split string of VOBs
  my $fstatus = $STATUS_OK;	          # return status from ct lsvob
  my $vob_ret = "";		          # ct lsvob return value

  # check if each $vob is mounted
  foreach my $vob (@vobs) {
	$vob_ret = `$ct lsvob $vob 2>/dev/null | $grep "^\*"`
	  || process_error("x","$ct lsvob $vob failed!");

	if ($vob_ret eq "") {
	  process_error("w","$vob vob not mounted");
	  $fstatus = $STATUS_ERROR;
	} # if ($vob_ret ...
  } # foreach my $vob ...

  return $fstatus;

} # end sub check_vob_mounts

#----------------------------------------------------------------------------
#                             Function: cleanup
#----------------------------------------------------------------------------
# Description:
#	Waits for child processes to end if this is the Group Process Leader.
#       This subroutine will call cleanup_local() in the caller's scope, if
#       that subroutine is defined.
#
# Argument(s):
#	None
#
# Return value:
#	Empty List, Undefined or Nothing depending on the context
#                    
# Pre condition(s):
#       This function is only to be used by the Group Process Leader.
#	The global variable $process_leader is set to $$ ($PID with English)
#	  by the process group leader.  This is needed so cleanup will reap
#	  child processes for the process group leader only.
#
# Post condition(s):
#       Reaped all child process.
#
# Note(s):
#       If a tool shall perform another additional trap processing, 
#       it shall be located in function "cleanup_local" in caller's scope
#
sub cleanup () {

  # This block of code allows the parent process to wait for all
  # its children when it terminates.  $$ is Process ID.
  if ($process_leader == $$){
    my $child;

    close(LOG_FH);

    # Waiting for all child processes to terminate.
    # This will avoid zombie processes.
    do {
      $child = waitpid(-1, &WNOHANG);
    } until $child == -1;

  } # end if ($process_leader ...

  (defined &{"${callingPkg}::cleanup_local"}) 
    && &{"${callingPkg}::cleanup_local"}(); 

  return;

} # end sub cleanup


#----------------------------------------------------------------------------
#                            Function: daemonize
#----------------------------------------------------------------------------
# Description:
#	This function will kill the parent process and turn the forked child
#	process into a daemon.
#
# Argument(s):
#	$logfile        - File name we are logging to.
#       $maillist       - Comma delimited list of email addresses to email
#                         errors to.
#
# Return value(s):
#       Failure: Calls process_error() with an error type of "x" or "mx". 
#       Success: Returns $execution_info.
#
# Pre condition(s):
#	The function "set_logfile" was previously called.
#
# Post condition(s):
#	The current (child) process is now disassociated from the controlling
# terminal and removed from the process group that initiated it. The current
# process is also now a session and group leader.
#
sub daemonize ($$) {
  my ($logfile, $maillist) = @_;
  
  # We fork here to:
  #	1. Disassociate the process from the controlling terminal.
  #	2. Remove the process from the process group that initiated
  #	   the program, which ensures that the process is not a
  #	   process group leader (required by setsid).
  # Note: fork returns the child PID if you are the parent process. It
  #       retuns 0 if you are the child.
  defined(my $child = fork) or
    process_error("x", "Can't fork to daemonize $tool: $!.");

  # We no longer need the parent process, so just exit if we are the parent.
  # Note: $child has the child's PID if we are the parent process and 0 if we
  # are the child process.
  $child and exit($STATUS_OK);

  # setsid() turns the current process into a session leader, group
  # leader, and ensures that it doesn't have a controlling terminal.
  setsid() or
    process_error("x", "Setsid failed!  Can't start a new session: $!.");

  # We need to reset the process_leader to the child process ID
  $process_leader = $$;     # Process ID for the process group

  # Reset initial execution information now that we have daemonized the
  # process
  my $execution_info = "Tool: \"$tool\"\n$tool Process ID: \""
                  . "$process_leader\"\nServer: \"$MACHINE.$DOMAIN\"\n"
                  . "Execution Directory: \"$cwd\"\nLog File: \"$logfile\"";

  # Append the view tag if the user is set into a ClearCase view
  ($VIEWNAME) and do {$execution_info .=
                        "\nCurrent ClearCase View: \"$VIEWNAME\"";};

  # Redirect STDERR to append to $cwd/$logfile log file
  open STDERR, '>>&', \*LOG_FH or
    process_error("mx",
      "Can't redirect STDERR to LOG_FH ($cwd/$logfile): $!.\n\n"
      . "$execution_info\n",$maillist, "$tool failure (PID $process_leader)");
  STDERR->autoflush($TRUE);

  # Redirect STDOUT to append to $cwd/$logfile log file
  open STDOUT, '>>&', \*LOG_FH or
    process_error("mx",
      "Can't redirect STDOUT to LOG_FH ($cwd/$logfile): $!.\n\n"
	. "$execution_info\n", $maillist,
        "$tool failure (PID $process_leader)");
  STDOUT->autoflush($TRUE);

  # Initially we read stdin from /dev/null
  open STDIN, '<', '/dev/null' or
    process_error("mx",
      "Can't read from /dev/null: $!.\n\n$execution_info\n",
	$maillist, "$tool failure (PID $process_leader)");

  return $execution_info;
  
} # end sub daemonize

#----------------------------------------------------------------------------
#                       Function: default_create_view
#----------------------------------------------------------------------------
# Description: Default command to create a ClearCase view.
#
# Argument(s):
#	$view	        - ClearCase view to create.
#	$create_view	- Command to execute to create a view
#
# Return value(s):
#	Exits tool with $STATUS_ERROR or Empty List, Undefined or Nothing
#       depending on the context
#
# Pre condition(s):
#	Global $createView is populated with the command to create $view.
#
# Post condition(s):
#	$view has been created as a ClearCase view.
#
sub default_create_view ($$) {
  my ($view, $create_view) = @_;
  $create_view =~ s/<view>/$view/g;

  exec_cmd("x",
           "$create_view",
           "Could not create view $view!");

  return;
  
} # end sub default_create_view...

#----------------------------------------------------------------------------
#                       Function: exec_cmd
#----------------------------------------------------------------------------
# Description:
#       This function executes a system command. It will exit or warn if 
#       execution of the command is not successful.
#
# Argument(s):
#       $error_instr - Test this to determine whether to warn or exit if 
#                      execution of passed command not successful
#       $command:    - The command to execute
#       $msg:        - Error/warning message
#
# Return value:
#	Exits tool with $STATUS_ERROR or Empty List, Undefined or Nothing
#       depending on the context
#
# Pre condition(s):
#       None
#
# Post condition(s):
#       Passed command executed.
#
# Note:
# If a tool shall perform cleanup procedures before fatal exit, it shall be
# located in function "cleanup" in caller's scope.
#
sub exec_cmd ($$$) {

  my ($error_instr, $command, $msg) = @_;
 
  my $cmd_status = $STATUS_OK;  # Initial command status set to $STATUS_OK

  (($error_instr ne "x") && ($error_instr ne "w")) && do {
    cleanup();
    process_error("x", 
      "Internal error: improper error instruction passed to exec_cmd().");
  };

  # Open process filehandle for system command. 
  open (COMMAND_FH, '|-', "$command") || do {
    cleanup();
    process_error("x","Cannot spawn process to execute $command.");
  };

  # Close COMMAND_FH
  close(COMMAND_FH);

  # Capture the return status from the program and not the shell.
  # Exit value of the subprocess is in the high byte, $? >> 8.
  # The low byte says which signal the process died from, $?.
  $cmd_status = ($? >> 8);

  # If an error was encountered, warn or quit based on $error_instr
  if ($cmd_status > 0) {
    if ($error_instr eq "w") {
       process_error("w", "$msg");
    } else {
      cleanup();
      process_error("x", "$msg");
    }
  } # end if ($cmd_status ...

  return;

} # end sub exec_cmd

#----------------------------------------------------------------------------
#                            Function: execute_pl
#----------------------------------------------------------------------------
# Description:
#     This function executes a command and calls print_and_log to output the
#     execution of the command to STDOUT and to a logfile.  This function is
#     only to be used by tools that want to print to STDOUT and log to a
#     file.
#
# Argument(s):
#	Command to execute.
#
# Return value:
#	Exits tool with $STATUS_ERROR or Empty List, Undefined or Nothing
#       depending on the context
#
# Pre condition(s):
#	The function "set_logfile" was previously called.
#
# Post condition(s):
#       Attempted to execute passed command.
#
sub execute_pl ($) {

  my ($command) = @_;
  my $cmd_status = $STATUS_OK;	# Initial command status set to $STATUS_OK
  # Print and Log the command before execution
  print_and_log("pl",$command."\n\n");

  # open filehandle for command for read.  Redirect STDERR to STDOUT to
  # capture all.  "|" is for read access only.
  open (COMMAND_FH, '-|', "$command 2>&1")
    || process_error("x","Cannot spawn process to execute $command: $!");

  # Write command output to logfile
  while (my $data = <COMMAND_FH>) {
    print_and_log("pl",$data);
  }

  # Close COMMAND_FH
  close(COMMAND_FH);

  # Capture the return status from the program and not the shell.
  # Exit value of the subprocess is in the high byte, $? >> 8.
  # The low byte says which signal the process died from, $?.
  $cmd_status = ($? >> 8);

  # If an error was encountered, quit
  ($cmd_status > 0) &&
    process_error("x","Command did not execute successfully: $cmd_status");

  return;

} # end sub execute_pl


#----------------------------------------------------------------------------
#                          Function: is_cc_installed
#----------------------------------------------------------------------------
# Description:
#	This function determines if clearcase is installed, sets the
#	clearcase version, and returns 1 if clearcase is installed and 0 if
#	it's not.
#
# Argument(s):
#	None
#
# Return value:
#	1 - ClearCase is installed
#	0 - ClearCase is not installed
#
# Pre condition(s):
#	None
#
# Post condition(s):
#	Call process_error if there is an error retrieving the ClearCase
#	version.  If there were no issues and ClearCase is installed, $cc_ver
#	is set.
#
sub is_cc_installed () {

  my $temp_cc_ver = "";		# Temporary ClearCase Version

  # First, test to see if the cleartool command is executable by the effective
  # UserID/GroupID.
  if (! -x $ct) {
    return 0;
  } # end if (! -x $ct ...

  # Get the ClearCase Release
  open(CCVER, '-|', "$ct -ver 2>/dev/null") ||
    process_error("x","Cannot fork process ($ct -ver): $!.");
  my @temp_cc_ver = grep(/ClearCase version/,readline(*CCVER));
  close(CCVER) ||
    process_error("x","Cannot close CCVER process handle: $!.");
  @temp_cc_ver = split(/ /,$temp_cc_ver[0]);
  $cc_ver = $temp_cc_ver[2];

  return 1;

} # end sub is_cc_installed


#----------------------------------------------------------------------------
#                            Function: mail_setup
#----------------------------------------------------------------------------
# Description:
#       This function sets the needed information to send email using the
#       Perl module Mail::Sender.  The setup is based on the user's current
#       host domain.
#
# Argument(s):
#       None
#
# Return value:
#	Exits tool with $STATUS_ERROR or Empty List, Undefined or Nothing
#       depending on the context
#
# Pre condition(s):
#       None
#
# Post condition(s):
#       The send_email_update function can now be used.
#
sub mail_setup () {
 
  # mail_config hash contains a list of known domains that point to arrays
  # of information about that domain:
  #     array[0] = smtp address
  #     array[1] = mail suffix
  my %mail_config = (
        "cig.mot.com"  => ["relay.cig.mot.com", "cig.mot.com"],
        "comm.mot.com" => ["relay.iden.comm.mot.com", "pronto1.comm.mot.com"],
        "ftw.mot.com"  => ["mailbox.ftw.mot.com", "ftw.mot.com"],
        "spb.mot.com"  => ["smtp.spb.mot.com", "spb.mot.com"]
  );

  # Set the SMTP (outgoing mail) server
  $smtp_server = $mail_config{$DOMAIN}[0];

  # Set the mail from address domain
  $mail_from   = $mail_config{$DOMAIN}[1];

  # Verify we have the smtp_server and mail_from vars set
  ((defined($smtp_server) && $smtp_server !~ /^\s*$/) &&
    (defined($mail_from) && $mail_from !~ /^\s*$/)) ||
    process_error("x",
     "SMTP server and/or email suffix not set properly domain \"$DOMAIN\".");

  return;

} # end sub mail_setup

#----------------------------------------------------------------------------
#                         Function: print_and_log
#----------------------------------------------------------------------------
# Description:
#	This function is used to output data to STDOUT and to a log file.
#
# Argument(s):
#	Type of logging and message to print and log
#       $code:
#                  The first parameter is one of [l|p]:
#                    l = Log     --> Logging to LOG_FH
#                    p = Print   --> Printing to STDOUT
#                    e = Error   --> Printing to STDERR
#
# Return value:
#	Empty List, Undefined or Nothing depending on the context
#
# Pre condition(s):
#	The function "set_logfile" was previously called.
#
# Post condition(s):
#       None
#
sub print_and_log ($$) {

  my ($code, $message) = @_;
  case:{

    # print to the screen
    ($code =~ /p/) && do {
      print "$message";
    };
    # print to STDERR
    ($code =~ /e/) && do {
      print STDERR "$message";
    };


    # print the message to the log file, call process_error if you cannot
    # write to logfile
    ($code =~ /l/) && do {
      # Return from print_and_log without any logging to file or warning
      # if print_and_log was called from process_error and log file was not
      # opened for writing.
      return
        if ( defined( caller (1) ) &&
             (caller (1) )[3] eq "SCM_common::process_error" &&
             !defined (fileno LOG_FH)
            );
            
      unless (print(LOG_FH "$message")) {
        process_error("w","Unable to print to logfile");
      } # unless (print ...
    }; # ($code =~ ...

  } # end case

  return;

} # end sub print_and_log

#----------------------------------------------------------------------------
#                       Function: print_support_msg
#----------------------------------------------------------------------------
# Description:
#	This function prints a message indicating where the user can get
#	support, to standard error.
#
# Argument(s):
#	None.
#
# Return value:
#	Empty List, Undefined or Nothing depending on the context
#
# Pre condition(s):
#	None
#
# Post condition(s):
#       None
#
sub print_support_msg () {

 printf STDERR
 " +-----------------------------------------------------------+
 |  For help with this tool, contact the LTE SCM Team at     |
 |  cltescm\@motorola.com or refer to the LTE SCM Team web    |
 |  page: http://compass.mot.com/go/ltecm                    |
 +-----------------------------------------------------------+\n\n";

 return;

} # end sub print_support_msg

#----------------------------------------------------------------------------
#                         Function: process_error
#----------------------------------------------------------------------------
# Description:
#	Prints out a variety of errors and, depending on the error type, may
#	exit.
#
# Argument(s):
#	$error_type:
#         The first parameter is one of [e|x|u|w|f|me|mw|mx]:
#            e = Error        --> Print the error, do not exit
#            x = eXit         --> Print the error, exit
#            u = Usage        --> Print the error and usage statement
#                                 then exit
#            w = Warning      --> Print warning, do not exit
#            f = Failure      --> Print failure warning, do not exit
#           me = Mail Error   --> Same as Error Type "e", except that the
#                                 msg is also mailed to the given email
#                                 addresses.
#           mw = Mail Warning --> Same as Error Type "w", except that the
#                                 msg is also mailed to the given email
#                                 addresses.
#           mx = Mail eXit    --> Same as Error Type "x", except that the
#                                 msg is also mailed to the given email
#                                 addresses.
#      
#      $explanation: the error message that accompanies the error type
#      $mail_list: Required for "me|mw|mx" error type.  Recipient email list.
#      $msg_sub: Required for "me|mw|mx" error type.  Message subject.
# 
# Tool Return Value:
#      $STATUS_ERROR	- With Error Types: x|u|mx|*
#
# Function Return Value:
#      $STATUS_OK	- No problems encountered executing the function
#      $STATUS_WARNING	- Encountered problems executing the function
#
# Pre condition(s):
#      A process in the tools did not execute correctly.  Requires that a
#      function "print_usage" be defined in the main program if using the "u"
#      option.
#
# Post condition(s):
#      The tool will print the message with the error type. Terminate if
#      fatal error.  
#
sub process_error ($$;$$) {
    my ($error_type, $explanation, $mail_list, $msg_sub) = @_;
    my $cmd_status = $STATUS_OK; # Return status of Open
    my $fstatus = $STATUS_OK;    # Function status
    my $mail_cmd = "";		 # Command to send mail    
    my $msg = "";		 # Message to be emailed to sctadmin
    my $pkg   = (caller)[0];	 # Calling package name
    my $plcode = 'le';           # Default print_and_log code
    my $sender;                  # Mail::Sender class

    # If ${$pkg . '::plcode'} then use it
    if (defined(${$pkg . '::plcode'})) {
        $plcode = ${$pkg . '::plcode'};
    } # end if (defined

    # If this is a mail error/warning, check to see that all passed vars
    # are defined with a value not empty string.
    if (grep("m",$error_type)) {
      if (!defined($mail_list) || $mail_list eq "") {
        $mail_list = $mail_ccadm;
      }
      if (!defined($msg_sub) || $msg_sub eq "") {
        $msg_sub = "SCM_common.pm - No Subject Provided";
      }
 
      # If mail context has not defined, call mail_setup()  
      ((defined($smtp_server) && $smtp_server !~ /^\s*$/) &&
       (defined($mail_from) && $mail_from !~ /^\s*$/)) || mail_setup(); 

      # Prepares a sender object
      $sender = new Mail::Sender {
         smtp => $smtp_server,
         from => "${USER}\@${mail_from}",
      };
    } # end if (grep ...
    
    # print the error message
    print_and_log ($plcode, "\n$tool - ");

    case:{

      # Non-fatal ERROR type
      ($error_type eq "e") && do {
        print_and_log ($plcode, "\aERROR:\n\n  $explanation\n\n");
	last case;
      };

      # Fatal ERROR type
      ($error_type eq "x") && do {
        print_and_log ($plcode, "\aERROR:\n\n  $explanation\n\n");
	print_support_msg();
        exit($STATUS_ERROR);
      };

      # WARNING type
      ($error_type eq "w") && do {
        print_and_log ($plcode, "WARNING:\n\n  $explanation\n\n");
	last case;
      };

      # FAILED type
      ($error_type eq "f") && do {
        print_and_log ($plcode, "\aFAILED:\n\n  $explanation\n\n");
	last case;
      };

      # USAGE type
      ($error_type eq "u") && do {
        my $usage_error = "\aERROR:\n\n  $explanation\n\n\n";
        &{"${callingPkg}::print_usage"}($usage_error);
        print_and_log ("l",$usage_error);
        exit($STATUS_ERROR);
      };
      # Mail Non-Fatal ERROR type
      ($error_type eq "me") && do {
        print_and_log ($plcode, "\aERROR:\n\n  $explanation\n\n");

        # use eval block to avoid problem when smtp server does not exists
	(eval{
           $sender->MailMsg({
               to => "$mail_list",
               subject => "$msg_sub",
               msg => "$tool - ERROR:\n\n  $explanation" });
        } && (!defined $sender->{'error'})) ||  do { 
            print_and_log ($plcode, "\aCould not mail ERROR to ".
                                 "\"$mail_list\"\n$Mail::Sender::Error.\n\n");
	    $fstatus = $STATUS_WARNING;
        };
	last case;
      };
      # Mail WARNING type
      ($error_type eq "mw") && do {
        print_and_log ($plcode, "WARNING:\n\n  $explanation\n\n");

        # use eval block to avoid problem when smtp server does not exists
	(eval{
           $sender->MailMsg({
               to => "$mail_list",
               subject => "$msg_sub",
               msg => "$tool - WARNING:\n\n  $explanation" });
        } && (!defined $sender->{'error'})) ||  do { 
            print_and_log ($plcode, "\aCould not mail WARNING to ".
                                 "\"$mail_list\"\n$Mail::Sender::Error.\n\n");
	    $fstatus = $STATUS_WARNING;
        };
	last case;
      };
      # Mail Fatal ERROR type
      ($error_type eq "mx") && do {
        print_and_log ($plcode, "\aERROR:\n\n  $explanation\n\n");

        # use eval block to avoid problem when smtp server does not exists
	(eval{
           $sender->MailMsg({
               to => "$mail_list",
               subject => "$msg_sub",
               msg => "$tool - ERROR:\n\n  $explanation" });
        } && (!defined $sender->{'error'}))|| do { 
            print_and_log ($plcode, "\aCould not mail ERROR to \"$mail_list\"\n".
                                 "$Mail::Sender::Error.\n\n");
        };
	print_support_msg();
        exit($STATUS_ERROR);
      };

      # An invalid error_type was used
      print_and_log ($plcode,"\a  INTERNAL ERROR: Invalid error type\
                     \r  ($error_type) in function \"process_error\"\n\n");
      print_support_msg();
      exit($STATUS_ERROR);

    } # end case 

    return $fstatus;

} # end sub process_error

#----------------------------------------------------------------------------
#                        Function: send_email_update
#----------------------------------------------------------------------------
# Description:
#       This function sends email to $mail_list to update on tool progress.
#
# Argument(s):
#       $message: Message to be sent.
#       $subject: Subject of the message.
#       $mail_list: The receiver of the mail.
#
# Return value:
#	Exits tool with $STATUS_ERROR or Empty List, Undefined or Nothing
#       depending on the context
#
# Pre condition(s):
#       Function mail_setup has been executed successfully.
#
# Post condition(s):
#       Message sent.
#
sub send_email_update ($$$) {

  my ($message, $subject, $mail_list) = @_;

  if (!defined($message) || $message eq "") {
    $message = "($tool) - No Message Provided";
  }

  if (!defined($subject) || $subject eq "") {
    $subject = "($tool) - No Subject Provided";
  }

  if (!defined($mail_list) || $mail_list eq "") {
   process_error("x","No Maillist Provided");
  }

  # Prepares a sender object
  my $sender = new Mail::Sender {
    smtp => $smtp_server,
    from => "${USER}\@${mail_from}"
  };

  # use eval block to avoid problem when smtp server does not exists
  (eval{

      $sender->MailMsg({
           to => "$mail_list",
           subject => "$subject",
           msg => "$message" });

  } && (!defined $sender->{'error'}) 
    && print "Update mail sent successfully!\n") 
    || process_error ("w", "Cannot send mail: $Mail::Sender::Error.");

  return;

} # end sub send_email_update


#----------------------------------------------------------------------------
#                           Function: set_logfile
#----------------------------------------------------------------------------
# Description:
#	This function sets up the logfile.  It creates the parent directory
# as needed.
#
# Argument(s):
#	(Optional) Logfile name
#
# Return value:
#	Exits tool with $STATUS_ERROR or Empty List, Undefined or Nothing
#       depending on the context
#
# Pre condition(s):
#	None.
#
# Post condition(s):
#	The LOG_FH is set for tool logging.  process_error called for any
#	errors/warnings.
#
sub set_logfile (;$) {
  my ($logfile) = @_;
  
  # If no valid logfile name was specified, default is <user>_<tool>.log
  unless (defined $logfile && $logfile ne "") {
    $logfile = "${USER}_${tool}.log";
  } # unless (defined ...

  my $dir = dirname($logfile);  # Parent directory of the log file

  # Try to create the parent directory (mkdir -p) if it does not exist
  # Note: File::Path::mkpath will throw an exception if there is any failure,
  # so there is no need for additional error handling.
  if (! -d $dir) {
    mkpath($dir);
  } # end if (! -d...

  # Remove existing logfile
  if (-e $logfile) { 
    (unlink $logfile) ||
      process_error "w","\nCannot remove existing logfile.\
                         \rWill append to current: $logfile.\n";
  } # if (-e $logfile ...

  # Open logfile filehandle - This allows printing to the logfile
  open(LOG_FH, '>>', "$logfile") ||
    process_error "x","\nCannot create the log file $logfile\n";

  # Change the logfile permissions
  chmod(0644,$logfile) ||
    process_error "w","\nUnable to change permissions on $logfile\n";

  # Enable autoflush on the logfile filehandle
  LOG_FH->autoflush(1);

  return;

} # end sub set_logfile

#----------------------------------------------------------------------------
#                       Function: trapsig
#----------------------------------------------------------------------------
# Description:
#       This function handles signals received by the process.
#
# Pre condition(s):
#       A signal was received by the current process.
#       
# Post condition(s):
#       The program will end gracefully.
#
# Note: Do not use kill() with the "-$PID" option as it is not portable.
#
# If a tool shall perform another additional trap processing, 
# it shall be located in function "trapsig_local" in caller's scope
#
# This function (trapsig) shall be pointed in $SIG array as indirect call: 
# $SIG{'INT'}  = sub { trapsig(@_); };
#
sub trapsig ($) {
use Config; # We need this to get the list of signals from $Config{sig_name}

  my ($signal) = @_; # gathering the signal type sub argument
  my %signo = ();    # Key is sig name, points to sig numerical value
  my $i = 0;         # The first signal is 0 (ZERO)
  
  foreach my $name (split(' ', $Config{sig_name})) {
    $signo{$name} = $i;
    $i++;
  } # end foreach my...

  # Only the parent process / group leader should execute this code.
  # $$ is Process ID.
  if ($process_leader == $$){
    
    # Immunizing the parent process from terminating for the same signal.
    local $SIG{$signal} = 'IGNORE';

    printf("\n\n($tool) $signal signal received\
            \r($tool) Gracefully terminating $tool\
            \r($tool) Terminating child processes...\n");

    # Send the same signal to the process group
    kill - $signo{$signal}, $process_leader;

    cleanup();
    
    (defined &{"${callingPkg}::trapsig_local"})
      && &{"${callingPkg}::trapsig_local"}(); 

     printf("($tool) $tool terminated.\n");
  } # end if ($process_leader ...
  
  exit($STATUS_ERROR);
} # end sub trapsig

#----------------------------------------------------------------------------
#                            Function: usage_log
#----------------------------------------------------------------------------
#
# Description:
# 	Updates the usage logs.
#
# Argument(s):
#	Array of arguments.
#
# Return value:
#	$STATUS_OK for success
#	$STATUS_WARNING for any failure
#
# Pre condition(s):
#	$tool and $tool_version must be defined.  $tool_version must be
#	defined in the tool and $tool is defined by SCM_common.
#	The $tool_version must be a global type in the $tool.
#
# Post condition(s):
#	If the user is not a member of ccsupport, the current tool usage is
#	added to the usage file.  process_error is called when errors are
#	encountered.
#
# Usage:
#	usage_log(<arguments>)
#
#       e.g. usage_log(@ARGV);
#
sub usage_log (\@) {
  
  my ($arg_ref) = @_;
  my $tool_ver = ${"${callingPkg}::tool_version"};

  my $arglist = join(" ",@$arg_ref);
  my $file = "/mot/proj/lte_scm/toolusage/${tool}_v${tool_ver}_usage_log";

  # Only log non-ccsupport users 
  if (scalar(grep /^$USER$/, @ccsupport) == 0) {
    # Append to $file
    open (FH, '>>', "$file")
	|| process_error("mw", "Cannot open tool usage logfile for $tool!",
	$mail_ccadm,"Usage Log Error");
    print FH "Time: $TIME_STAMP\nUser: $USER\nMachine: $MACHINE\n"
	|| return $STATUS_WARNING;
    print FH "View: $VIEWNAME\nPWD: $cwd\nUsage: $tool $arglist\n\n"
	|| return $STATUS_WARNING;
    close(FH);
    chmod(0666, $file) || return $STATUS_WARNING;

  } # end if (scalar(grep ...

  return $STATUS_OK;

} # end sub usage_log


#----------------------------------------------------------------------------
#                         Function: write_to_script
#----------------------------------------------------------------------------
# Description: Write to target Korn Shell script.
#
# Argument(s):
#	$scriptFH	- Script File Handle
#	$script		- Script name
#	$cmd		- Command to be added to script
#	$desc		- Description of command for script to print
#
# Return value(s):
#	Exits tool with $STATUS_ERROR or Empty List, Undefined or Nothing
#       depending on the context
#
# Pre condition(s):
#	Passed file handle has already been opened for writing to $script.
#
# Post condition(s):
#	Necessary text written to script.
#
sub write_to_script ($$$$) {
  my ($scriptFH, $script, $cmd, $desc) = @_;
  my $scriptName = basename($script);
  my $errorMsg = "Could not write to the file handle for $script";

  # Write description print statement
  print($scriptFH 'print "' ."($scriptName) $desc" .'"' . "\n")
    or process_error("x", $errorMsg);

  # Write command for print to stdout
  print($scriptFH "print \"($scriptName) Command: $cmd\"\n")
    or process_error("x", $errorMsg);

  # Write command for execution
  print($scriptFH "$cmd\n") or process_error("x", $errorMsg);

  # Write return code set
  print($scriptFH 'rc=$?' . "\n") or process_error("x", $errorMsg);

  # Write return code check
  print($scriptFH 'if [[ $rc != 0 ]]; then' . "\n")
    or process_error("x", $errorMsg);

  # Write error for non-zero return value
  print($scriptFH
    ' print -u2 "\n' . "$scriptName" . ' - ERROR:\n\n  Command (' . $cmd .
    ') has a non-zero return ' . 'value: $rc\n"' . "\n") or
      process_error("x", $errorMsg);

  # Write exit with $STATUS_ERROR return value from $scriptFH
  print($scriptFH " exit $STATUS_ERROR\n") or process_error("x", $errorMsg);

  # Write if block close
  print($scriptFH "fi\n") or process_error("x", $errorMsg);

  # Unset $rc
  print($scriptFH "unset rc\n") or process_error("x", $errorMsg);

  # Write execution of command completed print statement
  print($scriptFH "print \"($scriptName) Finished successful execution of" .
                  " command ($cmd)." . '\n"' . "\n\n") or
                    process_error("x", $errorMsg);

  return;
  
} # end sub write_to_script

# EOF
