#!/apps/public/perl_5.8.4/bin/perl
#############################################################################
#
#       Copyright (C) 2007 - 2009 MOTOROLA. All Rights Reserved.
#
#       The copyright notice above does not evidence any
#       actual or intended publication of such source code.
#       The code contains Motorola Confidential Restricted Information.
#
#############################################################################
#
#  FILE NAME:    test_SCM_common.pl
#
#  OWNER:        LTE SCM
#
#  DATE CREATED: 12/09/2007
#
#  SYNOPSIS:     Tool used for testing SCM_common.pm
#
#  EXIT VALUE:   0      All Test Cases Executed Successfully
#                >0     Number of failed test cases
#
#  DESCRIPTION:  This Perl tool contains tests for common functions in the
#                SCM_common.pm Perl module.
#
#############################################################################
#
#  MODIFICATION HISTORY:
#
# Ver    Date     Engineer     CR                    Change
# --- ---------- ---------- -------- ----------------------------------------
# 1.0 01/14/2009 skerr1     01120994 Ported from iSD SCM (/vob/sct/lib/test).
#
#############################################################################
#
#  FUNCTIONS:  (Alphabetical)
#
#	Local
#	-----
#	print_usage()		- prints this tool's usage message
#
#	SCM_common
#	----------
#	check_env()		- verifies and sets up the tool environment
#	process_error()		- error handling routine
#
#       Test::More
#       ----------
#       can_ok()                - test if you can access specific functions
#                                 or methods
#       cmp_ok()                - test two values using binary Perl operator
#       diag()                  - print a diagnostic message that will not
#                                 interfere with test output
#       is()                    - test two values using the "eq" operator
#       is_deeply()             - test that two data structures specified by
#                                 references are equivalent 
#       like()                  - matches value against regex
#       skip()                  - skip block of tests if proper condition met
#       use_ok()                - test that a module loads successfully
#
#       Test::Trap
#       ----------
#       trap()                  - traps exceptions like "eval", but also
#                                 traps exits and exit codes
#
#############################################################################
#
#  MAINTENANCE:
#
#       When adding new test sets (support for testing new functions) always
#   add the new tests to the end of the existing tests so you don't have to
#   go through and re-number existing test cases.
#
#       Update @test_sets when adding new test sets to this tool. 
#
#############################################################################

##
## POD Documentation
##

=head1 NAME

B<test_SCM_common.pl> - Executes a tests for SCM_common.pm

=head1 USAGE for B<test_SCM_common.pl> v1.0

Standard B<test_SCM_common.pl> usage:

     test_SCM_common.pl [-t/est <set1>,<set2>,...]


Print available test sets B<test_SCM_common.pl>:

     test_SCM_common.pl -p/rint_sets


View the B<test_SCM_common.pl> help message:

     test_SCM_common.pl -h/elp

=head1 DESCRIPTION

This tool will by default execute all available test cases for SCM_common.pm
The user may also wish to select specific test sets to test.  The exit value
of B<test_SCM_common.pl> is the number of I<failed> test cases.

=head1 OPTIONS

=over 1

=item B<-t/est>

Comma delimited list of test sets (SCM_common functions or other groups) to
execute the test cases for.

=item B<-p/rint_sets>

Print the available test sets.

=item B<-h/elp>

Print the help message for B<test_SCM_common.pl>.

=item B<-v/ersion>

Print the current version of B<test_SCM_common.pl>.

=back

=head1 EXIT STATUS

 0 for successful execution of all tests
 >0 for the number of test cases that failed

=head1 NOTES

=over 2

=item *

Two test cases, "use_ok SCM_common" and "can_ok(function_list)", will be
executed in any mode of operation.

=item *

If you execute B<test_SCM_common.pl> on a server where ClearCase is not
installed, the test cases for the "is_cc_installed" test set will fail.  This
is acceptable.

=item *

Currently, Solaris version(s) 2.10 and RedHat Enterprise Linux 4 are 
supported.

=back

=head1 AUTHOR

Shannon Kerr, LTE SCM

=cut

#############################################################################


#============================================================================
#=========================   Initialize Environment  ========================
#============================================================================

# Used as error checking mechanism: does not allow re-declaration of
# the same variable within the same scope.  For testing purposes only.
use strict;
use diagnostics;

BEGIN {

  # Set the location for iNI SCM modules
  push(@INC,($ENV{'SCM_ROOT'}||'/vob/ltescm').'/lib');

  # Autoflush Standard Error and Output; No Output buffering
  select(STDERR); $| = 1;		# Make unbuffered
  select(STDOUT); $| = 1;		# Make unbuffered

} # end BEGIN

use 5.8.4;	# Use Perl 5.8.4 or higher (also for debugging purposes)

# Set the number of test cases by setting "tests" below.
# Update this value when adding new test cases.
use Test::More tests => 22;

# Used to trap exit calls
use Test::Trap;

## Test Case 1 - SCM_common loads successfully
# For common SCM symbols.  You MUST update the version below to be in
# sync with the version of SCM_common.pm you are testing.
BEGIN {use_ok('SCM_common', 1.0);
} # end BEGIN

## Test Case 2 - SCM_common functions are available
can_ok('SCM_common', qw(process_error
                        is_cc_installed
                        write_to_script
                        default_create_view
                        daemonize
                       )
); # end can_ok...

# We "use" SCM_common again here so we can import functions.  You cannot
# explicitly import functions and check the module version with use_ok.
use SCM_common 1.0 qw(:DEFAULT
                      :BTOOLS
                      :CCTOOLS
); # end use SCM_common

# Use for some functions to be POSIX compliant, allows access to POSIX
# identifiers, and takes care of dynamic loading and autoloading (e.g. Perl
# subroutine definitions, etc.)
use POSIX;    

use Getopt::Long qw(:config no_ignore_case); # Use for options processing

my $maillist = "$USER";         # For tests that involve email, default addr

our $pager = '';		# Used for paging through output
# Set the pager to the user's environment PAGER or default to "more"
($pager = $ENV{'PAGER'}) or ($pager=$more);
# Add -E if the page is "less" so less won't hang at the end of the output
((grep(/less/,$pager)) > 0) and ($pager.=' -E');
                      
# Array of available test sets.
# Keep these in the order they appear in 'main'.
my @test_sets = qw(process_error
                   print_support_msg
                   is_cc_installed
                   main
                   daemonize
                   default_create_view
                   write_to_script
);

my $stderr = "";                # Output captured from STDERR

# Get the support message
trap { print_support_msg(); };
my $support_msg = $trap->stderr;

my @test_cases = ();            # Command line tests to perform (default all)
my $test_rc;                    # Test return code

our $tool_version = '1.0';      # Current version of $tool


#============================================================================
#==============================   Functions  ================================
#============================================================================


#----------------------------------------------------------------------------
#                          Function: print_usage
#----------------------------------------------------------------------------
# Description:
#     This function prints the usage of this tool to standard output.
#
# Argument(s):
#	Optional: Error message.
#
# Return value:
#	Exits tool with $status_error or function returns with return value
#	of the last executed command (not particularly useful).
#
# Pre condition(s):
#	None.
#
# Post condition(s):
#	None.
#
sub print_usage {

my ($usage_error) = @_; # gathering the usage error sub argument

# This next line makes sure usage_error has something
if (!defined($usage_error) or $usage_error eq 'help') { $usage_error='';}

# We don't want the usage to fly by on the screen, so we need to open a
# process handle so we can pipe to $pager.  This will allow the user to
# page through the usage output even when usage errors are encountered.

open(my $USAGE_OUT, '|-',  "$pager")
	or process_error('x',"Can't fork your pager ($pager): $!.");

print $USAGE_OUT <<EOT_USAGE;
$usage_error USAGE for $tool v$tool_version:    

      Standard $tool usage:

               $tool [-t/est <set1>,<set2>,...]


      Print tests $tool usage:

               $tool -p/rint_test_sets


      View the $tool help message:

               $tool -h/elp


 NOTES: 
  - $tool requires that you are in a supported Solaris 2.10 or RedHat
    Enterprise Linux 4.
  - $tool exit status is the number of failed test cases

EOT_USAGE

close($USAGE_OUT) or process_error('w',
			"Can't close process handle \$USAGE_OUT: $!.");

} # end sub print_usage


#============================================================================
#===============================   MAIN  ====================================
#============================================================================

##
## Validate the environment etc.
##

# Supported Operating System with version(s)
%sup_os = ('Linux' => [qw(2.6.9-55.ELsmp)],
           'SunOS' => [qw(5.10)],
);

@sup_domains = qw(cig.mot.com comm.mot.com ftw.mot.com);

check_env(qw(os_name os_ver domains));

#----------------------------------------------------------------------------


##
## Trap signals.  We must wait for child processes to finish or we'll
## encounter broken pipe errors.
##

# The following signals are not supported in the Windows OS, so we ignore
# them (HUP, BUS, XFSZ)
if ($OS_NAME !~ /Windows/) {
  # 1 controlling TTY gets hang-up
  $SIG{'HUP'}  = sub { trapsig(@_); };
  # 7 bus fault
  $SIG{'BUS'}  = sub { trapsig(@_); };  
  # 25 Excessive File Size limits reached
  $SIG{'XFSZ'} = sub { trapsig(@_); }; 
} # end if ($OS_NAME...

$SIG{'INT'}  = sub { trapsig(@_); };	# 2 Ctrl+C (Interrupt)
$SIG{'QUIT'} = sub { trapsig(@_); };	# 3 Quit key
$SIG{'SEGV'} = sub { trapsig(@_); };	# 11 Segmentation Fault
$SIG{'PIPE'} = sub { trapsig(@_); };	# 13 Broken Pipe
$SIG{'TERM'} = sub { trapsig(@_); };	# 15 Termination

#----------------------------------------------------------------------------


##
## Process command line arguments
##

# Catch any bad opts, which are passed in the __WARN__ signal
$SIG{'__WARN__'} = sub {
  if ($_[0] =~ /^Unknown option: (.*)/) {
    # We only want the bad arg
    my $bad_arg = $1;
    chomp($bad_arg);
    process_error('u', "Invalid argument (-$bad_arg) specified.\n");
  } else {
    # GetOptions cuts the - off the arg, so we add it back for clarity
    (my $bad_arg = $_[0]) =~ s/Option /Option -/;
    chomp($bad_arg);
    process_error('u', "$bad_arg");
  } # if ($_[0]...
}; # end sub {

my $rc = GetOptions(
           'print_test_sets' => sub { print("\nAvailable test sets: " .
                                            join(', ', @test_sets) . "\n\n");
				      push(@test_cases,'none')
                                },
           'test=s'  => \@test_cases,
           'help|Help|HELP|?'  => sub { print_usage(); exit($STATUS_OK) },
           'version' => sub { print("$tool version $tool_version\n"); 
			      exit($STATUS_OK)
                        },
           '<>'      => sub { process_error('u',
                                "Received bad argument: $_[0]")
                        },
         );

(!$rc) and process_error('x', 'Some failure other than bad option has '
  . "occurred during option processing.\n");

# Set the __WARN__ back to the default behavior
local $SIG{'__WARN__'} = 'DEFAULT';

# Process @test_cases to combine into properly formatted array.
@test_cases = split(/,/,join(',',@test_cases));

# end of processing command line arguments

#----------------------------------------------------------------------------


##
## Setup test sets
##

# Add all available tests if no specific tests were selected
if(scalar(@test_cases) == 0) {push(@test_cases, @test_sets); }

print(
  "\nExecuting test cases in the following test set(s): @test_cases\n\n");

#----------------------------------------------------------------------------


######################################
## Test SCM_common::process_error() ##
######################################

SKIP: {

# Currently, there are "16" test cases, so the "skip" call below says that
# if "process_error" test set wasn't selected, skip "16" test cases.
# Update this value when new test cases for this test set are added.
skip '"process_error" test set not selected',
  16 unless grep(/^process_error$/,@test_cases);

##
## Test cases 3 & 4 - Verify process_error('w','msg1') executes successfully
##

$test_rc = trap{
                process_error('w','msg1');
};

# Test case 3
cmp_ok($test_rc, '==', $STATUS_OK,  'process_error(\'w\') - return value Success');

# Test case 4
is($trap->stderr, "\n$tool - WARNING:\n\n  msg1\n\n",
   'process_error(\'w\') - proper message printed to STDERR');

# Cleanup - clear $test_rc
undef($test_rc);

## End Test cases 3 & 4


##
## Test cases 5 & 6 - Verify process_error('e',''msg2') executes successfully
##

$test_rc = trap{
                process_error('e','msg2');
};

# Test case 5
cmp_ok($test_rc, '==', $STATUS_OK,  'process_error(\'e\') - return value Success');

# Test case 6
is($trap->stderr, "\n$tool - \aERROR:\n\n  msg2\n\n",
   'process_error(\'e\') - proper message printed to STDERR');

# Cleanup - clear $test_rc
undef($test_rc);

## End Test cases 5 & 6


##
## Test cases 7 & 8 - Verify process_error('f','msg3') executes successfully
##

$test_rc = trap{
                process_error('f','msg3');
};

# Test case 7
cmp_ok($test_rc, '==', $STATUS_OK,  'process_error(\'f\') - return value Success');

# Test case 8
is($trap->stderr, "\n$tool - \aFAILED:\n\n  msg3\n\n",
   'process_error(\'f\') - proper message printed to STDERR');

# Cleanup - clear $test_rc
undef($test_rc);

## End Test cases 7 & 8


##
## Test cases 9 & 10 - Verify process_error('x','msg4') executes
## successfully
##

$test_rc = trap{
                process_error('x','msg4');
};

# Test case 9
cmp_ok($trap->exit, '==', $STATUS_ERROR,
   'process_error(\'x\') - returned exit value of 1');

# Test case 10
is($trap->stderr, "\n$tool - \aERROR:\n\n  msg4\n\n${support_msg}",
   'process_error(\'x\') - proper message printed to STDERR');

# Cleanup - clear $test_rc
undef($test_rc);

## End Test cases 9 & 10


##
## Test cases 11 & 12 - Verify process_error('mw','msg5',$user,
## 'msg5 subject') executes successfully
##

$test_rc = trap{
                process_error('mw','msg5',$USER,'msg5 subject');
};

# Test case 11
cmp_ok($test_rc, '==', $STATUS_OK, 
       'process_error(\'mw\') - return value Success');

# Test case 12
is($trap->stderr, "\n$tool - WARNING:\n\n  msg5\n\n",
   'process_error(\'mw\') - proper message printed to STDERR');

print("\nYou must now examine your email inbox to see if you"
      . " received an email WARNING for tool $tool.  Subject should"
      . " be \"msg5 subject\".  Body should be:\n\"$tool - \aWARNING"
      . ":\n\n  msg5\"\n\n");

# Cleanup - clear $test_rc
undef($test_rc);

## End Test cases 11 & 12


##
## Test cases 13 & 14 - Verify process_error('me','msg6',$user,
##   'msg6 subject')
## executes successfully
##

$test_rc = trap{
                process_error('me','msg6',$USER,'msg6 subject');
};

# Test case 13
cmp_ok($test_rc, '==', $STATUS_OK,  'process_error(\'me\') - return value Success');

# Test case 14
is($trap->stderr, "\n$tool - \aERROR:\n\n  msg6\n\n",
   'process_error(\'me\') - proper message printed to STDERR');

print("\nYou must now examine your email inbox to see if you"
      . " received an email ERROR for tool $tool.  Subject should"
      . " be \"msg6 subject\".  Body should be:\n\"$tool - \aERROR"
      . ":\n\n  msg6\"\n\n");

# Cleanup - clear $test_rc
undef($test_rc);

## End Test cases 13 & 14


##
## Test cases 15 & 16 - Verify process_error('mx','msg7',$user,
##   'msg7 subject')
## executes successfully
##

$test_rc = trap{
                process_error('mx','msg7',$USER,'msg7 subject');
};

# Test case 15
cmp_ok($trap->exit, '==', $STATUS_ERROR,
     'process_error(\'mx\') - returned exit value of 1');

# Test case 16
is($trap->stderr, "\n$tool - \aERROR:\n\n  msg7\n\n${support_msg}",
   'process_error(\'mx\') - proper message printed to STDERR');

print("\nYou must now examine your email inbox to see if you"
      . " received an email ERROR for tool $tool.  Subject should"
      . " be \"msg7 subject\".  Body should be:\n\"$tool - \aERROR"
      . ":\n\n  msg7\"\n\n");

# Cleanup - clear $test_rc
undef($test_rc);

## End Test cases 15 & 16


##
## Test cases 17 & 18 - Verify process_error with bad error type
## causes a tool failure.
##

$test_rc = trap{
                process_error("foo","msg8");
};

# Test case 17
cmp_ok($trap->exit, '==', $STATUS_ERROR,
     'process_error(\'foo\') - returned exit value of 1');

# Test case 18
my $temp_msg =  "\a  INTERNAL ERROR: Invalid error type\n                 "
  . "    \r  (foo) in function \"process_error\"\n\n";
  
is($trap->stderr, "\n$tool - ${temp_msg}${support_msg}",
   'process_error(\'foo\') - proper message printed to STDERR');

# Cleanup - clear $test_rc, $temp_msg
undef($test_rc);
undef($temp_msg);

## End Test cases 17 & 18

} # end SKIP

print("\n");

# End SCM_common::process_error test cases
 
#----------------------------------------------------------------------------


##########################################
## Test SCM_common::print_support_msg() ##
##########################################

SKIP: {

# Currently, there are "2" test cases, so the "skip" call below says that
# if "print_support_msg" test set wasn't selected, skip "2" test cases.
# Update this value when new test cases for this test set are added.
skip '"print_support_msg" test set not selected',
  2 unless grep(/^print_support_msg$/,@test_cases);

##
## Test cases 19 & 20 - Verify successful execution of print_support_msg
##

$test_rc = trap{
                print_support_msg();
};

# Test case 19
# We "expect" 1 here because the last print call should return undef for
# success.
cmp_ok($test_rc, '==', undef,
     'print_support_msg() - returned exit value of undef');

# Test case 20
my $temp_msg =
" +-----------------------------------------------------------+
 |  For help with this tool, contact the LTE SCM Team at     |
 |  cltescm\@motorola.com or refer to the LTE SCM Team web    |
 |  page: http://compass.mot.com/go/ltecm                    |
 +-----------------------------------------------------------+\n\n";
  
is($trap->stderr, $temp_msg,
     'print_support_msg() - proper message printed to STDERR');

# Cleanup - clear $test_rc
undef($test_rc);

## End Test cases 19 & 20

} # end SKIP

print("\n");

# End SCM_common::print_support_msg test cases

#----------------------------------------------------------------------------


########################################
## Test SCM_common::is_cc_installed() ##
########################################

SKIP: {

# Currently, there are "2" test cases, so the "skip" call below says that
# if "is_cc_installed" test set wasn't selected, skip "2" test cases.
# Update this value when new test cases for this test set are added.
skip '"is_cc_installed" test set not selected',
  2 unless grep(/^is_cc_installed$/,@test_cases);

##
## Test cases 21 & 22 - Verify successful execution of is_cc_installed
##

$test_rc = trap{
                is_cc_installed();
};

# Test case 21
# We "expect" 1 here for ClearCase installed.  Note: If you run this on a
# server that does not have ClearCase installed, you should expect failure.
cmp_ok($test_rc, '==', 1,
     'is_cc_installed() - returned exit value of 1');

# Warn the user that if is_cc_installed fails, ClearCase may not be
# installed.
if ($test_rc != 1) {
    diag('"is_cc_installed" can fail if ClearCase is not '
         . 'installed on the current server.');
    print("\n"); # diag() doesn't support "\n"
} # end if ($test_rc)

# Test case 22
# This may not be set if ClearCase was not installed 
like($cc_ver, qr/^(\d|\.)+$/, 'is_cc_installed() - $cc_ver set');

# Warn the user if $cc_ver is not set that ClearCase may not be installed.
if ($cc_ver eq "") {
    diag('"is_cc_installed" will not set $cc_ver if ClearCase is'
         . ' not installed on the current server.');
    print("\n"); # diag() doesn't support "\n"
} # end if ($cc_ver)

# Cleanup - clear $test_rc
undef($test_rc);

## End Test cases 21 & 22

} # end SKIP

print("\n");

# End SCM_common::is_cc_installed test cases

#----------------------------------------------------------------------------


#############################
## Test SCM_common::main() ##
#############################

SKIP: {

# Currently, there are "0" test cases, so the "skip" call below says that
# if "main" test set wasn't selected, skip "0" test cases.  Update this value
# when new test cases for this test set are added.
skip '"main" test set not selected', 0 unless grep(/^main$/,@test_cases);

  print("\nSCM_common::main cannot be tested at this time.\n\n");

} # end SKIP

# End SCM_common "main" test cases

#----------------------------------------------------------------------------


##################################
## Test SCM_common::daemonize() ##
##################################

SKIP: {

# Currently, there are "0" test cases, so the "skip" call below says that
# if "daemonize" test set wasn't selected, skip "0" test cases.  Update this
# value when new test cases for this test set are added.
skip '"daemonize" test set not selected',
  0 unless grep(/^daemonize$/,@test_cases);
  
  print("\nSCM_common::daemonize cannot be tested.\n\n");

} # end SKIP

# End SCM_common::daemonize test cases

#----------------------------------------------------------------------------


############################################
## Test SCM_common::default_create_view() ##
############################################

SKIP: {

# Currently, there are "0" test cases, so the "skip" call below says that
# if "default_creat_view" test set wasn't selected, skip "0" test cases.
# Update this value when new test cases for this test set are added.
skip '"default_create_view" test set not selected', 
  0 unless grep(/^default_create_view$/,@test_cases);
  
  print(
    "\nSCM_common::default_create_view cannot be tested at this time.\n\n");

} # end SKIP

# End SCM_common::default_create_view test cases

#----------------------------------------------------------------------------

#######################################
## Test SCM_common::write_to_script() #
#######################################

SKIP: {

# Currently, there are "0" test cases, so the "skip" call below says that
# if "write_to_script" test set wasn't selected, skip "0" test cases.
# Update this value when new test cases for this test set are added.
skip '"write_to_script" test set not selected', 
  0 unless grep(/^write_to_script$/,@test_cases);
  
  print(
    "\nSCM_common::write_to_script cannot be tested at this time.\n\n");

} # end SKIP

# End SCM_common::write_to_script test cases

#----------------------------------------------------------------------------

##
## NOTE: Exit value set by Test::More based on pass/fail of test cases.
##

#EOF
