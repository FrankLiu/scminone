package MY_CMBP;

########################################
# check environment variable
########################################

BEGIN {
   if (defined($ENV{LTE_BLDTOOLS})){
	   unshift @INC, "$ENV{LTE_BLDTOOLS}/../lib", "$ENV{LTE_BLDTOOLS}", "$ENV{LTE_BLDTOOLS}/enodeb";
   } elsif (defined($ENV{SCM_BLDTOOLS})) {
	   unshift @INC, "$ENV{SCM_BLDTOOLS}", "$ENV{SCM_BLDTOOLS}/..", "$ENV{SCM_BLDTOOLS}/../../lib";
   } else {
	   unshift @INC,"/vob/ltescm/bin","/vob/ltescm/lib","/vob/ltescm/bin/enodeb";
   }
}

####################
# import modules
####################

use CMBP_SQL_BUILDER;
use TOOLS;
use DBI;
use CGI qw( :standard );

use Data::Dumper;

####################
# global variables
####################
my $dbh;
my $cmbp_sql_builder;
my $tools;
my $debug=0;

####################
# functions
####################

sub getDBData($$);
sub getCRsData($);
sub getTargetedCR($);
sub getTargetedCRData($);
sub getBaselinesTree($);
sub getBaselinesData($);
sub getBaselinesForDevintCR($);
sub getBaselineData($);
sub getChildBaselinesData($);

sub isBaselineExist($);

sub parseArguments;
sub parseYes($);
sub CreateConnection();
sub EndConnection();

####################
# constructor
####################

sub new {
   my $this = shift @_;
   my $class = ref($this) || $this;

   my %initParams = @_;
   my $self = { %initParams };
   $debug = $ENV{'DB_DEBUG'};
   CreateConnection();

   $tools = new TOOLS();

   bless $self, $class;
   return $self;
}

sub DESTROY {
   print "Destructor body\n" if $debug;
   EndConnection();
}

sub CreateConnection()
{

# Connecting to CAMIS to use CQCM and/or EDW ? SP unknown at the time
   my $DSN = "DBI:Proxy:hostname=camis.mot.com;port=52180;dsn=DBI:CAMIS:MOTCM";
   $dbh = DBI->connect($DSN);
# Checking connection status and
# loading CAMIS runtime env if connection is OK.
   if (!$dbh || !$dbh->{private_camis_info}->{is_env}->{active}) {
      die("An error occurred while attempting to connect: $!\n");
   } else {
      eval $dbh->{proxy_dbh}->setup_camis();
      die("Error invoking setup_camis: ",$dbh->errstr," - $@ \n") if ($@);
   }
   $dbh->{'private_camis:srvProvider:0'} = 'MOTCM';
   $cmbp_sql_builder = new CMBP_SQL_BUILDER();
   return;

}
sub EndConnection() {
   $dbh->disconnect() if defined($dbh);
   print "Database Connection closed: $dbh\n" if $debug;
}


# this function is a internal one used by another function
# Takes:
# record type name -  (for example: CR, Baseline ) allowed values
#                 can be found in CMBP_SQL_BUILDER.pm  %sql_fields
# query param - reference to hash->{'keys'} - table of fileds name
#               hash->{'condition'} -table of hash with conditions
# INPUT EXAMPLE:
#$VAR1 = [
#          'CR',
#          {
#            'keys' => [
#                        'id',
#                        'Headline',
#                        'State',
#                        'BL_Actual_Target',
#                        'CR_branch',
#                        'CR_branch_state',
#                        'SR'
#                      ],
#            'conditions' => [
#                              {
#                                'condition' => ' = \'LTE-ENB_R1.0_BLD-1.01.01\'',
#                                'field' => 'BL_Actual_Target'
#                              },
#                              {
#                                'condition' => ' not like \'%DELETED%\'',
#                                'field' => 'CR_branch_state'
#                              },
#                              {
#                                'condition' => ' not like \'%OBSOLETED%\'',
#                                'field' => 'CR_branch_state'
#                              }
#                            ]
#          }
#        ];
sub getDBData($$)
{
   @_ = parseArguments(@_);

   print Dumper \@_ if $debug;
   my $table = shift @_;
   my $query_param = shift @_;

   my @result = ();
   my $sql;

   $cmbp_sql_builder->BuildSql($table,@{$query_param->{'keys'}});

   foreach $row (@{$query_param->{'conditions'}})
   {
      $sql = $cmbp_sql_builder->AddCondition($row->{'field'}, $row->{'condition'});
   }
   print "SQL: $sql\n" if $debug;
   my $sth = $dbh->prepare( $sql ) or die "STH creation faild: $DBI::errstr";
   my $rv = $sth->execute();
   my $tmp = {};

   if ($rv) {
      print " RV : $rv \n" if $debug;
      while (my $hRow = $sth->fetchrow_hashref()) {
         $tmp = {};
         foreach $key (@{$query_param->{'keys'}})
         {
            $tmp->{"$key"} = defined($hRow->{"$key"}) ? $hRow->{"$key"} : "";
         }
         push @result, $tmp;
      }
   } else {
      $tools->error("Connection to CQ failed with status:\n".$sth->errstr);
   }
   print Dumper \@result if $debug;
   return @result;
}

# return data for CR tageted to given baseline
sub getTargetedCRData($)
{
   @_ = parseArguments(@_);
   my $baseline;
   $baseline = shift @_;
   my @result = ();
   my $data = {};
   my @tmp_arr =  qw(id Headline CR_Usage State BL_Actual_Target CR_branch CR_branch_state SR);
   $data->{'keys'} = \@tmp_arr;
   my @conditions = ();
   my $tmp_hash = {};

   $tmp_hash->{'field'} = "BL_Actual_Target";
   $tmp_hash->{'condition'} = " = \'$baseline\'";
   push @conditions, $tmp_hash;

   $tmp_hash = {};
   $tmp_hash->{'field'} = "CR_branch_state";
   $tmp_hash->{'condition'} = " not like \'\%DELETED\%\'";
   push @conditions, $tmp_hash;

   $tmp_hash = {};
   $tmp_hash->{'field'} = "CR_branch_state";
   $tmp_hash->{'condition'} = " not like \'\%OBSOLETED\%\'";
   push @conditions, $tmp_hash;

   $data->{'conditions'} = \@conditions;

   @result = getDBData("CR",$data);
   return @result;
}

# function is invoking in BL_report in INITIAL.pm
sub getTargetedCR($)
{
    @_ = parseArguments(@_);

    my $baseline;

    $baseline = shift @_;

    my @result = ();
    my $found = 0;

    $cmbp_sql_builder->BuildSql("Baseline",qw(Identifier NameSpace Product_Family_Name Targeted_CRs));
    my $sql = $cmbp_sql_builder->AddCondition("Identifier", "= \'$baseline\'");

    print "Get Targeted CR SQL\n$sql\n" if $debug;
    my $sth = $dbh->prepare( $sql ) or die "STH creation faild: $DBI::errstr";
    my $rv = $sth->execute();

     if ($rv ) {
        while (my $hRow = $sth->fetchrow_hashref()) {
            if ((defined $hRow->{Targeted_CRs}) && ($hRow->{Targeted_CRs}=~ /MOTCM\d+/)) {
                $found = 1;
                push @result, "\n$hRow->{Targeted_CRs}";
            }
        }
        if (!$found) {
            push @result, "NONE";
        }
    }  else {
        $tools->error("Connection to CQ failed with status:\n".$sth->errstr);
        raiseCQError($sth->errstr);
    }

    print "Get Targeted CR\n@result\n" if $debug;
    return @result;
}

sub getCRsData($){
   @_ = parseArguments(@_);
   my @keys =
      ('id',
       'Headline',
       'BL_Actual_Target',
       'State',
       'Technical_Authority',
      );

   my @result=();
#my %row;
   my $sql = "";
   my $condition = "";
   my $hRow;
   my $cnt = 0;

   $cmbp_sql_builder->BuildSql("Development_CR",@keys);

# prepare condition:
# 1. traslate condition to SQL
# 2. next conect it to sql query

   foreach my $CR(@_) {
      print "CR = $CR \n" if $debug;
      if ($cnt) {
         $condition = $condition . " or ";
      }else{
         $cnt = 1;
      }
      $condition = $cmbp_sql_builder->TranslateCondition("id", " = \'$CR\'",$condition);
      print "condition = $condition\n" if $debug;
   }

   $sql = $cmbp_sql_builder->ConnectCondition($condition, "and");
   print "\n\n\nSQL === $sql\n\n\n" if $debug;
   my $sth = $dbh->prepare( $sql );
   my $rv = $sth->execute();

   if (!$rv) {
      return (raiseCQError($sth->errstr)); # -1
   }
   while ($hRow = $sth->fetchrow_hashref())    {
      if (defined($hRow->{id}) && $hRow->{id} =~ /MOTCM\d+/) {
         push @result, $hRow;
      }
   }

   $sth->finish();
   return @result;

}
sub getChildBaselinesData($)
{
   @_ = parseArguments(@_);
   my $baseline;
   $baseline = shift @_;
   my @result = ();

   print "getChildBaselinesData Baseline: $baseline\n" if $debug;

   my $data = {};

   my @tmp_arr =  qw(Identifier Org_CR Parent_BLs Baseline_Type Status Predecessor_BL);
   $data->{'keys'} = \@tmp_arr;
   my @conditions = ();

   my $tmp_hash = {};
   $tmp_hash->{'field'} = "Parent_BLs";
   $tmp_hash->{'condition'} = " = \'$baseline\'";
   push @conditions, $tmp_hash;

   $data->{'conditions'} = \@conditions;

   @result = getDBData("Baseline",$data);
   return @result;
}

sub getBaselinesTree($)
{
   @_ = parseArguments(@_);
   my $baseline = shift @_;
   my $bl_kind = shift @_;
   my $data = {};
   my @BLs = ();
   
   my @tmp_arr =  qw(Identifier Org_CR Baseline_Type Status Predecessor_BL);
   $data->{'keys'} = \@tmp_arr;
   my @conditions = ();

   my $tmp_hash = {};
   $tmp_hash->{'field'} = "Identifier";
   $tmp_hash->{'condition'} = " = \'$baseline\'";
   push @conditions, $tmp_hash;

   $data->{'conditions'} = \@conditions;

   my @result = getDBData("Baseline",$data);

   my $tmp = {};
   if(!defined($result[0]) || ($result[0]->{Identifier} ne "$baseline"))
   {
      $tools->error("Could not find $baseline in database");
      exit;
   }
   else
   {
      $tmp->{Identifier} = $result[0]->{Identifier};
      $tmp->{Status} = $result[0]->{Status};
      $tmp->{Predecessor_BL} = $result[0]->{Predecessor_BL};
      $tmp->{Baseline_Type} = $result[0]->{Baseline_Type};
      $tmp->{Org_CR} = $result[0]->{Org_CR};
      $tmp->{Parent_BLs} = "Main Baseline";
   }

   push @BLs, $tmp;

#get Baseline content (child baselines and CR targeted to those baselines)
   my $index = 0;
   my $arr_size = 1;
   while($index < $arr_size)
   {
      my @result = getBLs($BLs[$index]);
      foreach my $row (@result)
      {
         push @BLs, $row;
         $arr_size++;
      }
      $index++;
      return @BLs if (defined $bl_kind and $bl_kind eq 'REL');
   }
   return @BLs;
}

sub getBLs(@){   
   @_ = parseArguments(@_);
   my $BL = shift @_;
  
   my @result = ();
  
   print "baseline= $BL->{Identifier} is $BL->{Baseline_Type} \n " if $debug;

   if(!($BL->{Baseline_Type} =~ /Dev-Build/) and
         !($BL->{Baseline_Type} =~ /Int-Build/) and
         !($BL->{Baseline_Type} =~ /SCM-Build/)and
         !($BL->{Baseline_Type} =~ /Patch-Build/)
         )
   {
      print "baseline= $BL->{Identifier} is $BL->{Baseline_Type} \n " if $debug;
      return;
   }
   my $baseline = $BL->{Identifier};

   @result = getChildBaselinesData($baseline);
   return @result;
}

sub getBaselinesForDevintCRs($){
   @_ = parseArguments(@_);
   my $Devint_CR = shift @_;
   my @keys =
      ('Identifier',
       'Org_CR',
       'Status',
       'Parent_BLs'
      );

   my @result=();
   my $sql = "";
   my $condition = "";
   my $hRow;
   my $cnt = 0;

   $cmbp_sql_builder->BuildSql("Baseline",@keys);

# prepare condition:
# 1. traslate condition to SQL
# 2. next conect it to sql query

   print "Baseline Org_CR = $Devint_CR \n";
   $condition = $cmbp_sql_builder->TranslateCondition("Org_CR", " =
         \'$Devint_CR\'","");

   $sql = $cmbp_sql_builder->ConnectCondition($condition, "and");
   print "\n\n\nSQL === $sql\n\n\n";
   my $sth = $dbh->prepare( $sql );
   my $rv = $sth->execute();

   if (!$rv) {
      return (raiseCQError($sth->errstr)); # -1
   }
   while ($hRow = $sth->fetchrow_hashref())    {
      if (defined($hRow->{Identifier})) {
         push @result, $hRow;
      }
   }
   $sth->finish();
   print Dumper @result;
   return @result;

}
sub getBaselinesData($){
   @_ = parseArguments(@_);
   my @keys =
      ('Identifier',
       'Status',
       'Predecessor_BL',
       'Child_BLs'
      );

   my @result=();
   my $sql = "";
   my $condition = "";
   my $hRow;
   my $cnt = 0;

   $cmbp_sql_builder->BuildSql("Baseline",@keys);

# prepare condition:
# 1. traslate condition to SQL
# 2. next conect it to sql query

   foreach my $Baseline(@_) {
      print "Baseline Identifier = $Baseline \n" if $debug;
      if ($cnt) {
         $condition = $condition . " or ";
      }else{
         $cnt = 1;
      }
      $condition = $cmbp_sql_builder->TranslateCondition("Identifier", " =
            \'$Baseline\'",$condition);
   }

   $sql = $cmbp_sql_builder->ConnectCondition($condition, "and");
   $condition = $cmbp_sql_builder->TranslateCondition("Identifier", "","");
   $sql = $cmbp_sql_builder->ConnectCondition($condition, " order by ");
   print "\n\n\nSQL === $sql\n\n\n" if $debug;
   my $sth = $dbh->prepare( $sql );
   my $rv = $sth->execute();

   if (!$rv) {
      return (raiseCQError($sth->errstr)); # -1
   }
   while ($hRow = $sth->fetchrow_hashref())    {
      if (defined($hRow->{Identifier})) {
         push @result, $hRow;
      }
   }

   $sth->finish();
   return @result;

}
sub getBaselineData($)
{
   @_ = parseArguments(@_);
   my $baseline = shift @_;
   
   my $data = {};

   my @tmp_arr =  qw(Identifier Baseline_Type Status Predecessor_BL);
   $data->{'keys'} = \@tmp_arr;
   my @conditions = ();

   my $tmp_hash = {};
   $tmp_hash->{'field'} = "Identifier";
   $tmp_hash->{'condition'} = " = \'$baseline\'";
   push @conditions, $tmp_hash;

   $data->{'conditions'} = \@conditions;

   my @result = getDBData("Baseline",$data);
   my $tmp = {};
   if(!defined($result[0]) || ($result[0]->{Identifier} ne "$baseline"))
   {
      $tools->error("Could not find $baseline in database");
      return;
   }
   return @result;
}

sub isBaselineExist($)
{   
   @_ = parseArguments(@_);
   my $baseline;
   $baseline = shift @_;

   my @result = ();
   my $data = {};

   my @tmp_arr =  qw(Identifier);
   $data->{'keys'} = \@tmp_arr;
   my @conditions = ();
   
   my $tmp_hash = {};

   $tmp_hash->{'field'} = "Identifier";
   $tmp_hash->{'condition'} = " = \'$baseline\'";
   push @conditions, $tmp_hash;
   
   $data->{'conditions'} = \@conditions;
   @result = getDBData("Baseline",$data);
   if(defined($result[0]) && ($result[0]->{'Identifier'} eq "$baseline"))
   {
      return 1;
   }
   else
   {
      return 0;
   }
}
####################
# inner functions
####################
sub parseArguments
{
   if (defined(@_)) {
      shift @_ if ( $_[0] =~ /MY_CMBP=HASH/);
   }

   return @_;
}

sub parseYes($)
{
   return 1 if ($_[0] eq 'yes');
   return 0;
}
return 'true';
