#!/apps/public/perl_5.8.4/bin/perl
#############################################################################
#
#       Copyright (C) 2010 MOTOROLA. All Rights Reserved.
#
#       The copyright notice above does not evidence any
#       actual or intended publication of such source code.
#       The code contains Motorola Confidential Restricted Information.
#
#############################################################################
#
#  FILE NAME:    BUILD_ENV.pm
#
#  OWNER:        LTE SCM Team
#
#  DATE CREATED: 01/25/2010
#
#  SYNOPSIS:     None.
#
#  EXIT VALUE:   1; - Mandatory for module to load successfully
#
#  DESCRIPTION:  This Perl module contains functions and variables used
#                for this specific component of the build automation.
#
#############################################################################
#
#  MODIFICATION HISTORY:
#
# Ver    Date     Engineer     CR                     Change
# --- ---------- ---------- --------  ---------------------------------------
# 1.0 06/30/2010 skerr1     01336346  Created initial version.
#
#############################################################################
#
#  FUNCTIONS:  (Alphabetical)
#
#	Local
#	-----
#	new			- Create and return new BUILD_ENV object.
#	close_build		- Create build report and send release email.
#	valid_env		- Validate the build environment.
#
#############################################################################

## DEVELOPMENT NOTES:
#  -----------------
# 1. Any variables global to this package must be declared within the 'our'
#    directive because of the 'strict' pragma.

## CHECKLIST WHEN UPDATING THIS MODULE:
#  -----------------------------------
# 1. Update @EXPORT if created a function or variable to be exported.
# 2. Update 'our' if added a global variable to this module or if a variable
#    needs to be exported. 
# 3. Update the "FUNCTIONS" list in the prologue.
# 4. Update the "MODIFICATION HISTORY" in the prologue.
# 5. Turn Perl diagnostics (use diagnostics;) and strict (use strict;) off
#    before valid_env.

# Used as error checking mechanism: does not allow re-declaration of
# the same variable within the same scope.  For testing purposes only.
# Note: We do not check for strict references in order to access globals from
#       the calling package.
#use strict qw(vars subs);
#use diagnostics;

# Indicates that the entire library's symbol table or namespace is labeled
# as <package>  The compiler will look for any undefined symbols, in the
# calling program, in this package.
package BUILD_ENV;

use 5.8.4;	# Use Perl 5.8.4 or higher (also for debugging purposes)

use Data::Dumper;  # Used for dumping data structures

# Used to setup export methods into calling programs.  Allows the use of
# import(), @ISA, @EXPORT, etc., which allows for different ways of exporting
# symbols.
require Exporter;

# Standard global symbols
our (@ISA, @EXPORT);

# Search location for unresolved functions in the current package.
# The search is left to right.
# Exporter is included here because of the import() function.
@ISA = qw(Exporter);

# List of symbols to be exported by :DEFAULT.
# List functions first, then all other symbols.
@EXPORT	  =  qw(new
                close_build
                valid_env
                
               );

# Package global variables (some are imported from the calling namespace).
our    ($stepsToModules,
        $objectsRef,
        $buildVer,
        $cp,
        $createView,
        $ct,
        $DOMAIN,
        $httpReleaseLoc,
        $lapTime,
        $logsDir,
        $MACHINE,
        $maillist,
        $CC_METRICS_FH,
        $plcode,
        $product,
        $release,
        $releaseDir,
        $scmEmail,
        $scriptDir,
        $STATUS_ERROR,
        $STATUS_OK,
        $system,
        $teamEmail,
        $timeStamp,
        $TIME_STAMP,
        $tool,
        $tool_version,
        $USER,
        $VIEWNAME,
       );

#============================================================================
#=====================  Exported Variable Initialization  ===================
#============================================================================
#
# Do not use the 'my' directive for those definitions we are using the 'our'
# directive for above.
#

## Do not touch the following block of code ##
# Sets the name of the calling package (tool)
my $pkg   = (caller)[0];		# Calling package name

# Import exported variables from calling package (tool)
$pkg->import;

 
#============================================================================
#==============================  FUNCTIONS  =================================
#============================================================================

#----------------------------------------------------------------------------
#                              Function: new
#----------------------------------------------------------------------------
# Description:
#	Constructor for CC.
#
# Argument(s):
#	$this		- class name
#	$self		- hash ref initially containning config data
#	$debug		- Debug true or false
#
# Return value:
#	Failure: Function returns hash reference
#       Success: requested object reference
#
# Pre condition(s):
#	None.
#
# Post condition(s):
#	None.
#
sub new {
   my ($this, $self, $debug) = @_;
   my $class = ref($this) || $this;

   $self->{'dbg'} = $debug;
   $self->{'return_code'} = 0;
   
   ($self->{'dbg'}) and print Dumper $self;
   
   return bless $self, $class;
} # end new()

#----------------------------------------------------------------------------
#                             Function: close_build
#----------------------------------------------------------------------------
# Description:
#	Create build report and send release email.
#
# Argument(s):
#	N/A
#
# Return value:
#	Failure: Exit process with non-zero value
#       Success: Return 0
#
# Pre condition(s):
#	Your team uses CQCM
#	scstart executed
#
# Post condition(s):
#	build report created
#	release email sent
#
## MAIN
# Generate the build report via lte_bld_report.pl
# Generate and send the build email

sub close_build {

    my ($self) = @_;
    
    # Setup local vars for readabilty
    my $curStep     = 'rel_build';  # Current build step
    my $debug       = $self->{'dbg'};
    my $envVars     = $self->{'envVars'};
    my $initial     = $objectsRef->{'INITIAL'};
    my $logging     = $self->{'logging'};
    my $prev_build  = $objectsRef->{'COMMON'}->{'LTE_PREV_LBL_NAME'};
    my $return_code = $self->{'return_code'};
    my $rc          = 0;        # Temp return code
    my $startDir    = $self->{'startDir'};
    my $prod        = lc($product);

    
#----------------------------------------------------------------------------


    ($debug) and print Dumper $self;

    # Change to the desired start directory
    if (defined($startDir) and $startDir) {
      chdir($startDir) or process_error('x', "Could not change directory " .
        "to $startDir");
    } # end if (defined...

    ($logging) and
      print_and_log($plcode, "($tool) Changed to directory $startDir.\n");
    
    ($debug) and print Dumper $self;

    # Set environment vars
    if (scalar(keys(%$envVars)) > 0) {
      foreach my $k (sort keys %$envVars) {
        $ENV{"$k"}=$envVars->{"$k"};
      } # end foreach...
    } # end if (scalar(keys...
    
    ($logging) and
      print_and_log($plcode,
      	"($tool) Set requested environment variables.\n");

    ($debug) and print Dumper $self;


    ## Setup the build report
    # First get the view
    my $branch = $VIEWNAME;
    if ($branch =~ m/_REL-/) {
      $branch = "${system}_${release}-main";
      $branch = lc($branch);
    } # end if ($branch...
    
    # Setup the build report command
    my $cmd = "/vob/ltescm/bin/lte_bld_report.pl -prod ${system}-${product}"
            . " -bl $buildVer -pred $prev_build -br $branch";

    exec_cmd('x', $cmd, "Could not create the build report!");

    ($logging) and
      print_and_log($plcode,
      	"($tool) Build report generated successfully!\n");


    ## Setup the release email
    
    my $emailBody = <<EOB;
Build ${buildVer} is labeled and available for use.

Build information page for this build (punch list, release notes and/or other information):
http://lte.comm.mot.com/scm/cgi-bin/ltebuildinfo.pl?getByLabel=${buildVer}

Build artifacts are located at:
$httpReleaseLoc

EMS bundle (if requested) is located at:
$httpReleaseLoc/ems/${buildVer}.tar

Build Report: 
$httpReleaseLoc/${buildVer}.mail

Config spec:
$httpReleaseLoc/logs/${buildVer}_cs.wri
  
---------------------------------------- 
LTE SCM - $scmEmail 
  
EOB

    # First remove the mail file if it already exists
    if (-f "$releaseDir/${buildVer}.mail") {
      unlink("$releaseDir/${buildVer}.mail") or process_error('mw',
        "Could not remove existing $releaseDir/${buildVer}.mail file!",
        $maillist, "$buildVer: Could not remove ${buildVer}.mail file");      
    } # end if (-f...
    
    # Now create the mail file
    `echo "$emailBody" > $releaseDir/${buildVer}.mail` and process_error('mw',
        "Could not create $releaseDir/${buildVer}.mail file: $!",
        $maillist, "$buildVer: Could not create ${buildVer}.mail file");

    send_email_update("$emailBody\n",
      "${buildVer}: Build Announcement for ${buildVer}",$teamEmail);

    return $return_code;

} # end sub close_build

#----------------------------------------------------------------------------
#                           Function: valid_env
#----------------------------------------------------------------------------
# Description:
#	Validate the build environment.
#
# Argument(s):
#	N/A
#
# Return value:
#	Failure: Exit process with non-zero value
#       Success: Return 0
#
# Pre condition(s):
#	N/A
#
# Post condition(s):
#	N/A
#
## MAIN
# cd to start directory
# set environment variables
# check for sufficient FA space via gdf
# check for sufficient View space via myquota

sub valid_env {

    my ($self, @branchesToMerge) = @_;
    
    # Setup local vars for readabilty
    my $buildSize   = $self->{'buildSize'};
    my $curStep     = 'valid_env';  # Current build step
    my $debug       = $self->{'dbg'};
    my $envVars     = $self->{'envVars'};
    my $initial     = $objectsRef->{'INITIAL'};
    my $logging     = $self->{'logging'};
    my $rc          = 0;            # Temp return code
    my $return_code = $self->{'return_code'};
    my $startDir    = $self->{'startDir'};
    my $availableFA = 0;	    # Available FA space in MB
    my $availableVSpc = 0;	    # Available View space in MB
    my $usedVSpc    = 0;	    # Used View Space
    my $viewHrdQta  = 0;	    # View Hard Quota
    
#----------------------------------------------------------------------------


    ($debug) and print Dumper $self;

    # Change to the desired start directory
    if (defined($startDir) and $startDir) {
      chdir($startDir) or process_error('x', "Could not change directory " .
        "to $startDir");
    } # end if (defined...

    ($logging) and
      print_and_log($plcode,
      	"($tool) Changed to directory $startDir.\n");
    
    ($debug) and print Dumper $self;

    # Set environment vars
    if (scalar(keys(%$envVars)) > 0) {
      foreach my $k (sort keys %$envVars) {
        $ENV{"$k"}=$envVars->{"$k"};
      } # end foreach...
    } # end if (scalar(keys...
    
    ($logging) and
      print_and_log($plcode,
      	"($tool) Set requested environment variables.\n");

    ($debug) and print Dumper $self;

    ($logging) and
      print_and_log($plcode, "($tool) Build size for this build type is " .
                             "$buildSize MB.\n");

    ## Check disk space
    # Get the current usage in $releaseDir and check to see if there is
    # enough space for the size identified by build type module.
    # /apps/public/bin/gdf (GNU df) works on Solaris and Linux
    open(my $DF, '-|', "/apps/public/bin/gdf -P -B 1M $releaseDir") or
    	process_error("Failed to open process handle \$DF: $!");
    
    # Process the gdf output. Get the available space (3rd # param on 2nd
    # line of gdf output).
    foreach my $line (<$DF>) {
    	if ($line =~ m/\S+\s+\d+\s+\d+\s+(\d+)\s+.*/) {
    	  $availableFA = $1;
    	} # end if ($line...
    } # end foreach my...

    close($DF);
    
    # Capture the return status from the program and not the shell.
    # Exit value of the subprocess is in the high byte, $? >> 8.
    # The low byte says which signal the process died from, $?.
    $rc = ($? >> 8);
    ($rc) and process_error('x', "GNU df (gdf) execution failed: $!");

    # Check to see if the user build type module provided size is not bigger
    # than the available disk space for the $releaseDir.
    ($buildSize > $availableFA) and process_error('mx', 'There is ' .
      "insufficient disk space ($availableFA MB) for this build, which " .
      "requires $buildSize MB", $maillist, "$buildVer: Insufficient FA " .
      "space for build.");
      
    ($logging) and
      print_and_log($plcode, "($tool) There is sufficient disk space " .
                             "($availableFA MB) for this build.\n");
    
       
    ($debug) and print Dumper $self;

    ## Check view quota
    # Get the current view space usage and hard quota.  Current space used +
    # $buildSize must be less than $viewHrdQta. 
    open(my $MQ, '-|', '/apps/internal/bin/myquota view') or
    	process_error("Failed to open process handle \$MQ: $!");
    
    # Process the myquota output. Get the used space ($1) and hard quota ($2).
    foreach my $line (<$MQ>) {
    	if ($line =~ m/^\s+(\d+)\s+\d+\s+(\d+)\s+.*/) {
    	  $usedVSpc   = ($1/1024);	# It's in K so / 1024 to get MB
    	  $viewHrdQta = ($2/1024);	# It's in K so / 1024 to get MB
    	  $availableVSpc = int ($viewHrdQta - $usedVSpc);
    	} # end if ($line...
    } # end foreach my...

    close($MQ);
    
    # Capture the return status from the program and not the shell.
    # Exit value of the subprocess is in the high byte, $? >> 8.
    # The low byte says which signal the process died from, $?.
    $rc = ($? >> 8);
    ($rc) and process_error('x', "myquota execution failed: $!");

    # Error if the current used View space + 2*$buildSize is > $viewHrdQta.
    # than the available disk space for the $releaseDir.
    (($usedVSpc+(2*$buildSize)) > $viewHrdQta) and process_error('mx', 'There is ' .
      "insufficient View space ($availableVSpc MB) for this build, which " .
      "requires $buildSize MB", $maillist, "$buildVer: Insufficient View " .
      "space for build.");
     
    ($logging) and
      print_and_log($plcode, "($tool) There is sufficient View space " .
                             "($availableVSpc MB) for this build.\n");
    
    return $return_code;
    
} # end sub valid_env


1;

# EOF
