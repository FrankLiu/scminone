package INITIAL;

#############################################################################
#
#                     Copyright (c) 2007 Motorola, Inc.
#                     Motorola Confidential Proprietary
#
#############################################################################

########################################
# check environment variable
########################################


BEGIN {
   if (defined($ENV{LTE_BLDTOOLS})){
	   unshift @INC, "$ENV{LTE_BLDTOOLS}/../lib", "$ENV{LTE_BLDTOOLS}", "$ENV{LTE_BLDTOOLS}/enodeb";
   } elsif (defined($ENV{SCM_BLDTOOLS})) {
	   unshift @INC, "$ENV{SCM_BLDTOOLS}", "$ENV{SCM_BLDTOOLS}/..", "$ENV{SCM_BLDTOOLS}/../../lib";
   } else {
	   unshift @INC,"/vob/ltescm/bin","/vob/ltescm/lib","/vob/ltescm/bin/enodeb";
   }
}

####################
# import modules
####################
#use strict;
use Getopt::Long;
use File::Basename;
use Data::Dumper;
use TOOLS;
use LTE_BLD_CONF;

####################
# functions declarations
####################
sub usage($);
sub get_request();
sub parse_request($$);
sub print_request($);
sub create_CRs_BRs($$$);
sub create_BRs_to_merge();
sub parse_req_data($);
sub parse_baseline($);
sub create_lte_env($$$$$);

####################
# globals
####################
#my $self = {
#	'BASELINE'     => "",
#	'baseline'     => "",
#	'view'         => "",
#	'branch'       => "",
#	'release'      => "",
#	'rel_line'     => "",
#	'build_kind'   => "",
#	'build_number' => ""
#	};
my $tools = new TOOLS();
my $debug = 0;

###################
# constructor
####################

sub new
{
	my $this = shift @_;
	my $class = ref($this) || $this;
	my $baseline = shift @_;
	my $reqFile = shift @_;
	my $system = shift @_;
	my $self = {};
   $self->{'system'} = $system;
   $self->{'build_kind'} = undef;
	$self->{'request'} = [];
	$self->{'CRs'} = {};
	$self->{'BRs'} = {};
	$self->{'BRs_TO_MERGE'} = {};
	$self->{'CRs_ALL'} = {};
	$self->{'BLs_EXT'} = {};
	$self->{'BLs_CHILD'} = {};
	$debug = $ENV{'DEBUG'} if (defined $ENV{'DEBUG'});
	bless $self, $class;
	$self->parse_baseline($baseline);
	bless $self, $class;
	$self->parse_req_data($reqFile) if (defined $reqFile);
	bless $self, $class;
	return $self;
}

#############################################################################
# Function for parsing lte baseline.
#############################################################################
sub parse_baseline($)
{
#  @_ = parseArguments(@_);
  my $self = shift;
  my $baseline = shift@_;

  $baseline =~ tr/A-Z/a-z/;
  ($self->{'BASELINE'} = $baseline) =~ tr/a-z/A-Z/;
  ($self->{'baseline'} = $baseline) =~ tr/A-Z/a-z/;

# for label: LTE-ENB_R1.0_BLD-2.01.02 
# baseline:  lte-enb_r1.0_bld-2.01.02  
# release: r1.0
# rel_line: LTE_ENB_R1.0
# build kind: BLD
# build number: 2.01.02
# branch: lte-enb_r1.0_bld-2.01
# view: lte-enb_r1.0_bld-2.01   
  if ($baseline =~ /^(.+)?-(.+)?_(.+)?_(.+)?-([0-9]+)?\.([0-9]+)?\.([0-9]+)?/) {
    $self->{'release'} = $3;
    ($self->{'rel_line'} = $self->{'system'}."-$2_$3") =~ tr/a-z/A-Z/;
    ($self->{'build_kind'} = $4) =~ tr/a-z/A-Z/;
    $self->{'build_number'} = "$5.$6.$7";
    $self->{'branch'} = "$1-$2_".$self->{'release'}."_$4-$5.$6";
    $self->{'view'} = $self->{'branch'};
  } 
  
# for label: LTE-ENB_R1.0_REL-2.01 
# release: r1.0
# rel_line: LTE-ENB_R1.0
# build kind: REL
# build number: 2.01
# branch: lte-enb_r1.0-main
# view: lte-enb_r1.0_rel-2.01     
  elsif ($baseline =~ /^(.+)?-(.+)?_(.+)?_rel-([0-9]+)?\.([0-9]+)?/) {
    $self->{'release'} = $3;
    ($self->{'rel_line'} = $self->{'system'}."-$2_$3") =~ tr/a-z/A-Z/;
    $self->{'build_kind'} = "REL";
    $self->{'build_number'} = "$4.$5";
    ($self->{'branch'} = $baseline )= "$1-$2_$3-main" ;
    $self->{'view'} = $baseline;
  } 
# for label: MOTOAGT_CMT_R2.0_BLD-08
# release: r2.0
# rel_line: <$system>_CMT_R2.0
# build kind: devint
  elsif ($baseline =~ /^([^-]+)-([^_]+)_(r\d+\.\d+)_(bld|devint|int|rel)-.*/){
    $self->{'release'} = $3;
    ($self->{'rel_line'} = $self->{'system'}."-$2_$3") =~ tr/a-z/A-Z/;
    ($self->{'build_kind'} = $4) =~ tr/a-z/A-Z/;
  }else {
    print "WARNING: Unable to parse baseline $baseline!\n\n";
  }
  print "INITIAL.pm\n";
  print Dumper $self if $debug;
}


#############################################################################
# Function for parsing LTE build request
#############################################################################
sub parse_request($$)
{
#  @_ = parseArguments(@_);
    my $self = shift;
  my $request = shift@_;
  my $request_file = shift@_;
  my $pwd = `pwd`; 
  chomp($pwd);
  
  my $product;
  ($product = $self->{'rel_line'}) =~ s/_(.+)?$//;
  $product  =~ tr/a-z/A-Z/;
  my $rel = $self->{'release'};
  $rel  =~ tr/a-z/A-Z/;
  print "prod $product BL $self->{'BASELINE'} rel $rel\n " if $debug;

  my $config = new LTE_BLD_CONF($product,$self->{'BASELINE'},$rel ,$debug);
  $request_file = $pwd."/request_".$self->{'baseline'}.".txt" if (!defined $request_file);

  my $request_line;
  my $ext = 0;
  my $sub = 0;


 print "Request will be stored in $request_file\n" if $debug;
 if(-e $request_file){
    print "File request $request_file already exits and will be used.\nIf you want to regenerate this file please remove it\n";
 } else {
    my $cmd = "wget \'".$config->{'build_req_path'}. $self->{'BASELINE'}.
       "&TextVersion=yes\' -O $request_file";
    print  "cmd $cmd\n" if $debug;
    system ($cmd);
 }
 my $is_req_exists =  `grep \"Unable to display\" $request_file`;

 if($is_req_exists =~ /(.+Unable to display.+)/)
 {
    print "Request for Build:$self->{'BASELINE'} doesn't exist or is not locked\n";
    return 1;
 }
 else
 {
    print "Request for Build:$self->{'BASELINE'} exists \n";
 }

 if ($self->{'build_kind'} eq 'REL') {
    print "REL build\n";
 } 
 print "read REQ File: $request_file \n" if $debug;
 open (REQUEST_FILE, $request_file) or print "Can't open request file: $request_file\n";
 foreach my $line (<REQUEST_FILE>) {
    chomp($line);
    $line =~ tr/\x0a\x0d//d;
    if ($line =~ /\*\*\* EXT SUB_BASELINE \*\*\*/) {
       $ext = 1;
       next;
    } elsif ($line =~ /\*\*\* SUB_BASELINE \*\*\*/) {
       $sub = 1;
       next;
    } elsif ($line =~ /^(.*?);(.*?);(.*?);(.*?);(.*?);(.*?);(.*?);(.*?);(.*?);(.*?);(.*?);(.*?);$/) {
       $request_line = {
          'Baseline' => $tools->trim($1),
          'Branch' => $tools->trim($2),
          'SR' => $tools->trim($3),
          'Area' => $tools->trim($4),
          'State' => $tools->trim($5),
          'Inspection' => $tools->trim($6),
          'SR_type' => $tools->trim($7),
          'Feature' => $tools->trim($8),
          'Load_accepted' => $tools->trim($9),
          'Load_target' => $tools->trim($10),
          'Headline' => $tools->trim($11),
#        'Note' => $tools->trim($12),
          'TA' => $tools->trim($12),
       };
       if ($ext) {$request_line->{'SR'}='EXT'; $ext = 0;};
       if ($sub) {
          $request_line->{'SR'}='SUB'; 
          if ($self->{'build_kind'} eq 'REL') {
             push @{$request},$request_line;
             return 0;
          }
          $sub = 0;
       };
       push @{$request},$request_line;
    }
 }
 return 0;
}

#############################################################################
# Function for printing LTE build request from int table
#############################################################################
sub print_request($)
{
#  @_ = parseArguments(@_);
    my $self = shift;
  my $request = shift@_;
  my %request_line;

#  print Dumper $request;
  foreach my $i (0 .. $#{@{$request}}) {
    print "RECORD: $i\n";
    foreach my $attr (keys %{${@{$request}}[$i]}) {
      print "--$attr $request->[$i]->{$attr}\n";
    }
  }


}

#############################################################################
#############################################################################
# Function for parsing request. Fill up internal structure with parsed req. data 
#############################################################################
sub parse_req_data($)
{
    my $self = shift;
    my $req_file = shift @_;

    $self->parse_request($self->{'request'}, $req_file);
    $self->create_CRs_BRs( $self->{'request'}, $self->{'CRs'}, $self->{'BRs'});
    $self->create_BRs_to_merge( $self->{'request'},$self->{'BRs_TO_MERGE'}, $self->{'BLs_EXT'}, 
           $self->{'BLs_CHILD'},  $self->{'CRs_ALL'});
    return;
}
#############################################################################
# Function for parsing request. Returns hash CRs CR => branch
#############################################################################
sub create_CRs_BRs($$$)
{
#  @_ = parseArguments(@_);
    my $self = shift;
  my $request = shift@_;
#  my $baseline = shift@_;
  my $CRs = shift@_;
  my $BRs = shift@_;

 if ($self->{'build_kind'} eq 'REL') {
   (my $tmp_branch_to_merge = $self->{'view'}) =~ s/_rel/_bld/;
   $BRs->{$tmp_branch_to_merge} = $tmp_branch_to_merge ;
 } else {
  foreach my $i (0 .. $#{@{$request}}) {
      if (!($request->[$i]{'Branch'} eq "") && !($request->[$i]{'Branch'} eq $self->{'baseline'})) {
        $BRs->{$request->[$i]{'Baseline'}} = $request->[$i]{'Branch'};
      }
      if ($request->[$i]{'Baseline'} =~/^MOTCM\d{1,8}$/) {
        $CRs->{$request->[$i]{'Baseline'}} = $request->[$i]{'Branch'};
      }
  }
 }
# print Dumper $BRs;
# print Dumper $CRs;
#return %CRs,%BRs;
}

#############################################################################
# Function for parsing request. Returns hash BRs_to_merge Baseline => branch
#############################################################################
sub create_BRs_to_merge()
{
#  @_ = parseArguments(@_);
    my $self = shift;
  my $request = shift@_;
  my $BRs_to_merge  = shift@_;
  my $BLs_to_change = shift@_;
  my $BLs_to_link   = shift@_;
  my $CRs_for_SSMT  = shift@_;
  my $get_CRs = 1;
  my $get_BRs = 1;

 if ($self->{'build_kind'} eq 'REL') {
   (my $tmp_branch_to_merge = $self->{'view'}) =~ s/_rel/_bld/;
#   print "tmp_branch_to_merge:$tmp_branch_to_merge\n";
   $BRs_to_merge->{$tmp_branch_to_merge} = $tmp_branch_to_merge ;
 } 
 foreach my $i (0 .. $#{@{$request}}) {
#      print "$i:$get_CRs:$request->[$i]{'Baseline'}";

    if (($request->[$i]{'Baseline'} eq $self->{'BASELINE'}) || ($request->[$i]{'Baseline'} eq $self->{'branch'})) {
       next;
    }
    if ($request->[$i]{'Branch'} eq $self->{'branch'}) {
       next;
    }
    if ($get_CRs && ($request->[$i]{'Baseline'} =~/^MOTCM\d{1,8}$/)) {
       $BRs_to_merge->{$request->[$i]{'Branch'}} = $request->[$i]{'Branch'} if ($get_BRs);
       $CRs_for_SSMT->{$request->[$i]{'Baseline'}} = $request->[$i]{'Baseline'};
       next;
    } elsif ($request->[$i]{'Branch'} eq "" && !($request->[$i]{'Baseline'} =~/^MOTCM\d{1,8}$/)) {
       $BLs_to_change->{$request->[$i]{'Baseline'}} = $request->[$i]{'Branch'} if ($request->[$i]{'SR'} eq 'EXT');
       $BLs_to_change->{$request->[$i]{'Baseline'}} = $1 if ($BLs_to_change->{$request->[$i]{'Baseline'}} =~ /(.+)?:eNodeB/);
       $get_BRs = 0;
       $get_CRs = 0 if ($request->[$i]{'SR'} eq 'EXT');
       next;
    } elsif (!($request->[$i]{'Baseline'} =~/^MOTCM\d{1,8}$/)) {
       $BRs_to_merge->{$request->[$i]{'Branch'}} = $request->[$i]{'Branch'};
       $BLs_to_link->{$request->[$i]{'Baseline'}} = $request->[$i]{'Baseline'};
       $get_BRs = 0;
       $get_CRs = 1;
       next;
    } else {
       next;
    }
 }
}
#############################################################################
# Function creates lte_env hash.
#############################################################################
sub create_lte_env($$$$$)
{
#  @_ = parseArguments(@_);
    my $self = shift;
  my $lte_env = shift@_;
#  my $self = shift@_;
  my $BRs_to_merge = shift@_;
  my $CRs = shift@_;
  my $BRs = shift@_;
  my $CRs_for_SSMT = shift@_;
  my $pre_build_mode = shift@_;
  my $branch_to_merge="";
  my $branchlist ="";
  my $crlist ="";
  my $ssmtlist ="";

  #print Dumper $lte_baseline;

  $lte_env->{'LTE_REL_LINE'} = $self->{'rel_line'};
  $lte_env->{'LTE_BLD_VIEW'} = $self->{'view'};
  $lte_env->{'LTE_LBL_NAME'} = $self->{'BASELINE'};
  $lte_env->{'LTE_LBL_VIEW'} = $self->{'view'};
  $lte_env->{'BUILD_KIND'}   = $self->{'build_kind'};
  ($lte_env->{'RELEASE'}     = $self->{'release'}) =~ tr/a-z/A-Z/;
  $lte_env->{'release'}      = $self->{'release'};
  $lte_env->{'LTE_BRANCH'}   = $self->{'view'};
  ($lte_env->{'PRODUCT'}      = $self->{'rel_line'}) =~ s/_(.+)?$//;
  $lte_env->{'PRODUCT'}  =~ tr/a-z/A-Z/;
  $lte_env->{'LTE_PREV_LBL_NAME'} = "";

  print "INITIAL: pre_build_mode = $pre_build_mode\n" if $debug;
  my $config = new LTE_BLD_CONF($lte_env->{'PRODUCT'},$lte_env->{'LTE_LBL_NAME'},$lte_env->{'RELEASE'},$debug,$pre_build_mode);
  my $branch;
  my $cr;

  $lte_env->{'LTE_LOG_ROOT'} = $config->{'unix_deliverable_path'}."/".$lte_env->{'LTE_LBL_NAME'}."/logs";
    foreach $branch (keys %{$BRs_to_merge}) {
      $branch_to_merge = "$branch_to_merge $BRs_to_merge->{$branch}";
    }

    $lte_env->{'BRANCH_TO_MERGE'} = $branch_to_merge;

    foreach $branch (keys %{$BRs}) {
      ($branchlist = "$branchlist ".$BRs->{$branch}) if ($BRs->{$branch} ne $self->{'view'});
    }
    $lte_env->{'BRANCHLIST'} = $branchlist;
    foreach $cr (keys %{$CRs}) {
      $crlist = "$crlist $cr";
    }
    $lte_env->{'CRLIST'} = $crlist;
  $lte_env->{'LTE_DIR_ROOT'} = $config->{'unix_deliverable_path'}."/".$lte_env->{'LTE_LBL_NAME'};
  $lte_env->{'LTE_BIN_ROOT'} = $config->{'unix_deliverable_path'}."/".$lte_env->{'LTE_LBL_NAME'};
    foreach $cr (keys %{$CRs_for_SSMT}) {
      $ssmtlist = "$ssmtlist $cr";
    }
  $lte_env->{'CRLISTFORSSMT'} = $ssmtlist;


}
#############################################################################
# Function for parsing input aguments.
#############################################################################
sub parseArguments(@)
{
  if ( defined(@_) ) {
    if ( $_[0] =~ /INITIAL=HASH/ ) {
      shift @_;
    }
  }
  return @_;
}

#############################################################################
return 'true';


