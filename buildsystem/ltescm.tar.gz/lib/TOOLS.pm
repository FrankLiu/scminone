package TOOLS;


####################
# modules
####################

use Term::ANSIColor qw(:constants);
#use strict;
use Data::Dumper;


####################
# constructor
####################

sub new {
	my $this = shift @_;
	my $class = ref($this) || $this;
	my $self = {};

	bless $self, $class;
return $self;
}

####################
# function definitions
####################

sub printBold(@);
sub printBlue(@);
sub printRed(@);
sub printGreen(@);

sub printlnBold(@);
sub printlnBlue(@);
sub printlnRed(@);
sub printlnGreen(@);
sub print_hash($);
sub setAttr(@);

sub error(@);
sub warning(@);
sub chdirb($);

sub lastIndexOf($$);
sub parseArguments(@);
sub doAction($);
sub introCommand($);

sub askForCommand($);
sub askForCommand_bold($);
sub askForCommand_exec($);
sub askQuestion($);
sub printMetrics(@);

####################
# print functions
####################

sub printBold(@) {
	@_ = parseArguments(@_);
	setAttr(BOLD);
	print "@_";
	setAttr(RESET);
}

sub printGreen(@) {
	@_ = parseArguments(@_);
	setAttr(BOLD, GREEN);
	print "@_";
	setAttr(RESET);
}

sub printBlue(@) {
	@_ = parseArguments(@_);
	setAttr(BOLD, BLUE);
	print "@_";
	setAttr(RESET);
}

sub printRed(@) {
	@_ = parseArguments(@_);
	setAttr(BOLD, RED);
	print "@_";
        setAttr(RESET);
}


sub printlnBold(@) {
	@_ = parseArguments(@_);
	printBold(@_);
	print "\n";
}

sub printlnGreen(@) {
	@_ = parseArguments(@_);
	printGreen(@_);
	print "\n";
}

sub printlnBlue(@) {
	@_ = parseArguments(@_);
	printBlue(@_);
	print "\n";
}

sub printlnRed(@) {
	@_ = parseArguments(@_);
	printRed(@_);
	print "\n";
}

sub setAttr(@)
{
	@_ = parseArguments(@_);
	my $interactive_mode = "";
	my $color = 1;
#	my $self = shift;

	# Print ANSI attribute escape codes if it is forced.
	if ($color)
	{
		print @_;
		return;
	}
	elsif(defined $color)
	{
		return;
	}
    # Print ANSI attribute escape codes only if script is called "from hand"
	# If its output or input is redirected then don't print escape codes
	if (!defined($interactive_mode)) {
		$interactive_mode = -t STDIN && -t STDOUT;
	}
	# Don't print ANSI codes if no color printing is forced
	if ($interactive_mode)
	{
		print @_;
	}
}


#############################################################
# Function to remove whitespace from the start and end of the string
#############################################################
sub trim($)
{
	@_ = parseArguments(@_);
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}
#############################################################################
# Function for printing out table
#############################################################################
sub print_table($)
{
  @_ = parseArguments(@_);
  my $table = shift@_;
  foreach my $row (@$table) {
    print "$row\n";
  }
  print "\n\n";
}

sub print_table_to_file($)
{
  @_ = parseArguments(@_);
  my $table = shift@_;
  my $file = shift@_;
  open (FILE, ">$file") or print "It's impossible to open file $file\n";
  foreach my $row (@$table) {
    print "$row\n";
    print FILE "$row\n";
  }
  close (FILE);
  print "\n\n";
}

sub print_table_of_hash($)
{
  @_ = parseArguments(@_);
  my $table = shift@_;
  foreach my $row (@$table) {
    print_hash($row);
  }
  print "\n\n";
}
#############################################################################
# Function for printing out hash
#############################################################################
sub print_hash($)
{
  @_ = parseArguments(@_);
  my $hash = shift@_;
  foreach my $key (sort keys %{$hash}) {
    print "$key\t => ${%$hash}{$key}\n";
  }
  print "\n\n";
}

####################
# Additional functions:
####################


sub doAction($)
{
    @_ = parseArguments(@_);
    my $command = shift @_;
    ####################
    my $result;

    chomp($command);
    printBold("\n$command\n");
    $result = askForCommand("Should be executed above command");
    return 4 if $result == 4;
    return -1 if !$result;          # skip this command
    $result = introCommand(\$command) if ($result eq 1);
    return 4 if $result < 0;
    return -1 if !$result;          # skip this command after edition

    system($command);
    return 0;

}

sub chdirb($)
{
    @_ = parseArguments(@_);
    my $dir = shift @_;
    my $pwd;

    chdir $dir or print "\n\nWarning: Directory $dir not exist !!!!!\n\n";
    print "\nDirectory was changed to $dir\n\n";
    $pwd = `pwd`;
    print "You are in directory \(pwd\):\n$pwd";
}

####################
# introCommand
####################

=head1 introCommand($)

 Display command before execution

=cut


sub introCommand($)
{
    @_ = parseArguments(@_);
    my $command = shift @_;  # String by ref
    ####################################
    my $line;
    my $edcmd;

    $$command = "" if (!defined($$command));
    chomp($$command);

    while (1) {
        $edcmd = $$command;
        printBold("Please introduce new command:\n");
        print "\>";
        $edcmd = <STDIN>;
        chomp($edcmd);
        $edcmd =~ s/^\s//g;
        $edcmd =~ s/\s$//g;

        while (1) {
            if ($edcmd eq "") {
		print "Command is empty !! It will be interpreted as skipping of edited command.\nDo you want continue anyway? [yes/no/skip/quit] ";
            } else {
                print "    Is the folowing command:\n";
                printBold("$edcmd\n");
                print "    correct? [yes/no/quit] ";
            }

            $line = <STDIN>;
            chomp ($line);
            $line = lc($line);

            last if ($line eq "n" || $line eq "no");
            return -1 if ($line eq "q" || $line eq "qu"  || $line eq "qui" || $line eq "quit");
                    # return -1 to avoid exit of script from called library !
            if ($line eq "y" || $line eq "ye" || $line eq "yes" ||
                $line eq "s" || $line eq "sk"  || $line eq "ski" || $line eq "skip" ) {
                $edcmd = "" if ($line eq "s" || $line eq "sk"  || $line eq "ski" || $line eq "skip");
                $$command = $edcmd;
                return ($$command ne "");
            }
            print "\nOnly y[es], n[o], s[kip] or q[uit] are acceptable !\n";
		}
    }
}


sub error(@) {
	@_ = parseArguments(@_);
	printRed("\n######     ERROR !!!     #####\n\n");
	print @_;
	printRed("\n\n######     ERROR !!!     #####\n\n");
	exit 1;
}

sub warning(@) {
	@_ = parseArguments(@_);
	@_ = parseArguments(@_);
	printRed("\n######     ERROR !!!     #####\n\n");
	print @_;
	printRed("\n\n######     ERROR !!!     #####\n\n");
}

####################
# askQuestions
####################

sub askForCommand($)
{
	@_ = parseArguments(@_);
	my $line = shift @_;
	my $result;
	printBold ("$line [yes /no / edit / quit]? ");
	$result = askForCommand_exec($line);
	return $result;
}

sub askForCommand_bold($)
{
	@_ = parseArguments(@_);
	my $line = shift @_;
	my $result;
	printBold ("$line [yes /no / edit / quit]? ");
#	print "TOOLS:askForCommand_bold::$line::\n".$line."\n";
	$result = askForCommand_exec($line);
	return $result;
}

sub askForCommand_exec($)
{
	@_ = parseArguments(@_);
	my $line = shift @_;
	my $ch = "y";
#	print "TOOLS:askForCommand_exec::$line\n";

 	while($ch=<STDIN>) {
        chomp($ch);
        $ch = lc($ch);

        return 3 if ($ch eq 'all');                                                 # do all unconditionally
        return 2 if ($ch eq 'y' || $ch eq 'ye' || $ch eq 'yes');                    # do it unconditionally
        return 1 if ($ch eq 'e' || $ch eq 'ed' || $ch eq 'edi' || $ch eq 'edit');   # edit it before then do
        return 0 if ($ch eq 'n' || $ch eq 'no');
        return 4 if ($ch eq 'q' || $ch eq 'qu' || $ch eq 'qui' || $ch eq 'quit');
        printlnBold("\nWARNING: Please press \'y\', \'n\', \'q\'");
        printBold("$line [yes /no /quit]? ");
	}
}

sub askQuestion($)
{
	@_ = parseArguments(@_);
	my $line = shift @_;
	my $ch = "y";

	printBold("$line [yes /no /quit]? ");

    if ('true') {
	  while($ch=<STDIN>) {
	    chomp($ch);
	    $ch = lc($ch);

	    return 1 if ($ch eq 'y' || $ch eq 'ye' || $ch eq 'yes');
            return 0 if ($ch eq 'n' || $ch eq 'no');
            return 4 if ($ch eq 'q' || $ch eq 'qu' || $ch eq 'qui' || $ch eq 'quit'); # User terminated
            printlnBold("\nWARNING: Please press \'y\', \'n\', \'q\'");
            printBold("$line [yes /no /quit]? ");
	 }
    } else {
	   print "\n";
	   return 1;
   }
}
####################
# lastIndexOf STR, SUBSTR
# returns index of last occurence SUBSTR in STR
####################

sub lastIndexOf($$)  {
	@_ = parseArguments(@_);

	my ($str, $substr) = @_;
	my $ind = -1;
	my $prev = -1;

	while ("true") {
		$ind = index($str, $substr, $ind+1);
		if ($ind == -1 && $prev == -1) {
			return -1;
		} elsif ($ind == -1 && $prev != -1) {
			return $prev;
		} else {
			$prev = $ind;
		}
	}
}

sub parseArguments(@) {
	if ( defined(@_) ) {

		if ( $_[0] =~ /TOOLS=HASH/ ) {
			shift @_;
		}
	}
	return @_;
}

#----------------------------------------------------------------------------
#                          Function: printMetrics
#----------------------------------------------------------------------------
# Description:
#	This function prints the calculated "real" time metrics to the passed
#       file handle.
#
# Argument(s):
#	$log_dir	   - Directory where time_scripts shloud be loged
#	$sTime		- Start time we will subtract from Finish time
#	$fTime		- Finish time
#
# Return value(s):
#	Function substract start time from finish time and write result (in proper
#	format) in file or stdout if $log_dir is empty
#
# Post condition(s):
#	Time added to metrics file or printed to stdout
#
# Note(s):
#       If you already have the total time, pass the total time in $fTime
#       and 0 for $sTime (when $fTime already = $tTime, $fTime-0=$tTime).
#
sub printMetrics (@) {
	@_ = parseArguments(@_);

my ($log_dir, $sTime, $fTime) = @_;
my $file_name;
my $metricsFH;


if((defined $log_dir) && ($log_dir ne "")) {
   $file_name = "$log_dir/time_scripts";
   open ($metricsFH, ">>$file_name") or warning("Could not open metrics file: $file_name") ;
}

# Log Metrics
my $tTime     = $fTime - $sTime;
my $tHour     = int($tTime/3600);
my $tMin      = int($tTime/60 - $tHour*60);
my $tSec      = ($tTime - $tHour*3600 - $tMin*60);
my $bTime     = sprintf("%dh%dm%.02fs", $tHour, $tMin, $tSec);

# Build time_scripts logging
if(defined $metricsFH) {
   print($metricsFH "real\t$bTime\n\n") or warning(" Could not write metrics \"$bTime\". in file $file_name");
}
else {
   print "real\t$bTime\n\n";
}

close($metricsFH) if (defined $metricsFH);
return;
} # end printMetrics


return 'true';
