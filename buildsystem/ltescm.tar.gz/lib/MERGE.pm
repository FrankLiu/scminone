#!/apps/public/perl_5.8.4/bin/perl
#############################################################################
#
#       Copyright (C) 2010 MOTOROLA. All Rights Reserved.
#
#       The copyright notice above does not evidence any
#       actual or intended publication of such source code.
#       The code contains Motorola Confidential Restricted Information.
#
#############################################################################
#
#  FILE NAME:    MERGE.pm
#
#  OWNER:        LTE SCM Team
#
#  DATE CREATED: 01/25/2010
#
#  SYNOPSIS:     None.
#
#  EXIT VALUE:   1; - Mandatory for module to load successfully
#
#  DESCRIPTION:  This Perl module contains functions and variables used
#                for this specific component of the build automation.
#
#############################################################################
#
#  MODIFICATION HISTORY:
#
# Ver    Date     Engineer     CR                     Change
# --- ---------- ---------- --------  ---------------------------------------
# 1.0 05/27/2010 skerr1     01313325  Created initial version.
# 1.1 06/30/2010 skerr1     01336346  Renamed module.  Various updates.
# 1.2 08/05/2010 skerr1     01348638  Added br lock and tracemerge $? check.
#
#############################################################################
#
#  FUNCTIONS:  (Alphabetical)
#
#	Local
#	-----
#	getCompletedMergeBrList	- Get a list of already merged branches
#				  targeted to this baseline.
#	merge			- Generate script to merge, check-in and
#				  validate content.
#	new			- Create and return new MERGE object.
#
#############################################################################

## DEVELOPMENT NOTES:
#  -----------------
# 1. Any variables global to this package must be declared within the 'our'
#    directive because of the 'strict' pragma.

## CHECKLIST WHEN UPDATING THIS MODULE:
#  -----------------------------------
# 1. Update @EXPORT if created a function or variable to be exported.
# 2. Update 'our' if added a global variable to this module or if a variable
#    needs to be exported. 
# 3. Update the "FUNCTIONS" list in the prologue.
# 4. Update the "MODIFICATION HISTORY" in the prologue.
# 5. Turn Perl diagnostics (use diagnostics;) and strict (use strict;) off
#    before release.

# Used as error checking mechanism: does not allow re-declaration of
# the same variable within the same scope.  For testing purposes only.
# Note: We do not check for strict references in order to access globals from
#       the calling package.
#use strict qw(vars subs);
#use diagnostics;

# Indicates that the entire library's symbol table or namespace is labeled
# as <package>  The compiler will look for any undefined symbols, in the
# calling program, in this package.
package MERGE;

use 5.8.4;	# Use Perl 5.8.4 or higher (also for debugging purposes)

use Data::Dumper;  # Used for dumping data structures

# Used to setup export methods into calling programs.  Allows the use of
# import(), @ISA, @EXPORT, etc., which allows for different ways of exporting
# symbols.
require Exporter;

# Standard global symbols
our (@ISA, @EXPORT);

# Search location for unresolved functions in the current package.
# The search is left to right.
# Exporter is included here because of the import() function.
@ISA = qw(Exporter);

# List of symbols to be exported by :DEFAULT.
# List functions first, then all other symbols.
@EXPORT	  =  qw(processFunctions
                new
                
               );

# Package global variables (some are imported from the calling namespace).
our    ($stepsToModules,
        $objectsRef,
        $buildVer,
        $cp,
        $createView,
        $ct,
        $DOMAIN,
        $lapTime,
        $logsDir,
        $MACHINE,
        $maillist,
        $MERGE_METRICS_FH,
        $plcode,
        $SCM_ADMIN_VOB,
        $scriptDir,
        $STATUS_ERROR,
        $STATUS_OK,
        $timeStamp,
        $TIME_STAMP,
        $tool,
        $tool_version,
        $USER,
        $VIEWNAME,
       );

#============================================================================
#=====================  Exported Variable Initialization  ===================
#============================================================================
#
# Do not use the 'my' directive for those definitions we are using the 'our'
# directive for above.
#

## Do not touch the following block of code ##
# Sets the name of the calling package (tool)
my $pkg   = (caller)[0];		# Calling package name

# Import exported variables from calling package (tool)
$pkg->import;

# Set mergestat
my $mergestat = 'mergestat';

 
#============================================================================
#==============================  FUNCTIONS  =================================
#============================================================================

#----------------------------------------------------------------------------
#                     Function: getCompletedMergeBrList
#----------------------------------------------------------------------------
# Description:
#	Get the mergestat output and return only completed merges in an
#	array.
#
# Argument(s):
#	N/A
#
# Return value:
#	Failure: $STATUS_ERROR
#       Success: array of branches that have been merged
#
# Pre condition(s):
#	Assumes scstart already executed so mergestat will function
#	properly.  Note that mergestat uses the view tag as the branch to
#	examine by default.
#
# Post condition(s):
#	None.
#
sub getCompletedMergeBrList {
  my @mb = ();		# Merged branch list
  
  # Get list of branches that exist in mergestat list, but are non "yes yes" 
  open (my $MSL, '-|', "$mergestat -r") || do {
     process_error('e', 'Failed to open mergestat process handle!');
     return ($STATUS_ERROR);
  }; # end open (my $MSL...

  my @mergestatOutput = <$MSL>;

  # Close the process handle for mergestat      	
  close($MSL) || do {
    process_error('e', "$mergestat execution failed: $!.");
    return ($STATUS_ERROR);
  }; # end close($MSL...

  # Strip out the already merged branches
  foreach my $branchLine (@mergestatOutput) {
    
    # The branch line is:  <branch>  <merge begun y/n>  <merge done y/n>
    my ($branch, $mb, $md) = split /\s+/, $branchLine;
    
    # If the merge is not yet complete, skip it. 
    next if ($mb ne 'yes' and $md ne 'yes');
    
    # Add $branch to the merged branches array
    push @mb, $branch;
    
  } # end foreach my $branchLine...
  
  return @mb;

} # end sub getCompletedMergeBrList


#----------------------------------------------------------------------------
#                             Function: merge
#----------------------------------------------------------------------------
# Description:
#	Merge identified branches.  Check in content.  Validate REL content.
#
# Argument(s):
#	@mergeBranches		- Array of branches needing to be merged.
#
# Return value:
#	Failure: Non-zero value returned
#       Success: 0
#
# Pre condition(s):
#	Your team uses CQCM
#	scstart executed
#
# Post condition(s):
#	unmerged branches now merged and checked in
#	REL build content validated against BLD build
#
## PRE
# Branch list comes from either the build request or from <buildVer>.pm
# Verify BRs in the list not already merged and are valid BR types
# Report requested BRs we will not be merging
# Ensure there are no checkouts for the target branch type

## MAIN
# for each branch
#   ensure there are no checkouts for $branch
#   findmerge -merge -nc -avobs -abort -fver .../<branch>/LATEST -type d
#   findmerge -merge -nc -avobs -abort -fver .../<branch>/LATEST -type f
#   checkin
#   scBRMerge for hyperlinks
#   look for checkouts on the target branch type

## POST
# Lock the target branch type
# For REL, lte_checkmerge.pl -vew $VIEWNAME -branch <BLD view>

sub merge {

    my ($self, @branchesToMerge) = @_;
    
    # Setup local vars for readabilty
    my @alreadyMerged = ();	# List of branches already merged
    my $branchesToMerge = '';	# List of branches we will merge
    my $configSpec  = $self->{'configSpec'};
    my $curStep     = 'merge';  # Current build step
    my $debug       = $self->{'dbg'};
    my $envVars     = $self->{'envVars'};
    my $initial     = $objectsRef->{'INITIAL'};
    my $intBranch   = $self->{'intBranch'};
    my $logging     = $self->{'logging'};
    my @mergedBranches = ();    # Array of branches already merged
    my @noBrType    = ();	# List of branches with no brtype
    my $return_code = $self->{'return_code'};
    my $rc          = 0;        # Temp return code
    my $scriptName  = "${curStep}_${buildVer}_build_script";
    my $script      = "${scriptDir}/${scriptName}";
    my $server      = $self->{'server'};
    my $startDir    = $self->{'startDir'};
    my $view        = $self->{'view'};

    # Get the list of already merged branches.
    # Note: there is no mergestat to check for REL builds.
    if ($buildVer !~ m/_REL-/) {
    
      # Get list of branches that exist in mergestat list with status
      # "yes yes". 
      @mergedBranches = getCompletedMergeBrList();

      # We will exit this subroutine if there was any failure
      # ($STATUS_ERROR) with getting the mergestat output. 
      return $STATUS_ERROR if (defined($mergedBranches[0]) and
        $mergedBranches[0] eq $STATUS_ERROR);
        
    } # end if ($buildVer...

    # We don't need to get a list of branches to merge from the build request
    # if we already have a list of branches to merge from another source.
    if (scalar(@branchesToMerge) == 0) {

      # Update @branchesToMerge with the list of branches from the build request
      foreach my $bldReqBranch (keys %{$initial->{'BRs_TO_MERGE'}}) {

      	# Append new branch to branch list      	
        push @branchesToMerge, $bldReqBranch;
      	
      } # end foreach my $bldReqBranch...

    } # end if (scalar(@branchesToMerge...
    
    
    # Validate the list of branches
    foreach my $branch (@branchesToMerge) {

      # Skip any branches that are just empty strings      
      next if $branch =~ /^\s*$/;

      # If it is not a valid branch type, we won't try to merge it.
      # LTE MME Call Processing has CRs that are in this class.
      `$ct lstype brtype:$branch\@$ENV{'SCM_ADMIN_VOB'} 2>/dev/null 2>&1`;
      if (($? >> 8) > 0) {
      	push @noBrType, $branch;
        next;  
      } # end if (($?...
      
      # Exclude it if the branch has already been merged by searching for
      # it in the mergedBranches array.
      if (grep /^$branch$/, @mergedBranches) {
      	push @alreadyMerged, $branch;
      	next;
      } # end if (grep...
      
      $branchesToMerge .= " $branch";
      	
      ($debug) and print Dumper $branchesToMerge;

    } # end foreach my...
    
    # Strip the preceding excess white space
    $branchesToMerge =~ s/^\s*(.*)$/$1/;


    # Warn the user if we skipped any branches
    if (scalar(@alreadyMerged) > 0 or scalar(@noBrType) > 0) {
      # Set these to "None" if nothing was found
      (@alreadyMerged) or push(@alreadyMerged, "None");
      (@noBrType) or push(@noBrType, "None");
      
      process_error('mw',
        "The following branches will not be merged by $tool"
        . " for $buildVer.\n\nAlready Merged branches:\n"
        . join("\n", @alreadyMerged)
        . "\n\nNo branch type exists:\n"
        . join("\n", @noBrType)
        . "\n", $maillist, "$buildVer: branches not merged");
    } # end if (@alreadyMerged...  	
    
#----------------------------------------------------------------------------


    ($debug) and print Dumper $self;

    ## Merge
    ## Setup the merge

    # Merge commands
    my @CMDs = (
      "test -z \"\`$ct lsco -avobs -brtype \$branch 2>&1\`\"",
      "$ct findmerge -merge -nc -avobs -abort -fver .../\$branch/LATEST -type d",
      "$ct findmerge -merge -nc -avobs -abort -fver .../\$branch/LATEST -type f",
      "COs=\`$ct lsco -avobs -cview -short\`",
      "if [[ -n \"\$COs\" ]]; then $ct lsco -avobs -cview -short | "
        . "/usr/bin/xargs -i $ct checkin -identical -nc {}; fi",
      "scBRMerge -f \$branch",
      "$cp *erge* $logsDir/merge/",
      "test -z \"\`$ct lsco -avobs -cview -short 2>&1\`\"",
    ); # end my @CMDs...

    if ($view ne $VIEWNAME) {
      # Check to see if view already exists
      `$ct lsview $view 2>&1 1>/dev/null`;

      # Capture the return status from the program and not the shell.
      # Exit value of the subprocess is in the high byte, $? >> 8.
      # The low byte says which signal the process died from, $?.
      $rc = ($? >> 8);

      ## Create view if it doesn't exist
      if ($rc) {
        print("($tool) Creating View $view\n");
        # If a build specific createView is defined then use it, otherwise use
        # the default_create_view.
        if (defined &createView) {
	  createView($view);
        } else {
	  default_create_view($view, $createView);
        } # end if (defined...
      } else {
        print("($tool) View $view already exists. Continuing...\n");
      } # end if (!$rc...
      print("\n");

    } # end if ($view...

    # Only set the config spec if there is something to set  
    if (defined($configSpec) and $configSpec) {
      # Set the view config spec
      print("($tool) Setting configuration specification $configSpec\n");
      exec_cmd('x', "$ct setcs -tag $view $configSpec",
               "Could not set config spec $configSpec for view $view!");
      print("($tool) Finished setting config spec.\n\n");
    } # end if (defined...


    ## Generate the step specific script
    my $BLDSCRPT = undef(); # BLDSCRPT FH

    open($BLDSCRPT, '>' , "$script") or
      process_error('x',"Could not create the step build script \"$script\""
                      . ": $!");
    print($BLDSCRPT "#!/bin/ksh -p\n");
    print($BLDSCRPT "# Build Script for step: $curStep\n");
    print($BLDSCRPT "# Created $TIME_STAMP for $USER\n");
    print($BLDSCRPT "# Created by $tool $tool_version\n\n");

    # Check if build logging is desired
    if ($logging) { # Build command logging
      print($BLDSCRPT 'print "\n' . "($scriptName) $curStep build " .
                     "command logging active" . '.\n"' . "\n\n");
    } else { # No build command logging
      print($BLDSCRPT 'print "\n' . "($scriptName) Suppressing " .
                     "$curStep build command " . 'logging.\n"' . "\n\n");
    } # end if (!$logging...

    # Set into proper directory
    if ($startDir) {
      write_to_script($BLDSCRPT, $script, "cd ${startDir}",
                    "Setting into $curStep start directory.");
    } # end if ($startDir...

    # Set environment vars
    if (scalar(keys(%$envVars)) > 0) {
      print($BLDSCRPT "print \"($scriptName) Setting env vars.\"\n");
      foreach my $k (sort keys %$envVars) {
        write_to_script($BLDSCRPT, $script, "export $k=$envVars->{$k}",
                      "Setting $k to $envVars->{$k}");
      } # end foreach...
      print($BLDSCRPT 'print "' . "($scriptName) Finished setting " .
                     'env vars.\n"' . "\n\n");
    } # end if (scalar(keys...

    # Setup the step commands
    print($BLDSCRPT "print \"($scriptName) Executing $curStep step" .
		   'commands.\n"' . "\n");


    # Start the for loop
    # We only process the list of CMDs if there are CRs to integrate
    if ($branchesToMerge) {
      print($BLDSCRPT "print \"Processing branches: $branchesToMerge\n\"\n");
      print($BLDSCRPT "for branch in $branchesToMerge; do\n");
  
      # Process the array of commands
      foreach my $cmd (@CMDs) {

        if (!$logging) { # No logging
          $cmd .= " 1>/dev/null 2>&1";
        } # end if ($logging...

        write_to_script($BLDSCRPT, $script, $cmd, "Executing merge command");

      } # end foreach my $cmd...

      # End the foreach loop
      print($BLDSCRPT "done # end for branch in...\n\n");
      
    } else { # there were no branches to merge
      print($BLDSCRPT
        "print \"Processing branches: No branches to merge\n\"\n");
    } # end if ($branchesToMerge...
    
    # See if there are any unfinished merges
    # test will return 0 if there are no merges pending and 1 if there are.
    # A 1 return value would be treated as a failure.
    write_to_script($BLDSCRPT, $script, "test -z \"`$mergestat "
      . "-n | grep 'There are pending unmerged CRs listed' 2>&1`\"",
      "Checking merge status.");

#----------------------------------------------------------------------------


    # If this is a REL build for CQCM, compare against the BLD content
    if ($buildVer =~ m/_REL-/) {
      my $lcBuildVer = lc($buildVer);
      (my $childBranch = $lcBuildVer) =~  s/rel/bld/;
      $childBranch =~ s!\...$!!;
      write_to_script($BLDSCRPT, $script, "lte_checkmerge.pl -view $VIEWNAME"
                    . " -branch $childBranch",
                    "Comparing content for REL and child BLD.");
    } # end if (grep /_REL-...

    print($BLDSCRPT "print \"($scriptName) Finished executing build " .
                   'commands.\n"' . "\n\n");

    close($BLDSCRPT) or process_error('x', "Could not close BLDSCRPT: $!");

    # Set the permissions for $script
    (chmod(0775,$script) == 1)
      or process_error('x',
        "Cannot change permissions for $script to 775.");

    # Command we'll execute
    my $execCmd = '';
    
    # Only prefix with ct setview if $view not equal to $VIEWNAME or we are
    # running on a remote server.
    if ($view ne $VIEWNAME) {
      $execCmd = "$ct setview -exec \"$script\" $view";
    } else { # we are already set into $view
      # We need to set into the current view is we are executing on a
      # remote server
      if ($server and $server ne "$MACHINE.$DOMAIN") {
      	$execCmd = "/apps/public/bin/ssh -q $server $ct setview -exec "
               . "\"$execCmd\" $view";
      } else { # We are not using a remote server
        $execCmd = "$script";
      } # end if ($server...
    } # end if (defined($view)...

    print("($tool) Executing generated script for ${curStep}...\n");
    print("($tool) Command: $execCmd\n");

    my $PH = undef();   # Execution Process Handle
    open ($PH, '|-', "$execCmd")
      or process_error('x',
        "Could not open process handle for command ($execCmd): $!");
    close($PH);

    # Capture the return status from the program and not the shell.
    # Exit value of the subprocess is in the high byte, $? >> 8.
    # The low byte says which signal the process died from, $?.
    $rc = ($? >> 8);

    return $rc;

} # end sub merge

#----------------------------------------------------------------------------
#                          Function: tracemerge
#----------------------------------------------------------------------------
# Description:
#	Create the tracemerge and cmbp reports.  Examine the cmbp report for
#	known merge issues.
#
# Argument(s):
#	N/A
#
# Return value:
#	Failure: Non-zero value returned
#       Success: 0
#
# Pre condition(s):
#	The merge is typically complete.
#
# Post condition(s):
#	We know if all branches have been merged and targeted properly.
#
## MAIN
# For ! REL, run tracemerge/cmbp_report

sub tracemerge {

    my ($self) = @_;
    
    # Setup local vars for readabilty
    my $curStep     = 'merge';  # Current build step
    my $debug       = $self->{'dbg'};
    my $envVars     = $self->{'envVars'};
    my $intBranch   = $self->{'intBranch'};
    my $return_code = $self->{'return_code'};
    my $rc          = 0;        # Temp return code
    my $server      = $self->{'server'};
    my $startDir    = $self->{'startDir'};
    my $view        = $self->{'view'};

    ## Tracemerge/cmbp_report checks
    # Only if the merge was successful and only for ! REL, run the following checks
    if ($rc == 0 and $buildVer !~ m/_REL-/) {
      # Examine the output of the following commands to ensure that all
      # branches are for CR's targeted to the current build (or a predecessor
      # build of the same branch).
      #  o Fail if not Performed and build version of CR == $buildVer
      #  o Fail if Performed and build version of CR != $buildVer
      #  o Fail anything that is not Closed or Performed except for devint*
      #    if $buildVer =~ /DEVINT/

      # Set environment vars
      if (scalar(keys(%$envVars)) > 0) {
        foreach my $k (sort keys %$envVars) {
          $ENV{$k}=$envVars->{$k};
        } # end foreach...
      } # end if (scalar(keys...

      # Check if tracemerge and cmbp_report.pl are in the user's path
      foreach my $tempTool (qw{tracemerge cmbp_report.pl}) {
        unless (grep {-x "$_/$tempTool"} split/:/ =>$ENV{'PATH'}) {
          proces_error('x', "Cannot find executable $tempTool in your PATH!");
        } # unless (grep ...
      } # end foreach my $tempTool...
      
      # Get tracemerge output
      my $cmd = "tracemerge -l 0 > $logsDir/merge/tracemerge.log 2>&1";
      print_and_log($plcode, "Executing: $cmd\n\n");
      exec_cmd('x', $cmd, "tracemerge execution failed!");
      
      # Create the CMBP report based on the tracemerge output  
      $cmd = "cmbp_report.pl -f  $logsDir/merge/tracemerge.log  2>&1";
      print_and_log($plcode, "Executing: $cmd\n\n");
      open (my $CRO, '-|', $cmd) || do {
        process_error('x', "Failed to open cmbp_report.pl process handle: $!");
      }; # end open (my $TMO...

      # Store the tracemerge output
      my @cmbp_reportOutput = <$CRO>;
      chomp(@cmbp_reportOutput);
      
      # Close the process handle for tracemerge      	
      close($CRO) || do {
        process_error('x', "cmbp_report.pl execution failed: $!.");
      }; # end close($TMO...

      # Print the full CMBP report
      print_and_log($plcode, "FULL CMBP REPORT:\n_________________\n" .
        join("\n", @cmbp_reportOutput) . "\n\n");
      
      
      ## Start filtering
      
      # Sort unique
      my %tmpHash = map { $_ => 1 } @cmbp_reportOutput;
      @cmbp_reportOutput = sort keys %tmpHash;
      	
      # Strip out the devint branch if this is a DEVINT build.
      # Also, just keep lines with BL_Actual
      if ($buildVer =~ /_DEVINT-/) {
      	my $i = 0;
      	# In the cmbp_report, the devint is listed by CR, w/o "devint-".
      	(my $devintCR = $intBranch) =~ s/devint-//;

        print_and_log($plcode, "\nExcluding the DEVINT CR: $devintCR\n\n");
      
        # Exclude the devint CR
        @cmbp_reportOutput = grep { ! m/$devintCR/ } @cmbp_reportOutput;
      } # end if ($buildVer...

      # Exclude anything without BL_Actual
      @cmbp_reportOutput = grep { m/BL_Actual/ } @cmbp_reportOutput;

      # Check for not Performed or Closed and BL_ACTUAL_TARGET of CR == $buildVer
      my @notPerformedClosedAndBuildVer =
                               (grep { ! m/(Performed|Closed):/ and m/$buildVer/}
                                @cmbp_reportOutput);
      # Set return code to error or output to None
      if (@notPerformedClosedAndBuildVer) {
      	$rc = $STATUS_ERROR;
      } else {
      	push(@notPerformedClosedAndBuildVer, "None");
      } # end if...

      # Check for Performed and BL_ACTUAL_TARGET of CR != $buildVer
      my @performedAndNotBuildVer = (grep {m/Performed:/ and ! m/$buildVer/}
                                     @cmbp_reportOutput);
      # Set return code to error or output to None
      if (@performedAndNotBuildVer) {
      	$rc = $STATUS_ERROR;
      } else {
      	push(@performedAndNotBuildVer, "None");
      } # end if...

      # Check for anything that is not Closed or Performed
      my @notClosedPerformed = (grep {! m/Performed:/ and ! m/Closed:/}
                                     @cmbp_reportOutput);
      # Set return code to error or output to None
      if (@notClosedPerformed) {
      	$rc = $STATUS_ERROR;
      } else {
      	push(@notClosedPerformed, "None");
      } # end if...
      
      # Log the findings
      print_and_log($plcode,
        "-----------------------\n" . 
        "\nIntegrated CRs not Performed or Closed with BL_ACTUAL_TARGET of $buildVer:\n" .
        join("\n", @notPerformedClosedAndBuildVer) .
        "\n\nIntegrated CRs Performed but BL_ACTUAL_TARGET is not $buildVer:\n" .
        join("\n", @performedAndNotBuildVer) .
        "\n\nIntegrated CRs not Closed or Performed:\n" .
        join("\n", @notClosedPerformed) .
        "\n\n-----------------------\n\n" 
      ); # end print_and_log
      
    } # end if ($rc...
    
return($rc);

} # end sub tracemerge

#----------------------------------------------------------------------------
#                              Function: new
#----------------------------------------------------------------------------
# Description:
#	Constructor for MERGE.
#
# Argument(s):
#	$this		- class name
#	$self		- hash ref initially containning config data
#	$intBranch	- integration branch
#	$debug		- Debug true or false
#
# Return value:
#	Failure: Function returns Empty List, Undefined or Nothing depending
#       on the context
#       Success: requested object reference
#
# Pre condition(s):
#	None.
#
# Post condition(s):
#	None.
#
sub new {
   my ($this, $self, $intBranch, $debug) = @_;
   my $class = ref($this) || $this;

   $self->{'intBranch'} = $intBranch;
   $self->{'dbg'} = $debug;
   $self->{'return_code'} = 0;
   
   ($self->{'dbg'}) and print Dumper $self;
   
   return bless $self, $class;
} # end new()

#----------------------------------------------------------------------------
#                         Function: processFunctions
#----------------------------------------------------------------------------
# Description:
#	Process the functions for this build type.
#
# Argument(s):
#	@mergeBranches		- Array of branches needing to be merged.
#
# Return value:
#	Failure: Non-zero value returned
#       Success: 0
#
# Pre condition(s):
#	None.
#
# Post condition(s):
#	None.
#
sub processFunctions {
    my ($self, @branchesToMerge) = @_;
    my $intBranch   = $self->{'intBranch'};
    
    # We always lock the integration branch for everyone except $USER.
    my $cmd = "$ct lock -replace -nusers $USER brtype:$intBranch@$SCM_ADMIN_VOB 2>&1";
    print_and_log($plcode, "Executing $intBranch branch lock: $cmd\n\n");
    exec_cmd('x', $cmd, "$ct lock of brtype:$intBranch failed!");
    
    my $functions = $self->{'functions'};
    
    # We'll process the array of functions for this build type
    foreach my $func (@$functions) {
      case: {

	# Merge function
      	($func eq "merge") and do {
      	  # Call the merge function
      	  my $rc = $self->merge(@branchesToMerge);
      	  
      	  # Error handling
      	  ($rc) and return $rc;
      	  
      	  last case;	
      	}; # end ($func eq "merge")...

	# Tracemerge function
      	($func eq "tracemerge") and do {
      	  # Call the merge function
      	  my $rc = $self->tracemerge();
      	  
      	  # Error handling
      	  ($rc) and return $rc;
      	  
      	  last case;	
      	}; # end ($func eq "tracemerge")...

        # The user must have requested a custom function. It should have been
        # exported from the build type module to the buildProcessor namespace,
        # so let's call it from there.
        
        print_and_log($plcode, "Calling custom function: $func\n\n");
        my $rc = &{'buildProcessor::'.$func};

        # Error handling
        ($rc) and return $rc;

      } # end case...
    } # end foreach...

    return 0;

} # end sub processFunctions


1;

# EOF
