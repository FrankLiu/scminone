##########################################################################
##
##                       P E R L   M O D U L E
##
##                       COPYRIGHT 2006 MOTOROLA
##                      MOTOROLA INTERNAL USE ONLY
##
##########################################################################
##
##  Oracle.pm - Interface with Oracle DBMS
##
##  USAGE:
##      $ENV{ORACLE_HOME} = "/apps/vendor/oracle" unless $ENV{ORACLE_HOME};
##      use lib "/mot/proj/ddts/admin/lib";
##      use Oracle;
##
##      my $dbh = connect_to_db($DBNAME, $username, $password);
##      if ($dbh) {
##          my $ar_result = exec_sql_stmt($dbh, $sql, $show_headings);
##          $dbh->disconnect();
##          display_result($ar_result, $sep, $show_headings);
##      }
##
##  NOTES:
##    * VOB loc: /vob/sysadm/ddts/isd/san/admin/lib
##
##  CHANGE HISTORY
##      Developers:    LMA - Linc Abbey
##
##      Date       Who Description
##      ---------- --- ---------------------------------------------------
##      2005/06/06 LMA Created initial version (V0.1)
##      2006/04/27 LMA Give user-friendly message if DBI.pm not found.
##      2006/06/16 LMA Update USAGE to show how to set up calling script.
##
##########################################################################

##########################################################################
##
##  GLOBAL
##
##########################################################################

package Oracle;
require Exporter;
@ISA = ('Exporter');
@EXPORT = qw(
    parse_opts
    get_user_input
    get_conn_info
    connect_to_db
    exec_sql_stmt
    display_result
);


sub parse_opts($);
sub get_user_input(@);
sub get_conn_info($$);
sub connect_to_db($$$);
sub exec_sql_stmt($$$);
sub display_result($$$);



BEGIN { 
    unless (eval "require DBI") {
        warn << "EOF";
ERROR: The required Perl module DBI.pm is not installed on this machine.
EOF
        exit(1);
    }
}


sub get_user_input (@) {
    show_args(@_) if $debug;
    my ($query, $show_headings, $sep);

    @ARGV = @_;
    use vars qw($opt_n $opt_s);
    parse_opts("ns:");
    $show_headings = $opt_n ? 0 : 1;

    if (defined $opt_s) {
        if ($opt_s =~ m#^\\\d{3}$#  or
            $opt_s =~ m#^\\x[\da-f]{1,2}$# or
            $opt_s =~ m#^\\[a-z]$#) {
            my $cmd = qq{\$sep = sprintf "$opt_s", ""};
            $cmd = untaint($cmd);
            eval $cmd;
        } elsif (length($opt_s) == 1) {
            $sep = $opt_s
        } else {
            die qq{Argument to -s flag can only be one character\n};
        }
    }

    my @query;
    if (!@ARGV) {
        warn qq{(You need to specify <file> or "-".)\n\n};
    }
    if ($ARGV[0] eq "-") {
        @query = <STDIN>;
    } else {
        open F, $ARGV[0] or die qq{Cannot read file "$_[0]": $!\n};
        @query = <F>;
        close F;
    }
    $query = "@query";
    $query =~ s/[;\s]*$//;
    $query =~ s/\n+$//m;
    return ($query, $show_headings, $sep);
}


sub get_conn_info ($$) {
    show_args(@_) if $debug;
    my($dbname, $file) = @_;

    open CONN_INFO, $file or
        die "ERROR: Cannot read connection information file: $!\n";
    chomp(my @conn_info = <CONN_INFO>);
    close CONN_INFO;

    my $username = trim($conn_info[0]);
    my $password = trim($conn_info[1]);
    ($username, $password);
}


sub connect_to_db ($$$) {
    show_args(@_) if $debug;
    my($dbname, $username, $password) = @_;
    my $dsn = "dbi:Oracle:$dbname";
    my %attr = ();
    my $db_handle = DBI->connect($dsn, $username, $password, \%attr);
    if (!$db_handle) {
        die qq{ERROR: Could not connect to "$dbname" database: } .
            qq{$DBI::errstr\n};
    }
    return($db_handle);
}


sub exec_sql_stmt ($$$) {
    show_args(@_) if $debug;
    my($dbh, $sql, $show_headings) = @_;
    my @result;
    my $select_stmt = 0;
    if ($sql =~ /^\s*select/i) {
        $select_stmt = 1;
    }

    my $sth = $dbh->prepare($sql);
    die "\n" unless ($sth);
    my $rv = $sth->execute();
    die "\n" unless ($rv);

    if ($select_stmt) {
        if ($show_headings) {
            @result =  [ @{$sth->{NAME}} ]
        }
        while ( my @row = $sth->fetchrow_array ) {
             push @result, [ @row ];
        }
    }
    return \@result;
}


sub display_result ($$$) {
    show_args(@_) if $debug;
    my($ar_result, $sep, $show_headings) = @_;
    return unless @$ar_result;

    my $fmt;

    handle_nulls($ar_result);
    if (! defined $sep) {
        $fmt = get_fmt($ar_result, $show_headings);
        for my $ar_row (@$ar_result) {
            printf $fmt, @$ar_row;
        }
    } else {
        for my $ar_row (@$ar_result) {
            print((join $sep, @$ar_row), "\n");
        }
    }
    return;
}


    ##  handle_nulls - Replace NULLs with empty strings
    ##  Usage: handle_nulls($ar_result)
    ##  Input is a reference to an array of arrays.
sub handle_nulls {
    my $ar = shift;
    my $num_cols = @{$$ar[0]};
    my($i, $j); 
    for ($i = 0; $i <= $#{$ar}; $i++) {
        my $ar_row = $$ar[$i];
        for ($j = 0; $j < $num_cols; $j++) {
            $$ar_row[$j] = "" if (!defined $$ar_row[$j]);
        }
    }
}


sub get_fmt {
    my ($ar, $show_headings) = @_;
    my $num_cols = @{$$ar[0]};

    if ($num_cols == 1) {
        return "%s\n";
    } 

    my $sep = " " x 4;
    my (@fmt, $fmt, $i, $j);
    my @max_len = (0) x $num_cols;
    my @is_numeric = (1) x $num_cols;

    for ($i = 0; $i <= $#{$ar}; $i++) {
        my $ar_row = $$ar[$i];
        for ($j = 0; $j < $num_cols; $j++) {
            my $val = $$ar_row[$j];
            my $len = length($val);
            $max_len[$j] = $len if ($len > $max_len[$j]);
            next if ($i == 0 and $show_headings); 
            if ($val !~ /^[\d.\$]+$/) {
                $is_numeric[$j] = 0;
            }
        }
    }
    for ($i = 0; $i < $num_cols; $i++) {
        my $dash = $is_numeric[$i] ? "" : "-";
        my $len = $max_len[$i];
        push @fmt, "%${dash}${len}.${len}s";
    }
    $fmt = join $sep, @fmt;
    "$fmt\n";
}


    ##  show_args - Show the arguments passed to a subroutine.
    ##  Usage: show_args(@_) if $debug
sub show_args (@) {
    my @args = @_;
    for (my $i = 0; $i <= $#args; $i++) {
        if (! defined $args[$i]) {
            $args[$i] = "<undef>";
        } else {
            $args[$i] = qq{"$args[$i]"};
        }
    }
    my $arg_str = @args ? (join ", ", @args) : "";
    my $subname = (caller(1))[3];
    print "* $subname($arg_str)\n";
}


    ##  parse_opts()
    ##  Usage: parse_opts($opt_spec)
    ##  Example invocation:
    ##      usage() and exit(0) unless parse_opts("i:");
    ##  This would set $opt_i.
    ##
sub parse_opts($) {
    my($opt_spec) = @_;

    if (!@ARGV) {
        1;  ##  it's OK if there are no args
    } else {
        my($char, @vars);
        for $char (split //, $opt_spec) {
            if ($char =~ /[a-zA-Z]/) {
                push @vars, '$opt_' . $char;
            } elsif ($char ne ':') {
                warn "Error: parse_opts(): invalid opt spec: $opt_spec\n";
            }
        }

        use Getopt::Std;
        eval "use vars qw(@vars)";
        getopts($opt_spec);
    }
}


    ##  trim - trim leading and trailing whitespace
    ##  usage: trim($str, $str, ...)
sub trim {
    local($_);
    foreach (@_) {
        next unless defined($_);
        s/^\s+//;
        s/\s+$//;
    }
    wantarray ? @_ : "@_";
}


sub untaint {
    my @list = @_;
    local($_);
    for (@list) {
        /(.*)/; $_ = $1;  ##  appease taint mode
    }
    wantarray ? @list : $list[0];
}
1;
##  EOF
