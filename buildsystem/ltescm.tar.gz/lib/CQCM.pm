#!/apps/public/perl_5.8.4/bin/perl
#############################################################################
#
#       Copyright (C) 2010 MOTOROLA. All Rights Reserved.
#
#       The copyright notice above does not evidence any
#       actual or intended publication of such source code.
#       The code contains Motorola Confidential Restricted Information.
#
#############################################################################
#
#  FILE NAME:    CQCM.pm
#
#  OWNER:        LTE SCM Team
#
#  DATE CREATED: 01/28/2010
#
#  SYNOPSIS:     None.
#
#  EXIT VALUE:   1; - Mandatory for module to load successfully
#
#  DESCRIPTION:  This Perl module contains functions and variables used
#                for this specific component of the build automation.
#
#############################################################################
#
#  MODIFICATION HISTORY:
#
# Ver    Date     Engineer     CR                     Change
# --- ---------- ---------- -------------  ---------------------------------------
# 1.0 01/28/2010  amn002     MOTCM01269602  Created initial version.
# 2.0 08/18/2010  amn002     MOTCM01348681  remove print formating.
#
#############################################################################
#
#  FUNCTIONS:  (Alphabetical)
#  
#  valid_cqcm() - pre build CQ and CM activites
#  close_cqcm($) - post build CQ and CM activites
#  
#  LOCAL FUNCTION:
#  get_data_from_DB($);
#  print_BL_data($$);
#  post_verification();
#  compare_DB_and_request($$);
#  close_CRs_and_BLs($);

#############################################################################
package CQCM;

#use strict qw(vars subs);
#use diagnostics;

use 5.8.4;	# Use Perl 5.8.4 or higher (also for debugging purposes)

# use LTE SCM libararies
# MY_CMBP allow to connect and read CQ Database
use MY_CMBP;
# INITIAL parse request 
use INITIAL;
use LTE_BLD_CONF;
use Data::Dumper;
require Exporter;

# Standard global symbols
our (@ISA, @EXPORT);

# Search location for unresolved functions in the current package.
# The search is left to right.
# Exporter is included here because of the import() function.
@ISA = qw(Exporter);

our $objectsRef;
our $reqFile;
our $maillist;		# String of email addresses
## Do not touch the following block of code ##
# This block sets the user and buildVer var for use within this module
my $pkg  = (caller)[0];		# Calling package name
print "PKG: $pkg\n";
# Import exported variables from calling tool
$pkg->import;

#=========================
#== Variable declaration==
#=========================

my $my_cmbp;
my $config;
my $ERROR = 1;
my $CQTOOL = `which cqtool`;
chomp $CQTOOL;
my $BASELINE_TO_CHANGE = "Baseline_to_change";
my $BASELINE_TO_LINK = "Baseline_to_link";
my $EXIST = 1;
my $NON_EXIST = 0;
my $DB_CONSISTENT = "DB_consistent";
my $REQUESTED = "Requested";
my %states = ("Dev-Build" => "Dev-Built", "Ext-Build" => "Ext-Built",
   "Patch-Build" => "Patch-Built", "Int-Build" => "Int-Built", "SCM-Build" =>
   "SCM-Built");
my $INITIAL_STATE = "Initial";

# contains request in special format, content off this 
# file is genereted by Build Reqest Tool 
# top baseline
#==========================
#== Function declaration ==
#==========================

sub valid_cqcm();
sub close_cqcm();

#==========================
#===LOCAL Functions========
#==========================

sub get_data_from_DB($);
sub print_BL_data($$);
sub post_verification();
sub compare_DB_and_request($$);
sub close_CRs_and_BLs($);

#==========================
#==== Constructor==========
#==========================
sub new {
   my $this = shift @_;
   my $class = ref($this) || $this;

	my $baseline = shift @_;
   my $product = shift @_;
   my $debug = shift @_;
   my $REL = "R2.0";
	my $self = {};

   print "PRODUCT = $product\n" if $debug;
   $self->{'Baseline'} = $baseline;
   $self->{'dbg'} = $debug;
   $self->{'return_code'} = 0;
   $self->{'BLs_EXT'} = {};
   $self->{'BLs_CHILD'} = {};
   $self->{'CRs_ALL'} = {};
   $self->{'CQ_BLs'} = {};
   $self->{'CQ_CRs'} = {};
   $self->{DB_EXTENSION} = "";   
   if($baseline =~ /(.+_)?(R\d+\.\d+T?)?(_.+)/) {
        $REL = $2;
        print ("REL = $REL\n") if ($debug);
   }
   else
   {
      print "ERROR: unable to determine REL for Build: $baseline\n";
      return;
   }

   $my_cmbp = new MY_CMBP();
   $config = new LTE_BLD_CONF($product, $baseline, $REL, $debug);
   $self->{'DB_EXTENSION'} = $config->{'db_extension'};
   
   if (!defined $objectsRef->{'INITIAL'}) {
      print "WARNING!: INITIAL is not defined";
   } 
   print Dumper $self if $debug;
   bless $self, $class;

   return $self;
}

#====================================================================
#       Function: valid_cqcm
#====================================================================
# PRE Build module entry criteria
# 1.	Request exist for Baseline into Build Request tool <link>
# 2.	CQCM Baseline record exist for Baseline
# 3.	All necessary EXT Baselines are created and linked to Baseline in CQCM 
# 4.	All necessary EXT Baselines are created and linked to Baseline in Build Request tool
# 5.	All necessary CHILD Baselines are created and linked to Baseline in Build Request tool
# 6.	Predecessor Baseline is set for Baseline in CQCM
#
# PRE Build module 
# 1.	Parse request file to get:
#   a.	Baseline
#   b.	list of targeted CR's 
#   c.	list of CHILD Baselines
#   d.	list of EXT Baselines
#   e.	other options (re-baseline, staged)
#   f.	list of branches to merge (branches of CRs targeted to Baseline and not closed)
# 2.	Verify:
#   a.	if Baseline exits in CQCM. Error if not.
#   b.	if Baseline is not in terminated state. Error if it is.
#   c.	if all CRs requested in Build Request Tool match CRs targeted in CQCM. Error in case any discrepancies in both ways.
#   d.	if all requested CRs are in Perform or Closed state. Error is any is in not correct state.
#   e.	if all EXT Baselines are in Ext-Built state and linked as a Child to the Baseline. Warn if not.
#   f.	if all CHILD Baselines exists. Error if not.
#   g.	if all CHILD Baselines are in terminated state and linked as a CHILD. Warn if not.
# 3.	Print out the report.
# 
# PRE Build module exit criteria
#
# 1.	hash table which contains 
#   a.	Baseline
#   b.	list of targeted CR's 
#   c.	list of CHILD Baselines
#   d.	list of EXT Baselines
#   e.	other options (re-baseline, staged)
#   f.	list of branches to merge (branches of CRs targeted to Baseline and not closed)
#
#====================================================================
sub valid_cqcm()
{
    my $self = shift;
    my $baseline = $self->{'Baseline'};
    my $debug = $self->{'dbg'};
    my $bl_status;
    my $bl_predecessor;
    my %BRs = ();
    my @REQ_CRs =();
    my @request = ();
    my $result = 0;
    
    if(! $my_cmbp->isBaselineExist($baseline)) {
       print "ERROR: Main Baseline $baseline does not exist in Database\n";
       return $ERROR;
    }

    my $initial = $objectsRef->{'INITIAL'};

    $self->{'CRs'}=$initial->{'CRs'};
    $self->{'CRs_ALL'}=$initial->{'CRs_ALL'};
    $self->{'BLs_EXT'}=$initial->{'BLs_EXT'};
    $self->{'BLs_CHILD'}=$initial->{'BLs_CHILD'};

    print "valid_cqcm DUMPER: CQCM.pm\n" if $debug;
    print Dumper $self if $debug;
###### START - move to function
#check if requested Baselines exits in DB
   my $err_ch_bl = "\nThe following CHILD baselines do not exist in Database:\n";
   my $err_ch_cnt = 0;   
   foreach my $BL (keys %{$self->{'BLs_CHILD'}})
   {
    if(! $my_cmbp->isBaselineExist($BL)) {
       $self->{'BLs_CHILD'}->{$BL} = $NON_EXIST;
       $self->{'return_code'} = $ERROR;
       $err_ch_bl .= "$BL\n";
       $err_ch_cnt++;
    }
   }
   $result |= $err_ch_cnt;
   if($err_ch_cnt) {
      print $err_ch_bl;
   }
   my $err_ext_bl = "\nThe following EXT baselines do not exist in Database:\n";
   my $err_ext_cnt = 0;   
  
   foreach my $BL (keys %{$self->{'BLs_EXT'}})
   {
    if(! $my_cmbp->isBaselineExist($BL)) {
       $self->{'BLs_EXT'}->{$BL} = $NON_EXIST;
       $self->{'return_code'} = $ERROR;
       $err_ext_bl .= "$BL\n";
       $err_ext_cnt++;
    }
   }
   if($err_ext_cnt) {
      print $err_ext_bl;
   }
   $result |= $err_ext_cnt;
############## END MOVE
# get DB data for Baseline    
   my @baseline_data = $my_cmbp->getBaselineData($self->{'Baseline'});

   if (defined($baseline_data[0]->{'Identifier'})
         and $baseline_data[0]->{'Identifier'} eq $self->{'Baseline'} )
   {
      $bl_status = $baseline_data[0]->{'Status'};
      $bl_predecessor =  $baseline_data[0]->{'Predecessor_BL'};
      print "BL:$self->{'Baseline'}  State: $bl_status  Predecessor:$bl_predecessor\n" if $debug;
   }
#  verify baseline state
   if ($bl_status ne $INITIAL_STATE)
   {
      print "WARNING: Baseline $self->{'Baseline'} state is: $bl_status instead of Initial\n";
   }
# verify if Predecessor is set. Error if not.
   if(!defined $bl_predecessor or ($bl_predecessor eq ""))
   {
      process_error('mw',
         "Module: CQCM.pm, function: valid_cqcm. ".
         "The Predecessor for build $self->{'Baseline'} is not set.",
         $maillist, "valid_cqcm build warning - predecessor is not set.");
      $result |= $ERROR;
   }

#  compare Database with Request
   my $ret_val = $self->compare_DB_and_request($baseline);
   $result |= $ret_val;

   $self->get_data_from_DB($initial->{'build_kind'});
   print Dumper $self if $debug;
   my $counter = 0;

#  check if requested CRs are in apropriated state
   foreach my $cr (keys %{$self->{CQ_CRs}})
   {
      if(($self->{CQ_CRs}->{$cr}->{State} ne "Closed") and
            ($self->{CQ_CRs}->{$cr}->{State} ne "Performed")) {
         print "This CRs are not in proper state:\n";
         print"\t $self->{CQ_CRs}->{$cr}->{id} State: $self->{CQ_CRs}->{$cr}->{State} Target: $self->{CQ_CRs}->{$cr}->{BL_Actual_Target}\n";
         $counter++;
      }
   }
   $result |= $counter;
   $self->print_BL_data($baseline, "");

   print "res: $result \n";
   return $result;
}

#====================================================================
#       Function: close_cqcm
#====================================================================
# POST Build CQCM entry criteria
# 1.	Baseline exits in CQCM.
# 2.	All requested CRs are in Perform or Closed state.
# 3.	All EXT Baselines exist in CQCM.
# 4.	All CHILD Baselines exists. 
#
#
# POST Build CQCM module 
# 1.	Verify:
#   a.	if Baseline is not in terminated state. Warn if it is.
#   b.	if all CRs requested in Build Request Tool match CRs targeted in CQCM. Error in case any discrepancies in both ways.
#   c.	if Predecessor is set. Error if not.
# 2.	Close all CR's targeted to Baseline.
# 3.	Close CRs targeted to CHILD Baselines - to remove 
# 4.	Close CHILD Baselines
# 5.	Link CHILD Baselines to the Baseline
#     Link Orginal Basline to EXT Baseline as a Child
# 6.	Close EXT Baselines 
# 7.	Link EXT Baselines to the Baseline
# 8.	Close Baseline
# 9.	Print out state of Baseline, CHILD Baselines, EXT Baselines and CRs targeted to them.
# 
# POST Build CQCM module exit criteria
# 1.	Baseline, CHILD Baselines, EXT Baselines are closed.
#
#====================================================================
sub close_cqcm()
{
    my $self = shift @_;
    my $action;
    my $baseline = $self->{'Baseline'};
    my $debug = $self->{'dbg'};
    my $bl_status;
    my $bl_predecessor;
    my %BRs = ();
    my @REQ_CRs =();
    my @request = ();
    my $result = 0;
    
    if(! $my_cmbp->isBaselineExist($baseline)) {
       print "ERROR: Main Baseline $baseline does not exist in Database\n";
       return $ERROR;
    }

    my $initial = $objectsRef->{'INITIAL'};

    $self->{'CRs'}=$initial->{'CRs'};
    $self->{'CRs_ALL'}=$initial->{'CRs_ALL'};
    $self->{'BLs_EXT'}=$initial->{'BLs_EXT'};
    $self->{'BLs_CHILD'}=$initial->{'BLs_CHILD'};

    print "close_cqcm DUMPER: CQCM.pm\n" if $debug;
    print Dumper $self if $debug;
    
#  check if requested Baselines exits in DB
   my $err_ch_bl = "\nThe following CHILD baselines do not exist in Database:\n";
   my $err_ch_cnt = 0;   
   foreach my $BL (keys %{$self->{'BLs_CHILD'}})
   {
    if(! $my_cmbp->isBaselineExist($BL)) {
       $self->{'BLs_CHILD'}->{$BL} = $NON_EXIST;
       $self->{'return_code'} = $ERROR;
       $err_ch_bl .= "$BL\n";
       $err_ch_cnt++;
    }
   }
   if($err_ch_cnt) {
      print $err_ch_bl;
   }
   my $err_ext_bl = "\nThe following EXT baselines do not exist in Database:\n";
   my $err_ext_cnt = 0;   
  
   foreach my $BL (keys %{$self->{'BLs_EXT'}})
   {
    if(! $my_cmbp->isBaselineExist($BL)) {
       $self->{'BLs_EXT'}->{$BL} = $NON_EXIST;
       $self->{'return_code'} = $ERROR;
       $err_ext_bl .= "$BL\n";
       $err_ext_cnt++;
    }
   }
   if($err_ext_cnt) {
      print $err_ext_bl;
   }

# clear data    
   my @baseline_data = $my_cmbp->getBaselineData($self->{'Baseline'});

   if (defined($baseline_data[0]->{'Identifier'})
         and $baseline_data[0]->{'Identifier'} eq $self->{'Baseline'} )
   {
      $bl_status = $baseline_data[0]->{'Status'};
      $bl_predecessor =  $baseline_data[0]->{'Predecessor_BL'};
      print "BL:$self->{'Baseline'}  State: $bl_status  Predecessor:$bl_predecessor\n" if $debug;
   }
#  verify baseline state
   if ($bl_status ne $INITIAL_STATE)
   {
      print "WARNING: Baseline $self->{'Baseline'} state is: $bl_status instead of Initial\n";
   }
# verify if Predecessor is set. Error if not.
   if(!defined $bl_predecessor or ($bl_predecessor eq ""))
   {
      print "WARNING: Predecessor for Baseline: $baseline is not set ";
      $self->{'return_code'} = $ERROR;
   }

#  compare Database with Request
   my $ret_val = $self->compare_DB_and_request($baseline);
   return $ret_val if $ret_val;

#close CRs only when main BL is open, link Baselines, Close BLs
   if($bl_status eq $INITIAL_STATE) {
      $result = $self->close_CRs_and_BLs($baseline);
   } else {
      print "WARNING! Baseline $baseline is already closed, script will only verify Database with Build Request\n\n";
   }

#  when all requested child baselines are linked compare req. with database content.    
   $self->get_data_from_DB($initial->{'build_kind'});
   $self->print_BL_data($baseline, "");
   $result |= $self->post_verification();
   if(!$result){
      print "All CRs are closed and targeted correctly,\nAll Baselines are linked and closed correctly\n";
   }
   return $result;
}


#====================================================================
#    Function: close_CRs_and_BLs()
#====================================================================
sub close_CRs_and_BLs($) {
   my $self = shift @_;
   my $baseline = shift @_;
   my $action;

   if(!( -e $CQTOOL)){
      print "cqtool was not found \n";
      return $ERROR;
   }
# close all requested CRs    
   foreach my $CR (keys %{$self->{CRs_ALL}} ){
      $action = "$CQTOOL closecr -cr $CR ";
      print "$action\n"; 
      system($action);
   }

#close child baselines
   foreach my $BL (keys %{$self->{'BLs_EXT'}})
   {
      if ( $self->{'BLs_EXT'}->{$BL} eq $NON_EXIST) 
      {
         print "EXT baseline $BL:$self->{DB_EXTENSION} not exists in DB so will not be closed \n";
      }
      else
      {
         $action = "$CQTOOL closebl \"$BL:$self->{DB_EXTENSION}\" ";
         print "$action\n";
         system($action);
      }
   }
#close child baselines
   foreach my $BL (keys %{$self->{'BLs_CHILD'}})
   {
      if ( $self->{'BLs_CHILD'}->{$BL} eq $NON_EXIST) 
      {
         print "CHILD baseline $BL not exists in DB so will not be closed \n";
      }
      else
      {
         $action = "$CQTOOL closebl $BL";
         print "$action\n";
         system($action);
      }
   }
# link Ext baseline 
   foreach my $BL (keys %{$self->{'BLs_EXT'}})
   {
      if ( $self->{'BLs_EXT'}->{$BL} eq $NON_EXIST) 
      {
         print "EXT baseline $BL:$self->{DB_EXTENSION} not exists in DB so will not be linked \n";
      }
      else
      {
         $action = "$CQTOOL linkbl $baseline -add -child \"$BL:$self->{DB_EXTENSION}\" ";
         print "$action\n";
         system($action);
      }
   }

# link Child baseline 
   foreach my $BL (keys %{$self->{'BLs_CHILD'}})
   {
      if ( $self->{'BLs_CHILD'}->{$BL} eq $NON_EXIST) 
      {
         print "CHILD baseline $BL not exists in DB so will not be linked \n";
      }
      else
      {
         $action = "$CQTOOL linkbl $baseline -add -child $BL ";
         print "$action\n";
         system($action);
      }
   }
#close 
   if($self->{'return_code'} ne $ERROR)
   {
      $action = "$CQTOOL closebl $baseline ";
      print "$action\n";
      system($action);
   }
   return $self->{'return_code'};  
}
#====================================================================
#    Function: compare_DB_and_request()
#====================================================================
sub compare_DB_and_request($$) {
   my $self = shift @_;
   my $baseline = shift @_;

# get from CQ Database list of CR targeted directly to Baseline
    my @CQ_CRs = $my_cmbp->getTargetedCR($baseline);
    my @CRs_not_req = ();

# go throw CQ CRs and compare this list with Request
    foreach my $cr (@CQ_CRs)
    {
       if($cr =~ /(MOTCM(\d+))/) {
          my $CR = $1;
          if (defined $self->{'CRs_ALL'}->{$CR})
          {
             $self->{'CRs_ALL'}->{$CR} = $self->{'Baseline'};
          }
          else
          {
             push @CRs_not_req, $CR;
          }
       }
    }
    
# check if all CRs are targeted in database  
    my @missing_crs = ();
    foreach my $cr (keys %{$self->{CRs_ALL}}) 
    {
       if ($cr eq $self->{CRs_ALL}->{$cr})
       {
          push @missing_crs, $cr;
       }
    }
    if ($#missing_crs >=0)
    {
       my @missing_crs_data = $my_cmbp->getCRsData(@missing_crs);
       foreach my $cr (@missing_crs_data)
       {
          if(defined $self->{'BLs_CHILD'}->{$cr->{'BL_Actual_Target'}})
          {
             $self->{CRs_ALL}->{$cr->{'id'}} = $cr->{'BL_Actual_Target'};
          }
          if(defined $self->{'BLs_EXT'}->{$cr->{'BL_Actual_Target'}})
          {
             $self->{CRs_ALL}->{$cr->{'id'}} = $cr->{'BL_Actual_Target'};
          }
       }  
    } 
# check if all CRs targeted in DB are requested
    my $cnt1=0; 
    my $err_str = "\nAdditinal CRs are targeted to baseline $baseline in CQ Database:\n";
    foreach my $cr (@CRs_not_req)
    {  
          $cnt1++;
          $err_str = $err_str . "$cr\n";
    }
    print "$err_str" if ($cnt1 > 0);
    
    my $cnt2 = 0;
    $err_str = "\nThis CRs are requested and are not targeted to any requested baseline:\n";
    foreach my $cr (keys %{$self->{'CRs_ALL'}}) 
    {
       if ($cr eq $self->{'CRs_ALL'}->{$cr})
       {
          $cnt2++;
          $err_str = $err_str . "$cr\n";
       }
    }
    print "$err_str" if ($cnt2 > 0);
    if ($cnt1 > 0 or $cnt2 > 0)
    {
       print "\nERROR: discrepancies in CRs reqested and targeted in Database\n";
       return $ERROR;
    }

}
#====================================================================
#    Function: get_data_from_DB()
#====================================================================
#  $self->{CQ_BLs} is hash. Hash keys contains Baseline and subbaselines
#  {Baseline_name} => {Identifier => <value>, 
#                     Baseline_Type => <value>, 
#                     Status => <value>,
#                     Predecessor_BL => <value>,
#                     Parent_BLs => <value> } 
#  $self->{CQ_CRs} is hash. Contains all CRs targeted to Baseline or sub
#  Baseline (except EXT-Baselines). Keys are CR_id
#  {CR_id} => {id => <value>,
#              Headline  => <value>,
#              State  => <value>,
#              BL_Actual_Target  => <value>,
#              CR_branch  => <value>, 
#              CR_branch_state => <value>,
#              SR => <value> }   
#====================================================================
sub get_data_from_DB($)
{
   my $self = shift @_;
   my $bl_kind = shift @_;
   my $debug = $self->{'dbg'};
   
   print "get Data from DB for BASELINE: $self->{'Baseline'}\n" if $debug;
   my $bl = $self->{Baseline};
   my @CRs_arr = $my_cmbp->getTargetedCRData($bl);
   my @BLs;
   my @CRs = ();
   if ($bl_kind eq 'REL') {
      @BLs = $my_cmbp->getBaselinesTree($bl, $bl_kind);
   }else {
      @BLs = $my_cmbp->getBaselinesTree($bl);
   } 
   my $indent = "";
   for (my $index = 0 ; $index <= $#BLs ; $index++)
   {
      my @CRs_arr = $my_cmbp->getTargetedCRData($BLs[$index]->{Identifier});
      
      foreach my $CR (@CRs_arr) {
         push @CRs, $CR;
      }
   }
   foreach (my $i=0; $i <= $#BLs;$i++)
   {
      if (defined $BLs[$i]->{Identifier})
      {
         $self->{'CQ_BLs'}->{$BLs[$i]->{Identifier}} = $BLs[$i];
      }
   }
   foreach (my $i=0; $i <= $#CRs;$i++)
   {
      if (defined $CRs[$i]->{id})
      {
         $self->{'CQ_CRs'}->{$CRs[$i]->{id}} = $CRs[$i];
      }
   }
   return;
}

#====================================================================
#    Function:  print_BL_data()
#====================================================================
# 
#====================================================================
sub print_BL_data($$)
{
   my $self = shift;
   my $bl = shift @_;
   my $indent = shift @_;
   
   my $status = $self->{'CQ_BLs'}->{$bl}->{'Status'};
   my $parent = $self->{'CQ_BLs'}->{$bl}->{'Parent_BLs'};

   print "$indent Baseline: $bl Status: $status Parent_BLs: $parent\n";
   foreach my $cr (keys %{$self->{CQ_CRs}})
   {
      if($self->{CQ_CRs}->{$cr}->{BL_Actual_Target} eq  $bl)
      {
         print"$indent\t $self->{CQ_CRs}->{$cr}->{id} State:  $self->{CQ_CRs}->{$cr}->{State} \n";
      }
   }
   foreach my $baseline (keys %{$self->{CQ_BLs}})
   {
      if($self->{CQ_BLs}->{$baseline}->{Parent_BLs} eq $bl)
      {
         my $ind = $indent."\t";
         $self->print_BL_data($baseline, $ind);
      }
   }
}
#====================================================================
#    Function: post_verification()
#====================================================================
# 
#====================================================================
sub post_verification()
{
   my $self = shift;
   my $err_cnt = 0;

   print "\nLooking for warning or errors:\n";
   if($self->{CQ_BLs}->{$self->{'Baseline'}}->{Status} ne $states{$self->{CQ_BLs}->{$self->{'Baseline'}}->{Baseline_Type}} )
   {   
       print "Baseline $self->{'Baseline'} state is $self->{CQ_BLs}->{$self->{'Baseline'}}->{Baseline_Type}\n";
      $err_cnt++;
   }    
# check if all CHILD Baseline are linked and closed
   foreach my $REQ_BL (keys %{$self->{BLs_CHILD}})
   {
      if (defined $self->{CQ_BLs}->{$REQ_BL})
      {
#         print "SUB Baseline $REQ_BL is linked to $self->{CQ_BLs}->{$REQ_BL}->{Parent_BLs} it state is $self->{CQ_BLs}->{$REQ_BL}->{Status}\n";
         if ($self->{CQ_BLs}->{$REQ_BL}->{Status} ne $states{$self->{CQ_BLs}->{$REQ_BL}->{Baseline_Type}})
         {
            print "SUB Baseline $REQ_BL is not closed, it state is $self->{CQ_BLs}->{$REQ_BL}->{Status} type: $self->{CQ_BLs}->{$REQ_BL}->{Baseline_Type}\n";
            $err_cnt++;
         }
         $self->{CQ_BLs}->{$REQ_BL}->{Requested} = $REQUESTED;
      }
      else
      {
         print "SUB Baseline $REQ_BL is not linked\n";
         $err_cnt++;
      }
   }

   foreach my $REQ_BL (keys %{$self->{BLs_EXT}})
   {
      my $REQ_BL_EXT = $REQ_BL.":".$self->{'DB_EXTENSION'};
      if (defined $self->{CQ_BLs}->{$REQ_BL})
      {
         if ($self->{CQ_BLs}->{$REQ_BL}->{Status} ne $states{$self->{CQ_BLs}->{$REQ_BL}->{Baseline_Type}})
         {
            print "EXT Baseline $REQ_BL is not closed, it state is $self->{CQ_BLs}->{$REQ_BL}->{Status}\n";
            $err_cnt++;
         }
         $self->{CQ_BLs}->{$REQ_BL}->{Requested} = $REQUESTED;
      }elsif(defined $self->{CQ_BLs}->{$REQ_BL_EXT})
      {
         if ($self->{CQ_BLs}->{$REQ_BL_EXT}->{Status} ne $states{$self->{CQ_BLs}->{$REQ_BL_EXT}->{Baseline_Type}})
         {
            print "EXT Baseline $REQ_BL_EXT is not closed, it state is $self->{CQ_BLs}->{$REQ_BL_EXT}->{Status}\n";
            $err_cnt++;
         }
         $self->{CQ_BLs}->{$REQ_BL_EXT}->{Requested} = $REQUESTED;
      }
      else
      {
         print "EXT Baseline $REQ_BL is not linked\n";
         $err_cnt++;
      }
   }
   foreach my $LINKED_BL (keys %{ $self->{CQ_BLs}})
   {
      if(($LINKED_BL ne $self->{'Baseline'}) and 
            (!defined $self->{CQ_BLs}->{$LINKED_BL}->{Requested}))
      {
         print "Baseline: $LINKED_BL is linked but was not requested\n";
         $err_cnt++;
      }
   }
   print "NONE\n" if(! $err_cnt);
   return $err_cnt;
}


1;

# EOF
