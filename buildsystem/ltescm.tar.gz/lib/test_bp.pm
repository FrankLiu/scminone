#!/apps/public/perl_5.8.4/bin/perl
#############################################################################
#
#       Copyright (C) 2006-2010 MOTOROLA. All Rights Reserved.
#
#       The copyright notice above does not evidence any
#       actual or intended publication of such source code.
#       The code contains Motorola Confidential Restricted Information.
#
#############################################################################
#
#  FILE NAME:    test_bp.pm
#
#  OWNER:        LTE SCM Team
#
#  DATE CREATED: 01/13/2009
#
#  SYNOPSIS:     None.
#
#  EXIT VALUE:   1; - Mandatory for module to load successfully
#
#  DESCRIPTION:  This Perl module contains common functions and variables
#                used for building test_bp targets.
#
#############################################################################
#
#  MODIFICATION HISTORY:
#
# Ver    Date     Engineer     CR                     Change
# --- ---------- ---------- -------- ----------------------------------------
# 1.0 01/13/2009 skerr1     01120994 Created initial version based on iDEN
#				     SCM team's product_template.pm.
# 1.1 03/20/2009 skerr1     01167444 Updated template.
# 1.2 08/21/2009 skerr1     01217463 Added multi chassis support. Updated
#                                    template version to 1.3.
# 1.3 11/25/2009 skerr1     01257533 Updated template 1.5.
# 2.0 02/12/2010 skerr1     01269602 Updated template 2.0.
# 2.1 06/14/2010 skerr1     01313325 Updated template 2.3.
# 2.2 07/12/2010 skerr1     01336346 Updated template 2.4.
#
##############################################################################
#
#  FUNCTIONS:  (Alphabetical)
#
#    Local
#    -----
#	createView()		- Build Type-specific create view function
#
#	Always Called if Defined
#	------------------------
#	preBuild()		- Build Type-specific pre build
#	postBuild()		- Build Type-specific post build
#
#       Local Step Functions
#	--------------------
#	postCloseBuild()	- Build Type-specific post close_build
#	postCloseCQCM()		- Build Type-specific post close_cqcm
#	postCompile()		- Build Type-specific post compilation
#	postInstrument()	- Build Type-specific post instrumentation
#	postLabel()		- Build Type-specific post labeling
#	postMerge()		- Build Type-specific post merge
#	postPackage()		- Build Type-specific post packaging
#	postValidCQCM()		- Build Type-specific post valid_cqcm
#	postValidEnv()		- Build Type-specific post valid_env
#	postSSM()		- Build Type-specific post SSM
#
#############################################################################

## DEVELOPMENT NOTES:
#  -----------------
# 1. Any variables global to this package must be declared within the 'our'
#    directive because of the 'strict' pragma.

## CHECKLIST WHEN UPDATING THIS MODULE:
#  -----------------------------------
# 1. Update @EXPORT if created a function or variable to be exported.
# 2. Update 'our' if added a global variable to this module or if a variable
#    needs to be exported. 
# 3. Update the "FUNCTIONS" list in the prologue.
# 4. Update the "MODIFICATION HISTORY" in the prologue.
# 5. Turn Perl diagnostics (use diagnostics;) and strict (use strict;) off
#    before release.

# Used as error checking mechanism: does not allow re-declaration of
# the same variable within the same scope.  For testing purposes only.
# Note: We do not check for strict references in order to access globals from
#       the calling package.
use strict qw(vars subs);
use diagnostics;

# Indicates that the entire library's symbol table or namespace is labeled
# as test_bp.  The compiler will look for any undefined symbols, in the calling
# program, in this package.
package test_bp;

use 5.8.4;	# Use Perl 5.8.4 or higher (also for debugging purposes)
use Data::Dumper; # Used for dumping data structures/debugging

# Used to setup export methods into calling programs.  Allows the use of
# import(), @ISA, @EXPORT, etc., which allows for different ways of exporting
# symbols.
require Exporter;

# Standard global symbols
our (@ISA, @EXPORT);

# Search location for unresolved functions in the current package.
# The search is left to right.
# Exporter is included here because of the import() function.
@ISA = qw(Exporter);

# List of symbols to be exported by :DEFAULT.
# List functions first, then all other symbols.
@EXPORT	  =  qw(postBuild
                postCompile
                postInstrument
                postLabel
                postMerge
                postPackage
                postPCQCM
                postPreCQCM
                postSSM
		preBuild
                
		@bTDirs
		$buildSteps
		%close_build
                %close_cqcm
		$createView
		$defaultBuildVer
		$delivDir
		$httpReleaseLoc
		%labeling
		$logsDir
                %merge
		$metricsDir
		$objectsRef
		%packaging
                %pre_cqcm
		$product
		%project
		$releaseDir
		$SCM_ADMIN_VOB
		%ssm
		$system
		%targets
		$teamEmail
		$templateVersion
		$USE_BUILD_REQ
		%valid_cqcm
		%valid_env
               );

# Package global variables (some are imported from the calling namespace).
our    ($bld,
	@bTDirs,
	@buildSteps,
	$buildVer,
	$buildver,
	%close_build,
	%close_cqcm,
	$COMPILE_METRICS_FH,
	$cp,
	$createView,
	$ct,
	$defaultBuildVer,
	$delivDir,
	$httpReleaseLoc,
	$instr,
	$INSTR_METRICS_FH,
	$kwBin,
	$kwHost,
	$kwPort,
	$kwStates,
	$lcProd,
	$kwRel,
	%labeling,
	$lcSysProd,
	$logsDir,
	$maillist,
        %merge,
        $MERGE_METRICS_FH,
	$metricsDir,
	$objectsRef,
	%packaging,
	$PKG_METRICS_FH,
	$plcode,
	$POSTBLD_METRICS_FH,
	%pre_cqcm,
	$PREBLD_METRICS_FH,
	$product,
	%project,
	$release,
	$releaseDir,
	$scmEmail,
	$SCM_ADMIN_VOB,	
	%ssm,
	$SSM_METRICS_FH,
	$system,
	@targets,
	%targets,
	$teamEmail,
	$templateVersion,
	$timeStamp,
	$tool,
	$USE_BUILD_REQ,
	$USER,
	%valid_cqcm,
	%valid_env,
	$VIEWNAME,
       );

# Mandatory symbols that must be defined in this package include:
#
# $createView		- This is the command to create a view.  The most
#               	  common option is provided (for SCH).
# $defaultBuildVer	- Defined even if it is an empty string.
# $delivDir		- Used for target build deliverable storage.
# $logsDir		- Used for target build logs storage.
# $metricsDir		- Used for target build SCM metrics storage.
# $product		- Product this build type belongs to.
# $releaseDir		- Used for target build scripts.
# $system		- System this build type belongs to.
# $templateVersion	- Version of product_template.pm we are using.
#

# Note that "Instrumentation" in %targets can be set to "{}" if there is no
# defined instrumentation for that particular target.

#============================================================================
#=====================  Exported Variable Initialization  ===================
#============================================================================
#
# Do not use the 'my' directive for those definitions we are using the 'our'
# directive for above.
#

# Version of product_template.pm populated for this build type
$templateVersion = 2.4;

# Insert your default version here.  Leave as '' if your team has no default
# value (note, build will halt if no default value and no version is provided
# on the command line).
$defaultBuildVer = '';

## Do not touch the following block of code ##
# Sets the name of the calling package (tool)
my $pkg   = (caller)[0];		# Calling package name

# Import exported variables from calling package (tool)
$pkg->import;

# Set the default build version (baseline) if not set already.
if (!defined($buildVer) or $buildVer =~ /^\s*$/) {
    $buildVer = $defaultBuildVer;
} # end if (!defined...
##   Do not touch the above block of code   ##

# Ensure case is correct and set the lc version
$buildVer =~ tr/a-z/A-Z/;
($buildver = $buildVer) =~ tr/A-Z/a-z/;

# For LTE create new object to access common build information
eval {
  require "COMMON.pm";  # COMMON module
  COMMON->import;
}; # end eval...

# For LTE process any failure to use COMMON.pm
($@) and process_error('x', "Could not load COMMON.pm.  There is probably a"
    . " syntax error in this file: $@");

# For LTE create new object to access common LTE build information
my $common = new COMMON('LTE_LBL_NAME' => $buildVer, 'PRE_BUILD_MODE' => 0, 'LTE_BLD_VIEW'   => $VIEWNAME);
$objectsRef->{'COMMON'} = $common;

# Set the system, product and releaseDir if the Version is correctly
# formatted.
if ($buildVer =~ m/^([^-]+)-([^_]+)_(R\d+\.\d+)_(BLD|DEVINT|INT|REL)-.*/) {
  $system = $1;
  $product = $2;
  $release = $3; # Root directory for the release content
  $bld = $4;
  $lcProd     = lc($product);
  $lcSysProd = lc($system . $product);          # Lowercase SystemProduct
  $releaseDir = $common->{'LTE_BIN_ROOT'};	# release directory location
  $httpReleaseLoc = $common->{'LTE_HTTP_ROOT'}; # http release link
} else {
  process_error('x', 'Could not determine system, product and release from'
                    ." the passed version: $buildVer.");
} # end if ($buildVer...

# Release directory locations (standard locations provided) created by
# buildProcessor.pl
$delivDir   = "$releaseDir/deliverables";   # Deliverables
$logsDir    = "$releaseDir/logs";           # Log files
$metricsDir = "$releaseDir/metrics";        # Build metrics

# SCH createView basic command
# NOTE We use the non-CQCM makeview here and so we must set a config spec.
#      We do not use the DEVINT/BLD view.
$createView = "/apps/internal/bin/makeview -tag <view>";

# Default build automation steps to execute for this product.
# Note: preBuild, post<Step> and postBuild functions are automatically
# called if defined.
@buildSteps = qw(compile package label instrument ssm);

# For Klocwork
$kwBin = '/apps/vendor/klocwork_8.1.2.10/bin';
$kwHost = 'isdserv0.comm.mot.com';
$kwPort = '1105';
$kwStates = 'new/fixed';
($kwRel = $release) =~ s/\./_/;
$kwRel  = lc($kwRel);                       # Lowercase release used by KW

# Set to true if your team uses the build request tool
$USE_BUILD_REQ = 0;

# Initialize MAKEFLAGS to save us from a concatenation error with strict.
if (not defined $ENV{'MAKEFLAGS'}) { $ENV{'MAKEFLAGS'}=""; }

# Build type-specific definitions

# Set the admin VOB location (env var SCM_ADMIN_VOB overrides the default)
$SCM_ADMIN_VOB = $ENV{'SCM_ADMIN_VOB'} || '/vob/ltewbc';

# Team email list (use \ before @ symbols), comma delimited
$teamEmail = "$ENV{'USER'}\@motorola.com";

# SCM email list
$scmEmail = "$ENV{'USER'}\@motorola.com"; 

# Build type-specific directories to be created by buildProcessor.pl.
# Add directories your builds need here.
@bTDirs = ("$logsDir/compile",
           "$logsDir/instrumentation",
           "$logsDir/label",
           "$logsDir/merge",
           "$logsDir/other",
           "$logsDir/packaging",
           "$logsDir/post_build",
           "$logsDir/pre_build",
           "$logsDir/ssmt",
           "$delivDir/1440",
          );

#============================================================================
#================================  CONFIG  ==================================
#============================================================================

# Setup for Environment validation
#  Checks for 'buildSize' FA space
#  Checks for 'buildSize' View space
%valid_env = (
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {},
    'logging'    => 1,
    'logFile'    => "${logsDir}/pre_build/${lcProd}-${buildVer}-valid_env"
                  . "_log_${timeStamp}.txt",
    # Size of the average build in MB.  Used to check for sufficient space.
    'buildSize'  => 3000,
); # end of valid_env configuration


# Setup for CQCM validation
%valid_cqcm = (
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {},
    'logFile'    => "${logsDir}/other/${lcProd}-${buildVer}-valid_cqcm"
                  . "_log_${timeStamp}.txt",
); # end of valid_cqcm configuration


# Setup for merging
# Support merge and tracemerge functions, plus custom functions.
# merge: Merges necessary branches based on build request or predefined list.
#   For REL builds, checks REL and BLD content is identical
# tracemerge: Executes tracemerge/cmbp_report checks
%merge = (
    'view'       => '',
    'configSpec' => '',
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {'PATH' => "/vob/ltescm/bin:$ENV{'PATH'}"},
    'logging'    => 1,
    'logFile'    => "${logsDir}/merge/${lcProd}-${buildVer}-merge"
                  . "_log_${timeStamp}.txt",
    'functions'  => ['merge', 'tracemerge',],
); # end of merge configuration


# Define the build targets
#  Each target is comprised of user defined build commands
#  Each target can have multiple defined instrumentation types
%targets = (

    'wbcnib' => {

        'build' => {
            'view'       => "wbcnib_${buildVer}",
            'configSpec' => "${logsDir}/${buildVer}_cs.wri",
            'startDir'   => '/vob/ltewbc/bld/wuce/bin',
            'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
				       . ':/sbin:/usr/sbin:/usr/atria/bin:.'
				       . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
			     'WUCE' => '/vob/wuce/wuce/bin/wuce',
			     'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
			    },
            'logging'    => 1,
            'buildLog'   => "${logsDir}/compile/wbcnib-${buildVer}-build"
                            . "_log_${timeStamp}.txt",
            'buildCMDs'  =>
		['echo Starting....','sleep 5','echo Error!','exit 0',
		]
        },


        'instrument' => {
            'Klocwork' => {
                'view'       => "wbcnibKW_${buildVer}",
                'configSpec' => "${logsDir}/${buildVer}_cs.wri",
                'startDir'   => '/vob/ltewbc/bld/wuce/bin',
                'envVars'    => {'PATH' => "$kwBin:/apps/vendor/bin:/usr/bin:/bin:"
    				       . '/etc:/sbin:/usr/sbin:/usr/atria/bin:.'
    				       . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
    			         'WUCE' => '/vob/wuce/wuce/bin/wuce',
    			         'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
    			        },
                'logging'    => 1,
                'buildLog'   => "${logsDir}/instrumentation/wbcnib-${buildVer}-kw"
                            . "_log_${timeStamp}.txt",
                'buildCMDs'  =>
		  ['echo Starting....','sleep 10','echo Finished!',
		  ]
            }
        }
    },

    'wbcwab' => {

        'build' => {
            'view'       => "wbcwab_${buildVer}",
            'configSpec' => "${logsDir}/${buildVer}_cs.wri",
            'startDir'   => '/vob/ltewbc/bld/wuce/bin',
            'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
				       . ':/sbin:/usr/sbin:/usr/atria/bin:.'
				       . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
			     'WUCE' => '/vob/wuce/wuce/bin/wuce',
			     'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
			    },
            'logging'    => 1,
            'buildLog'   => "${logsDir}/compile/wbcwab-${buildVer}-build"
                            . "_log_${timeStamp}.txt",
            'buildCMDs'  =>
		['echo Starting....','sleep 15','echo Finished!','exit 0',
		]
        },


        'instrument' => {
            'Klocwork' => {
                'view'       => "wbcwabKW_${buildVer}",
                'configSpec' => "${logsDir}/${buildVer}_cs.wri",
                'startDir'   => '/vob/ltewbc/bld/wuce/bin',
                'envVars'    => {'PATH' => "$kwBin:/apps/vendor/bin:/usr/bin:/bin:"
    				       . '/etc:/sbin:/usr/sbin:/usr/atria/bin:.'
    				       . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
    			         'WUCE' => '/vob/wuce/wuce/bin/wuce',
    			         'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
    			        },
                'logging'    => 1,
                'buildLog'   => "${logsDir}/instrumentation/wbcwab-${buildVer}-kw"
                            . "_log_${timeStamp}.txt",
                'buildCMDs'  => 
		  ['echo Starting....','sleep 20','echo Finished!', 'exit 0',
		  ]
            }
        }
    },

    'wbcssc' => {

        'build' => {
            'view'       => "wbcssc_${buildVer}",
            'configSpec' => "${logsDir}/${buildVer}_cs.wri",
            'startDir'   => '/vob/ltewbc/bld/wuce/bin',
            'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
				       . ':/sbin:/usr/sbin:/usr/atria/bin:.'
				       . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
			     'WUCE' => '/vob/wuce/wuce/bin/wuce',
			     'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
			    },
            'logging'    => 1,
            'buildLog'   => "${logsDir}/compile/wbcssc-${buildVer}-build"
                            . "_log_${timeStamp}.txt",
            'buildCMDs'  =>
		['echo Starting....','sleep 15','echo Finished!','exit 0',
		]
        },


        'instrument' => {
            'Klocwork' => {
                'view'       => "wbcsscKW_${buildVer}",
                'configSpec' => "${logsDir}/${buildVer}_cs.wri",
                'startDir'   => '/vob/ltewbc/bld/wuce/bin',
                'envVars'    => {'PATH' => "$kwBin:/apps/vendor/bin:/usr/bin:/bin:"
    				       . '/etc:/sbin:/usr/sbin:/usr/atria/bin:.'
    				       . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
    			         'WUCE' => '/vob/wuce/wuce/bin/wuce',
    			         'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
    			        },
                'logging'    => 1,
                'buildLog'   => "${logsDir}/instrumentation/wbcssc-${buildVer}-kw"
                            . "_log_${timeStamp}.txt",
                'buildCMDs'  =>
		  ['echo Starting wbcssc KW....','sleep 20','echo Finished!',
		  ]
            },
        }
    },
); # end of builds definition


# Setup for creating the final package
#  User defined packaging commands
%packaging = (
    'view'       => "wbcssc_${buildVer}",
    'configSpec' => "${logsDir}/${buildVer}_cs.wri",
    'startDir'   => '/vob/ltewbc/bld/wuce/bin',
    'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
    				       . ':/sbin:/usr/sbin:/usr/atria/bin:.'
    				       . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
                    },
    'logging'    => 1,
    'logFile'    => "${logsDir}/packaging/${lcProd}-${buildVer}-pkg"
                  . "_log_${timeStamp}.txt",
    'CMDs'       => ['echo Starting EMS Packaging123....','sleep 10','echo Finished!',
                    ],
); # end of packaging configuration


# Setup for applying the ClearCase label
#  Default is lte_label.pl tool which labels CLEARCASE_AVOBS in
#    parallel
#  User may define any labeling commands/tools they wish
%labeling = (
    'view'       => '',
    #'view'       => "wbcssc_${buildVer}",
    'configSpec' => '',
    #'configSpec' => "${logsDir}/${buildVer}_cs.wri",
    'startDir'   => '/vob/ltewbc/bld/wuce/bin',
    'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
    				       . ':/sbin:/usr/sbin:/usr/atria/bin:.'
    				       . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
                    },
    'logging'    => 1,
    'logFile'    => "${logsDir}/label/${lcProd}-${buildVer}-label"
                  . "_log_${timeStamp}.txt",
    'CMDs'       => ['echo Starting Labeling123....','sleep 10','echo Finished!',
                    ],
); # end of labeling configuration


# Setup for post CQCM checks and closure
%close_cqcm = (
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {},
    'logFile'    => "${logsDir}/other/${lcProd}-${buildVer}-close_cqcm"
                  . "_log_${timeStamp}.txt",
); # end of close_cqcm configuration


# Setup for prj file creation
# You can specify your own project directory, exclude lines from the current
# view's configuration of specification, set the group your prj file should
# be created with and identify whether or not your prj file should be created
# as a VOB element.
%project = (
    'projDir'    => "", # If not defined in LTE_BLD_CONF.pm
    'in_vob'	 => 1,
    'newgrp'	 => "il02-ltescm",
    'logFile'    => "${logsDir}/other/${lcProd}-${buildVer}-project"
                  . "_log_${timeStamp}.txt",
    'exlcude_lines' => [],
); # end of project configuration


# Setup for closing the build
#  Execute the lte_bld_report.pl
#  Sends release email
%close_build = (
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {},
    'logging'    => 1,
    'logFile'    => "${logsDir}/post_build/${lcProd}-${buildVer}-close_build"
                  . "_log_${timeStamp}.txt",
); # end of close_build configuration


# Setup for source size metrics calcuation and upload
#  Default is to run ssmt.pl
#  User may define any SSM commands/tools they wish
%ssm = (
    'view'       => "wbcssc_${buildVer}",
    'configSpec' => "${logsDir}/${buildVer}_cs.wri",
    'server'     => 'ltesol1',
    'startDir'   => '/vob/ltewbc/bld/wuce/bin',
    'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
    				       . ':/sbin:/usr/sbin:/usr/atria/bin:.'
    				       . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
                    },
    'logging'    => 1,
    'logFile'    => "${logsDir}/ssmt/${lcProd}-${buildVer}-ssm"
                  . "_log_${timeStamp}.txt",
    'CMDs'       => ['echo Starting SSM123....','sleep 10','echo Finished!',
                    ],
); # end of ssm configuration


#============================================================================
#==============================  FUNCTIONS  =================================
#============================================================================

## Note(s):
## Besides the functions shown below, we have the following post<Step>
## functions availble: postValidEnv, postValidCQCM, postMerge, postCompile,
## postPackage, postLabel, postCloseCQCM, postCloseBuild, postInstrument, and
## postSSM.  Also, please note:
##      o Each function must be added to the list of symbols to be exported.
##      o Each defined function is automatically called after the
##        corresponding step (e.g. postCompile after compile, postSSM after
##        ssm etc).
##
## To execute a system command, please use execWMetrics so SCM metrics will
## be written for any failure.  For more info on this function, see
## buildProcessor.pl.

## Available functions provided by buildProcessor.pl:
##	<Name>		- <Where defined>
##	execWMetrics	- buildProcessor.pl
##      logMetrics	- buildProcessor.pl
##	print_and_log	- SCM_common.pm
##	process_error	- SCM_common.pm
##	time		- POSIX
##	write_to_script	- SCM_common.pm
##
## The SCM_common.pm API is here:
## http://compass.mot.com/go/lte_scm_common_api.doc


## Define "createView" to override the default createView behavior
#sub createView {
#} # end sub createView


## Define "preBuild" for any team-specific pre-build activities to be called
## by buildProcessor.pl.
## Notes: Will be called prior to any target processing.
##        This symbol must be added to the list of symbols to be exported.
sub preBuild {
    my $cmd     = '';        # Command we plan to execute
    my $sTime   = time();    # Current time (seconds) for metrics purposes
    
    ## Save the config spec and set the wuce version if set into a view
    if (defined $ENV{'CLEARCASE_ROOT'}) {

      ## Save the config spec
      $cmd = "$ct catcs > ${logsDir}/${buildVer}_cs.wri";
      print_and_log($plcode, "Executing: $cmd\n\n");

      execWMetrics($cmd, $PREBLD_METRICS_FH, $sTime);

    } else { # Not set into a view
      process_error('mx',
         "You are not set into a view, so ${tool} cannot save the config "
         . "spec or update the WUCE version.\n", $maillist,
         "$tool failure (PID $$)");         
    } # end if (defined $ENV...

} # end sub preBuild


## Define "postCompile" for any team-specific post-build activities to be
## called by buildProcessor.pl.
## Notes: Will be called after all target processing is complete.
##        This symbol must be added to the list of symbols to be exported.
sub postCompile {
    my $cmd     = '';        # Command we plan to execute
    my $pkgdir  = "$SCM_ADMIN_VOB/bld/pkg"; # The package staging area
    my $sTime   = time();    # Current time (seconds) for metrics purposes


    # Allow the user to set the env var BP_SKIP_FINAL_PKG if they want to
    # skip packaging for this execution of buildProcessor.pl.
    unless ($ENV{'BP_SKIP_FINAL_PKG'}) {

        sleep 5;
	if (-f "tmp1") { unlink("tmp1"); }
        execWMetrics("echo \"\nTESTING TESTING 123\n\" > tmp1; exit 0",
                     $COMPILE_METRICS_FH, $sTime);

    } # end unless ($ENV{'BP_SKIP_FINAL_PKG'}...
        
} # end sub postCompile

sub postBuild {
  my $tempvar123 = "";
}

1;

# EOF
