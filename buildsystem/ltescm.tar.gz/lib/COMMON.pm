package COMMON;

#############################################
# Library for common functions accross LTE
#############################################


########################################
# check environment variable
########################################

BEGIN {
   if (defined($ENV{LTE_BLDTOOLS})){
	   unshift @INC, "$ENV{LTE_BLDTOOLS}/../lib", "$ENV{LTE_BLDTOOLS}", "$ENV{LTE_BLDTOOLS}/enodeb";
   } elsif (defined($ENV{SCM_BLDTOOLS})) {
	   unshift @INC, "$ENV{SCM_BLDTOOLS}", "$ENV{SCM_BLDTOOLS}/..", "$ENV{SCM_BLDTOOLS}/../../lib";
   } else {
	   unshift @INC,"/vob/ltescm/bin","/vob/ltescm/lib","/vob/ltescm/bin/enodeb";
   }
}

####################
# import modules
####################
use Data::Dumper;
use LTE_BLD_CONF;
use MY_CMBP;
use strict qw(vars subs);
use diagnostics;

################################
# import name space form caller
################################
require Exporter;

# Standard global symbols
our (@ISA, @EXPORT);

# Search location for unresolved functions in the current package.
# The search is left to right.
# Exporter is included here because of the import() function.
@ISA = qw(Exporter);
#@EXPORT	  =  qw(write_to_script);
## Do not touch the following block of code ##
# This block sets the user and buildVer var for use within this module
my $pkg  = (caller)[0];		# Calling package name
# Import exported variables from calling tool
$pkg->import;

####################
# functions
####################
sub clean_view($);
sub find_predecessor($);
sub sendEmail($);
sub print_config_spec();
sub print_up_rev();
sub makeMail_build_is_avaliable();
sub create_dev_project();
#sub write_to_script($$$$);
####################
# globals
####################
my $CLEARTOOL = "/usr/atria/bin/cleartool";
my $SCM_BLDTOOLS = defined ($ENV{SCM_BLDTOOLS}) ? $ENV{SCM_BLDTOOLS} : "" ;
my $debug=0;
my $debug_pl = 0;
my $config;
my @exclude_array = qw(LTE-ENB_HOST-TEST_PREBLD);


####################
# constructor
####################

sub new {
   my $this = shift @_;
   my $class = ref($this) || $this;
   my %initParams = @_;
   my $self = { %initParams };
   $debug = $ENV{'DEBUG'};
   if (defined($ENV{'DEBUG_PL'})) {
   $debug_pl = $ENV{'DEBUG_PL'};
   print "Environment set to Poland \n";
   }
   bless $self, $class;
   print "\nnew COMMON.pm\n" if $debug;
   print Dumper $self if $debug;
#   print "LABEL:$self->{'LTE_LBL_NAME'}\n";
   $self = {$self->parse_LABEL()};
   print Dumper $self if $debug;

   $config = new LTE_BLD_CONF($self->{'PRODUCT'},$self->{'LTE_LBL_NAME'},$self->{'RELEASE'},$debug);
   $self->{'LTE_LOG_ROOT'} = $config->{'unix_deliverable_path'}.$self->{'LTE_LBL_NAME'}."/logs";
   $self->{'LTE_DIR_ROOT'} = $config->{'unix_deliverable_path'}.$self->{'LTE_LBL_NAME'};
   $self->{'LTE_BIN_ROOT'} = $config->{'unix_deliverable_path'}.$self->{'LTE_LBL_NAME'};
   $self->{'LTE_HTTP_ROOT'} = $config->{'http_deliverable_path'}.$self->{'LTE_LBL_NAME'};
   $self->{'config'} = $config;

   bless $self, $class;
   return $self;
}

sub DESTROY {
#   print "COMMON.pm Destructor body\n" if $debug;
}


####################
sub parse_LABEL()
{
    my $self = shift;
    print "Parse Label\n" if $debug;
    my $label = (defined $self->{'LTE_LBL_NAME'}) ? $self->{'LTE_LBL_NAME'} : "";
    my $view = (defined $self->{'LTE_BLD_VIEW'}) ? $self->{'LTE_BLD_VIEW'} : "";
    my $branch = (defined $self->{'LTE_BRANCH'}) ? $self->{'LTE_BRANCH'} : $view;
    my $predecessor = (defined $self->{'LTE_PREV_LBL_NAME'}) ? $self->{'LTE_PREV_LBL_NAME'} :find_predecessor($label) ;
    my $system = (defined $self->{'SYSTEM'}) ? $self->{'SYSTEM'} : "" ;
    my %lte_env;

#    print "LABEL:$label\n";
    $label =~ tr/a-z/A-Z/;
    $predecessor =~ tr/a-z/A-Z/;

    if ($label =~ /(^LTE-(.+)?_(.*)?_(.+)?-(0)*?(\d*)?\.(\d)*?(\d*)?)\.(\d)*?(\d)?$/) {
		($view = $1) =~ tr/A-Z/a-z/ if ($view eq "");
      	$branch = $view if ($branch eq "");
      	(my $release = $3) =~ tr/A-Z/a-z/;
      	%lte_env = (
			'LTE_REL_LINE'     => "LTE-$2_$3",
			'LTE_BLD_VIEW'     => "$view",
			'LTE_LBL_NAME'     => "$label",
			'LTE_LBL_VIEW'     => "$view",
			'LTE_BRANCH'       => "$branch",
			'LTE_PREV_LBL_NAME'=> "$predecessor",
			'LTE_LOG_ROOT'     => "",
			'BRANCH_TO_MERGE'  => "",
			'BRANCHLIST'       => "",
			'CRLIST'           => "",
			'LTE_DIR_ROOT'     => "",
			'LTE_BIN_ROOT'     => "",
			'RELEASE'          => "$3",
			'release'          => "$release",
			'PRODUCT'          => "LTE-$2",
			'BUILD_KIND'       => "$4"
			);

    } elsif ($label =~ /(^LTE-(.+)?_(.*)?_(.+)?-(0)*?(\d*)?\.(\d)*?(\d*)?)$/) {
     	($view = $1) =~ tr/A-Z/a-z/ if ($view eq "");
      	$branch = $view if ($branch eq "");
      	(my $release = $3) =~ tr/A-Z/a-z/;
      	%lte_env = (
			'LTE_REL_LINE'     => "LTE-$2_$3",
			'LTE_BLD_VIEW'     => "$view",
			'LTE_LBL_NAME'     => "$label",
			'LTE_LBL_VIEW'     => "$view",
			'LTE_BRANCH'       => "$branch",
			'LTE_PREV_LBL_NAME'=> "$predecessor",
			'LTE_LOG_ROOT'     => "",
			'BRANCH_TO_MERGE'  => "",
			'BRANCHLIST'       => "",
			'CRLIST'           => "",
			'LTE_DIR_ROOT'     => "",
			'LTE_BIN_ROOT'     => "",
			'RELEASE'          => "$3",
			'release'          => "$release",
			'PRODUCT'          => "LTE-$2",
			'BUILD_KIND'       => "$4"
			);
     } elsif ($label =~ /(^MMS-(.+)?_(.*)?_(.+)?-(0)*?(\d*)?\.(\d)*?(\d*)?)\.(\d)*?(\d)?$/) {
        ($view = $1) =~ tr/A-Z/a-z/ if ($view eq "");
      	$branch = $view if ($branch eq "");
      	(my $release = $3) =~ tr/A-Z/a-z/;
      	%lte_env = (
			'LTE_REL_LINE'     => "MMS-SE-$2_$3",
			'LTE_BLD_VIEW'     => "$view",
			'LTE_LBL_NAME'     => "$label",
			'LTE_LBL_VIEW'     => "$view",
			'LTE_BRANCH'       => "$branch",
			'LTE_PREV_LBL_NAME'=> "$predecessor",
			'LTE_LOG_ROOT'     => "",
			'BRANCH_TO_MERGE'  => "",
			'BRANCHLIST'       => "",
			'CRLIST'           => "",
			'LTE_DIR_ROOT'     => "",
			'LTE_BIN_ROOT'     => "",
			'RELEASE'          => "$3",
			'release'          => "$release",
			'PRODUCT'          => "MMS-$2",
			'BUILD_KIND'       => "$4"
			);

     } elsif ($label =~ /(^OMP-(.+)?_(.*)?_(.+)?-(0)*?(\d*)?\.(\d)*?(\d*)?)\.(\d)*?(\d)?$/) {
        ($view = $1) =~ tr/A-Z/a-z/ if ($view eq "");
      	$branch = $view if ($branch eq "");
      	(my $release = $3) =~ tr/A-Z/a-z/;
      	%lte_env = (
			'LTE_REL_LINE'     => "OMP-$2_$3",
			'LTE_BLD_VIEW'     => "$view",
			'LTE_LBL_NAME'     => "$label",
			'LTE_LBL_VIEW'     => "$view",
			'LTE_BRANCH'       => "$branch",
			'LTE_PREV_LBL_NAME'=> "$predecessor",
			'LTE_LOG_ROOT'     => "",
			'BRANCH_TO_MERGE'  => "",
			'BRANCHLIST'       => "",
			'CRLIST'           => "",
			'LTE_DIR_ROOT'     => "",
			'LTE_BIN_ROOT'     => "",
			'RELEASE'          => "$3",
			'release'          => "$release",
			'PRODUCT'          => "OMP-$2",
			'BUILD_KIND'       => "$4"
			);
     }
     elsif ($label =~ /^([^-]+)-([^_]+)_(R\d+\.\d+)_(BLD|DEVINT|INT|REL)-.*/){
      	(my $release = $3) =~ tr/A-Z/a-z/;
         print "NOTE!: Due to the label type: $label will be parsed with the use of simplified rules\n";
         if (!defined $system or $system eq "") {
            $system = $1;
            print "WARNING!: System is not defined and bacause of label type can be determined >$system< will be used as a system\n";
         }
      	%lte_env = (
			'LTE_REL_LINE'     => "$system-$2_$3",
			'LTE_BLD_VIEW'     => "$view",
			'LTE_LBL_NAME'     => "$label",
			'LTE_LBL_VIEW'     => "$view",
			'LTE_BRANCH'       => "$branch",
			'LTE_PREV_LBL_NAME'=> "$predecessor",
			'LTE_LOG_ROOT'     => "",
			'BRANCH_TO_MERGE'  => "",
			'BRANCHLIST'       => "",
			'CRLIST'           => "",
			'LTE_DIR_ROOT'     => "",
			'LTE_BIN_ROOT'     => "",
			'RELEASE'          => "$3",
			'release'          => "$release",
			'PRODUCT'          => "$system-$2",
			'BUILD_KIND'       => "$4"
			);
       print Dumper \%lte_env if $debug;
     } else {
       print Dumper $self;
       %lte_env = %$self;
       print "\nERROR! COMMON.pm unable to parse label: $label\n";
    }
    print Dumper \%lte_env if $debug;
    print "end of parsing label \n" if $debug;
    return %lte_env;
}


####################
sub clean_view($)
{
    my $self = shift;
    my $view = shift;

    print "Cleaning out view $view\n";
    print "Checking checked out files  ....\n";
    my $action = "$CLEARTOOL setview -exec \"$SCM_BLDTOOLS/enb_findco\" $view";
    system("$action");
    print "Removing view private files ....\n";
    $action = "$CLEARTOOL setview -exec \"$SCM_BLDTOOLS/rm_all_private.pl -u\" $view";
    system("$action");
}

####################
sub find_predecessor($)
{
#    my $self = shift;
   (my $build = shift) =~ tr/a-z/A-Z/;
   my $predecessor = "";

   my $my_cmbp = new MY_CMBP();
   if($my_cmbp->isBaselineExist($build)) {
	  my @predecessor_tbl = $my_cmbp->getBaselineData($build);
	  $predecessor = $predecessor_tbl[0]->{'Predecessor_BL'} if ((defined $predecessor_tbl[0]->{'Predecessor_BL'}))
   }
   return $predecessor if ((defined $predecessor) && ($predecessor ne ""));

   my $tmp_len;
   if ($build =~ /(^LTE-(.+)?_(.+)?_(.+)?-(\d+)?\.(\d+)?)\.(\d+)?$/) {
      my $tmp1 =$7;
      my $tmp2 =$6;
      if ($tmp1 >= 1) {
         $tmp_len = length($tmp1);
         --$tmp1;
         $tmp1 = "0".$tmp1 if (length($tmp1) < $tmp_len );
         $predecessor = $1.".".$tmp1;
      } elsif ( $tmp2 >= 1) {
         $tmp_len = length($tmp2);
         --$tmp2;
         $tmp2 = "0".$tmp2 if (length($tmp2) < $tmp_len);
         $predecessor = "LTE-$2_$3_REL-$5.$tmp2.00";
      } else {
         print "WARNING: Predecessor is not given and can't to be found\n";
         $predecessor = "$build";
      }
   } elsif ($build =~ /(^LTE-(.*)?_(.*)?_(.+)?-(\d+)?)\.(\d+)?$/) {
      my $tmp1 =$6;
      my $tmp2 = $5;
      if ($tmp1 >= 1) {
         $tmp_len = length($tmp1);
         --$tmp1;
         $tmp1 = "0".$tmp1 if (length($tmp1) < $tmp_len);
         $predecessor = $1.".".$tmp1;
      } elsif ($tmp2 >= 1) {
         $tmp_len = length($tmp2);
         --$tmp2;
         $tmp2 = "0".$tmp2 if (length($tmp2) < $tmp_len);
         $predecessor = "LTE-$2_$3_REL-$tmp2.00";
      } else {
         print "WARNING: Predecessor is not given and can't to be found\n";
         $predecessor = "$build";
      }
   } else {
      print "WARNING: Predecessor is not given and can't to be found\n";
      $predecessor = "$build";
   }
   $predecessor =~ tr/a-z/A-Z/;
   print "Predecessor is : $predecessor\n" if $debug;
   return $predecessor;
}

####################
sub sendEmail($)
{
    my $self = shift;
    my $mailfile = shift;
#    my $maillist = shift;
    my $pre_build_mode = shift@_;
    print "PRE_BUILD_MODE::: $pre_build_mode\n";
    $pre_build_mode = 1 if ((defined $pre_build_mode) && ($pre_build_mode ne 0));
    print "PRE_BUILD_MODE::: $pre_build_mode\n";
    my $maillist = $config->{'email_notyfication_list'};
    # if ((! defined $maillist) or ($mailist =~ //));
    if (open ( MAIL_FILE , "<$mailfile")) {
		  if ($self->{'PRODUCT'} eq "OMP-OMP4G") {
			  my $bsf_count = `wc -l $self->{'LTE_DIR_ROOT'}/bandbcu3_isdlinux.bsf |awk '{print \$1}'|sed 's% %%g'`;
			  print "wc -l $self->{'LTE_DIR_ROOT'}/bandbcu3_isdlinux.bsf |awk '{print $1}'|sed 's% %%g'\n";
			  $bsf_count =~ s/^\s+//; $bsf_count =~ s/\s+$//;
			  my $s = "s" if ($bsf_count >1);
			  system ("/bin/mail -s \"$self->{LTE_LBL_NAME} : $bsf_count build script failure$s\" $maillist < $mailfile");
  		} elsif ($pre_build_mode) {
     		system ("/bin/mail -s \"PRE build $self->{LTE_LBL_NAME} is now available\" $maillist < $mailfile");
		  } else {
     		system ("/bin/mail -s \"$self->{LTE_LBL_NAME} is now available\" $maillist < $mailfile");
		  }
    } else {
     print "I'm not able to open file $mailfile\n";
    }
}


####################
sub print_config_spec()
{
    my $self = shift;
    my $exclude_lines = [];
    $exclude_lines = shift;
    my $pre_build_mode =0;
    $pre_build_mode = shift;
#    print Dumper $self;
    my $view = $self->{LTE_BLD_VIEW};
    my $label = $self->{LTE_LBL_NAME};
    if (( $self->{PRODUCT} eq "LTE-ENB" ) &&( $self->{release} eq "r2.0" ) ) {
      if (( $self->{'LTE_LBL_NAME'} =~ /(.+)\.(\d+)?\.(\d+)?$/ ) ) {
	if (($2 < 70) && (($2 - 50)> 0)) {
		my $tmp = $2 - 50;
		$tmp    = "0" . "$tmp" if ( length($tmp) == 1 );
		$label  = "$1.$tmp.$3";
	}
      }
    }
    $label = $label."_BLD-TEST" if $pre_build_mode;
    my $release = $self->{release};
    my $RELEASE = $self->{RELEASE};
    (my $label_line = $label) =~ s/-\d+?\.\d+?\.\d+//;
    my @config_spec = `$CLEARTOOL catcs -tag $view`;
    my @new_config_spec;
    push @new_config_spec, "element * $label";
    foreach my $line (@config_spec) {
      $line =~ s/\s+$//;
      if (!(($line =~ /CHECKEDOUT/) || ($line =~ /main\/0/) || ($line =~ /element \* \/main\/LATEST/) || ($line =~ /lte_$release-main\/LATEST/) || ($line =~ /$view/) || ($line =~ /$label/) || ($line =~ /$label_line/) || ($line =~ /element \* $RELEASE/) || ($line =~ /lost\+found/) || ($line =~ /mkbranch/) ||($line =~ /--------/))) {
	  my $line_ok = 1;
          foreach my $excl_line (@$exclude_lines) {
            if ($line =~ /$excl_line/) {
	       $line_ok = 0;
	       next;
            }
          }
          push @new_config_spec, "$line" if $line_ok;
	  next;
      }
    }
    return @new_config_spec;

}



####################
sub print_up_rev()
{
  my $self = shift;
  print Dumper $config if $debug;
  my $project_file = $config->{'dev_project_path'}."/".$self->{'LTE_LBL_NAME'}.".prj";
  my $pred_project_file = $config->{'dev_project_path'}."/".$self->{'LTE_PREV_LBL_NAME'}.".prj";
  $project_file = "/vob/ltescm/enodeb/cqcm_project/LTE_ENB_projects/".$self->{'LTE_LBL_NAME'}.".prj" if ($debug_pl);
  $pred_project_file = "/vob/ltescm/enodeb/cqcm_project/LTE_ENB_projects/".$self->{'LTE_PREV_LBL_NAME'}.".prj" if ($debug_pl);
  print "WARNING: Unable to find $project_file\n" if !(-e $project_file);
  print "WARNING: Unable to find $pred_project_file\n" if !(-e $pred_project_file);
  my @diff_table = `/usr/bin/diff -w -u -U 120 $project_file $pred_project_file`;
  my $up_rev = {};

  foreach my $line (@diff_table){
    chomp($line); $line =~ s/\"|\\n" \.//g;
    print "up_rev line = $line\n" if $debug;
    if ($line =~ /^(.*)?element(\s+)(.+)?(\s+)(.+)(\s*)$/) {
      my $baseline = $5;
      print "baseline = $baseline\n" if $debug;
      if (!(($baseline =~ /main\//) || ($baseline =~ /$self->{'LTE_LBL_NAME'}/) || ($baseline =~ /nocheckout/) || ($baseline =~ /none/) || ($baseline =~ /^\s*$/))) {
        if ($line =~/^-/) {
	  if ($baseline =~ /^WBTS-PHY-/) {
	    $up_rev->{"<a href=http://cbtspscm.ftw.mot.com/cgi-bin/get/rfmod_recipe.cgi?fru=BCU3MDM&bucket=2_0>$baseline</a>"} = "CHANGED";
	  } else {
            $up_rev->{$baseline} = "CHANGED";
	  }
          next;
        } elsif ($line =~ /^\+/) {
          next;
        } else {
	  if ($baseline =~ /^WBTS-PHY-/) {
            $up_rev->{"<a href=http://cbtspscm.ftw.mot.com/cgi-bin/get/rfmod_recipe.cgi?fru=BCU3MDM&bucket=2_0>$baseline</a>"} = "SAME   ";
	  } else {
            $up_rev->{$baseline} = "SAME   ";
	  }
          next;
        }
      }
    }
   }

if (($self->{'PRODUCT'} =~ /LTE-ENB/) || ($self->{'PRODUCT'} =~ /LTE-LMTS/)) {

  my $andrew = 0;
  my $tmp = $1 if ($self->{LTE_BLD_VIEW} =~ /\.(\d+)?$/ );
  if ( ($tmp<70) && ($tmp -50) > 0) {$andrew =1;} else {$andrew=0;}
  my $label = "NONE";
  my $RRU_bininfo;

if ($andrew) {
  $RRU_bininfo = "/vob/lteenb-ctrl/code/apps/rruProxy/codeload/andrew/bin.info";
  if (-e $RRU_bininfo) {
  print "RRU_bininfo:$RRU_bininfo\n" if $debug;
  my $status = $self->rru_up_rev($RRU_bininfo,\$label) if ($self->{'PRODUCT'} =~ /LTE-ENB/);
  $up_rev->{$label} = $status;
  }

} else {

  my $RRU_bininfo = "/vob/lteenb-ctrl/code/apps/rruProxy/codeload/bin.info";
  if (-e $RRU_bininfo) {
  print "RRU_bininfo:$RRU_bininfo\n" if $debug;
  #my $status = $self->rru_up_rev($RRU_bininfo) if ($self->{'PRODUCT'} =~ /LTE-ENB/);
  my $status = $self->rru_up_rev($RRU_bininfo,\$label) if ($self->{'PRODUCT'} =~ /LTE-ENB/);
  $up_rev->{"MOTO RRU-$label"} = $status;
  }

  $RRU_bininfo = "/vob/lteenb-ctrl/code/apps/rruProxy/codeload/motorola/bin.info";
  if (-e $RRU_bininfo) {
  print "RRU_bininfo:$RRU_bininfo\n" if $debug;
  my $status = $self->rru_up_rev($RRU_bininfo,\$label) if ($self->{'PRODUCT'} =~ /LTE-ENB/);
  $up_rev->{"<a href=http://cbtspscm.ftw.mot.com/cgi-bin/get/rfmod_recipe.cgi?fru=RRU&bucket=1_0>MOTO(CTU4) 1170-HWType</a> RRU-$label"} = $status;
  }

  $RRU_bininfo = "/vob/lteenb-ctrl/code/apps/rruProxy/codeload/ctu4/1170/bin.info";
  if (-e $RRU_bininfo) {
  print "RRU_bininfo:$RRU_bininfo\n" if $debug;
  my $status = $self->rru_up_rev($RRU_bininfo,\$label) if ($self->{'PRODUCT'} =~ /LTE-ENB/);
  $up_rev->{"<a href=http://cbtspscm.ftw.mot.com/cgi-bin/get/rfmod_recipe.cgi?fru=RRU&bucket=1_0>MOTO(CTU4) 1170-HWType</a> RRU-$label"} = $status;
  }
  $RRU_bininfo = "/vob/lteenb-ctrl/code/apps/rruProxy/codeload/andrew/beta/bin.info";
  if (-e $RRU_bininfo) {
  print "RRU_bininfo:$RRU_bininfo\n" if $debug;
  my $status = $self->rru_up_rev($RRU_bininfo,\$label) if ($self->{'PRODUCT'} =~ /LTE-ENB/);
  $up_rev->{"ANDREW BETA 1190-HWType RRU-$label"} = $status;
  }

  $RRU_bininfo = "/vob/lteenb-ctrl/code/apps/rruProxy/codeload/andrew/1190/bin.info";
  if (-e $RRU_bininfo) {
  print "RRU_bininfo:$RRU_bininfo\n" if $debug;
  my $status = $self->rru_up_rev($RRU_bininfo,\$label) if ($self->{'PRODUCT'} =~ /LTE-ENB/);
  $up_rev->{"ANDREW BETA 1190-HWType RRU-$label"} = $status;
  }

  $RRU_bininfo = "/vob/lteenb-ctrl/code/apps/rruProxy/codeload/andrew/pilot/bin.info";
  if (-e $RRU_bininfo) {
  print "RRU_bininfo:$RRU_bininfo\n" if $debug;
  my $status = $self->rru_up_rev($RRU_bininfo,\$label) if ($self->{'PRODUCT'} =~ /LTE-ENB/);
  $up_rev->{"ANDREW PILOT 1191-HWType RRU-$label"} = $status;
  }

  $RRU_bininfo = "/vob/lteenb-ctrl/code/apps/rruProxy/codeload/andrew/1191/bin.info";
  if (-e $RRU_bininfo) {
  print "RRU_bininfo:$RRU_bininfo\n" if $debug;
  my $status = $self->rru_up_rev($RRU_bininfo,\$label) if ($self->{'PRODUCT'} =~ /LTE-ENB/);
  $up_rev->{"ANDREW PILOT 1191-HWType RRU-$label"} = $status;
  }

  my $sm1_fpga_bininfo = "/vobs/bcu3_modem_phy/release/bcu3_lte/bcu3_phy_fpga_version_0001.txt";
  if (-e $sm1_fpga_bininfo) {
  print "SM1_FPGA_bininfo:$sm1_fpga_bininfo\n" if $debug;
  my $status = $self->wbts_up_rev($sm1_fpga_bininfo, \$label) if ($self->{'PRODUCT'} =~ /LTE-ENB/);
  $up_rev->{"SM1 FPGA $label"} = $status;
  }

  my $sm2_fpga_bininfo = "/vobs/bcu3_modem_phy/release/bcu3_lte/bcu3_phy_fpga_version_0002.txt";
  if (-e $sm2_fpga_bininfo) {
  print "SM2_FPGA_bininfo:$sm2_fpga_bininfo\n" if $debug;
  my $status = $self->wbts_up_rev($sm2_fpga_bininfo, \$label) if ($self->{'PRODUCT'} =~ /LTE-ENB/);
  $up_rev->{"SM2 FPGA $label"} = $status;
  }

  my $DSP_bininfo = "/vobs/bcu3_modem_phy/release/bcu3_lte/release_notes.txt";
  if (-e $DSP_bininfo) {
  print "DSP_bininfo:$DSP_bininfo\n" if $debug;
  my $status = $self->wbts_up_rev($DSP_bininfo, \$label) if ($self->{'PRODUCT'} =~ /LTE-ENB/);
  $up_rev->{"DSP version $label"} = $status;
  }

  $DSP_bininfo = "/vobs/bcu3_modem_phy/release/bcu3_lte/release_notes.txt";
  if (-e $DSP_bininfo) {
  $label  = "PHY_EIS";
  print "DSP_bininfo:$DSP_bininfo, label: $label\n" if $debug;
  my $status = $self->wbts_up_rev($DSP_bininfo, \$label) if ($self->{'PRODUCT'} =~ /LTE-ENB/);
  $up_rev->{"PHY EIS version $label"} = $status;
  }

 }
}
#   print Dumper $up_rev;
   return $up_rev;
}

####################
sub wbts_up_rev ()
{
#	print Dumper \@_;
	my $self = shift;
	my $wbts_bininfo = shift;
	my $label = shift;
  my $label_prev = "";
	my $status = "UNKNOWN";
  my $wbts_label =`cleartool catcs |grep WBTS-PHY |awk '{print \$3;}'`;
  $wbts_label =~ s/^\s+//;
	$wbts_label =~ s/\s+$//;
	print "wbts_label is $wbts_label\n" if $debug;
  my $wbts_label_prev = `cat $config->{'dev_project_path'}/$self->{'LTE_PREV_LBL_NAME'}.prj |grep WBTS |awk '{print \$3;}'`;
	print "wbts_label_prev is $wbts_label_prev\n" if $debug;
  $wbts_label_prev =~ s/^\s+//;
	$wbts_label_prev =~ s/\s+$//;
	$wbts_label_prev =~ s/\\n"$//;
	print "wbts_label_prev is $wbts_label_prev\n" if $debug;

  my $wbts_bininfo_prev = "$wbts_bininfo\@\@/$wbts_label_prev" if (-e "$wbts_bininfo\@\@/$wbts_label_prev");
  $wbts_bininfo = "$wbts_bininfo\@\@/$wbts_label" if (-e "$wbts_bininfo\@\@/$wbts_label");

  print "$wbts_label:$wbts_bininfo\n" if $debug;
  print "$wbts_label_prev:$wbts_bininfo_prev\n" if $debug;

  if (($wbts_bininfo =~ /release_notes.txt/) && (${$label} eq "PHY_EIS") ) {
    ${$label} = `cat $wbts_bininfo | grep VERSION | grep EIS |awk '{print \$3;}'`;
    $label_prev = `cat $wbts_bininfo_prev | grep VERSION | grep EIS |awk '{print \$3;}'`;
  } elsif ($wbts_bininfo =~ /release_notes.txt/) {
     ${$label} = `cat $wbts_bininfo | grep Version | grep DSP |awk '{print \$2;}'`;
     $label_prev = `cat $wbts_bininfo_prev | grep Version | grep DSP |awk '{print \$2;}'`;
  } else {
    ${$label} = `cat $wbts_bininfo` if ($wbts_bininfo =~ /bcu3_phy_fpga_version/ );
    $label_prev = `cat $wbts_bininfo_prev` if ($wbts_bininfo =~ /bcu3_phy_fpga_version/ );
  }

  ${$label} =~ s/^\s+//;
	${$label} =~ s/\s+$//;
  $label_prev =~ s/^\s+//;
	$label_prev =~ s/\s+$//;

  print "${$label}:$label_prev\n" if $debug;

  if (${$label} eq $label_prev ) {
     $status = "SAME   ";
  } else {
     $status =  "CHANGED";
  }
  print "${$label} - $status\n" if $debug;

  return $status;
}


####################

####################
sub rru_up_rev ()
{
#	print Dumper \@_;
	my $self = shift;
	my $RRU_bininfo = shift;
	my $label = shift;
	${$label} = "";
	my $status = "UNKNOWN";
    my $RRU_bininfo_prev = "$RRU_bininfo\@\@/$self->{'LTE_PREV_LBL_NAME'}" if (-e "$RRU_bininfo\@\@/$self->{'LTE_PREV_LBL_NAME'}");
    $RRU_bininfo = "$RRU_bininfo\@\@/$self->{'LTE_LBL_NAME'}" if (-e "$RRU_bininfo\@\@/$self->{'LTE_LBL_NAME'}");

   print "RRU_bininfo:$RRU_bininfo\n" if $debug;
   print "RRU_bininfo_prev:$RRU_bininfo_prev\n" if $debug;
	if ($self->{'PRODUCT'} =~ /LTE-ENB/ ) {
    ${$label} = `cat $RRU_bininfo|grep version | awk '{print \$4 ; }'`;
    ${$label} =~ s/^\s+//;
	${$label} =~ s/\s+$//;
    #chomp (${$label});
    if (system ("cleartool diff $RRU_bininfo $RRU_bininfo_prev >/dev/null 2>&1")) {
     $status =  "CHANGED";
    } else {
     $status = "SAME   ";
    }
#    ${$label} = $lbl;
    print "${$label} - $status\n" if $debug;

   }
   return $status;
}


####################
sub makeMail_build_is_avaliable()
{
  my $self = shift;
  my $pre_build_mode = 0;
  $pre_build_mode = shift@_;
  print "PRE_BUILD_MODE::: $pre_build_mode\n";
 $pre_build_mode = 1 if ((defined $pre_build_mode) && ($pre_build_mode ne 0));
  print "PRE_BUILD_MODE::: $pre_build_mode\n";
  my $config = new LTE_BLD_CONF($self->{'PRODUCT'},$self->{'LTE_LBL_NAME'},$self->{'RELEASE'},$debug,$pre_build_mode);
  $self->{'LTE_DIR_ROOT'} = $config->{'unix_deliverable_path'}."/".$self->{'LTE_LBL_NAME'} if $pre_build_mode;
  my $mail = $self->{LTE_DIR_ROOT}."/".$self->{LTE_LBL_NAME}."\_avaliable.txt";
  my @config_spec = $self->print_config_spec(\@exclude_array, $pre_build_mode);
  my $LTE_LBL_NAME = $self->{LTE_LBL_NAME};
  $LTE_LBL_NAME = $self->{LTE_LBL_NAME}."_BLD-TEST" if $pre_build_mode;

  open ( MAIL_FILE , ">$mail") or print "I'm not able to open file $mail\n";
  print "$mail created\n";

print MAIL_FILE "_____________________________________________________________________________\n";
print MAIL_FILE "\n";
print MAIL_FILE "PRE " if $pre_build_mode ;
print MAIL_FILE "Build ". $LTE_LBL_NAME." is labeled and available for use\n";
print MAIL_FILE "\n";
print MAIL_FILE "Build information page for this build (punch list, release notes and/or other information):\n";
print MAIL_FILE $config->{'build_info_path'}.$self->{LTE_LBL_NAME}."\n";
print MAIL_FILE "\n";
print MAIL_FILE "Build artifacts are located at:\n";
print MAIL_FILE $config->{'http_deliverable_path'}.$LTE_LBL_NAME."\n";
print MAIL_FILE "\n";
if ($config->{'build_req_path'} ne "") {
print MAIL_FILE "Build Submission Tool details for this baseline (opens in new window):\n";
print MAIL_FILE $config->{'build_req_path'}.$self->{LTE_LBL_NAME}."\n";
print MAIL_FILE "\n";
}
print MAIL_FILE "Build Report :\n";
if ($self->{'PRODUCT'} eq "OMP-OMP4G") {
print MAIL_FILE $config->{'http_deliverable_path'}."/".$LTE_LBL_NAME."/"."bandbcu3_isdlinux".".mail\n";
} else {
print MAIL_FILE $config->{'http_deliverable_path'}."/".$LTE_LBL_NAME."/".$self->{LTE_LBL_NAME}.".mail\n";
}
print MAIL_FILE "\n";
if ($config->{'http_matrix_path'} ne "") {
print MAIL_FILE "Build Matrix for ".$self->{RELEASE}." (includes codeload procedures and other important information):\n";
print MAIL_FILE $config->{'http_matrix_path'}."\n";
print MAIL_FILE "\n";
}
print MAIL_FILE "______________________________________________________________________________\n";
print MAIL_FILE "\n";
print MAIL_FILE "Config spec for this build:\n";
print MAIL_FILE "\n";
foreach my $line (@config_spec) {
  print MAIL_FILE "\t$line\n";
}
print MAIL_FILE "\n";
print MAIL_FILE "________________________________________________________________________\n";
print MAIL_FILE "|\n";
print MAIL_FILE "|  ".$self->{'PRODUCT'}." SCM Team\n";
print MAIL_FILE "|_____________________________________________________________________\n";
print MAIL_FILE "|\n";
print MAIL_FILE "| Motorola ".$self->{'PRODUCT'}." SCM team\n";
print MAIL_FILE "| E-Mail: ".$config->{'email_notyfication_list'}."\n";
print MAIL_FILE "|_____________________________________________________________________|\n";

close(MAIL_FILE);

	return $mail;
}

####################
sub check_cs_agains_dev_project()
{
  my $self = shift;
  my $file = shift;
  my $dev_project_dir = $config->{'dev_project_path'};
  $file = $dev_project_dir ."/". $file;
  my $rc;

  open (FILE, $file) or print "Unable to open file: $file\n";

  foreach my $line (<FILE>) {
    if ($line =~ /\s*?"element \*(.+)?\\n" ./) {
     my $value = $1;
     if (system ("$CLEARTOOL catcs |grep $value >/dev/null 2>&1")) {
       print "WARNING: Config spec hasn't been upgraded for baseline: $value\n";
       $rc = 1 if (!$rc);
     }
    } elsif ($line =~ /\s*?"element (.+)?\/... (.+)? \\n" ./) {
     my $value = $1;
     if (system ("$CLEARTOOL catcs |grep $value |grep $2>/dev/null 2>&1")) {
       print "WARNING: Config spec hasn't been upgraded for baseline: $value\n";
       $rc = 1 if (!$rc);
     }
    }

  }
  return $rc;
}
####################
sub create_dev_project()
{

  my $self = shift;
  my $in_vob = shift;
  my $newgrp = shift;
  my $server = shift;
  my $exclude_lines = shift;
  my $dev_project_dir = shift;
  $dev_project_dir = $config->{'dev_project_path'} if ((!defined $dev_project_dir) || ($dev_project_dir eq ""));
  my $tmp_project_file = "$self->{'LTE_DIR_ROOT'}/logs/other/".$self->{LTE_LBL_NAME}.".prj";
  my $rc = 0;
  my $buildCMDs = (); # shell commands' table, which will be executed as shell script

  print "Temporaty project file $tmp_project_file\n";

  my %DEV_PROJECT= (
	'NAME'                => "$self->{LTE_LBL_NAME}",
	'FILE'                => "__FILE__",
	'DESCRIPTION'         => "$self->{LTE_LBL_NAME}",
	'CSPEC_BEGIN'         		=> "",
	'CSPEC_WITHIN_VW_TEMPLATE'      => "",
	'CSPEC_END'           		=> "",
	);
  my @config_spec = $self->print_config_spec($exclude_lines,0);
  open (DEV_PROJECT_FILE, ">$tmp_project_file") || do {
    print "It's impossible to open file $tmp_project_file for write\n";
    return 1;
  };
  print DEV_PROJECT_FILE "\n";
  print DEV_PROJECT_FILE "###########################################################################\n";
  print DEV_PROJECT_FILE "\%DEVPROJECT = (\n";
  print DEV_PROJECT_FILE "NAME\t=> \'${%DEV_PROJECT}{NAME}\',\n";
  print DEV_PROJECT_FILE "FILE\t=> ${%DEV_PROJECT}{FILE},\n";
  print DEV_PROJECT_FILE "DESCRIPTION\t=> \'${%DEV_PROJECT}{DESCRIPTION}\',\n";
  print DEV_PROJECT_FILE "CSPEC_BEGIN\t=> \'${%DEV_PROJECT}{CSPEC_BEGIN}\',\n";
  print DEV_PROJECT_FILE "CSPEC_WITHIN_VW_TEMPLATE\t=> \n";
  foreach my $line (@config_spec) {
   print DEV_PROJECT_FILE "\t\t\"$line\\n\" .\n";
  }
  print DEV_PROJECT_FILE "\t\t\"\\n\",\n";
  print DEV_PROJECT_FILE "CSPEC_END\t=> \'${%DEV_PROJECT}{CSPEC_END}\'\n";
  print DEV_PROJECT_FILE "\n);\n";
  print DEV_PROJECT_FILE "\n1;\n";
  print DEV_PROJECT_FILE "###########################################################################\n";

  close (DEV_PROJECT_FILE);
  my $dev_project_file = "$dev_project_dir/".$self->{LTE_LBL_NAME}.".prj";
  print "Final project file: $dev_project_file\n";
  my $action ="";


  if ($in_vob) {
  	$action ="$CLEARTOOL co -nc -branch main $dev_project_dir/.";
  	push @$buildCMDs, $action;
  	if (-e $dev_project_file) {
    	$action = "$CLEARTOOL co -nc -branch main $dev_project_file";
    	push @$buildCMDs, $action;
    	$action = "cp $tmp_project_file $dev_project_file" ;
    	push @$buildCMDs, $action;
  	} else {
        $action = "cp $tmp_project_file $dev_project_file";
    	push @$buildCMDs, $action;
        $action = "$CLEARTOOL mkelem -eltype text_file -nc -nco $dev_project_file" ;
    	push @$buildCMDs, $action;
    	$action = "$CLEARTOOL co -nc -branch main $dev_project_file" ;
    	push @$buildCMDs, $action;
  	}
  	$action = "$CLEARTOOL ci -nc $dev_project_file";
  	push @$buildCMDs, $action;
  	$action = "$CLEARTOOL ci -nc $dev_project_dir";
  	push @$buildCMDs, $action;
  } else {
  	$action = "cp $tmp_project_file $dev_project_file";
  	push @$buildCMDs, $action;
  }

  print "Creation project file shell script:\n";
  print Dumper $buildCMDs if $debug;

    ## Generate the target specific build script
    my $BLDSCRPT = undef(); # BLDSCRPT FH
    my $scriptDir  = $self->{'LTE_DIR_ROOT'}."/bin/";
    my $scriptName = "project_".$self->{'LTE_LBL_NAME'}."_build_script";
    my $script     = "$scriptDir/$scriptName";

    print "SCRIPT:$script\n";
    open($BLDSCRPT, '>' , "$script") or
      process_error('x',"Could not create the target build script" .
                        " \"$script\": $!");
    print($BLDSCRPT "#!/bin/ksh -p\n");
    print($BLDSCRPT "# Build Script for target: project\n");
    print($BLDSCRPT "# Created by COMMON.pm\n\n");

    # Execute the Build
    print($BLDSCRPT "print \"($scriptName) Building the project target." .
		   '\n"' . "\n");

    print "BLDSCRPT:$BLDSCRPT\n";
    foreach my $cmd (@$buildCMDs) {
      write_to_script($BLDSCRPT, $script, $cmd, "Executing build command");
    } # end foreach my $cmd...
    print($BLDSCRPT "print \"($scriptName) Finished executing build " .
                   'commands.\n"' . "\n\n");

    close($BLDSCRPT) or process_error('x', "Could not close BLDSCRPT: $!");

    # Set the permissions for $script
    (chmod(0775,$script) == 1)
      or process_error('x',
        "Cannot change permissions for $script to 775.");

  print "Execution project file shell script:\n";
  my $cmd = "$script";

  $cmd = "sg $newgrp \" $cmd \"" if ((defined $newgrp) && ($newgrp ne ""));
  $cmd = "ssh -q $server ".$cmd if ((defined $server) && ($server ne ""));

   print "action: $cmd\n" if $debug;
   $rc = system("$cmd");

  if ($rc == 0) { # NORMAL EXIT, return 0
  } elsif (($rc & 0xff) != 0) { # SIGNAL-RELATED EXIT, return full code
  } else {  # COMMAND FAILURE, strip lower 8 bits and return
    $rc >>= 8;
  }

return $rc;

}

return 'true';
