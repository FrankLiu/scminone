#!/apps/public/perl_5.8.4/bin/perl
package LTE_BLD_CONF;

########################################################################################
#
# 									Motorola Internal Use Only
#
#	Cracow 2009, by amn002
#
#  LTE_BLD_CONF
#
########################################################################################

#use strict qw(vars subs);
#use diagnostics;
use Data::Dumper;


############### GLOBALS ##########################################################
#################################################################################
# This file contains cofiguration data for another LTE script
#
#################################################################################
my $product;
my $debug = 0;
my $pre_build_mode = 0;
my $REL="R1.0";
my $baseline;

$LTE_BLD_CONF::DB = 'MOTCM';
@LTE_BLD_CONF::prodNames= (
      "LTE-ENB",
      "LTE-WBC",
      "LTE-MGR",
      "LTE-MOTOMGR",
      "LTE-MOTOAGT",
      "CMT",
      "LTE-IM",
      "LTE-LMTS",
      "MMS-SE",
      "OMP-OMP4G",
      "WMX-AP",);
$LTE_BLD_CONF::cleartool = "cleartool";

$LTE_BLD_CONF::http_path_base = "http://lte.comm.mot.com/scm/";
$LTE_BLD_CONF::unix_path_base = "/mot/proj/lte_scm/public_html/";

my %specific_path = (
      'LTE-ENB' => "enb_official_builds/",
      'LTE-WBC' => "wbc_official_builds/",
      'LTE-MGR' => "ltemgr_official_builds/",
      'LTE-MOTOMGR' => "motomgr_official_builds/",
      'LTE-MOTOAGT' => "motoagt_official_builds/",
      'CMT' => "motoagt_official_builds/",
      'LTE-IM' => "im_official_builds/",
      'LTE-LMTS' => "enb_official_builds/",
      'MMS-SE' => "ltemgr_official_builds/",
      'OMP-OMP4G' => "omp_daily_builds/",
      'WMX-AP' => "",
      );
my %admin_vob = (
      'LTE-ENB' => "/vob/lteenb/",
      'LTE-WBC' => "/vob/ltewbc/",
      'LTE-MGR' => "/vob/ltemgr/",
      'LTE-MOTOMGR' => "/vobs/motomgr/",
      'LTE-MOTOAGT' => "/vob/4g_cneomi",
      'CMT' => "/vob/4g_cneomi",
      'LTE-IM' => "/vob/lteim",
      'LTE-LMTS' => "/vob/lteenb",
      'MMS-SE' => "/vob/mmsse",
      'OMP-OMP4G' => "/vob/omp4g",
      'WMX-AP' => "/vob/wibb_bts",
       );
my %build_req_path = (
      'LTE-ENB' => "http://ct11gtssweb110.am.mot.com:8080/bts-jsp/ENodeBBuilds?Action=StaticUBSBLRecord&Value=",
      'LTE-WBC' => "http://ct11gtssweb110.am.mot.com:8080/bts-jsp/WBCBuilds?Action=StaticUBSBLRecord&Value=",
      'LTE-MGR' => "http://ct11gtssweb110.am.mot.com:8080/bts-jsp/LTEMgrBuilds?Action=StaticUBSBLRecord&Value=",
      'LTE-MOTOMGR' => "http://ct11gtssweb110.am.mot.com:8080/bts-jsp/MotoMgrBuilds?Action=StaticUBSBLRecord&Value=",
      'LTE-MOTOAGT' => "http://ct11gtssweb110.am.mot.com:8080/bts-jsp/MotoAgtBuilds?Action=StaticUBSBLRecord&Value=",
      'CMT' => "",
      'LTE-IM' => "http://ct11gtssweb110.am.mot.com:8080/bts-jsp/InfoModelBuilds?Action=StaticUBSBLRecord&Value=",
      'LTE-LMTS' => "http://ct11gtssweb110.am.mot.com:8080/bts-jsp/ENodeBBuilds?Action=StaticUBSBLRecord&Value=",
      'MMS-SE' => "",
      'OMP-OMP4G' => "http://ct11gtssweb110.am.mot.com:8080/bts-jsp/OMP4GBuilds?Action=StaticUBSBLRecord&Value=",
      'WMX-AP' => "",
      );

my %http_matrix_path = (
      'LTE-ENB' => "http://compass.mot.com/web/ltecm-wiki/eNB+Release+Notes+%26+Builds",
      'LTE-WBC' => "",
      'LTE-MGR' => "",
      'LTE-MOTOMGR' => "",
      'LTE-MOTOAGT' => "",
      'CMT' => "",
      'LTE-IM' => "",
      'LTE-LMTS' => "",
      'MMS-SE' => "http://compass.mot.com/go/298278188",
      'OMP-OMP4G' => "",
      'WMX-AP' => "",
      );

my %email_notyfication_list = (
      'LTE-ENB' => "enball\@motorola.com",
      'LTE-WBC' => "",
      'LTE-MGR' => "",
      'LTE-MOTOMGR' => "",
      'LTE-MOTOAGT' => "",
      'CMT' => "",
      'LTE-IM' => "",
      'LTE-LMTS' => "enball\@motorola.com",
      'MMS-SE' => "qsk002\@motorola.com",
      'OMP-OMP4G' => "pnayak1\@motorola.com",
      'WMX-AP' => "aea024\@motorola.com",
      );

my %dev_project_path = (
      'LTE-ENB' => "/view/ltescm_main/vob/ltescm/enodeb/cqcm_project/LTE_ENB_projects",
      'LTE-WBC' => "/mot/proj/lte_scm/cmbp/lte_wbc/cm-policy/config/LTE_WBC_projects",
      'LTE-MGR' => "/mot/proj/lte_scm/cmbp/lte_mgr/cm-policy/config/LTE_MGR_projects",
      'LTE-MOTOMGR' => "/mot/proj/lte_scm/cmbp/lte_motomgr/cm-policy/config/LTE_MOTOMGR_projects",
      'LTE-MOTOAGT' => "/mot/proj/lte_scm/cmbp/lte_motoagt/cm-policy/config/LTE_MOTOAGT_projects",
      'CMT' => "",
      'LTE-IM' => "/mot/proj/lte_scm/cmbp/lte_se/cm-policy/config/LTE_IM_projects",
      'LTE-LMTS' => "/view/ltescm_main/vob/ltescm/lmts/cqcm_project/LTE_LMTS_projects",
      'MMS-SE' => "/mot/proj/lte_scm/cmbp/mms_se/cm-policy/config/MMS_SE_projects",
      'OMP-OMP4G' => "/mot/proj/wibb_bts/cmbp/prod/cm-policy/config/OMP4G_projects",
      'WMX-AP' => "/mot/proj/wibb_bts/cmbp/prod/cm-policy/config/WIBB_BTS_projects",
      );

my %ssmt_project_name = (
      'LTE-ENB' => "LTE-ENB-",
      'LTE-WBC' => "WBC-",
      'LTE-MGR' => "LTEMgr-",
      'LTE-MOTOMGR' => "MotoManager-",
      'LTE-MOTOAGT' => "MotoAgent-",
      'CMT' => "MotoAgent_CMT-",
      'LTE-IM' => "",
      'LTE-LMTS' => "LTE-ENB-",
      'MMS-SE' => "",
      'OMP-OMP4G' => "OMP-OMP4G-",
      'WMX-AP' => "WMX-AP_",
      );
my %db_extension = (
      'LTE-ENB' => 'eNodeB',
      'LTE-WBC' => 'WBC',
      'LTE-MGR' => 'LTEMgr',
      'LTE-MOTOMGR' => 'MotoManager',
      'LTE-MOTOAGT' => 'MotoAgent:LTE',
      'CMT' => 'CMT',
      'LTE-IM' => 'IM_LTE',
      'LTE-LMTS' => 'LMTS',
      'MMS-SE' => 'SE_MMS',
      'OMP-OMP4G' => 'OMP4G',
      'WMX-AP' => "",
       );

sub new {
  my $this = shift @_;
  my $class = ref($this) || $this;
  my $subdir;

  $product = shift @_;
  $baseline = shift @_;
  $REL = shift @_;
  $debug = shift @_;
  $pre_build_mode = shift @_;

  $LTE_BLD_CONF::cleartool_path = `which cleartool`;
  my $is_prod_allowed = 0;
  foreach my $prod (@LTE_BLD_CONF::prodNames)
  {
      $is_prod_allowed = 1 if($product eq $prod);
  }
  if (!$is_prod_allowed){
     print "ERROR: unkonwn product: $product in LTE_BLD_CONF.pm \n";
     return;
  }

  print "BASELINE =$baseline \n" if $debug;
  
  if ($baseline =~ /(.+)?(_$REL)_(.+)/) {
     $subdir = $1;
     print "subdir = $subdir\n" if $debug;
  }

  print "-----------------------\nCONF DEBUG FLAG IS SET \n----------------------\n" if $debug;
  print "PRODUCT = $product\n" if $debug;
  print "REL = $REL\n" if $debug;
  print "SUBDIR = $subdir\n" if $debug;
  print "PRE_BUILD_MODE = $pre_build_mode\n" if (defined $pre_build_mode and $debug);

  my $self = {};

  $self->{'Error'} = '';

  $self->{'http_deliverable_path'} = "$LTE_BLD_CONF::http_path_base" . "$specific_path{$product}" . "$REL/" . "$subdir/" ;
  $self->{'unix_deliverable_path'} = "$LTE_BLD_CONF::unix_path_base" . "$specific_path{$product}" . "$REL/" . "$subdir/" ;
  $self->{'build_info_path'} = "http://lte.comm.mot.com/scm/cgi-bin/ltebuildinfo.pl?getByLabel=";
  $self->{'admin_vob'} = $admin_vob{$product};
  $self->{'build_req_path'} = $build_req_path{$product};
  $self->{'http_matrix_path'} = $http_matrix_path{$product};
  $self->{'email_notyfication_list'} = $email_notyfication_list{$product};
  $self->{'dev_project_path'} = $dev_project_path{$product};
  $self->{'ssmt_project_name'} = $ssmt_project_name{$product}."$REL";
  $self->{'ssmt_project_name'} = $ssmt_project_name{$product}."$REL"."_BLD" if ($product eq "WMX-AP");
  $self->{'db_extension'} = $db_extension{$product};

  bless $self, $class ;

  print "BLD CONFIG \n" if $debug;
  print Dumper $self if $debug;
  print "END BLD CONFIG \n" if $debug;


  return $self;
}

sub isProdAllowed($)
{
   my $result = 0;
   foreach my $prod (@LTE_BLD_CONF::prodNames)
   {
      $result = 1 if($product eq $prod);
   }
   return $result;
}

