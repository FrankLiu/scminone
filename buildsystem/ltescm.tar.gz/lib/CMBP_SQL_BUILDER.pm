#!/perl

########################################################################################
#
# 									Motorola Internal Use Only
#
#	Cracow 2007, by amn002
#
#	CMBP SQL BUILDER                
#
########################################################################################

package CMBP_SQL_BUILDER;


########################################
# check environment variable
########################################

BEGIN {
   if (defined($ENV{LTE_BLDTOOLS})){
	   unshift @INC, "$ENV{LTE_BLDTOOLS}/../lib", "$ENV{LTE_BLDTOOLS}", "$ENV{LTE_BLDTOOLS}/enodeb";
   } elsif (defined($ENV{SCM_BLDTOOLS})) {
	   unshift @INC, "$ENV{SCM_BLDTOOLS}", "$ENV{SCM_BLDTOOLS}/..", "$ENV{SCM_BLDTOOLS}/../../lib";
   } else {
	   unshift @INC,"/vob/ltescm/bin","/vob/ltescm/lib","/vob/ltescm/bin/enodeb";
   }
}

use TOOLS;
#use strict;


############### GLOBALS##########################################################
#################################################################################
# This hash helps to build SQL query. Contains information about database
# fields name. Additonal contains predefinied conditions for a few record types 
#################################################################################
my $tools;
my %sql_fields=(
   Development_CR => {
     Fields => {
      id => "T1.id \"id\"",
      Technical_Authority => "T1.Technical_Authority \"Technical_Authority\"",
      Priority => "T1.Priority \"Priority\"",
      CI_Component => "T14.name \"CI_Component\"",
      Headline => "T1.Headline \"Headline\"",
      BL_Actual_Target => "T18.identifier \"BL_Actual_Target\"",
      State => "T5.name \"State\"",
      Original_SR_ID => "T1.Original_SR_ID \"Original_SR_ID\"",
      Resolution_Description => "DBMS_LOB.substr(T1.Resolution_Description, 4000) \"Resolution_Description\"",
      Team => "T16.name \"Team\""
     },
     Condition => " from Development_CR
          T1,Baseline T18,team T16,configuration_item T14,statedef T5 where
          T1.bl_actual_target = T18.dbid and T1.team = T16.dbid and
          T1.ci_component = T14.dbid and T1.State = T5.id"
   },
   CR => 
   {
     Fields => {
      id => "T1.id \"id\"",
      CR_Usage => "T1.CR_Usage \"CR_Usage\"",
      Technical_Authority => "T1.Technical_Authority \"Technical_Authority\"",
      Priority => "T1.Priority \"Priority\"",
      CI_Component => "T14.name \"CI_Component\"",
      Headline => "T1.Headline \"Headline\"",
      BL_Actual_Target => "T18.identifier \"BL_Actual_Target\"",
      BL_Predicted_Target => "T18.identifier \"BL_Predicted_Target\"",
      State => "T5.name \"State\"",
      SR => "T1.Original_SR_ID \"SR\"",
      Resolution_Description => "DBMS_LOB.substr(T1.Resolution_Description, 4000) \"Resolution_Description\"",
      Team => "T16.name \"Team\"",
      CR_branch => "T31.object_oid \"CR_branch\"",
      CR_branch_state => "T31.name \"CR_branch_state\"",
      CR_branch_vob => "T31.replica_vob \"CR_branch_vob\""
     },
     Condition => " from Development_CR T1,configuration_item T14,Baseline
        T18,Baseline T27,statedef T5,team T16,cc_change_set T2,cc_vob_object
        T31,parent_child_links T31mm where T1.ci_component = T14.dbid and
        T1.bl_actual_target = T18.dbid and T1.bl_predicted_target = T27.dbid
        and T1.State = T5.id and T1.team = T16.dbid and T1.cc_change_set =
        T2.dbid and T2.dbid = T31mm.parent_dbid  (+)  and 16777440 =
        T31mm.parent_fielddef_id  (+)  and T31mm.child_dbid = T31.dbid  (+) "
   },

   Baseline => {
   
     Fields => {
        Identifier => "T1.identifier \"Identifier\"", 
        Org_CR => "T1.originating_cr \"Org_CR\"", 
        NameSpace => "T1.namespace \"NameSpace\"",
        Product_Family_Name => "T5.Name \"Product_Family_Name\"",
        Targeted_CRs => "T10.id \"Targeted_CRs\"",
        Configuration_Item => "T20.identifier \"Configuration_Item\"",
        Status => "T1.status \"Status\"",
        Parent_BLs => "T9.identifier \"Parent_BLs\"",
        Child_BLs => "T8.identifier \"Child_BLs\"",
        Predecessor_BL => "T17.identifier \"Predecessor_BL\"",
        Baseline_Type => "T1.baseline_type \"Baseline_Type\"",
        Team => "T13.name \"Team\"",
        Proj_Release => "T15.identifier \"Proj_Release\""
     },
     Condition1 => "from Baseline T1,Product_Family T2,Baseline
        T9,parent_child_links T9mm where T1.Product_Family_Name = T2.dbid and
        T1.dbid = T9mm.parent_dbid  (+)  and 16777592 =
        T9mm.parent_fielddef_id  (+)  and T9mm.child_dbid = T9.dbid  (+)",

     Condition => " from Baseline T1,Product_Family T5,Development_CR
        T10,configuration_item T20,Baseline T9,parent_child_links
        T9mm,Baseline T8,parent_child_links T8mm,Baseline T17,team T13,project
        T15 where T1.Product_Family_Name = T5.dbid and T1.dbid =
        T10.bl_actual_target (+)  and T1.configuration_item = T20.dbid and
        T1.dbid = T9mm.child_dbid  (+)  and 16777593 = T9mm.child_fielddef_id
        (+)  and T9mm.parent_dbid = T9.dbid  (+)  and T1.dbid =
        T8mm.parent_dbid  (+)  and 16777592 = T8mm.parent_fielddef_id  (+)
        and T8mm.child_dbid = T8.dbid  (+)  and T1.predecessor_bl = T17.dbid
        and T1.team = T13.dbid and T1.proj_release = T15.dbid"
   },
   CR_releated_SRs => {
     Fields => {
      CR_id => "T1.id \"CR_id\"",
      SR_id => "T5.id \"SR_id\""
     },
     Condition => "from Development_CR T1,Submission_Record T5,
               parent_child_links T5mm where T1.dbid = T5mm.child_dbid  (+)  and
        16777389 = T5mm.child_fielddef_id  (+)  and T5mm.parent_dbid = T5.dbid",
   },
   );

my $debug=0;
###############################################################
#               Constructor 
###############################################################
sub new {
    my $this = shift @_;
    my $class = ref($this) || $this;
    my $self = {record_type => "",
                sql => "",
                errors => ""   
    };
   
    $tools = new TOOLS();
    $debug = $ENV{'SQL_DEBUG'};
    bless($self, $class);
    return $self;
}

#sub DESTROY {
#   print "DESTRUCTOR\n"
#}

#########################################################
# This function created SQL query base on record type
# and requested key
#########################################################
sub BuildSql {
   my $self = shift;

   $self->{record_type} = shift @_;

   my @keys = @_; 

   $self->{sql}="select distinct ";
   printf "rec Type= %s \n", $self->{'record_type'} if $debug;
   foreach my $key(@keys) {
      if(defined($sql_fields{$self->{'record_type'}}{Fields}{$key}))
      {
         $self->{'sql'} = $self->{'sql'} . $sql_fields{$self->{'record_type'}}{Fields}{$key} . ",";
      }
      else
      {
         $tools->warning("Build SQL: Column name =>$key<= is not supported");
      }
   }

   $self->{'sql'} = $1 if ($self->{'sql'} =~ /(.+),$/);
   $self->{'sql'} = $self->{'sql'} . $sql_fields{$self->{'record_type'}}{Condition};
}

#####################################################
# This function add condition
#####################################################
sub AddCondition {
   my $self = shift;
   my $field = shift @_;
   my $user_cond = shift @_;

   if(defined($sql_fields{$self->{'record_type'}}{Fields}{$field}))
   {
      my $tmp_cmbp_field =  $sql_fields{$self->{'record_type'}}{Fields}{$field};
      my $cmbp_field = $1 if ($tmp_cmbp_field =~ /(.+)?\s+.*/);

      $self->{'sql'} = $self->{'sql'} ." and (". $cmbp_field . $user_cond .")";
   }
   else
   {
      $tools->warning("Add Condition: Column name =>$field<= is not supported");
   }
   return $self->{'sql'};
}

sub TranslateCondition {
   my $self = shift;
   my $field = shift @_;
   my $user_cond = shift @_;
   my $condition = shift @_;

   if(defined($sql_fields{$self->{'record_type'}}{Fields}{$field}))
   {
      my $tmp_cmbp_field =  $sql_fields{$self->{'record_type'}}{Fields}{$field};
      my $cmbp_field = $1 if ($tmp_cmbp_field =~ /(.+)?\s+.*/);

      $condition = $condition ."(". $cmbp_field . $user_cond .")";
   }
   else
   {
      $tools->warning("Add Condition: Column name =>$field<= is not supported");
   }

   return $condition;
}

sub ConnectCondition {
   my $self = shift;
   my $user_cond = shift @_;
   my $conjunction = shift @_; 

   $self->{'sql'} = $self->{'sql'} ." ". $conjunction." (". $user_cond .")";

   return $self->{'sql'};
}

#############################################################
# This function alow to use one of the predefined conditions
#############################################################
sub AddPredCondition {
   my $self = shift;
   my $cond_name = shift @_;

   if(defined($sql_fields{$self->{'record_type'}}{$cond_name}))
   {
      $self->{'sql'} = $self->{'sql'} ." and (". $sql_fields{$self->{'record_type'}}{$cond_name} .")";
   }
   else
   {
      $tools->warning("Add Condition: Column name =>$cond_name<= is not supported");
   }
   return $self->{'sql'};
}

1;
