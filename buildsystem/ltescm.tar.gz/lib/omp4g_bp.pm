#!/apps/public/perl_5.8.4/bin/perl
#############################################################################
#
#       Copyright (C) 2006-2010 MOTOROLA. All Rights Reserved.
#
#       The copyright notice above does not evidence any
#       actual or intended publication of such source code.
#       The code contains Motorola Confidential Restricted Information.
#
#############################################################################
#
#  FILE NAME:    omp4g_bp.pm
#
#  OWNER:        LTE SCM Team
#
#  DATE CREATED: 05/25/2010
#
#  SYNOPSIS:     None.
#
#  EXIT VALUE:   1; - Mandatory for module to load successfully
#
#  DESCRIPTION:  This Perl module contains common functions and variables
#                used for building omp4g_pm targets.
#
#############################################################################
#
#  MODIFICATION HISTORY:
#
# Ver    Date     Engineer     CR                     Change
# --- ---------- ---------- --------  ---------------------------------------
# 1.0 05/25/2010 pnayak1    01120994  Created initial version
# 2.0 07/27/2010 pnayak1    01345667  Upgraded from template version 2.2 to
#                                     version 2.4
# 2.1 08/18/2010 amn002     01351386  add "system" parameter to new COMMOM 
#
#############################################################################
#
#  FUNCTIONS:  (Alphabetical)
#
#    Local
#    -----
#	createView()		- Build Type-specific create view function
#
#	Always Called if Defined
#	------------------------
#	preBuild()		- Build Type-specific pre build
#	postBuild()		- Build Type-specific post build
#
#       Local Step Functions
#	--------------------
#	postCloseBuild()	- Build Type-specific post close_build
#	postCloseCQCM()		- Build Type-specific post close_cqcm
#	postCompile()		- Build Type-specific post compilation
#	postInstrument()	- Build Type-specific post instrumentation
#	postLabel()		- Build Type-specific post labeling
#	postMerge()		- Build Type-specific post merge
#	postPackage()		- Build Type-specific post packaging
#	postValidCQCM()		- Build Type-specific post valid_cqcm
#	postValidEnv()		- Build Type-specific post valid_env
#	postSSM()		- Build Type-specific post SSM
#
#############################################################################

## DEVELOPMENT NOTES:
#  -----------------
# 1. Any variables global to this package must be declared within the 'our'
#    directive because of the 'strict' pragma.

## CHECKLIST WHEN UPDATING THIS MODULE:
#  -----------------------------------
# 1. Update @EXPORT if created a function or variable to be exported.
# 2. Update 'our' if added a global variable to this module or if a variable
#    needs to be exported. 
# 3. Update the "FUNCTIONS" list in the prologue.
# 4. Update the "MODIFICATION HISTORY" in the prologue.
# 5. Turn Perl diagnostics (use diagnostics;) and strict (use strict;) off
#    before release.

# Used as error checking mechanism: does not allow re-declaration of
# the same variable within the same scope.  For testing purposes only.
# Note: We do not check for strict references in order to access globals from
#       the calling package.
#use strict qw(vars subs);
#use diagnostics;

# Indicates that the entire library's symbol table or namespace is labeled
# as omp4g_bp.  The compiler will look for any undefined symbols, in the calling
# program, in this package.
package omp4g_bp;

use 5.8.4;	  # Use Perl 5.8.4 or higher (also for debugging purposes)
use Data::Dumper; # Used for dumping data structures/debugging

# Use POSIX for strftime.
use POSIX qw(strftime);

# Used to setup export methods into calling programs.  Allows the use of
# import(), @ISA, @EXPORT, etc., which allows for different ways of exporting
# symbols.
require Exporter;

# Standard global symbols
our (@ISA, @EXPORT);

# Search location for unresolved functions in the current package.
# The search is left to right.
# Exporter is included here because of the import() function.
@ISA = qw(Exporter);

# List of symbols to be exported by :DEFAULT.
# List functions first, then all other symbols.
@EXPORT	  =  qw(postBuild
                postCloseCQCM
                postCompile
                postInstrument
                postLabel
                postMerge
                postPackage
                postSSM
                postValidCQCM
		preBuild
		write_to_script
                
		@bTDirs
		$buildSteps
		%close_build
		%close_cqcm
		$createView
		$defaultBuildVer
		$delivDir
		$httpReleaseLoc
		%labeling
		$logsDir
		%merge
		$metricsDir
		$objectsRef
		%packaging
		$product
		%project
		$release
		$releaseDir
		$results
		$scmEmail
		$SCM_ADMIN_VOB
		%ssm
		$system
		%targets
		$teamEmail
		$templateVersion
		$USE_BUILD_REQ
		%valid_cqcm
		%valid_env
               );

# Package global variables (some are imported from the calling namespace).
our    ($bld,
	@bTDirs,
	@buildSteps,
	$buildVer,
	$buildver,
	%close_build,
	%close_cqcm,
	$COMPILE_METRICS_FH,
	$cp,
	$createView,
	$ct,
	$defaultBuildVer,
	$delivDir,
	$httpReleaseLoc,
	$INSTR_METRICS_FH,
	$kwBin,
	$kwHost,
	$kwPort,
	$kwStates,
	$kwRel,
	%labeling,
	$lcProd,
	$lcSysProd,
	$logsDir,
	$maillist,
	%merge,
	$MERGE_METRICS_FH,
	$metricsDir,
	$objectsRef,
	%packaging,
	$PKG_METRICS_FH,
	$plcode,
	$POSTBLD_METRICS_FH,
	$PREBLD_METRICS_FH,
	$product,
	%project,
	$release,
	$releaseDir,
	$results,
	$scmEmail,
	$SCM_ADMIN_VOB,	
	%ssm,
	$SSM_METRICS_FH,
	$system,
	@targets,
	%targets,
	$teamEmail,
	$templateVersion,
	$timeStamp,
	$tool,
	$USER,
	$USE_BUILD_REQ,
	%valid_cqcm,
	%valid_env,
	$VIEWNAME,
        $viewBldVer,
       );

# Mandatory symbols that must be defined in this package include:
#
# $createView		- This is the command to create a view.  The most
#               	  common option is provided (for SCH).
# $defaultBuildVer	- Defined even if it is an empty string.
# $delivDir		- Used for target build deliverable storage.
# $logsDir		- Used for target build logs storage.
# $metricsDir		- Used for target build SCM metrics storage.
# $product		- Product this build type belongs to.
# $releaseDir		- Used for target build scripts.
# $system		- System this build type belongs to.
# $templateVersion	- Version of product_template.pm we are using.
#

# Note that "Instrumentation" in %targets can be set to "{}" if there is no
# defined instrumentation for that particular target.

#============================================================================
#=====================  Exported Variable Initialization  ===================
#============================================================================
#
# Do not use the 'my' directive for those definitions we are using the 'our'
# directive for above.
#

# Version of product_template.pm populated for this build type
$templateVersion = 2.4;

# Insert your default version here.  Leave as '' if your team has no default
# value (note, build will halt if no default value and no version is provided
# on the command line).
$defaultBuildVer = '';

## Do not touch the following block of code ##
# Sets the name of the calling package (tool)
my $pkg   = (caller)[0];		# Calling package name

# Import exported variables from calling package (tool)
$pkg->import;

# Set the default build version (baseline) if not set already.
if (!defined($buildVer) or $buildVer =~ /^\s*$/) {
    $buildVer = $defaultBuildVer;
} # end if (!defined...
##   Do not touch the above block of code   ##

# Ensure case is correct and set the lc version
$buildVer =~ tr/a-z/A-Z/;
($buildver = $buildVer) =~ tr/A-Z/a-z/;

# Set the system, product and releaseDir if the Version is correctly
# formatted.
if ($buildVer =~ m/^([^-]+)-([^_]+)_(R\d+\.\d+)_(BLD|DEVINT|INT|REL)-.*/) {
  $system = "OMP";
  $product = $2;
  $release = $3; # Root directory for the release content
  $bld = $4;
  $lcProd     = lc($product);
  $lcSysProd = lc($system . $product);         # Lowercase SystemProduct
  my $lcSys_Prod = lc("${system}_${product}"); # Lowercase System_Product

  # Build ver minus bldrev or # after bld value for view reuse
  ($viewBldVer = $buildVer) =~ s/\.[^\.]*$//;

  if (defined $ENV{'OMPSCM_HOURLY'} and $ENV{'OMPSCM_HOURLY'}) {
     $releaseDir = "/mot/proj/wibb_bts3/omp4g/builds/hourly/${buildVer}";
     # Build ver minus bldrev.HOURLY or #.HOURLY after bld value for view reuse
     ($viewBldVer = $buildVer) =~ s/\.[^\.]*\.HOURLY$//;
  }
  elsif (defined $ENV{'OMPSCM_NIGHTLY_KW'} and $ENV{'OMPSCM_NIGHTLY_KW'}){
     $releaseDir = "/mot/proj/wibb_bts3/omp4g/builds/nightly/${buildVer}";
  }
  elsif ($USER eq "ompbld"){
        $releaseDir = "/mot/proj/wibb_bts3/omp4g/builds/${buildVer}";
  }
  else {
     $releaseDir = "/mot/proj/wibb_bts3/omp4g/dev_builds/${buildVer}";
  }

} else {
  process_error('x', 'Could not determine system, product and release from'
                    ." the passed version: $buildVer.");
} # end if ($buildVer...

# For LTE create new object to access common build information
eval {
  require "COMMON.pm";  # COMMON module
  COMMON->import;
}; # end eval...

# For LTE process any failure to use COMMON.pm
($@) and process_error('x', "Could not load COMMON.pm.  There is probably a"
    . " syntax error in this file: $@");

# For LTE create new object to access common LTE build information
my $common = new COMMON('LTE_LBL_NAME' => $buildVer, 'PRE_BUILD_MODE' => 0,
   'LTE_BLD_VIEW'   => $VIEWNAME, 'SYSTEM' => $system);
$objectsRef->{'COMMON'} = $common;

# Release directory locations (standard locations provided) created by
# buildProcessor.pl
$delivDir   = "$releaseDir";                # Deliverables

$logsDir    = "$releaseDir/logs";           # Log files
$metricsDir = "$releaseDir/metrics";        # Build metrics

# SCH createView basic command
# NOTE We use the non-CQCM makeview here and so we must set a config spec.
#      We do not use the DEVINT/BLD view.
$createView = "/apps/internal/bin/makeview -tag <view>";

# Default build automation steps to execute for this product.
# Note: preBuild, post<Step> and postBuild functions are automatically
# called if defined.
@buildSteps = qw(valid_env valid_cqcm metrics compile label package
                 close_cqcm close_build ssm instrument);

# For Klocwork
$kwBin = '/apps/vendor/klocwork_8.1.2.10/bin';
$kwHost = 'isdserv0.comm.mot.com';
$kwPort = '1105';
$kwStates = 'new/fixed/existing/recurred';
($kwRel = $release) =~ s/\./_/;
$kwRel  = lc($kwRel);                       # Lowercase release used by KW

# Set to true if your team uses the build request tool or undef if you don't.
$USE_BUILD_REQ = 1;

# Initialize MAKEFLAGS to save us from a concatenation error with strict.
if (not defined $ENV{'MAKEFLAGS'}) { $ENV{'MAKEFLAGS'}=""; }

## Build type-specific definitions

# Set the admin VOB location (env var SCM_ADMIN_VOB overrides the default)
$SCM_ADMIN_VOB = $ENV{'SCM_ADMIN_VOB'} || '/vob/omp4g';

# Team email list (use \ before @ symbols), comma delimited
$teamEmail = "pnayak1\@motorola.com";

# SCM email list
$scmEmail = ""; 

# Build type-specific directories to be created by buildProcessor.pl.
# Add directories your builds need here.
@bTDirs = ("$logsDir/compile",
           "$logsDir/instrumentation",
           "$logsDir/label",
           "$logsDir/merge",
           "$logsDir/packaging",
           "$logsDir/post_build",
           "$logsDir/pre_build",
           "$logsDir/ssmt",
           "$logsDir/other",
          );

#============================================================================
#================================  CONFIG  ==================================
#============================================================================

# Setup for Environment validation
#  Checks for 'buildSize' FA space
#  Checks for 'buildSize' View space
%valid_env = (
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {},
    'logging'    => 1,
    'logFile'    => "${logsDir}/pre_build/${lcProd}-${buildVer}-valid_env"
                  . "_log_${timeStamp}.txt",
    # Size of the average build in MB.  Used to check for sufficient space.
    'buildSize'  => 3000,
); # end of valid_env configuration


# Setup for CQCM validation
%valid_cqcm = (
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {},
    'logFile'    => "${logsDir}/other/${lcProd}-${buildVer}-valid_cqcm"
                  . "_log_${timeStamp}.txt",
); # end of valid_cqcm configuration


# Setup for merging
# Support merge and tracemerge functions, plus custom functions.
# merge: Merges necessary branches based on build request or predefined list.
#   For REL builds, checks REL and BLD content is identical
# tracemerge: Executes tracemerge/cmbp_report checks
%merge = (
    'view'       => '',
    'configSpec' => '',
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {'PATH' => "/vob/ltescm/bin:$ENV{'PATH'}"},
    'logging'    => 1,
    'logFile'    => "${logsDir}/merge/${lcProd}-${buildVer}-merge"
                  . "_log_${timeStamp}.txt",
    'functions'  => ['merge', 'tracemerge',],
); # end of merge configuration

## We want to run the 'merge' function only if a 'devint' or a 'bld'
## branch is being merged.  Otherwise we updated the 'functions' in 
## %merge to run just 'tracemerge'.
my $initial     = $objectsRef->{'INITIAL'};
if (not grep {/^devint-|_bld-/} keys %{$initial->{'BRs_TO_MERGE'}}){
       @{$merge{'functions'}} = ('tracemerge');
} #end if (grep


# Define the build targets
#  Each target is comprised of user defined build commands
#  Each target can have multiple defined instrumentation types
%targets = (

    ########################################################
    # LTE BCU2 - lompsac
    ########################################################
    'lompsac' => {

        'build' => {
            'view'       => "${viewBldVer}_lompsac_nightly",
            'configSpec' => "${logsDir}/${buildVer}_cs.wri",
            'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
            'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
				     . ':/sbin:/usr/sbin:/usr/atria/bin:.'
				     . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
			     'WUCE' => '/vob/wuce/wuce/bin/wuce',
 			     'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
			    },
            'logging'    => 1,
            'buildLog'   => "${logsDir}/compile/lompsac-${buildVer}-build"
                            . "_log_${timeStamp}.txt",
            'buildCMDs'  =>
		[
                 ############################################################
                 # Note:  OMPSCM_HOURLY section below expects the 'wbld' 
                 # command to be in a specific array element.  Review and make 
                 # appropriate updates to the OMPSCM_HOURLY section if you 
                 # make any change to this section. 
                 ############################################################
                 # Remove view private objects
                 "$ct lsp | xargs rm -rf {}",

                 'wbld -C nodebug -N -C strip -V -k -v lompsac lompsac.pkg lompsac.rel',
		 "r2bsf1 -f ${logsDir}/compile/lompsac-${buildVer}-build"
	       . "_log_${timeStamp}.txt -p aps",
		],
        },


        'instrument' => {
            'Klocwork' => {
                'view'       => "lompsacKW_${buildVer}",
                'configSpec' => "${releaseDir}/lompsac.cs",
                'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
                'envVars'    => {'PATH' => "$kwBin:/apps/vendor/bin:/usr/bin:/bin:"
    				         . '/etc:/sbin:/usr/sbin:/usr/atria/bin:.'
    				         . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",

    			         'WUCE' => '/vob/wuce/wuce/bin/wuce',
    			         'KWPROJ' => 'lompsac',
    			         'WUCE_KWPROJ_NAME' => "omp_omp4g_${kwRel}_lompsac_full",
 			         'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
    			        },
                'logging'    => 1,
                'buildLog'   => "${logsDir}/instrumentation/lompsac-${buildVer}-kw"
                                . "_log_${timeStamp}.txt",
                'buildCMDs'  =>
		  [
                   ##########################################################
                   # Create a temporary view with ${buildVer} as the baseline
                   # so that we get the correct config specs, which looks at
                   # the correct  WUCE version.  We cannot use the config
                   # specs in ${releaseDir}/lompbcu3vx.cs because it points to
                   # the LATEST on the bld branch, which has an updated   
                   # WUCE version instead of ${buildVer}.                     
                   ##########################################################
                   '. /mot/proj/wibb_bts/cmbp/bin/scstart omp4g',
                   "mkview -tag tmp-lompsacKW -nobr -b ${buildVer}",
                   "cleartool catcs -tag tmp-lompsacKW > ${logsDir}/instrumentation/lompsac_KW.cs",
                   "cleartool setcs ${logsDir}/instrumentation/lompsac_KW.cs",
                   'cleartool rmview -tag tmp-lompsacKW',

                   #########################################################
                                                                    
                   'wbld_lompsac_kw8',
		   "r2bsf1 -f ${logsDir}/instrumentation/lompsac-${buildVer}-kw"
	         . "_log_${timeStamp}.txt -p aps",
		   'build_list=`kwadmin list-builds $WUCE_KWPROJ_NAME| /bin/sed -e \'s/No builds found.*\n//\'`',
		   'build=`echo $build_list | /bin/sed -e \'s/\(^\w*\)\s.*$/\1/\'`',
		   "kwinspectreport --project \$WUCE_KWPROJ_NAME --build \$build --host $kwHost --port $kwPort"
		   . " --state $kwStates --text ${logsDir}/instrumentation/raw_\${KWPROJ}_KW_inspect_report",
		  ],
            },
        },
    },

    ########################################################
    # LTE BCU2 - lompmodem
    ########################################################
    'lompmodem' => {

        'build' => {
            'view'       => "${viewBldVer}_lompmodem_nightly",
            'configSpec' => "${logsDir}/${buildVer}_cs.wri",
            'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
            'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
				     . ':/sbin:/usr/sbin:/usr/atria/bin:.'
				     . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
			     'WUCE' => '/vob/wuce/wuce/bin/wuce',
 			     'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
			    },
            'logging'    => 1,
            'buildLog'   => "${logsDir}/compile/lompmodem-${buildVer}-build"
                            . "_log_${timeStamp}.txt",
            'buildCMDs'  =>
		[
                 ############################################################
                 # Note:  OMPSCM_HOURLY section below expects the 'wbld' 
                 # command to be in a specific array element.  Review and make 
                 # appropriate updates to the OMPSCM_HOURLY section if you 
                 # make any change to this section. 
                 ############################################################
                 # Remove view private objects
                 "$ct lsp | xargs rm -rf {}",

                 'wbld -C nodebug -N -C strip -V -k -v lompmodem lompmodem.pkg lompmodem.rel',
		 "r2bsf1 -f ${logsDir}/compile/lompmodem-${buildVer}-build"
	       . "_log_${timeStamp}.txt -p aps",
		],
        },


        'instrument' => {
            'Klocwork' => {
                'view'       => "lompmodemKW_${buildVer}",
                'configSpec' => "${releaseDir}/lompmodem.cs",
                'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
                'envVars'    => {'PATH' => "$kwBin:/apps/vendor/bin:/usr/bin:/bin:"
    				         . '/etc:/sbin:/usr/sbin:/usr/atria/bin:.'
    				         . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",

    			         'WUCE' => '/vob/wuce/wuce/bin/wuce',
    			         'KWPROJ' => 'lompmodem',
    			         'WUCE_KWPROJ_NAME' => "omp_omp4g_${kwRel}_lompmodem_full",
 			         'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
    			        },
                'logging'    => 1,
                'buildLog'   => "${logsDir}/instrumentation/lompmodem-${buildVer}-kw"
                                . "_log_${timeStamp}.txt",
                'buildCMDs'  =>
		  [
                   ##########################################################
                   # Create a temporary view with ${buildVer} as the baseline
                   # so that we get the correct config specs, which looks at
                   # the correct  WUCE version.  We cannot use the config
                   # specs in ${releaseDir}/lompbcu3vx.cs because it points to
                   # the LATEST on the bld branch, which has an updated   
                   # WUCE version instead of ${buildVer}.                     
                   ##########################################################
                   '. /mot/proj/wibb_bts/cmbp/bin/scstart omp4g',
                   "mkview -tag tmp-lompmodemKW -nobr -b ${buildVer}",
                   "cleartool catcs -tag tmp-lompmodemKW > ${logsDir}/instrumentation/lompmodem_KW.cs",
                   "cleartool setcs ${logsDir}/instrumentation/lompmodem_KW.cs",
                   'cleartool rmview -tag tmp-lompmodemKW',

                   #########################################################
                                                                    
                   'wbld_lompmodem_kw8',
		   "r2bsf1 -f ${logsDir}/instrumentation/lompmodem-${buildVer}-kw"
	         . "_log_${timeStamp}.txt -p aps",
		   'build_list=`kwadmin list-builds $WUCE_KWPROJ_NAME| /bin/sed -e \'s/No builds found.*\n//\'`',
		   'build=`echo $build_list | /bin/sed -e \'s/\(^\w*\)\s.*$/\1/\'`',
		   "kwinspectreport --project \$WUCE_KWPROJ_NAME --build \$build --host $kwHost --port $kwPort"
		   . " --state $kwStates --text ${logsDir}/instrumentation/raw_\${KWPROJ}_KW_inspect_report",
		  ],
            },
        },
    },

    ########################################################
    # Common BCU3 - lompbcu3vx
    ########################################################
    'lompbcu3vx' => {

        'build' => {
            'view'       => "${viewBldVer}_lompbcu3vx_nightly",
            'configSpec' => "${logsDir}/${buildVer}_cs.wri",
            'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
            'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
				     . ':/sbin:/usr/sbin:/usr/atria/bin:.'
				     . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
			     'WUCE' => '/vob/wuce/wuce/bin/wuce',
 			     'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
			    },
            'logging'    => 1,
            'buildLog'   => "${logsDir}/compile/lompbcu3vx-${buildVer}-build"
                            . "_log_${timeStamp}.txt",
            'buildCMDs'  =>
		[
                 ############################################################
                 # Note:  OMPSCM_HOURLY section below expects the 'wbld' 
                 # command to be in a specific array element.  Review and make 
                 # appropriate updates to the OMPSCM_HOURLY section if you 
                 # make any change to this section. 
                 ############################################################
                 # Remove view private objects
                 "$ct lsp | xargs rm -rf {}",

                 'wbld -C nodebug -N -C strip -V -k -v lompbcu3vx lompbcu3vx.pkg lompbcu3vx.rel',
		 "r2bsf1 -f ${logsDir}/compile/lompbcu3vx-${buildVer}-build"
	       . "_log_${timeStamp}.txt -p aps",
		],
        },


        'instrument' => {
            'Klocwork' => {
                'view'       => "lompbcu3vxKW_${buildVer}",
                'configSpec' => "",
                'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
                'envVars'    => {'PATH' => "$kwBin:/apps/vendor/bin:/usr/bin:/bin:"
    				         . '/etc:/sbin:/usr/sbin:/usr/atria/bin:.'
    				         . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",

    			         'WUCE' => '/vob/wuce/wuce/bin/wuce',
    			         'KWPROJ' => 'lompbcu3vx',
    			         'WUCE_KWPROJ_NAME' => "omp_omp4g_${kwRel}_lompbcu3vx_full",
 			         'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
    			        },
                'logging'    => 1,
                'buildLog'   => "${logsDir}/instrumentation/lompbcu3vx-${buildVer}-kw"
                                . "_log_${timeStamp}.txt",
                'buildCMDs'  =>
		  [
                   ##########################################################
                   # Create a temporary view with ${buildVer} as the baseline
                   # so that we get the correct config specs, which looks at
                   # the correct  WUCE version.  We cannot use the config
                   # specs in ${releaseDir}/lompbcu3vx.cs because it points to
                   # the LATEST on the bld branch, which has an updated   
                   # WUCE version instead of ${buildVer}.                     
                   ##########################################################
                   '. /mot/proj/wibb_bts/cmbp/bin/scstart omp4g',
                   "mkview -tag tmp-lompbcu3vxKW -nobr -b ${buildVer}",
                   "cleartool catcs -tag tmp-lompbcu3vxKW > ${logsDir}/instrumentation/lompbcu3vx_KW.cs",
                   "cleartool setcs ${logsDir}/instrumentation/lompbcu3vx_KW.cs",
                   'cleartool rmview -tag tmp-lompbcu3vxKW',

                   #########################################################
                                                                    
                   'wbld_lompbcu3vx_kw8',
		   "r2bsf1 -f ${logsDir}/instrumentation/lompbcu3vx-${buildVer}-kw"
	         . "_log_${timeStamp}.txt -p aps",
		   'build_list=`kwadmin list-builds $WUCE_KWPROJ_NAME| /bin/sed -e \'s/No builds found.*\n//\'`',
		   'build=`echo $build_list | /bin/sed -e \'s/\(^\w*\)\s.*$/\1/\'`',
		   "kwinspectreport --project \$WUCE_KWPROJ_NAME --build \$build --host $kwHost --port $kwPort"
		   . " --state $kwStates --text ${logsDir}/instrumentation/raw_\${KWPROJ}_KW_inspect_report",
		  ],
            },
        },
    },

    ########################################################
    # Common BCU3 - lompbcu3lx
    ########################################################
    'lompbcu3lx' => {

        'build' => {
            'view'       => "${viewBldVer}_lompbcu3lx_nightly",
            'configSpec' => "${logsDir}/${buildVer}_cs.wri",
            'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
            'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
				     . ':/sbin:/usr/sbin:/usr/atria/bin:.'
				     . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
			     'WUCE' => '/vob/wuce/wuce/bin/wuce',
 			     'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
			    },
            'logging'    => 1,
            'buildLog'   => "${logsDir}/compile/lompbcu3lx-${buildVer}-build"
                            . "_log_${timeStamp}.txt",
            'buildCMDs'  =>
		[

                 ############################################################
                 # Note:  OMPSCM_HOURLY section below expects the 'wbld' 
                 # command to be in a specific array element.  Review and make 
                 # appropriate updates to the OMPSCM_HOURLY section if you 
                 # make any change to this section. 
                 ############################################################
                 # Remove view private objects
                 "$ct lsp | xargs rm -rf {}",

                 'wbld -C nodebug -N -C strip -V -k -v lompbcu3lx',
		 "r2bsf1 -f ${logsDir}/compile/lompbcu3lx-${buildVer}-build"
	       . "_log_${timeStamp}.txt -p aps",
                 "/bin/mkdir -p ${SCM_ADMIN_VOB}/bld/pkg",
		],
        },


        'instrument' => {
            'Klocwork' => {
                'view'       => "lompbcu3lxKW_${buildVer}",
                'configSpec' => "${releaseDir}/lompbcu3lx.cs",
                'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
                'envVars'    => {'PATH' => "$kwBin:/apps/vendor/bin:/usr/bin:/bin:"
    				         . '/etc:/sbin:/usr/sbin:/usr/atria/bin:.'
    				         . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",

    			         'WUCE' => '/vob/wuce/wuce/bin/wuce',
    			         'KWPROJ' => 'lompbcu3lx',
    			         'WUCE_KWPROJ_NAME' => "omp_omp4g_${kwRel}_lompbcu3lx_full",
 			         'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
    			        },
                'logging'    => 1,
                'buildLog'   => "${logsDir}/instrumentation/lompbcu3lx-${buildVer}-kw"
                                . "_log_${timeStamp}.txt",
                'buildCMDs'  =>
		  [
                   ##########################################################
                   # Create a temporary view with ${buildVer} as the baseline
                   # so that we get the correct config specs, which looks at
                   # the correct  WUCE version.  We cannot use the config
                   # specs in ${releaseDir}/lompbcu3lx.cs because it points to
                   # the LATEST on the bld branch, which has an updated   
                   # WUCE version instead of ${buildVer}.                     
                   ##########################################################
                   '. /mot/proj/wibb_bts/cmbp/bin/scstart omp4g',
                   "mkview -tag tmp-lompbcu3lxKW -nobr -b ${buildVer}",
                   "cleartool catcs -tag tmp-lompbcu3lxKW > ${logsDir}/instrumentation/lompbcu3lx_KW.cs",
                   "cleartool setcs ${logsDir}/instrumentation/lompbcu3lx_KW.cs",
                   'cleartool rmview -tag tmp-lompbcu3lxKW',

                   #########################################################
                                                                    
                   'wbld_lompbcu3lx_kw8',
		   "r2bsf1 -f ${logsDir}/instrumentation/lompbcu3lx-${buildVer}-kw"
	         . "_log_${timeStamp}.txt -p aps",
		   'build_list=`kwadmin list-builds $WUCE_KWPROJ_NAME| /bin/sed -e \'s/No builds found.*\n//\'`',
		   'build=`echo $build_list | /bin/sed -e \'s/\(^\w*\)\s.*$/\1/\'`',
		   "kwinspectreport --project \$WUCE_KWPROJ_NAME --build \$build --host $kwHost --port $kwPort"
		   . " --state $kwStates --text ${logsDir}/instrumentation/raw_\${KWPROJ}_KW_inspect_report",
		  ],
            },
        },
    },

    ########################################################
    # 4xModem target
    ########################################################
    'wompmodem' => {

        'build' => {
            'view'       => "${viewBldVer}_wompmodem_nightly",
            'configSpec' => "${logsDir}/${buildVer}_cs.wri",
            'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
            'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
				     . ':/sbin:/usr/sbin:/usr/atria/bin:.'
				     . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
			     'WUCE' => '/vob/wuce/wuce/bin/wuce',
 			     'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
			    },
            'logging'    => 1,
            'buildLog'   => "${logsDir}/compile/wompmodem-${buildVer}-build"
                            . "_log_${timeStamp}.txt",
            'buildCMDs'  =>
		[

                 ############################################################
                 # Note:  OMPSCM_HOURLY section below expects the 'wbld' 
                 # command to be in a specific array element.  Review and make 
                 # appropriate updates to the OMPSCM_HOURLY section if you 
                 # make any change to this section. 
                 ############################################################
                 # Remove view private objects
                 "$ct lsp | xargs rm -rf {}",

                 'wbld -C nodebug -N -C strip -V -k -v wompmodem wompmodem.rel',
		 "r2bsf1 -f ${logsDir}/compile/wompmodem-${buildVer}-build"
	       . "_log_${timeStamp}.txt -p aps",
		],
        },


        'instrument' => {
            'Klocwork' => {
                'view'       => "wompmodemKW_${buildVer}",
                'configSpec' => "${releaseDir}/wompmodem.cs",
                'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
                'envVars'    => {'PATH' => "$kwBin:/apps/vendor/bin:/usr/bin:/bin:"
    				         . '/etc:/sbin:/usr/sbin:/usr/atria/bin:.'
    				         . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",

    			         'WUCE' => '/vob/wuce/wuce/bin/wuce',
    			         'KWPROJ' => 'wompmodem',
    			         'WUCE_KWPROJ_NAME' => "omp_omp4g_${kwRel}_wompmodem_full",
 			         'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
    			        },
                'logging'    => 1,
                'buildLog'   => "${logsDir}/instrumentation/wompmodem-${buildVer}-kw"
                                . "_log_${timeStamp}.txt",
                'buildCMDs'  =>
		  [
                   ##########################################################
                   # Create a temporary view with ${buildVer} as the baseline
                   # so that we get the correct config specs, which looks at
                   # the correct  WUCE version.  We cannot use the config
                   # specs in ${releaseDir}/wompmodem.cs because it points to
                   # the LATEST on the bld branch, which has an updated   
                   # WUCE version instead of ${buildVer}.                     
                   ##########################################################
                   '. /mot/proj/wibb_bts/cmbp/bin/scstart omp4g',
                   "mkview -tag tmp-wompmodemKW -nobr -b ${buildVer}",
                   "cleartool catcs -tag tmp-wompmodemKW > ${logsDir}/instrumentation/wompmodem_KW.cs",
                   "cleartool setcs ${logsDir}/instrumentation/wompmodem_KW.cs",
                   'cleartool rmview -tag tmp-wompmodemKW',

                   #########################################################
                                                                    
                   'wbld_wompmodem_kw8',
		   "r2bsf1 -f ${logsDir}/instrumentation/wompmodem-${buildVer}-kw"
	         . "_log_${timeStamp}.txt -p aps",
		   'build_list=`kwadmin list-builds $WUCE_KWPROJ_NAME| /bin/sed -e \'s/No builds found.*\n//\'`',
		   'build=`echo $build_list | /bin/sed -e \'s/\(^\w*\)\s.*$/\1/\'`',
		   "kwinspectreport --project \$WUCE_KWPROJ_NAME --build \$build --host $kwHost --port $kwPort"
		   . " --state $kwStates --text ${logsDir}/instrumentation/raw_\${KWPROJ}_KW_inspect_report",
		  ],
            },
        },
    },

    ########################################################
    # WiMAX BCU1 target
    ########################################################

    'wompsc' => {

        'build' => {
            'view'       => "${viewBldVer}_wompsc_nightly",
            'configSpec' => "${logsDir}/${buildVer}_cs.wri",
            'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
            'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
				     . ':/sbin:/usr/sbin:/usr/atria/bin:.'
				     . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
			     'WUCE' => '/vob/wuce/wuce/bin/wuce',
 			     'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
			    },
            'logging'    => 1,
            'buildLog'   => "${logsDir}/compile/wompsc-${buildVer}-build"
                            . "_log_${timeStamp}.txt",
            'buildCMDs'  =>
		[
                 ############################################################
                 # Note:  OMPSCM_HOURLY section below expects the 'wbld' 
                 # command to be in a specific array element.  Review and make 
                 # appropriate updates to the OMPSCM_HOURLY section if you 
                 # make any change to this section. 
                 ############################################################
                 # Remove view private objects
                 "$ct lsp | xargs rm -rf {}",

                 'wbld -C nodebug -N -C strip -V -k -v wompsc wompsc.rel',
		 "r2bsf1 -f ${logsDir}/compile/wompsc-${buildVer}-build"
	       . "_log_${timeStamp}.txt -p aps",
		],
        },


        'instrument' => {
            'Klocwork' => {
                'view'       => "wompscKW_${buildVer}",
                'configSpec' => "${releaseDir}/wompsc.cs",
                'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
                'envVars'    => {'PATH' => "$kwBin:/apps/vendor/bin:/usr/bin:/bin:"
    				         . '/etc:/sbin:/usr/sbin:/usr/atria/bin:.'
    				         . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",

    			         'WUCE' => '/vob/wuce/wuce/bin/wuce',
    			         'KWPROJ' => 'wompsc',
    			         'WUCE_KWPROJ_NAME' => "omp_omp4g_${kwRel}_wompsc_full",
 			         'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
    			        },
                'logging'    => 1,
                'buildLog'   => "${logsDir}/instrumentation/wompsc-${buildVer}-kw"
                                . "_log_${timeStamp}.txt",
                'buildCMDs'  =>
		  [
                   ##########################################################
                   # Create a temporary view with ${buildVer} as the baseline
                   # so that we get the correct config specs, which looks at
                   # the correct  WUCE version.  We cannot use the config
                   # specs in ${releaseDir}/wompsc.cs because it points to
                   # the LATEST on the bld branch, which has an updated   
                   # WUCE version instead of ${buildVer}.                     
                   ##########################################################
                   '. /mot/proj/wibb_bts/cmbp/bin/scstart omp4g',
                   "mkview -tag tmp-wompscKW -nobr -b ${buildVer}",
                   "cleartool catcs -tag tmp-wompscKW > ${logsDir}/instrumentation/wompsc_KW.cs",
                   "cleartool setcs ${logsDir}/instrumentation/wompsc_KW.cs",
                   'cleartool rmview -tag tmp-wompscKW',

                   #########################################################
                                                                    
                   'wbld_wompsc_kw8',
		   "r2bsf1 -f ${logsDir}/instrumentation/wompsc-${buildVer}-kw"
	         . "_log_${timeStamp}.txt -p aps",
		   'build_list=`kwadmin list-builds $WUCE_KWPROJ_NAME| /bin/sed -e \'s/No builds found.*\n//\'`',
		   'build=`echo $build_list | /bin/sed -e \'s/\(^\w*\)\s.*$/\1/\'`',
		   "kwinspectreport --project \$WUCE_KWPROJ_NAME --build \$build --host $kwHost --port $kwPort"
		   . " --state $kwStates --text ${logsDir}/instrumentation/raw_\${KWPROJ}_KW_inspect_report",
		  ],
            },
        },
    },


    ########################################################
    # WiMAX BCU2 target
    ########################################################

    'wompsac' => {

        'build' => {
            'view'       => "${viewBldVer}_wompsac_nightly",
            'configSpec' => "${logsDir}/${buildVer}_cs.wri",
            'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
            'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
				     . ':/sbin:/usr/sbin:/usr/atria/bin:.'
				     . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
			     'WUCE' => '/vob/wuce/wuce/bin/wuce',
 			     'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
			    },
            'logging'    => 1,
            'buildLog'   => "${logsDir}/compile/wompsac-${buildVer}-build"
                            . "_log_${timeStamp}.txt",
            'buildCMDs'  =>
		[
                 ############################################################
                 # Note:  OMPSCM_HOURLY section below expects the 'wbld' 
                 # command to be in a specific array element.  Review and make 
                 # appropriate updates to the OMPSCM_HOURLY section if you 
                 # make any change to this section. 
                 ############################################################
                 # Remove view private objects
                 "$ct lsp | xargs rm -rf {}",

                 'wbld -C nodebug -N -C strip -V -k -v wompsac wompsac.rel',
		 "r2bsf1 -f ${logsDir}/compile/wompsac-${buildVer}-build"
	       . "_log_${timeStamp}.txt -p aps",
		],
        },


        'instrument' => {
            'Klocwork' => {
                'view'       => "wompsacKW_${buildVer}",
                'configSpec' => "${releaseDir}/wompsac.cs",
                'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
                'envVars'    => {'PATH' => "$kwBin:/apps/vendor/bin:/usr/bin:/bin:"
    				         . '/etc:/sbin:/usr/sbin:/usr/atria/bin:.'
    				         . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",

    			         'WUCE' => '/vob/wuce/wuce/bin/wuce',
    			         'KWPROJ' => 'wompsac',
    			         'WUCE_KWPROJ_NAME' => "omp_omp4g_${kwRel}_wompsac_full",
 			         'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
    			        },
                'logging'    => 1,
                'buildLog'   => "${logsDir}/instrumentation/wompsac-${buildVer}-kw"
                                . "_log_${timeStamp}.txt",
                'buildCMDs'  =>
		  [
                   ##########################################################
                   # Create a temporary view with ${buildVer} as the baseline
                   # so that we get the correct config specs, which looks at
                   # the correct  WUCE version.  We cannot use the config
                   # specs in ${releaseDir}/wompsac.cs because it points to
                   # the LATEST on the bld branch, which has an updated   
                   # WUCE version instead of ${buildVer}.                     
                   ##########################################################
                   '. /mot/proj/wibb_bts/cmbp/bin/scstart omp4g',
                   "mkview -tag tmp-wompsacKW -nobr -b ${buildVer}",
                   "cleartool catcs -tag tmp-wompsacKW > ${logsDir}/instrumentation/wompsac_KW.cs",
                   "cleartool setcs ${logsDir}/instrumentation/wompsac_KW.cs",
                   'cleartool rmview -tag tmp-wompsacKW',

                   #########################################################
                                                                    
                   'wbld_wompsac_kw8',
		   "r2bsf1 -f ${logsDir}/instrumentation/wompsac-${buildVer}-kw"
	         . "_log_${timeStamp}.txt -p aps",
		   'build_list=`kwadmin list-builds $WUCE_KWPROJ_NAME| /bin/sed -e \'s/No builds found.*\n//\'`',
		   'build=`echo $build_list | /bin/sed -e \'s/\(^\w*\)\s.*$/\1/\'`',
		   "kwinspectreport --project \$WUCE_KWPROJ_NAME --build \$build --host $kwHost --port $kwPort"
		   . " --state $kwStates --text ${logsDir}/instrumentation/raw_\${KWPROJ}_KW_inspect_report",
		  ],
            },
        },
    },

); # end of build targets definition


###################################################################
##  For hourly builds, '<target>.rel'(copy build objects to FA) 
##  is not executed.  Updating %targets to change the view name, and
##  to remove '<target>.rel' from the build commands.
###################################################################
if (defined $ENV{'OMPSCM_HOURLY'} and $ENV{'OMPSCM_HOURLY'}) {
   
    foreach my $key (keys %targets){

       # Replace the view tag
       $targets{$key}->{'build'}->{'view'} = "${viewBldVer}_${key}_hourly";

       # Remove '$ct lsp' command since there is no need to remove
       # view private objects for hourly builds
       if ((defined $targets{$key}->{'build'}->{'buildCMDs'}[0])
       and ($targets{$key}->{'build'}->{'buildCMDs'}[0])){
           $targets{$key}->{'build'}->{'buildCMDs'}[0] =~ s/^$ct lsp.*/print/;
       }

       # Remove the wuce target ${key}.rel
       if ((defined $targets{$key}->{'build'}->{'buildCMDs'}[1])
       and ($targets{$key}->{'build'}->{'buildCMDs'}[1])){
          $targets{$key}->{'build'}->{'buildCMDs'}[1] =~ s/ $key.rel//;
       }
    }

} # end if (defined...


############################################################################
##  For nightly KW builds, the view name, WUCE_KW7_SCOPE and WUCE_KWPROJ_NAME
##  are different.  Also, only the last five builds are saved in the KW
##  portal. This code is commented out because it is not used currently
############################################################################
if (defined $ENV{'OMPSCM_NIGHTLY_KW'} and $ENV{'OMPSCM_NIGHTLY_KW'}) {
   
    foreach my $key (keys %targets){

       # Replace the view tag
       $targets{$key}->{'instrument'}->{'Klocwork'}->{'view'} = "${viewBldVer}_${key}_nightlyKW";
       $targets{$key}->{'instrument'}->{'Klocwork'}->{'envVars'}->{'WUCE_KW7_SCOPE'} = 'nightly';
       $targets{$key}->{'instrument'}->{'Klocwork'}->{'envVars'}->{'WUCE_KWPROJ_NAME'} = "omp_omp4g_${kwRel}_${key}_nightly";
       
       # Keep only the last 5 builds
       push @{$targets{$key}->{'instrument'}->{'Klocwork'}->{'buildCMDs'}},
         'old_build=`echo $build_list | /bin/sed -e \'s/.*\s\(\w*\)$/\1/\'`',
         '[[ `echo $build_list | wc -w` -gt 5 ]] && kwadmin delete-build $WUCE_KWPROJ_NAME $old_build'
          . ' || echo "Five or less builds available, so no build removed."',
         "$ct lspriv -s | /usr/bin/xargs -i rm -rf {}";
    } #end foreach my $key


    foreach my $key (keys %targets){

         print "key = $key\n";
         print "view = $targets{$key}->{'instrument'}->{'Klocwork'}->{'view'}\n";
         print "KW7_SCOPE = $targets{$key}->{'instrument'}->{'Klocwork'}->{'envVars'}->{'WUCE_KW7_SCOPE'}\n" ;
         print "KWPROJ_NAME = $targets{$key}->{'instrument'}->{'Klocwork'}->{'envVars'}->{'WUCE_KWPROJ_NAME'}\n";
   }
} # end if (defined...

# Setup for creating the final package
#  User defined packaging commands
# Not used in OMP builds
%packaging = (
    'view'       => "",
    'configSpec' => "${logsDir}/${buildVer}_cs.wri",
    'startDir'   => "$SCM_ADMIN_VOB/bld/wuce/bin",
    'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
    			     . ':/sbin:/usr/sbin:/usr/atria/bin:.'
    			     . ':/vob/ltescm/bin:'
    			     . "/vob/wuce/wuce/bin:$ENV{'PATH'}",
                    },
    'logging'    => '',
    'logFile'    => "${logsDir}/packaging/${lcProd}-${buildVer}-pkg"
                  . "_log_${timeStamp}.txt",
    'CMDs'       => [''],
); # end of packaging configuration


# Setup for applying the ClearCase label
#  Default is lte_label.pl tool which labels CLEARCASE_AVOBS in
#    parallel
#  User may define any labeling commands/tools they wish
%labeling = (
    'view'       => "${buildVer}",
    'configSpec' => "${logsDir}/${buildVer}_cs.wri",
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
    			     . ':/sbin:/usr/sbin:/usr/atria/bin:.'
    			     . ':/vob/ltescm/bin:'
    			     . "/vob/wuce/wuce/bin:$ENV{'PATH'}",
                    },
    'logging'    => 1,
    'logFile'    => "${logsDir}/label/${lcProd}-${buildVer}-label"
                  . "_log_${timeStamp}.txt",
    'CMDs'       => ["$ct mklbtype -global -nc ${buildVer}\@${SCM_ADMIN_VOB}",
                     
                     #############################################
                     # Label /vob/omp4g and /vob/omp4g_rd_oss vobs
                     #############################################
                     "$ct mklabel -recurse -replace ${buildVer} "
                    . "/vob/omp4g /vob/omp4g_rd_oss "
                    . "> ${logsDir}/label/mklabel_log_${timeStamp}.txt 2>&1; echo 0",

                     #############################################
                     # Filter out known errors from the label log 
                     # using check_label_log.pl                   
                     #############################################
                     "/vob/ltescm/bin/omp4g/check_label_log.pl -f ${logsDir}/label/mklabel_log_${timeStamp}.txt",

                     #############################################
                     # Lock the label type and attach 'DevProject'
                     # attribute.                                   
                     #############################################
                     "$ct lock -replace -nuser $USER lbtype:$buildVer\@${SCM_ADMIN_VOB}",
                     "$ct mkattr -nc DevProject \\\"${buildVer}.prj\\\" "
                   . "lbtype:${buildVer}\@$SCM_ADMIN_VOB",
                     "$ct lock -replace lbtype:$buildVer\@${SCM_ADMIN_VOB}",
                    ],

); # end of labeling configuration


# Setup for post CQCM checks and closure
%close_cqcm = (
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {},
    'logFile'    => "${logsDir}/other/${lcProd}-${buildVer}-close_cqcm"
                  . "_log_${timeStamp}.txt",
); # end of close_cqcm configuration


# Setup for prj file creation
# You can specify your own project directory, exclude lines from the current
# view's configuration of specification, set the group your prj file should
# be created with and identify whether or not your prj file should be created
# as a VOB element.
%project = (
    'projDir'    => "",             # if not defined in LTE_BLD_CONF.pm
    'in_vob'	 => 0,              # 0 in on UXIX path, 1 if in vob
    'newgrp'	 => "il02-ltescm",  # the group for gewgrp, if necessary
    'server'     => "ltelinux2",    # the server to execute the generated script
    'logFile'    => "${logsDir}/other/${lcProd}-${buildVer}-project"
                  . "_log_${timeStamp}.txt",
    'exlcude_lines' => [],          # table of patterns to excludde from config_spec
); # end of project configuration


# Setup for closing the build
#  Execute the lte_bld_report.pl
#  Sends release email
%close_build = (
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {},
    'logging'    => 1,
    'logFile'    => "${logsDir}/post_build/${lcProd}-${buildVer}-close_build"
                  . "_log_${timeStamp}.txt",
); # end of close_build configuration


# Setup for source size metrics calcuation and upload
#  Default is to run ssmt.pl
#  User may define any SSM commands/tools they wish
%ssm = (
    'view'       => "",
    'configSpec' => "",
    'server'     => 'ltesol1',
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
    			     . ':/sbin:/usr/sbin:/usr/atria/bin:.'
    			     . ':/vob/ltescm/bin:'
    			     . "/vob/wuce/wuce/bin:$ENV{'PATH'}",
                    },
    'logging'    => 1,
    'logFile'    => "${logsDir}/ssmt/${lcProd}-${buildVer}-ssm"
                  . "_log_${timeStamp}.txt",
    'CMDs'       => [
                     "cd ${releaseDir}; ssmt.pl -prod ${system}-${product} -b ${buildVer}"
                     . " -dir ./logs/ssmt -metrics_dir ./metrics/ssmt",
                    ],
); # end of ssm configuration

#============================================================================
#==============================  FUNCTIONS  =================================
#============================================================================

## Note(s):
## Besides the functions shown below, we have the following post<Step>
## functions availble: postValidEnv, postValidCQCM, postMerge, postCompile,
## postPackage, postLabel, postCloseCQCM, postCloseBuild, postInstrument, and
## postSSM.  Also, please note:
##      o Each function must be added to the list of symbols to be exported.
##      o Each defined function is automatically called after the
##        corresponding step (e.g. postCompile after compile, postSSM after
##        ssm etc).
##
## To execute a system command, please use execWMetrics so SCM metrics will
## be written for any failure.  For more info on this function, see
## buildProcessor.pl.
##
## If you are not using execWMetrics to run system commands or if you have
## your own private error handling block for Perl failures, please add the
## following line to that error handler to the final status report from bP
## will reflect your module failure:
##	$results .= "<subroutine> FAILED to complete successfully!\n";

## Available functions provided by buildProcessor.pl:
##	<Name>		- <Where defined>
##	execWMetrics	- buildProcessor.pl
##      logMetrics	- buildProcessor.pl
##	print_and_log	- SCM_common.pm
##	process_error	- SCM_common.pm
##	time		- POSIX
##	write_to_script	- SCM_common.pm
##
## The SCM_common.pm API is here:
## http://compass.mot.com/go/lte_scm_common_api.doc


## Define "createView" to override the default createView behavior
#sub createView {
#}


## Define "preBuild" for any team-specific pre-build activities to be called
## by buildProcessor.pl.
## Notes: Will be called prior to any target processing.
##        This symbol must be added to the list of symbols to be exported.
sub preBuild {
    my $cmd     = '';        # Command we plan to execute
    my $PH      = undef();   # Process Handle
    my $rc      = undef;     # Return code from executed command
    
    ## Save the config spec and set the wuce version if set into a view
    if (defined $ENV{'CLEARCASE_ROOT'}) {

        ## Save the config spec
        $cmd = "$ct catcs";

        # Open the build config spec file for writing.
        open(my $buildCS, '>', "${logsDir}/${buildVer}_cs.wri")
          or do {
          process_error('mx',
            'Failed to open FH on ' . __FILE__ .
            ' line ' . (__LINE__ - 3) . '!', $maillist,
            "$tool failure (PID $$)");
        };
        
	# First add the time stamp in GMT
	print $buildCS "##\n## Time rule for this build in UTC (GMT)\n##\n" .
	  'time ' . strftime("%d-%B-%Y.%H:%M", gmtime(time)) . "UTC\n\n";

        # Note the '-|' in the next line that is used so we can capture the
        # output.  Different than the other open commands in this function.      
        open($PH, '-|', "$cmd") or do {
          process_error('mx',
            'Failed to open PH on ' . __FILE__ .
            ' line ' . (__LINE__ - 3) . '!', $maillist,
            "$tool failure (PID $$)");
        };
        
        # Send output to the $buildCS file
        while (my $outline = <$PH>) {
            print $buildCS "$outline";
        } # end while (my $outline...
      
	# Close out the time rule
	print $buildCS "\n##\n## End time rule\n##\nend time\n";

        close($buildCS);
        close($PH);
      
        # Capture the return status from the program and not the shell.
        # Exit value of the subprocess is in the high byte, $? >> 8.
        # The low byte says which signal the process died from, $?.
        $rc = ($? >> 8);
        ($rc > 0) && do {
          process_error('mx',
           "$cmd failed with a return code of $rc: $!\n", $maillist,
           "$tool failure (PID $$)");
        };
        
        undef($cmd);
        undef($PH);
        undef($rc);

    } else { # Not set into a view
      process_error('mx',
         "You are not set into a view, so ${tool} cannot save the config "
         . "spec or update the WUCE version.\n", $maillist,
         "$tool failure (PID $$)");         
    } # end if (defined $ENV...

} # end sub preBuild


## Define "postCompile" for any team-specific post-compile activities to be
## called by buildProcessor.pl.
## Notes: Will be called after all target compiling/linking is complete.
##        This symbol must be added to the list of symbols to be exported.
sub postCompile {
    my $cmd     = '';        # Command we plan to execute
    my $pkgdir  = "$SCM_ADMIN_VOB/bld/pkg"; # The package staging area
    my $sTime   = time();    # Current time (seconds) for metrics purposes


    # Allow the user to set the env var BP_SKIP_FINAL_PKG if they want to
    # skip packaging for this execution of buildProcessor.pl.
    unless ($ENV{'BP_SKIP_FINAL_PKG'}) {

      ######################################################################
      # lompbcu3lx.pkg needs lompbcu3vx.tgz in $pkgdir.  Copy lompbcu3vx.tgz
      # from <lompbcu3vx view>/$pkgdir, and execute lompbcu3lx.pkg 
      # and lompbcu3lx.rel
      ######################################################################
      if (grep (/^lompbcu3lx$/, @targets)){

         my $viewSuffix;
         my $wbld_cmd;
         if (defined $ENV{'OMPSCM_HOURLY'} and $ENV{'OMPSCM_HOURLY'}) {
            $viewSuffix = "hourly";
            $wbld_cmd = "wbld -C nodebug -N -C strip -V -k -v lompbcu3lx.pkg";
         }
         else{
            $viewSuffix = "nightly";
            $wbld_cmd = "wbld -C nodebug -N -C strip -V -k -v lompbcu3lx.pkg lompbcu3lx.rel";
         }

         # Start lompbcu3vx view
         $cmd = "$ct setview -exec \"$ct startview ${viewBldVer}_lompbcu3vx_${viewSuffix}\" ${viewBldVer}_lompbcu3lx_${viewSuffix}";
         execWMetrics($cmd, $COMPILE_METRICS_FH, $sTime);
         undef($cmd);
        
         $cmd = "$ct setview -exec \"$cp /view/${viewBldVer}_lompbcu3vx_${viewSuffix}/$pkgdir/lompbcu3vx.tgz"
              . " $pkgdir\" ${viewBldVer}_lompbcu3lx_${viewSuffix}";
         execWMetrics($cmd, $COMPILE_METRICS_FH, $sTime);
         undef($cmd);

         # Execute lompbcu3lx.pkg lompbcu3lx.rel
         $cmd = "$ct setview -exec \"${wbld_cmd}"
           . " >> ${logsDir}/compile/lompbcu3lx-${buildVer}-build"
           . "_log_${timeStamp}.txt 2>&1\" ${viewBldVer}_lompbcu3lx_${viewSuffix}";
         execWMetrics($cmd, $COMPILE_METRICS_FH, $sTime);
         undef($cmd);

         # Run r2bsf1 to examine packaging log for "real" errors.
         #  valid values for the -p flag are: {aps|capc|cpe}
         $cmd = "$ct setview -exec \"/vob/wuce/wuce/bin/r2bsf1 -f ${logsDir}"
           . "/compile/lompbcu3lx*-build_log_${timeStamp}.txt -p aps > "
           . "${logsDir}/compile/lompbcu3lxpkg_r2bsf1_build_analysis.txt\" "
           . "${viewBldVer}_lompbcu3lx_${viewSuffix}";
         execWMetrics($cmd, $COMPILE_METRICS_FH, $sTime);
         undef($cmd);
         
      } # end (if (grep (/^lompbcu3lx$/, @targets)) ...

     } # end unless ($ENV{'BP_SKIP_FINAL_PKG'}...

} # end sub postCompile


## Define "postInstrument" for any team-specific post-instrument activities
## to be called by buildProcessor.pl.
## Notes: Will be called after all target instrumentation is complete.
##        This symbol must be added to the list of symbols to be exported.
sub postInstrument {
    my $cmd     = '';        # Command we plan to execute
    my $sTime   = time();    # Current time (seconds) for metrics purposes

    # Call weave on nightlyKW to send out report
    # We apply the officialKW.sed script to nightlyKW to rip out the
    # section that executes the build since this now happens in bP.
    # For <TARGET> below, use any one valid "wbld" target (e.g. wbcssc,
    # ldapmodem, sdl ...).
    $cmd = "/vob/wuce/wuce/bin/weave -s -f /vob/ltescm/bin/sed/officialKW."
         . "sed /vob/ltescm/bin/nightlyKW -s omp -p $lcProd -l lompbcu3vx -m"
         . " $teamEmail -v $buildVer -r ${logsDir}/instrumentation >> "
         . "${logsDir}/instrumentation/${lcProd}-${buildVer}-kw_log_"
         . "${timeStamp}.txt 2>&1";
    print_and_log($plcode, "Executing: $cmd\n\n");
    execWMetrics($cmd, $INSTR_METRICS_FH, $sTime);

   ######################################################
   # Upload the KW metrics if it is not a nightly KW build
   ######################################################
   if ((not defined $ENV{'OMPSCM_NIGHTLY_KW'}) or (not $ENV{'OMPSCM_NIGHTLY_KW'})) {
       # Now we upload the KW build data to the shared Oracle database.
       $cmd = "/vob/ltescm/bin/4g_kwmetrics_upload.pl -prod $lcProd -v "
            . "$buildVer -path $releaseDir >> ${logsDir}/instrumentation/"
            . "${lcProd}-${buildVer}-kw_log_${timeStamp}.txt 2>&1";
       print_and_log($plcode, "Executing: $cmd\n\n");
       execWMetrics($cmd, $INSTR_METRICS_FH, $sTime);
   }
} # end sub postInstrument


## Define "postMerge" for any team-specific post-merge activities to be
## called by buildProcessor.pl.
## Notes: Will be called after all build processing is complete.
##        This symbol must be added to the list of symbols to be exported.
sub postMerge {
    my $cmd     = '';        # Command we plan to execute
    my $sTime   = time();    # Current time (seconds) for metrics purposes
    my $initial     = $objectsRef->{'INITIAL'};
    
    ## Save the config spec and set the wuce version if set into a view
    #  Note: this is not perfect because if you did an "scstart" you are
    #  actually set into a view if you had not been before.  Our build
    #  process has us set into the official view before we get to this
    #  point anyway, so this is just an extra check.
    if (defined $ENV{'CLEARCASE_ROOT'}) {

      ## Update of the WUCE version is taken care of by the nightly builds
      ## We need to take care of updating the WUCE version only when 
      ## a 'devint' is being merged to a 'bld', or when a 'bld' is being
      ## merged to the rel main.
      if (grep {/^devint-|_bld-/} keys %{$initial->{'BRs_TO_MERGE'}}){
         $cmd = "/vob/ltescm/bin/update_version_number.pl -b $buildVer -vob "
           . $SCM_ADMIN_VOB;
         print_and_log($plcode, "Executing: $cmd\n\n");

         execWMetrics($cmd, $MERGE_METRICS_FH, $sTime);
      } # end if (grep
    } # end if (defined...
 
} # end sub postMerge

## Define "postBuild" for any team-specific post-build activities to be
## called by buildProcessor.pl.
## Notes: Will be called after all other processing is complete.
##        This symbol must be added to the list of symbols to be exported.
#sub postBuild {
#} # end sub postBuild

1;

# EOF
