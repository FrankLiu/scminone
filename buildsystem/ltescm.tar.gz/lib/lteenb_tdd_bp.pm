#!/apps/public/perl_5.8.4/bin/perl
#############################################################################
#
#       Copyright (C) 2006-2009 MOTOROLA. All Rights Reserved.
#
#       The copyright notice above does not evidence any
#       actual or intended publication of such source code.
#       The code contains Motorola Confidential Restricted Information.
#
#############################################################################
#
#  FILE NAME:    lteenb_bp.pm
#
#  OWNER:        LTE SCM Team
#
#  DATE CREATED: 01/13/2009
#
#  SYNOPSIS:     None.
#
#  EXIT VALUE:   1; - Mandatory for module to load successfully
#
#  DESCRIPTION:  This Perl module contains common functions and variables
#                used for building lteenb_bp targets.
#
#############################################################################
#
#  MODIFICATION HISTORY:
#
# Ver    Date     Engineer     CR                     Change
# --- ---------- ---------- --------  ---------------------------------------
# 1.0 01/13/2009 skerr1     01120994  Created initial version based on iDEN
#				      SCM team's product_template.pm.
# 1.1 03/20/2009 skerr1     01167444  Fixed releaseDir location.
#
#############################################################################
#
#  FUNCTIONS:  (Alphabetical)
#
#	Local
#	-----
#	createView()		- Build Type-specific create view function
#	postBuild()		- Build Type-specific post-build commands
#	preBuild()		- Build Type-specific pre-build commands
#
#############################################################################

## DEVELOPMENT NOTES:
#  -----------------
# 1. Any variables global to this package must be declared within the 'our'
#    directive because of the 'strict' pragma.

## CHECKLIST WHEN UPDATING THIS MODULE:
#  -----------------------------------
# 1. Update @EXPORT if created a function or variable to be exported.
# 2. Update 'our' if added a global variable to this module or if a variable
#    needs to be exported.
# 3. Update the "FUNCTIONS" list in the prologue.
# 4. Update the "MODIFICATION HISTORY" in the prologue.
# 5. Turn Perl diagnostics (use diagnostics;) and strict (use strict;) off
#    before release.

# Used as error checking mechanism: does not allow re-declaration of
# the same variable within the same scope.  For testing purposes only.
# Note: We do not check for strict references in order to access globals from
#       the calling package.
#use strict qw(vars subs);
#use diagnostics;

# Using LTE COMMON libraries
BEGIN {
   if (defined($ENV{LTE_BLDTOOLS})){
	   unshift @INC, "$ENV{LTE_BLDTOOLS}/../lib", "$ENV{LTE_BLDTOOLS}", "$ENV{LTE_BLDTOOLS}/enodeb";
   } elsif (defined($ENV{SCM_BLDTOOLS})) {
	   unshift @INC, "$ENV{SCM_BLDTOOLS}", "$ENV{SCM_BLDTOOLS}/..", "$ENV{SCM_BLDTOOLS}/../../lib";
   } else {
	   unshift @INC,"/vob/ltescm/bin","/vob/ltescm/lib","/vob/ltescm/bin/enodeb";
   }
}

# Indicates that the entire library's symbol table or namespace is labeled
# as lteenb_bp.  The compiler will look for any undefined symbols, in the calling
# program, in this package.
package lteenb_tdd_bp;

use 5.8.4;	# Use Perl 5.8.4 or higher (also for debugging purposes)
use Data::Dumper;
use COMMON;

# Used to setup export methods into calling programs.  Allows the use of
# import(), @ISA, @EXPORT, etc., which allows for different ways of exporting
# symbols.
require Exporter;

# Standard global symbols
our (@ISA, @EXPORT);

# Search location for unresolved functions in the current package.
# The search is left to right.
# Exporter is included here because of the import() function.
@ISA = qw(Exporter);

# List of symbols to be exported by :DEFAULT.
# List functions first, then all other symbols.
@EXPORT	  =  qw(
		preBuild
		postBuild
        $createView
		$defaultBuildVer
		$delivDir
		$logsDir
		$metricsDir
		$product
		$releaseDir
		$system
		%targets
 		$templateVersion
	       );

# Package global variables (some are imported from the calling namespace).
our    ($buildVer,
	$buildver,
	$COMPILE_METRICS_FH,
	$cp,
	$createView,
	$ct,
	$defaultBuildVer,
	$delivDir,
	$delivView,
	$INSTR_METRICS_FH,
	$logsDir,
	$maillist,
	$metricsDir,
	$product,
	$releaseDir,
	$system,
	%targets,
	$templateVersion,
	$tool,
	$USER,
	$SCM_BLDTOOLS,
	$dts,
       );

# Mandatory symbols that must be defined in this package include:
#
# $createView		- This is the command to create a view.  The most
#               	  common option is provided (for SCH).
# $defaultBuildVer	- Defined even if it is an empty string.
# $delivDir		- Used for target build deliverable storage.
# $logsDir		- Used for target build logs storage.
# $metricsDir		- Used for target build SCM metrics storage.
# $product		- Product this build type belongs to.
# $releaseDir		- Used for target build scripts.
# $system		- System this build type belongs to.
# %targets		- At least one target must be defined.
# $templateVersion	- Version of product_template.pm we are using.
#

# Note that "Instrumentation" in %targets can be set to "{}" if there is no
# defined instrumentation for that particular target.

#============================================================================
#=====================  Exported Variable Initialization  ===================
#============================================================================
#
# Do not use the 'my' directive for those definitions we are using the 'our'
# directive for above.
#

# Version of product_template.pm populated for this build type
$templateVersion = 1.1;

# Insert your default version here.  Leave as '' if your team has no default
# value (note, build will halt if no default value and no version is provided
# on the command line).
$defaultBuildVer = '';

## Do not touch the following block of code ##
# This block sets the user and buildVer var for use within this module
my $pkg   = (caller)[0];		# Calling package name

# Import exported variables from calling tool
$pkg->import;

if (!defined($buildVer) or $buildVer =~ /^\s*$/) {
    $buildVer = $defaultBuildVer;
} # end if (!defined...
##   Do not touch the above block of code   ##
$buildVer =~ tr/a-z/A-Z/;
($buildver = $buildVer) =~ tr/A-Z/a-z/;

my $common = new COMMON('LTE_LBL_NAME' => $buildVer, 'PRE_BUILD_MODE' => 0);
print Dumper $common;

# Set the system, product and releaseDir if the Version is correctly
# formatted.
if ($common->{'PRODUCT'} =~ /(.*)?-(.*)?/) {
	$system = $1;
	$product = $2;
} else {
  process_error('x', 'Could not determine system, product and release from'
                    ." the passed version: $buildVer.");
}
$releaseDir = $common->{'LTE_DIR_ROOT'};

print "SYSTEM: $system, PRODUCT: $product, RELEASE_DIR: $releaseDir \n";

# Release directory locations (standard locations provided) created by
# buildProcessor.pl
$delivDir   = "$releaseDir/deliverables";   # Deliverables
$logsDir    = "$releaseDir/logs";           # Log files
$metricsDir = "$releaseDir/metrics";        # Build metrics
$vob 		= "/vob/lteenb";

# current view is used to copy binaries, making hap_lomp_pkg, cl_files and final lap_bundle
$currView = `$CLEARTOOL pwv -s`;
chomp($currView);
#$delivView = $currView.$vob."/bld/pkg/" if ($currView ne "");
$delivView = "/view/".$common->{'LTE_BLD_VIEW'}."/vob/lteenb/bld/pkg/";
$dts=`date '+%Y_%m_%d.%H_%M_%S'`;
chomp($dts);

$SCM_BLDTOOLS = "/vob/ltescm/bin/enodeb";
$SCM_BLDTOOLS = $ENV{SCM_BLDTOOLS} if (defined($ENV{SCM_BLDTOOLS}));

# SCH createView basic command
$createView = "/mot/proj/lte_scm/cmbp/lte_enb/cm-policy/bin/mkview -tag <view> -nobr";
# NOTE We use the non-CQCM makeview here and so we must set a config spec.
#      We do not use the DEVINT/BLD view.

# Build type-specific definitions

#============================================================================
#===============================  TARGETS  ==================================
#============================================================================

%targets = (


    'ldapmodem' => {

        'build' => {
            'view'       => "ldapmodem_${buildver}",
            'configSpec' => "${logsDir}/build.cs",
            'startDir'   => '/vob/lteenb',
            'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
				       		. ':/sbin:/usr/sbin:/usr/atria/bin:.'
				       		. ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
			     			'WUCE' => '/vob/wuce/wuce/bin/wuce',
			    			},
            'logging'    => 1,
            'buildLog'   => "${logsDir}/ldapmodem-${buildVer}-build_log.$dts.wri",
            'buildCMDs'  =>
							['MAKE_OPT=-k /vob/wuce/wuce/bin/wbld logmanager_gui',
							'WUCE_CFLAGS=-DLTE_TDD_MODE MAKE_OPT=-k time /vob/wuce/wuce/bin/wbld -C metric -C strip -V -k -v ldapmodem  ldapmodem.pkg',
		 					"echo $vob/bld/pkg/* ${delivView}",
		 					"$cp -rp $vob/bld/pkg/* ${delivView}",
							]
        },

        'instrumentation' => {
            'Klocwork' => {
                'view'       => "ldapmodem_${buildver}",
                'configSpec' => "${logsDir}/build.cs",
                'startDir'   => "${vob}/bld/wuce/bin",
                'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
    				       		. ':/sbin:/usr/sbin:/usr/atria/bin:.'
    				       		. ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
    			         		'WUCE' => '/vob/wuce/wuce/bin/wuce',
    			        		},
                'logging'    => 1,
                'buildLog'   => "${logsDir}/ldapmodem-${buildVer}-kw_log.${dts}.wri",
                'buildCMDs'  =>
		  						['wbld_ldapmodem_kw8',
		  						]
            }
        }

    },

    'lapsac' => {

        'build' => {
            'view'       => "lapsac_${buildver}",
            'configSpec' => "${logsDir}/build.cs",
            'startDir'   => '/vob/lteenb-om/code/utx/palPCDClassNames',
            'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
				       		. ':/sbin:/usr/sbin:/usr/atria/bin:.'
				       		. ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
			     			'WUCE' => '/vob/wuce/wuce/bin/wuce',
			     			'WUCE_APP_CFG' => 'lte-lapsac-lapsac',
			    			},
            'logging'    => 1,
            'buildLog'   => "${logsDir}/lapsac-${buildVer}-build_log.${dts}.wri",
            'buildCMDs'  =>
							['wuce -V',
							 '/vob/wuce/wuce/bin/wbld lapsac_linux',
							 '/vob/wuce/wuce/bin/wbld -V -v lapsac lapsac.pkg',
		 					 "echo $cp -rp $vob/bld/pkg/* ${delivView}",
							 "$cp -rp ${vob}/bld/pkg/* ${delivView}",
		 					 "echo cp -rp ${vob}/bld/lib/do.ppc_e500v2-glibc_cgl ${delivView}/../lib/",
		 					 "cp -rp ${vob}/bld/lib/do.ppc_e500v2-glibc_cgl ${delivView}/../lib/",
							]
        },


        'instrumentation' => {
            'Klocwork' => {
                'view'       => "lapsac_${buildver}",
                'configSpec' => "$logsDir/build.cs",
                'startDir'   => "${vob}/bld/wuce/bin",
                'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
    				       		. ':/sbin:/usr/sbin:/usr/atria/bin:.'
    				       		. ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
    			                 'WUCE' => '/vob/wuce/wuce/bin/wuce',
    			        		},
                'logging'    => 1,
                'buildLog'   => "${logsDir}/lapsac-${buildVer}-kw_log.${dts}.wri",
                'buildCMDs'  =>
							  ['wbld_lapsac_kw8',
							  ]
            }
        }
    },

); # end of builds definition


#============================================================================
#==============================  FUNCTIONS  =================================
#============================================================================

## Note(s):
##  If you want to capture SCM metrics for any step in the preBuild or
##  postBuild functions, you only need to capture the time just before you
##  you process the commands you want to execute:
##      my $sTime   = time();    # Current time (seconds) for metrics purposes
##  When you are finished processing the command(s) you want to time, call
##  printMetrics with either one of the already defined file handles
##  ($COMPILE_METRICS_FH or $INSTR_METRICS_FH), the start time and the
##  current time:
##      printMetrics($COMPILE_METRICS_FH, $sTime, time());
##  You may also define your own metrics file and pass that FH to
##  printMetrics instead (you must open it first).


## Define "createView" to override the default createView behavior
#sub createView {
#}

## Define "postBuild" for any team-specific post-build activities to be
## called by buildProcessor.pl.
## Notes: Will be called after all target processing is complete.
##        This symbol must be added to the list of symbols to be exported.
sub postBuild {
	# add Produce lap_bundle.tgz

    my $cmd     = '';        # Command we plan to execute
    my $mv      = '/bin/mv'; # *nix move command
    my $pkgdir  = $delivView; # The package staging area

    print "This is postBuild function\n";
    # Allow the user to set the env var BP_SKIP_FINAL_PKG if they want to
    # skip packaging for this execution of buildProcessor.pl.
    unless ($ENV{'BP_SKIP_FINAL_PKG'}) {

        ## Copy pkg directories
#        $cmd = "cp /view/ldapmodem_${buildver}/$vob/bld/pkg/* $vob/bld/pkg/";
#        execute($cmd);
#        $cmd = "cp /view/lapsac_${buildver}/${vob}/bld/pkg/* ${pkgdir}";
#        execute($cmd);

  		print "\n---------------------------\n";
		print " Produce lap_bundle.tgz ... \n";
		print "---------------------------\n";
#		chdir ("/view/lapsac_${buildver}");
		$cmd = "$SCM_BLDTOOLS/call_and_log.pl -c \"/vob/lteenb/bld/wuce/bin/hap_lomp_pkg lteenb /vob/lteenb/bld/wuce/bin /vob/lteenb-om/code/runtime_config\" -l $logsDir/build/build.${buildVer}.hap_lomp_pkg.${dts}.log";
		execute($cmd);
		$cmd = "$SCM_BLDTOOLS/call_and_log.pl -c \"/vob/lteenb/bld/wuce/bin/mm_lap_wrap /vob/lteenb\" -l $logsDir/build/build.${buildVer}.mm_lap_wrap.${dts}.log";
		execute($cmd);
		print "\n---------------------------\n";
		print " Produce cl_files.txt ... \n";
		print "---------------------------\n";
		$cmd = "cp -p /vob/lteenb/bld/pkg/lap_bundle.tgz /vob/lteenb/bld/pkg/lap_bundle2.tgz";
		execute($cmd);
		$cmd = "gunzip /vob/lteenb/bld/pkg/lap_bundle2.tgz";
		execute($cmd);
		$cmd = "perl /vob/lteenb/bld/wuce/bin/gen_cl_files.pl /vob/lteenb/bld/pkg/lap_bundle2.tar /vob/lteenb/bld/pkg";
		execute($cmd);
		$cmd = "rm /vob/lteenb/bld/pkg/lap_bundle2.tar";
		execute($cmd);

    }
} # end sub postBuild

## Define "preBuild" for any team-specific pre-build activities to be called
## by buildProcessor.pl.
## Notes: Will be called prior to any target processing.
##        This symbol must be added to the list of symbols to be exported.
sub preBuild {
	print "\n---------------------------\n";
	print " dts = ${dts}\n";
	print Dumper \$targets;
	print "---------------------------\n";

	## Config_spec
	print "\n---------------------------\n";
	print " Build config_spec is:\n";
	print "---------------------------\n";
	system ("$ct catcs | tee ${logsDir}/build.cs");
	print "\nConfig spec is saved in: ${logsDir}/build.cs\n";

	# Find checkedouts
	print "\n---------------------------\n";
	print " Find checked out files ...\n";
	print "---------------------------\n";
	print "VIEW: ldapmodem_${buildver}\n";
	print "$ct setview -exec \'$ct lsco -avo -cvi -s\' ldapmodem_${buildver}\n";
	system ("$ct setview -exec \'$ct lsco -avo -cvi -s\' ldapmodem_${buildver}");
	print "VIEW: lapsac_${buildver}\n";
	print "$ct setview -exec \'$ct lsco -avo -cvi -s\' lapsac_${buildver}\n";
	system ("$ct setview -exec \'$ct lsco -avo -cvi -s\' lapsac_${buildver}");

	# Remove private files
	print "\n---------------------------\n";
	print " Remove private files ... \n";
	print "---------------------------\n";
	print "VIEW: $common->{'LTE_BLD_VIEW'}\n";
	system("$ct setview -exec \'$SCM_BLDTOOLS/rm_all_private.pl -u\' $common->{'LTE_BLD_VIEW'} ");
#	print "VIEW: ldapmodem_${buildver}\n";
#	system("$ct setview -exec \'$SCM_BLDTOOLS/rm_all_private.pl -u\' ldapmodem_${buildver} ");
#	print "VIEW: lapsac_${buildver}\n";
#	system("$ct setview -exec \'$SCM_BLDTOOLS/rm_all_private.pl -u\' lapsac_${buildver} ");

	# Create pkg and lib directories for future copies
	print "\n---------------------------\n";
	print " Create pkg and lib directories ... \n";
	print "---------------------------\n";
	system("mkdir $delivView ") if (! -e "$delivView" );
	system("mkdir $delivView/../lib/ ") if (! -e "$delivView/../lib/" ) ;

	# Checking version number
	print "\n---------------------------\n";
	print " Checking version number ... \n";
	print "---------------------------\n";
	print "VIEW: ldapmodem_${buildver}\n";
	system("$SCM_BLDTOOLS/../update_version_number.pl -b ldapmodem_${buildVer} -vob ${vob} -check ");
	print "VIEW: lapsac_${buildver}\n";
	system("$SCM_BLDTOOLS/../update_version_number.pl -b lapsac_${buildVer} -vob ${vob} -check ");

} # end sub preBuild


sub execute () {
	my $cmd = shift @_;
    my $rc      = undef;     # Return code from executed command
    my $sTime   = time();    # Current time (seconds) for metrics purposes
    my $PH      = undef();   # Process Handle

	print "$cmd\n";
	open($PH, "|-", "$cmd") || do {
    printMetrics($COMPILE_METRICS_FH, $sTime, time()); # log the time
    process_error('mx', "Failed to open PH on " . __FILE__ .
              ' line ' . (__LINE__ - 3) . '!', $maillist, "$tool failure");
    };
    close($PH);

    # Capture the return status from the program and not the shell.
    # Exit value of the subprocess is in the high byte, $? >> 8.
    # The low byte says which signal the process died from, $?.
    $rc = ($? >> 8);
    ($rc > 0) && do {
          printMetrics($COMPILE_METRICS_FH, $sTime, time()); # log the time
          process_error("mx",
          "$cmd failed with a return code of $rc: $!\n", $maillist,
          "$tool failure");
    };

    undef($cmd);
    undef($rc);
    undef($PH);

    return $rc;
}


1;

# EOF
