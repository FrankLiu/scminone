#!/apps/public/perl_5.8.4/bin/perl
#############################################################################
#
#       Copyright (C) 2006-2010 MOTOROLA. All Rights Reserved.
#
#       The copyright notice above does not evidence any
#       actual or intended publication of such source code.
#       The code contains Motorola Confidential Restricted Information.
#
#############################################################################
#
#  FILE NAME:    lteenb_bp.pm
#
#  OWNER:        LTE SCM Team
#
#  DATE CREATED: 02/09/2010
#
#  SYNOPSIS:     None.
#
#  EXIT VALUE:   1; - Mandatory for module to load successfully
#
#  DESCRIPTION:  This Perl module contains common functions and variables
#                used for building lteenb_bp targets.
#
#############################################################################
#
#  MODIFICATION HISTORY:
#
# Ver    Date     Engineer     CR                     Change
# --- ---------- ---------- --------  ---------------------------------------
#
#############################################################################
#
#  FUNCTIONS:  (Alphabetical)
#
#	Local
#	-----
#	createView()		- Build Type-specific create view function
#	postBuild()		- Build Type-specific post build
#	postCompile()		- Build Type-specific post compilation
#	postInstrument()	- Build Type-specific post instrumentation
#	postLabel()		- Build Type-specific post labeling
#	postPackage()		- Build Type-specific post packaging
#	postSSM()		- Build Type-specific post SSM
#	preBuild()		- Build Type-specific pre build
#
#############################################################################

## DEVELOPMENT NOTES:
#  -----------------
# 1. Any variables global to this package must be declared within the 'our'
#    directive because of the 'strict' pragma.

## CHECKLIST WHEN UPDATING THIS MODULE:
#  -----------------------------------
# 1. Update @EXPORT if created a function or variable to be exported.
# 2. Update 'our' if added a global variable to this module or if a variable
#    needs to be exported.
# 3. Update the "FUNCTIONS" list in the prologue.
# 4. Update the "MODIFICATION HISTORY" in the prologue.
# 5. Turn Perl diagnostics (use diagnostics;) and strict (use strict;) off
#    before release.

# Using LTE COMMON libraries
BEGIN {
   if (defined($ENV{LTE_BLDTOOLS})){
	   unshift @INC, "$ENV{LTE_BLDTOOLS}/../lib", "$ENV{LTE_BLDTOOLS}", "$ENV{LTE_BLDTOOLS}/enodeb";
   } elsif (defined($ENV{SCM_BLDTOOLS})) {
	   unshift @INC, "$ENV{SCM_BLDTOOLS}", "$ENV{SCM_BLDTOOLS}/..", "$ENV{SCM_BLDTOOLS}/../../lib";
   } else {
	   unshift @INC,"/vob/ltescm/bin","/vob/ltescm/lib","/vob/ltescm/bin/enodeb";
   }
}

# Used as error checking mechanism: does not allow re-declaration of
# the same variable within the same scope.  For testing purposes only.
# Note: We do not check for strict references in order to access globals from
#       the calling package.
use strict qw(vars subs);
use diagnostics;

# Indicates that the entire library's symbol table or namespace is labeled
# as ngibsc.  The compiler will look for any undefined symbols, in the calling
# program, in this package.
package lteenb_r2_0_bp;

use 5.8.4;	# Use Perl 5.8.4 or higher (also for debugging purposes)
use Data::Dumper;

# Used to setup export methods into calling programs.  Allows the use of
# import(), @ISA, @EXPORT, etc., which allows for different ways of exporting
# symbols.
require Exporter;

# Standard global symbols
our (@ISA, @EXPORT);

# Search location for unresolved functions in the current package.
# The search is left to right.
# Exporter is included here because of the import() function.
@ISA = qw(Exporter);

# List of symbols to be exported by :DEFAULT.
# List functions first, then all other symbols.
@EXPORT	  =  qw(	postBuild
        		preBuild
			write_to_script
        		postCompile
        		postInstrument
                	postLabel
        	        postPackage
	                postSSM
        		execWMetrics
		@bTDirs
		$buildSteps
		$createView
		$defaultBuildVer
		$delivDir
		%labeling
		$logsDir
		$metricsDir
		%packaging
		$product
		$releaseDir
		%ssm
		%close_cqcm
		%valid_cqcm
		%project
		$system
		%targets
		$teamEmail
		$templateVersion
);

# Package global variables (some are imported from the calling namespace).
our    (
	@bTDirs,
	@buildSteps,
	$buildVer,
	$COMPILE_METRICS_FH,
	$cp,
	$createView,
	$ct,
	$defaultBuildVer,
	$delivDir,
	$instr,
	$INSTR_METRICS_FH,
	$kwBin,
	$kwHost,
	$kwPort,
	$kwStates,
	$lcProd,
	$kwRel,
	$LABEL_METRICS_FH,
	%labeling,
	$lcSysProd,
	$logsDir,
	$metricsDir,
	$objectsRef,
   $USE_BUILD_REQ,
	%packaging,
	$PKG_METRICS_FH,
	$plcode,
	$POSTBLD_METRICS_FH,
	$PREBLD_METRICS_FH,
	$product,
	%project,
	$release,
	$releaseDir,
	%ssm,
        $stepsToModules,
	%close_cqcm,
	%valid_cqcm,
	$SSM_METRICS_FH,
	$system,
	@targets,
	%targets,
	$templateVersion,
	$timeStamp,
	$tool,
	$USER,
	$buildver,
	$maillist,
);

# Mandatory symbols that must be defined in this package include:
#
# $createView		- This is the command to create a view.  The most
#               	  common option is provided (for SCH).
# $defaultBuildVer	- Defined even if it is an empty string.
# $delivDir		- Used for target build deliverable storage.
# $logsDir		- Used for target build logs storage.
# $metricsDir		- Used for target build SCM metrics storage.
# $product		- Product this build type belongs to.
# $releaseDir		- Used for target build scripts.
# $system		- System this build type belongs to.
# %targets		- At least one target must be defined.
# $templateVersion	- Version of product_template.pm we are using.
#

# Note that "Instrument" in %targets can be set to "{}" if there is no
# defined instrumentation for that particular target.

#============================================================================
#=====================  Exported Variable Initialization  ===================
#============================================================================
#
# Do not use the 'my' directive for those definitions we are using the 'our'
# directive for above.
#

# Version of product_template.pm populated for this build type
$templateVersion = 2.4;

# Insert your default version here.  Leave as '' if your team has no default
# value (note, build will halt if no default value and no version is provided
# on the command line).
$defaultBuildVer = '';

## Do not touch the following block of code ##
# This block sets the user and buildVer var for use within this module
my $pkg   = (caller)[0];		# Calling package name

# Import exported variables from calling tool
$pkg->import;

if (!defined($buildVer) or $buildVer =~ /^\s*$/) {
    $buildVer = $defaultBuildVer;
} # end if (!defined...
##   Do not touch the above block of code   ##

$buildVer =~ tr/a-z/A-Z/;
($buildver = $buildVer) =~ tr/A-Z/a-z/;

$USE_BUILD_REQ = 1; # flag, turn on INITAL object creation
eval {
          require "COMMON.pm";  # COMMON module
             COMMON->import;
}; # end eval

$USE_BUILD_REQ = 1; # flag, turn on INITAL object creation
my $common = new COMMON('LTE_LBL_NAME' => $buildVer, 'PRE_BUILD_MODE' => 0);
print Dumper $common;

$objectsRef->{'COMMON'} = $common;
if ($common->{'PRODUCT'} =~ /(.*)?-(.*)?/) {
	$system = $1;
	$product = $2;
	$release = $common->{'release'};
	$lcProd     = lc($product);
	$lcSysProd = lc($system . $product);         # Lowercase SystemProduct
	my $lcSys_Prod = lc("${system}_${product}"); # Lowercase System_Product
	$releaseDir = $common->{'LTE_BIN_ROOT'};
} else {
  process_error('x', 'Could not determine system, product and release from'
                    ." the passed version: $buildVer.");
} # end if ($buildVer...


print "SYSTEM: $system, PRODUCT: $product, RELEASE_DIR: $releaseDir \n";

# Release directory locations (standard locations provided) created by
# buildProcessor.pl
$delivDir   = "$releaseDir/deliverables";   # Deliverables
$logsDir    = "$releaseDir/logs";           # Log files
$metricsDir = "$releaseDir/metrics";        # Build metrics
my $vob 	= "/vob/lteenb";

my $SCM_BLDTOOLS = "/vob/ltescm/bin/enodeb";
$SCM_BLDTOOLS = $ENV{SCM_BLDTOOLS} if (defined($ENV{SCM_BLDTOOLS}));
my $MKEMS_script = $vob . "/bld/wuce/bin/mkems_enb_bld.ksh";
$MKEMS_script = "$ENV{MKEMS}" if ( defined( $ENV{MKEMS} ) );

# current view is used to copy binaries, making hap_lomp_pkg, cl_files and final lap_bundle
# $currView = `$ct pwv -s`;
# chomp($currView);
#$delivView = $currView.$vob."/bld/pkg/" if ($currView ne "");
my $delivView = "/view/".$common->{'LTE_BLD_VIEW'}.$vob."/bld/pkg/";

# SCH createView basic command
# NOTE We use the non-CQCM makeview here and so we must set a config spec.
#      We do not use the DEVINT/BLD view.
#$createView = "/apps/internal/bin/makeview -tag <view>";
#$createView = "/mot/proj/lte_scm/cmbp/lte_enb/cm-policy/bin/mkview -tag <view> -nobr";
$createView = "/mot/proj/lte_scm/cmbp/prod/cm-policy/bin/mkview -tag <view> -nobr";


# Default build automation steps to execute for this product.
# Note: preBuild, post<Step> and postBuild functions are automatically
# called if defined.
#@buildSteps = qw(compile label package instrument);
#@buildSteps = qw(instrument);
@buildSteps = qw(project);
#@buildSteps = qw(label compile package ssm instrument close_cqcm);

# For Klocwork SCH
$kwBin = '/apps/vendor/klocwork_8.1.2.10/bin';
$kwHost = 'isdserv0.comm.mot.com';
$kwPort = '1105';
$kwStates = 'new/fixed/existing/recurred';
($kwRel = $release) =~ s/\./_/;
$kwRel  = lc($kwRel);                       # Lowercase release used by KW

# Build type-specific definitions

# Build type-specific directories to be created by buildProcessor.pl.
# Add directories your builds need here.
@bTDirs = ("$logsDir/compile",
           "$logsDir/instrumentation",
           "$logsDir/build",
           "$logsDir/label",
           "$logsDir/packaging",
           "$logsDir/ssmt",
           "$logsDir/other",
          );



#============================================================================
#================================  CONFIG  ==================================
#============================================================================

%targets = (

    'ldapmodem' => {

        'build' => {
            'view'       => "ldapmodem_${buildver}",
            'configSpec' => "${logsDir}/build.cs",
            'startDir'   => "$vob",
            'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
				       		. ':/sbin:/usr/sbin:/usr/atria/bin:.'
				       		. ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
			     			'WUCE' => '/vob/wuce/wuce/bin/wuce',
			     			'WUCE_APP_CFG' => 'lte-ldapmodem-vx68_e500mc',
							'MAKEFLAGS' => '-N',
			    			},
            'logging'    => 1,
            'buildLog'   => "${logsDir}/build/ldapmodem-${buildVer}-build_log.${timeStamp}.wri",
            'buildCMDs'  =>
							[
							'MAKE_OPT=-k /vob/wuce/wuce/bin/wbld logmanager_gui',
							'wbld -V -v -C strip -C nodebug ldapmodem ldapmodem.pkg',
#							"/vob/wuce/wuce/bin/r2bsf1 -f ${logsDir}/build/ldapmodem-${buildVer}-build_log.${timeStamp}.wri -p aps",
		 					"echo $vob/bld/pkg/* ${delivView}",
							]
        },

        'instrument' => {
            'Klocwork' => {
                'view'       => "ldapmodem_${buildver}",
                'configSpec' => "${logsDir}/build.cs",
                'startDir'   => "${vob}/bld/wuce/bin",
                'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
    				       		. ':/sbin:/usr/sbin:/usr/atria/bin:.'
    				       		. ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
    			         		'WUCE' => '/vob/wuce/wuce/bin/wuce',
				     			'WUCE_APP_CFG' => 'lte-ldapmodem-vx68_e500mc',
#    			         		'KWPROJ' => 'ldapmodem',
    			         		'WUCE_KWPROJ_NAME' => "lte_enb_".$kwRel."_ldapmodem_full",
								'MAKEFLAGS' => '-N',
#WUCE_KW7_SCOPE=fexpo
    			        		},
                'logging'    => 1,
                'buildLog'   => "${vob}/ldapmodem-${buildVer}-kw_log.${timeStamp}.wri",
                'buildCMDs'  =>
		  						[
		  						'echo /vob/wuce/wuce/bin/wbld -C metric -V -v ldapmodem.kw8',
		  						'/vob/wuce/wuce/bin/wbld -C metric -V -v ldapmodem.kw8',
							    "/vob/wuce/wuce/bin/r2bsf1 -f ${vob}/ldapmodem-${buildVer}-kw_log.${timeStamp}.wri -p aps",
 							    'build_list=`kwadmin list-builds $WUCE_KWPROJ_NAME| /bin/sed -e \'s/No builds found.*\n//\'`',
		   					    'build=`echo $build_list | /bin/sed -e \'s/\(^\w*\)\s.*$/\1/\'`',
		   					    "/apps/vendor/klocwork_8.1.2.10/bin/kwinspectreport --project \$WUCE_KWPROJ_NAME --build \$build --host $kwHost --port $kwPort"
		   						. " --state $kwStates --text ${vob}/raw_ldapmodem_KW_inspect_report",
		  						]
            }
        }

    },

    'lapsac' => {

        'build' => {
            'view'       => "lapsac_${buildver}",
            'configSpec' => "${logsDir}/build.cs",
            'startDir'   => '/vob/lteenb-om/code/utx/palPCDClassNames',
            'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
				       		. ':/sbin:/usr/sbin:/usr/atria/bin:.'
				       		. ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
			     			'WUCE' => '/vob/wuce/wuce/bin/wuce',
			     			'WUCE_APP_CFG' => 'lte-lapsac-lompbcu3lx',
							'MAKEFLAGS' => '-N',
			    			},
            'logging'    => 1,
            'buildLog'   => "${logsDir}/build/lapsac-${buildVer}-build_log.${timeStamp}.wri",
            'buildCMDs'  =>
							[
							'wuce -V',
							 '/vob/wuce/wuce/bin/wbld lapsac_linux',
							 '/vob/wuce/wuce/bin/wbld -V -v lapsac lapsac.pkg',
#							 "/vob/wuce/wuce/bin/r2bsf1 -f ${logsDir}/build/lapsac-${buildVer}-build_log.${timeStamp}.wri -p aps",
							]
        },


        'instrument' => {
            'Klocwork' => {
                'view'       => "lapsac_${buildver}",
                'configSpec' => "$logsDir/build.cs",
                'startDir'   => "${vob}/bld/wuce/bin",
                'envVars'    => {'PATH' => '/apps/vendor/bin:/usr/bin:/bin:/etc'
    				       		. ':/sbin:/usr/sbin:/usr/atria/bin:.'
    				       		. ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
    			                 'WUCE' => '/vob/wuce/wuce/bin/wuce',
#    			         		'KWPROJ' => 'lapsac',
    			         		'WUCE_KWPROJ_NAME' => "lte_enb_".$kwRel."_lapsac_full",
								'MAKEFLAGS' => '-N',
#WUCE_KW7_SCOPE=fexpo
    			        		},
                'logging'    => 1,
                'buildLog'   => "${vob}/lapsac-${buildVer}-kw_log.${timeStamp}.wri",
                'buildCMDs'  =>
							  [
							  "echo /vob/wuce/wuce/bin/wbld -C metric -V -v lapsac.kw8",
							  "/vob/wuce/wuce/bin/wbld -C metric -V -v lapsac.kw8",
							  "/vob/wuce/wuce/bin/r2bsf1 -f ${vob}/lapsac-${buildVer}-kw_log.${timeStamp}.wri -p aps",
							  'build_list=`kwadmin list-builds $WUCE_KWPROJ_NAME| /bin/sed -e \'s/No builds found.*\n//\'`',
		   					  'build=`echo $build_list | /bin/sed -e \'s/\(^\w*\)\s.*$/\1/\'`',
		   					  "/apps/vendor/klocwork_8.1.2.10/bin/kwinspectreport --project \$WUCE_KWPROJ_NAME --build \$build --host $kwHost --port $kwPort"
		   					  . " --state $kwStates --text ${vob}/raw_lapsac_KW_inspect_report",
							  ]
            }
        }
    },

); # end of builds configuration


%packaging = (
    'view'       => "$common->{'LTE_BLD_VIEW'}",
    'configSpec' => "$logsDir/build.cs",
    'startDir'   => "$vob",
    'envVars'    => {},
    'logging'    => 1,
    'logFile'    => "${logsDir}/packaging/${lcProd}-${buildVer}-pkg"
                  . "_log_${timeStamp}.txt",
    'CMDs'       => [
    				'echo ------------------------------',
    				'echo  Making EMS bundle for TYPEA ... ',
    				'echo ------------------------------',
    				"BASEDIR=$common->{'LTE_BIN_ROOT'} ENB_LBL_NAME=$buildVer $MKEMS_script TYPEA",
#    				"$SCM_BLDTOOLS/../greperr.pl ${logsDir}/packaging/${lcProd}-${buildVer}-pkg"
#                   . "_log_${timeStamp}.txt",
    				"cp -rp /vob/omp4g_r2/eNodeB/software/lomp_factory.tgz $common->{'LTE_BIN_ROOT'}/TYPEA 2>&1 |tee $common->{'LTE_LOG_ROOT'}/packaging/build.$common->{'LTE_LBL_NAME'}.ems_bundle_typea.log",
				"gtar tzvf $common->{'LTE_BIN_ROOT'}/TYPEA/lapbcu3lx.tgz 2>&1 | tee $common->{'LTE_LOG_ROOT'}/build/build.$common->{'LTE_LBL_NAME'}.lapbcu3lx.pkg.contents",
				"gtar tzvf $common->{'LTE_BIN_ROOT'}/TYPEA/lapbcu3vx.tgz 2>&1 | tee $common->{'LTE_LOG_ROOT'}/build/build.$common->{'LTE_LBL_NAME'}.lapbcu3vx.pkg.contents",
				"gtar tzvf $common->{'LTE_BIN_ROOT'}/TYPEA/lap_bundle.tgz 2>&1 | tee $common->{'LTE_LOG_ROOT'}/build/build.$common->{'LTE_LBL_NAME'}.lap_bundle.pkg.contents",
				"md5sum $common->{'LTE_BIN_ROOT'}/TYPEA/*.tgz 2>&1 | tee $common->{'LTE_BIN_ROOT'}/TYPEA/MD5SUM",
				"md5sum $common->{'LTE_BIN_ROOT'}/TYPEA/ems/$common->{'LTE_LBL_NAME'}.tar 2>&1 | tee $common->{'LTE_BIN_ROOT'}/TYPEA/ems/$common->{'LTE_LBL_NAME'}.tar.md5sum.txt",
				"md5sum $common->{'LTE_BIN_ROOT'}/TYPEA/cl_files.txt 2>&1 | tee $common->{'LTE_BIN_ROOT'}/TYPEA/cl_files.md5sum.txt",
				"md5sum $common->{'LTE_BIN_ROOT'}/TYPEA/lomp_factory.tgz 2>&1 | tee $common->{'LTE_BIN_ROOT'}/TYPEA/lomp_factory.tgz.md5sum.txt",
				"md5sum $common->{'LTE_BIN_ROOT'}/TYPEA/lap_bundle.tgz 2>&1 | tee $common->{'LTE_BIN_ROOT'}/TYPEA/lap_bundle.tgz.md5sum.txt",
     				'echo ------------------------------',
    				'echo  Making EMS bundle for TYPEB ... ',
    				'echo ------------------------------',
    				"BASEDIR=$common->{'LTE_BIN_ROOT'} ENB_LBL_NAME=$buildVer $MKEMS_script TYPEB",
#    				"$SCM_BLDTOOLS/../greperr.pl ${logsDir}/packaging/${lcProd}-${buildVer}-pkg"
#                   . "_log_${timeStamp}.txt",
    				"cp -rp /vob/omp4g_r2/eNodeB/software/lomp_factory.tgz $common->{'LTE_BIN_ROOT'}/TYPEB 2>&1 |tee $common->{'LTE_LOG_ROOT'}/packaging/build.$common->{'LTE_LBL_NAME'}.ems_bundle_typeb.log",
				"md5sum $common->{'LTE_BIN_ROOT'}/TYPEB/*.tgz 2>&1 | tee $common->{'LTE_BIN_ROOT'}/TYPEB/MD5SUM",
				"md5sum $common->{'LTE_BIN_ROOT'}/TYPEB/ems/$common->{'LTE_LBL_NAME'}.tar 2>&1 | tee $common->{'LTE_BIN_ROOT'}/TYPEB/ems/$common->{'LTE_LBL_NAME'}.tar.md5sum.txt",
				"md5sum $common->{'LTE_BIN_ROOT'}/TYPEB/cl_files.txt 2>&1 | tee $common->{'LTE_BIN_ROOT'}/TYPEB/cl_files.md5sum.txt",
				"md5sum $common->{'LTE_BIN_ROOT'}/TYPEB/lomp_factory.tgz 2>&1 | tee $common->{'LTE_BIN_ROOT'}/TYPEB/lomp_factory.tgz.md5sum.txt",
				"md5sum $common->{'LTE_BIN_ROOT'}/TYPEB/lap_bundle.tgz 2>&1 | tee $common->{'LTE_BIN_ROOT'}/TYPEB/lap_bundle.tgz.md5sum.txt",
    				],
); # end of packaging configuration


%labeling = (
    'view'       => "$common->{'LTE_BLD_VIEW'}",
    'configSpec' => "$logsDir/build.cs",
    'startDir'   => "$vob",
    'envVars'    => {},
    'logging'    => 1,
    'logFile'    => "${logsDir}/label/${lcProd}-${buildVer}-label"
                  . "_log_${timeStamp}.txt",
    'CMDs'       => [
    				"$SCM_BLDTOOLS/../lte_label.pl -view $common->{'LTE_BLD_VIEW'} -parallel -replace -label $buildVer -log $common->{'LTE_LOG_ROOT'}",
    				"CLEARCASE_AVOBS=/vob/host_test $SCM_BLDTOOLS/../lte_label.pl -view $common->{'LTE_BLD_VIEW'} -parallel -replace -label $buildVer -log $common->{'LTE_LOG_ROOT'}",
    				],
); # end of labeling configuration

%ssm = (
    'view'       => "$common->{'LTE_BLD_VIEW'}",
    'configSpec' => "$logsDir/build.cs",
    'server'     => 'ltesol1',
    'startDir'   => "$vob",
    'logging'    => 1,
    'logFile'    => "${logsDir}/ssmt/${lcProd}-${buildVer}-ssm"
                  . "_log_${timeStamp}.txt",
    'CMDs'       => ["$SCM_BLDTOOLS/../ssmt.pl -prod $common->{'PRODUCT'} -b ${buildVer} -follow_bl ",
                    ],
); # end of labeling configuration

%project = (
    'projDir'    => "", #if not defined into LTE_BLD_CONF
    'in_vob'	 => 1,
    'newgrp'	 => "il02-ltescm",
    'server'	 => "ltelinux2",
    'logFile'    => "${logsDir}/other/${lcProd}-${buildVer}-project"
                  . "_log_${timeStamp}.txt",
    'exlcude_lines' => ["LTE-ENB_HOST-TEST_PREBLD",
    			"tmp-", 
 			],
); # end of labeling configuration

%close_cqcm = (
    'startDir'   => "$vob",
    'envVars'    => {},
    'logFile'    => "${logsDir}/other/${lcProd}-${buildVer}-close_cqcm"
                  . "_log_${timeStamp}.txt",
); # end of labeling configuration

%valid_cqcm = (
    'startDir'   => "$vob",
    'envVars'    => {},
    'logFile'    => "${logsDir}/other/${lcProd}-${buildVer}-valid_cqcm"
                  . "_log_${timeStamp}.txt",
); # end of labeling configuration


#============================================================================
#==============================  FUNCTIONS  =================================
#============================================================================

## Note(s):
##  If you want to capture SCM metrics for any step in the preBuild or
##  postBuild functions, you only need to capture the time just before you
##  you process the commands you want to execute:
##      my $sTime   = time();    # Current time (seconds) for metrics purposes
##  When you are finished processing the command(s) you want to time, call
##  logMetrics with either one of the already defined file handles
##  ($COMPILE_METRICS_FH or $INSTR_METRICS_FH), the start time and the
##  current time:
##      logMetrics($COMPILE_METRICS_FH, $sTime, time());
##  You may also define your own metrics file and pass that FH to
##  logMetrics instead (you must open it first).
##

## Define "createView" to override the default createView behavior
#sub createView {
#} # end sub createView

## Define "preBuild" for any team-specific pre-build activities to be called
## by buildProcessor.pl.
## Notes: Will be called prior to any target processing.
#sub preBuild {
#} # end sub preBuild
sub preBuild {

    my $cmd     = "";        # Command we plan to execute
    my $sTime   = time();    # Current time (seconds) for metrics purposes
    my $ViewExist;
    my $ldapmodem_ViewExist = 0;
    my $lapsac_ViewExist = 0;

    $ViewExist = `$ct lsview -s ldapmodem_${buildver}`;
	chomp($ViewExist);
    $ldapmodem_ViewExist = 1 if ($ViewExist eq "ldapmodem_${buildver}");

    $ViewExist = `$ct lsview -s lapsac_${buildver}`;
	chomp($ViewExist);
    $lapsac_ViewExist = 1 if ($ViewExist eq "lapsac_${buildver}");

	print "\n---------------------------\n";
	print " Time = ${timeStamp}\n";
#	print Dumper \@targets;
#	print Dumper \%targets;
	print "---------------------------\n";

	## Config_spec
	print "\n---------------------------\n";
	print " Build config_spec is:\n";
	print "---------------------------\n";
	system ("$ct catcs | tee ${logsDir}/build.cs");
	print "\nConfig spec is saved in: ${logsDir}/build.cs\n";

	# Find checkedouts
	print "\n---------------------------\n";
	print " Find checked out files ...\n";
	print "---------------------------\n";
	print "VIEW: $common->{'LTE_BLD_VIEW'}\n";
	$cmd = "$ct setview -exec \'$ct lsco -avo -cvi -s\' $common->{'LTE_BLD_VIEW'}";
	print "$cmd\n";
	system ($cmd);
	if ($ldapmodem_ViewExist) {
		print "VIEW: ldapmodem_${buildver}\n";
		$cmd = "$ct setview -exec \'$ct lsco -avo -cvi -s\' ldapmodem_${buildver}";
		print "$cmd\n";
		execWMetrics($cmd,$PREBLD_METRICS_FH,$sTime);
	}
	if ($lapsac_ViewExist){
		print "VIEW: lapsac_${buildver}\n";
		$cmd = "$ct setview -exec \'$ct lsco -avo -cvi -s\' lapsac_${buildver}";
		print "$cmd\n";
		execWMetrics($cmd,$PREBLD_METRICS_FH,$sTime);
	}

	# Remove private files
#	print "\n---------------------------\n";
#	print " Remove private files ... \n";
#	print "---------------------------\n";
#	print "VIEW: $common->{'LTE_BLD_VIEW'}\n";
#	$cmd = "$ct setview -exec \'$SCM_BLDTOOLS/rm_all_private.pl -u\' $common->{'LTE_BLD_VIEW'} ";
#	execWMetrics($cmd,$PREBLD_METRICS_FH,$sTime);

	# Create pkg and lib directories for future copies
	print "\n---------------------------\n";
	print " Create pkg and lib directories ... \n";
	print "---------------------------\n";
	execWMetrics("mkdir $delivView ",$PREBLD_METRICS_FH,$sTime) if (! -e "$delivView" );
	execWMetrics("mkdir $delivView/../lib/ ",$PREBLD_METRICS_FH,$sTime) if (! -e "$delivView/../lib/" );

	# Checking version number
	print "\n---------------------------\n";
	print " Checking version number ... \n";
	print "---------------------------\n";
	print "\nVIEW: ${buildver}\n";
	$cmd = "$SCM_BLDTOOLS/../update_version_number.pl -b ${buildVer} -vob ${vob} -check ";
	print "$cmd\n";
	execWMetrics($cmd,$PREBLD_METRICS_FH,$sTime);
	print "---------------------------\n";
	print "\n\n";

} # end sub preBuild

## Define "postBuild" for any team-specific post-build activities to be
## called by buildProcessor.pl.
## Notes: Will be called after all build processing is complete.
##        This symbol must be added to the list of symbols to be exported.
#sub postBuild {
#} # end sub postBuild
sub postCompile {
	# add Produce lap_bundle.tgz

    my $cmd     = "";        # Command we plan to execute
    my $sTime   = time();    # Current time (seconds) for metrics purposes
    my $pkgdir  = $delivView; # The package staging area

    print "This is postBuild function\n";
    # Allow the user to set the env var BP_SKIP_FINAL_PKG if they want to
    # skip packaging for this execution of buildProcessor.pl.
    unless ($ENV{'BP_SKIP_FINAL_PKG'}) {

        ## Copy pkg directories
#        $cmd = "cp /view/ldapmodem_${buildver}/$vob/bld/pkg/* $vob/bld/pkg/";
#        execute($cmd);
#        $cmd = "cp /view/lapsac_${buildver}/${vob}/bld/pkg/* ${pkgdir}";
#        execute($cmd);

  		print "\n---------------------------\n";
		print " Coping artifact to ${delivView} ... \n";
		print "---------------------------\n";
		print "$cp -rp /view/ldapmodem_${buildver}/$vob/bld/pkg/* ${delivView}\n";
		$cmd = "$cp -rp /view/ldapmodem_${buildver}/$vob/bld/pkg/* ${delivView}";
		execWMetrics($cmd,$COMPILE_METRICS_FH,$sTime);
		print "$cp -rp /view/lapsac_${buildver}/$vob/bld/pkg/* ${delivView}\n";
		$cmd = "$cp -rp /view/lapsac_${buildver}/${vob}/bld/pkg/* ${delivView}";
		execWMetrics($cmd,$COMPILE_METRICS_FH,$sTime);
		print "cp -rp /view/lapsac_${buildver}/${vob}/bld/lib/do.ppc_e500mc-glibc_std ${delivView}/../lib/\n";
		$cmd = "cp -rp /view/lapsac_${buildver}/${vob}/bld/lib/do.ppc_e500mc-glibc_std ${delivView}/../lib/";
		execWMetrics($cmd,$COMPILE_METRICS_FH,$sTime);
  		print "\n---------------------------\n";
		print " Produce lap_bundle.tgz ... \n";
		print "---------------------------\n";
		chdir ("$vob/bld/pkg");
		$cmd = "ln -s ldapmodem.tgz lapbcu3vx.tgz";
		execWMetrics($cmd,$COMPILE_METRICS_FH,$sTime);
		chdir ("$vob");
		$cmd = "$SCM_BLDTOOLS/call_and_log.pl -c \"$vob/bld/wuce/bin/hap_lomp_pkg lteenb /vob/lteenb/bld/wuce/bin /vob/lteenb-om/code/runtime_config\" -l $logsDir/build/build.${buildVer}.hap_lomp_pkg.${timeStamp}.log";
		execWMetrics($cmd,$COMPILE_METRICS_FH,$sTime);
		$cmd = "cp /vob/lteenb/bld/pkg/ldapmodem.tgz $vob/bld/pkg/HAPSTAGE/target/active/software/ENB_BCU3/";
		execWMetrics($cmd,$COMPILE_METRICS_FH,$sTime);
		chdir("$vob/bld/pkg/HAPSTAGE/target/active/software/ENB_BCU3/");
		$cmd = "ln -s ldapmodem.tgz lapbcu3vx.tgz";
		execWMetrics($cmd,$COMPILE_METRICS_FH,$sTime);
		$cmd = "$SCM_BLDTOOLS/call_and_log.pl -c \"/vob/omp4g_r2/eNodeB/bin/mm_lap_wrap $vob\" -l $logsDir/build/build.${buildVer}.mm_lap_wrap.${timeStamp}.log";
		execWMetrics($cmd,$COMPILE_METRICS_FH,$sTime);
		print "\n---------------------------\n";
		print " Produce cl_files.txt ... \n";
		print "---------------------------\n";
		$cmd = "cp -p $vob/bld/pkg/lap_bundle.tgz $vob/bld/pkg/lap_bundle2.tgz";
		execWMetrics($cmd,$COMPILE_METRICS_FH,$sTime);
		$cmd = "gunzip $vob/bld/pkg/lap_bundle2.tgz";
		execWMetrics($cmd,$COMPILE_METRICS_FH,$sTime);
		$cmd = "perl /vob/omp4g_r2/eNodeB/bin/gen_cl_files.pl $vob/bld/pkg/lap_bundle2.tar $vob/bld/pkg";
		execWMetrics($cmd,$COMPILE_METRICS_FH,$sTime);
		$cmd = "rm $vob/bld/pkg/lap_bundle2.tar";
		execWMetrics($cmd,$COMPILE_METRICS_FH,$sTime);
		print "---------------------------\n";
		$cmd = "/vob/wuce/wuce/bin/r2bsf1 -f ${logsDir}/build/lapsac-${buildVer}-build_log.${timeStamp}.wri -p aps";
		execWMetrics($cmd,$COMPILE_METRICS_FH,$sTime);
		$cmd = "/vob/wuce/wuce/bin/r2bsf1 -f ${logsDir}/build/ldapmodem-${buildVer}-build_log.${timeStamp}.wri -p aps";
		execWMetrics($cmd,$COMPILE_METRICS_FH,$sTime);
		my @compiling_status = `/vob/wuce/wuce/bin/r2bsf1 -f ${logsDir}/build/lapsac-${buildVer}-build_log.${timeStamp}.wri -p aps`;
		send_email_update("@compiling_status","Compiling status for LAPSAC ${buildVer}", $maillist);
		@compiling_status = `/vob/wuce/wuce/bin/r2bsf1 -f ${logsDir}/build/ldapmodem-${buildVer}-build_log.${timeStamp}.wri -p aps`;
		send_email_update("@compiling_status","Compiling status for LDAPMODEM ${buildVer}", $maillist);
    }
} # end sub postBuild

sub postLabel {
		print "---------------------------\n";
		print " Labeling summary ... \n";
		print "---------------------------\n";
		system("cat ${logsDir}/label/lte_label.${buildVer}.vob_host_test.summary.log");
		system("cat ${logsDir}/label/lte_label.${buildVer}.vob_lteenb.summary.log");
		my @labeling_status = `cat ${logsDir}/label/lte_label.${buildVer}.vob_lteenb.summary.log cat ${logsDir}/label/lte_label.${buildVer}.vob_host_test.summary.log`;
		send_email_update("@labeling_status","Labeling status for ${buildVer}", $maillist);

}

## Define "postInstrument" for any team-specific post-instrument activities to be
## called by buildProcessor.pl.
## Notes: Will be called after all target instrumentation is complete.
##        This symbol must be added to the list of symbols to be exported.
sub postInstrument {
    my $cmd     = '';        # Command we plan to execute
    my $sTime   = time();    # Current time (seconds) for metrics purposes

    # Call weave on nightlyKW to send out report
    # We apply the officialKW.sed script to nightlyKW to rip out the
    # section that executes the build since this now happens in bP.
    # For <TARGET> below, use any one valid "wbld" target (e.g. wbcssc,
    # ldapmodem, sdl ...).
    $cmd = "/vob/wuce/wuce/bin/weave -s -f /vob/ltescm/bin/sed/officialKW."
         . "sed /vob/ltescm/bin/nightlyKW -s lte -p $lcProd -l lapsac -m "
         . "$maillist -v $buildVer -r ${logsDir}/instrumentation >> "
         . "${logsDir}/instrumentation/${lcProd}-${buildVer}-kw_log_"
         . "${timeStamp}.txt 2>&1";

    execWMetrics($cmd, $INSTR_METRICS_FH, $sTime);

    # Now we upload the KW build data to the shared Oracle database
    # We do not want this done for nightly builds.  This is only for BLD's.
    $cmd = "/vob/ltescm/bin/4g_kwmetrics_upload.pl -prod $lcProd -v "
         . "$buildVer -path $releaseDir >> ${logsDir}/instrumentation/"
         . "${lcProd}-${buildVer}-kw_log_${timeStamp}.txt 2>&1";

    execWMetrics($cmd, $INSTR_METRICS_FH, $sTime);

} # end sub postInstr


1;

# EOF
