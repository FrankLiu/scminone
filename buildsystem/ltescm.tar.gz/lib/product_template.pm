#!/apps/public/perl_5.8.4/bin/perl
#############################################################################
#
#       Copyright (C) 2006-2010 MOTOROLA. All Rights Reserved.
#
#       The copyright notice above does not evidence any
#       actual or intended publication of such source code.
#       The code contains Motorola Confidential Restricted Information.
#
#############################################################################
#
#  FILE NAME:    <package>_bp.pm
#
#  OWNER:        LTE SCM Team
#
#  DATE CREATED: 07/07/2006
#
#  SYNOPSIS:     None.
#
#  EXIT VALUE:   1; - Mandatory for module to load successfully
#
#  DESCRIPTION:  This Perl module contains common functions and variables
#                used for building <package>_bp targets.
#
#############################################################################
#
#  MODIFICATION HISTORY:
#
# Ver    Date     Engineer     CR                     Change
# --- ---------- ---------- --------  ---------------------------------------
# 1.0 01/13/2009 skerr1     01120994  Created initial version based on iDEN
#				      SCM team's product_template.pm.
# 1.1 03/20/2009 skerr1     01167444  Changed releaseDir, system, and
#                                     product setup.
# 1.2 07/06/2009 skerr1     01206580  Added $plcode to global vars.
# 1.3 08/19/2009 skerr1     01217463  Added @targets to global vars.
# 1.4 10/05/2009 skerr1     01242038  Updated import to import all symbols
#                                     exported from calling namespace.
# 1.5 11/24/2009 skerr1     01145469  Updated for ltemgr enhancements.
# 2.0 01/26/2010 skerr1     01269590  Added support for new functionality
#                                     including labeling and packaging.
# 2.1 04/26/2010 skerr1     01310250  Fixed bug in mkattr.
# 2.2 04/07/2009 amn002     01269602  Post CQCM functionality added, closing
#                                     CRs, link baselines and close them
# 2.3 05/27/2010 skerr1     01313325  Added support for merge component.
#                amn002     01323888  Added support for valid_cqcm.
#		 skerr1     01318603  Fixed postInstrument function name.
# 2.4 06/30/2010 skerr1     01336346  valid_env component support added.
#                skerr1     01336346  close_build component support added.
#                ajm032     01337121  project component support added.
#                amn002     01351386  added new parameter "system" for COMMON .
#
#############################################################################
#
#  FUNCTIONS:  (Alphabetical)
#
#    Local
#    -----
#	createView()		- Build Type-specific create view function
#
#	Always Called if Defined
#	------------------------
#	preBuild()		- Build Type-specific pre build
#	postBuild()		- Build Type-specific post build
#
#       Local Step Functions
#	--------------------
#	postCloseBuild()	- Build Type-specific post close_build
#	postCloseCQCM()		- Build Type-specific post close_cqcm
#	postCompile()		- Build Type-specific post compilation
#	postInstrument()	- Build Type-specific post instrumentation
#	postLabel()		- Build Type-specific post labeling
#	postMerge()		- Build Type-specific post merge
#	postPackage()		- Build Type-specific post packaging
#	postValidCQCM()		- Build Type-specific post valid_cqcm
#	postValidEnv()		- Build Type-specific post valid_env
#	postSSM()		- Build Type-specific post SSM
#
#############################################################################

## DEVELOPMENT NOTES:
#  -----------------
# 1. Any variables global to this package must be declared within the 'our'
#    directive because of the 'strict' pragma.

## CHECKLIST WHEN UPDATING THIS MODULE:
#  -----------------------------------
# 1. Update @EXPORT if created a function or variable to be exported.
# 2. Update 'our' if added a global variable to this module or if a variable
#    needs to be exported. 
# 3. Update the "FUNCTIONS" list in the prologue.
# 4. Update the "MODIFICATION HISTORY" in the prologue.
# 5. Turn Perl diagnostics (use diagnostics;) and strict (use strict;) off
#    before release.

# Used as error checking mechanism: does not allow re-declaration of
# the same variable within the same scope.  For testing purposes only.
# Note: We do not check for strict references in order to access globals from
#       the calling package.
use strict qw(vars subs);
use diagnostics;

# Indicates that the entire library's symbol table or namespace is labeled
# as ngibsc.  The compiler will look for any undefined symbols, in the calling
# program, in this package.
package package_bp;

use 5.8.4;	  # Use Perl 5.8.4 or higher (also for debugging purposes)
use Data::Dumper; # Used for dumping data structures/debugging

# Used to setup export methods into calling programs.  Allows the use of
# import(), @ISA, @EXPORT, etc., which allows for different ways of exporting
# symbols.
require Exporter;

# Standard global symbols
our (@ISA, @EXPORT);

# Search location for unresolved functions in the current package.
# The search is left to right.
# Exporter is included here because of the import() function.
@ISA = qw(Exporter);

# List of symbols to be exported by :DEFAULT.
# List functions first, then all other symbols.
@EXPORT	  =  qw(postBuild
                postCloseCQCM
                postCompile
                postInstrument
                postLabel
                postMerge
                postPackage
                postSSM
                postValidCQCM
		preBuild
		write_to_script
                
		@bTDirs
		$buildSteps
		%close_build
		%close_cqcm
		$createView
		$defaultBuildVer
		$delivDir
		$httpReleaseLoc
		%labeling
		$logsDir
		%merge
		$metricsDir
		$objectsRef
		%packaging
		$product
		%project
		$release
		$releaseDir
		$results
		$scmEmail
		$SCM_ADMIN_VOB
		%ssm
		$system
		%targets
		$teamEmail
		$templateVersion
		$USE_BUILD_REQ
		%valid_cqcm
		%valid_env
               );

# Package global variables (some are imported from the calling namespace).
our    ($bld,
	@bTDirs,
	@buildSteps,
	$buildVer,
	$buildver,
	%close_build,
	%close_cqcm,
	$COMPILE_METRICS_FH,
	$cp,
	$createView,
	$ct,
	$defaultBuildVer,
	$delivDir,
	$httpReleaseLoc,
	$INSTR_METRICS_FH,
	$kwBin,
	$kwHost,
	$kwPort,
	$kwStates,
	$kwRel,
	%labeling,
	$lcProd,
	$lcSysProd,
	$logsDir,
	$maillist,
	%merge,
	$MERGE_METRICS_FH,
	$metricsDir,
	$objectsRef,
	%packaging,
	$PKG_METRICS_FH,
	$plcode,
	$POSTBLD_METRICS_FH,
	$PREBLD_METRICS_FH,
	$product,
	%project,
	$release,
	$releaseDir,
	$results,
	$scmEmail,
	$SCM_ADMIN_VOB,	
	%ssm,
	$SSM_METRICS_FH,
	$system,
	@targets,
	%targets,
	$teamEmail,
	$templateVersion,
	$timeStamp,
	$tool,
	$USER,
	$USE_BUILD_REQ,
	%valid_cqcm,
	%valid_env,
	$VIEWNAME,
       );

# Mandatory symbols that must be defined in this package include:
#
# $createView		- This is the command to create a view.  The most
#               	  common option is provided (for SCH).
# $defaultBuildVer	- Defined even if it is an empty string.
# $delivDir		- Used for target build deliverable storage.
# $logsDir		- Used for target build logs storage.
# $metricsDir		- Used for target build SCM metrics storage.
# $product		- Product this build type belongs to.
# $releaseDir		- Used for target build scripts.
# $system		- System this build type belongs to.
# $templateVersion	- Version of product_template.pm we are using.
#

# Note that "Instrument" in %targets can be set to "{}" if there is no
# defined instrumentation for that particular target.

#============================================================================
#=====================  Exported Variable Initialization  ===================
#============================================================================
#
# Do not use the 'my' directive for those definitions we are using the 'our'
# directive for above.
#

# Version of product_template.pm populated for this build type
$templateVersion = 2.4;

# Insert your default version here.  Leave as '' if your team has no default
# value (note, build will halt if no default value and no version is provided
# on the command line).
$defaultBuildVer = '';

## Do not touch the following block of code ##
# Sets the name of the calling package (tool)
my $pkg   = (caller)[0];		# Calling package name

# Import exported variables from calling package (tool)
$pkg->import;

# Set the default build version (baseline) if not set already.
if (!defined($buildVer) or $buildVer =~ /^\s*$/) {
    $buildVer = $defaultBuildVer;
} # end if (!defined...
##   Do not touch the above block of code   ##

# Ensure case is correct and set the lc version
$buildVer =~ tr/a-z/A-Z/;
($buildver = $buildVer) =~ tr/A-Z/a-z/;

# Set the system, product and releaseDir if the Version is correctly
# formatted.
# when label does not start with system name $system should be hardcoded 
# e.g. $system = LTE"
if ($buildVer =~ m/^([^-]+)-([^_]+)_(R\d+\.\d+)_(BLD|DEVINT|INT|REL)-.*/) {
  $system = $1;
  $product = $2;
  $release = $3; # Root directory for the release content
  $bld = $4;
  
  $lcProd     = lc($product);
  $lcSysProd = lc($system . $product);          # lowercase SystemProduct
} else {
  process_error('x', 'Could not determine system, product and release from'
                    ." the passed version: $buildVer.");
} # end if ($buildVer...

# For LTE create new object to access common build information
eval {
  require "COMMON.pm";  # COMMON module
  COMMON->import;
}; # end eval...

# For LTE process any failure to use COMMON.pm
($@) and process_error('x', "Could not load COMMON.pm.  There is probably a"
    . " syntax error in this file: $@");

# For LTE create new object to access common LTE build information
# SYSTEM parameter is not obligatory when all labels for given product
# start with system name for example LTE-ENB_R1.0_BLD-1.01.02 (system eq 'LTE')

my $common = new COMMON('LTE_LBL_NAME' => $buildVer, 'PRE_BUILD_MODE' => 0,
   'LTE_BLD_VIEW'   => $VIEWNAME, 'SYSTEM' => $system);
$objectsRef->{'COMMON'} = $common;

$releaseDir = $common->{'LTE_BIN_ROOT'};	# release directory location
$httpReleaseLoc = $common->{'LTE_HTTP_ROOT'}; # http release link

# Release directory locations (standard locations provided) created by
# buildProcessor.pl
$delivDir   = "$releaseDir/deliverables";   # Deliverables
$logsDir    = "$releaseDir/logs";           # Log files
$metricsDir = "$releaseDir/metrics";        # Build metrics

# SCH createView basic command
# NOTE We use the non-CQCM makeview here and so we must set a config spec.
#      We do not use the DEVINT/BLD view.
$createView = "/apps/internal/bin/makeview -tag <view>";

# Default build automation steps to execute for this product.
# Note: preBuild, post<Step> and postBuild functions are automatically
# called if defined and the corresponding step was successfully executed.
@buildSteps = qw(valid_env valid_cqcm metrics compile label package
                 close_cqcm close_build ssm instrument);

# For Klocwork SCH
$kwBin = '/apps/vendor/klocwork_8.1.2.10/bin';
$kwHost = 'isdserv0.comm.mot.com';
$kwPort = '1105';
$kwStates = 'new/fixed/existing/recurred';
($kwRel = $release) =~ s/\./_/;
$kwRel  = lc($kwRel);                       # Lowercase release used by KW

# Set to true if your team uses the build request tool or undef if you don't.
$USE_BUILD_REQ = 1;

# Initialize MAKEFLAGS to save us from a concatenation error with strict.
if (not defined $ENV{'MAKEFLAGS'}) { $ENV{'MAKEFLAGS'}=""; }

## Build type-specific definitions

# Set the admin VOB location (env var SCM_ADMIN_VOB overrides the default)
$SCM_ADMIN_VOB = $ENV{'SCM_ADMIN_VOB'} || '<your default>';

# Team email list (use \ before @ symbols), comma delimited
$teamEmail = "";

# SCM email list
$scmEmail = ""; 

# Build type-specific directories to be created by buildProcessor.pl.
# Add directories your builds need here.
@bTDirs = ("$logsDir/compile",
           "$logsDir/instrumentation",
           "$logsDir/label",
           "$logsDir/merge",
           "$logsDir/packaging",
           "$logsDir/post_build",
           "$logsDir/pre_build",
           "$logsDir/ssmt",
           "$logsDir/other",
          );

#============================================================================
#================================  CONFIG  ==================================
#============================================================================


# Setup for Environment validation
#  Checks for 'buildSize' FA space
#  Checks for 2 X 'buildSize' View space
%valid_env = (
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {},
    'logging'    => 1,
    'logFile'    => "${logsDir}/pre_build/${lcProd}-${buildVer}-valid_env"
                  . "_log_${timeStamp}.txt",
    # Size of the average build in MB.  Used to check for sufficient space.
    'buildSize'  => 3000,
); # end of valid_env configuration


# Setup for CQCM validation
%valid_cqcm = (
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {},
    'logFile'    => "${logsDir}/other/${lcProd}-${buildVer}-valid_cqcm"
                  . "_log_${timeStamp}.txt",
); # end of valid_cqcm configuration


# Setup for merging
# Support merge and tracemerge functions, plus custom functions.
# merge: Merges necessary branches based on build request or predefined list.
#   For REL builds, checks REL and BLD content is identical
# tracemerge: Executes tracemerge/cmbp_report checks
%merge = (
    'view'       => '',
    'configSpec' => '',
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {'PATH' => "/vob/ltescm/bin:$ENV{'PATH'}"},
    'logging'    => 1,
    'logFile'    => "${logsDir}/merge/${lcProd}-${buildVer}-merge"
                  . "_log_${timeStamp}.txt",
    'functions'  => ['merge', 'tracemerge',],
); # end of merge configuration


# Define the build targets
#  Each target is comprised of user defined build commands
#  Each target can have multiple defined instrumentation types
%targets = (

    '' => {

        'build' => {
            'view'       => "${lcProd}_${buildVer}",
            'configSpec' => "${logsDir}/${buildVer}_cs.wri",
            'startDir'   => "$SCM_ADMIN_VOB",
            'envVars'    => {'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",},
            'logging'    => '',
            'buildLog'   => "${logsDir}/compile/${lcProd}-${buildVer}-build"
                          . "_log_${timeStamp}.txt",
            'buildCMDs'  => [''],
        },


        'instrument' => {
            'klocwork' => {
                'view'       => '',
                'configSpec' => '',
                'startDir'   => "$SCM_ADMIN_VOB",
                'envVars'    => {'PATH' => "$kwBin:/apps/vendor/bin:/usr/bin:/bin:"
    				         . '/etc:/sbin:/usr/sbin:/usr/atria/bin:.'
    				         . ":/vob/wuce/wuce/bin:$ENV{'PATH'}",
    			         'KWPROJ' => '',
    			         'WUCE_KWPROJ_NAME' => "",
 			         'MAKEFLAGS' => "\"$ENV{'MAKEFLAGS'} -N\"",
    			        },
                'logging'    => '',
                'buildLog'   => "${logsDir}/instrument/${lcProd}-${buildVer}"
                              . "-kw_log_${timeStamp}.txt",
                'buildCMDs'  =>
		  ['<KW wbld command>',
		   'build_list=`kwadmin list-builds $WUCE_KWPROJ_NAME| /bin/sed -e \'s/No builds found.*\n//\'`',
		   'build=`echo $build_list | /bin/sed -e \'s/\(^\w*\)\s.*$/\1/\'`',
		   "kwinspectreport --project \$WUCE_KWPROJ_NAME --build \$build --host $kwHost --port $kwPort"
		   . " --state $kwStates --text ${logsDir}/instrumentation/raw_\${KWPROJ}_KW_inspect_report",
		  ],
            },
        },
    },
); # end of build targets configuration


# Setup for creating the final package
#  User defined packaging commands
%packaging = (
    'view'       => "${lcProd}_${buildVer}",
    'configSpec' => "${logsDir}/${buildVer}_cs.wri",
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {},
    'logging'    => '',
    'logFile'    => "${logsDir}/packaging/${lcProd}-${buildVer}-pkg"
                  . "_log_${timeStamp}.txt",
    'CMDs'       => [''],
); # end of packaging configuration


# Setup for applying the ClearCase label
#  Default is lte_label.pl tool which labels CLEARCASE_AVOBS in
#    parallel
#  User may define any labeling commands/tools they wish
%labeling = (
    'view'       => "${lcProd}_${buildVer}",
    'configSpec' => "${logsDir}/${buildVer}_cs.wri",
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {'PATH' => "/vob/ltescm/bin:$ENV{'PATH'}"},
    'logging'    => '',
    'logFile'    => "${logsDir}/label/${lcProd}-${buildVer}-label"
                  . "_log_${timeStamp}.txt",
    'CMDs'       => ["lte_label.pl -viewname ${lcProd}_${buildVer} -labelname"
                   . " ${buildVer} -logroot ${logsDir}/label -parallel -replace",
                     "$ct lock -replace -nuser $USER lbtype:$buildVer",
                     "$ct mkattr -nc DevProject \\\"${buildVer}.prj\\\" "
                   . "lbtype:${buildVer}\@$SCM_ADMIN_VOB",
                     "$ct lock -replace lbtype:$buildVer",
             	    ],
); # end of labeling configuration


# Setup for post CQCM checks and closure
%close_cqcm = (
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {},
    'logFile'    => "${logsDir}/other/${lcProd}-${buildVer}-close_cqcm"
                  . "_log_${timeStamp}.txt",
); # end of close_cqcm configuration


# Setup for prj file creation
# You can specify your own project directory, exclude lines from the current
# view's configuration of specification, set the group your prj file should
# be created with and identify whether or not your prj file should be created
# as a VOB element.
%project = (
    'projDir'    => "",             # if not defined in LTE_BLD_CONF.pm
    'in_vob'	 => 0,              # 0 in on UXIX path, 1 if in vob
    'newgrp'	 => "il02-ltescm",  # the group for gewgrp, if necessary
    'server'     => "ltelinux2",    # the server to execute the generated script
    'logFile'    => "${logsDir}/other/${lcProd}-${buildVer}-project"
                  . "_log_${timeStamp}.txt",
    'exlcude_lines' => [],          # table of patterns to exclude from config_spec
); # end of project configuration


# Setup for closing the build
#  Execute the lte_bld_report.pl
#  Sends release email
%close_build = (
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {},
    'logging'    => 1,
    'logFile'    => "${logsDir}/post_build/${lcProd}-${buildVer}-close_build"
                  . "_log_${timeStamp}.txt",
); # end of close_build configuration


# Setup for source size metrics calcuation and upload
#  Default is to run ssmt.pl
#  User may define any SSM commands/tools they wish
%ssm = (
    'view'       => "${lcProd}_${buildVer}",
    'configSpec' => "${logsDir}/${buildVer}_cs.wri",
    'server'     => 'ltesol1',
    'startDir'   => "$SCM_ADMIN_VOB",
    'envVars'    => {'PATH' => "/vob/ltescm/bin:$ENV{'PATH'}"},
    'logging'    => '',
    'logFile'    => "${logsDir}/ssmt/${lcProd}-${buildVer}-ssm"
                  . "_log_${timeStamp}.txt",
    'CMDs'       => ["ssmt.pl -prod ${system}-${product} -b ${buildVer}",
                    ],
); # end of ssm configuration


#============================================================================
#==============================  FUNCTIONS  =================================
#============================================================================

## Note(s):
## Besides the functions shown below, we have the following post<Step>
## functions availble: postValidEnv, postValidCQCM, postMerge, postCompile,
## postPackage, postLabel, postCloseCQCM, postCloseBuild, postInstrument, and
## postSSM.  Also, please note:
##      o Each function must be added to the list of symbols to be exported.
##      o Each defined function is automatically called after the
##        corresponding step (e.g. postCompile after compile, postSSM after
##        ssm etc).
##
## To execute a system command, please use execWMetrics so SCM metrics will
## be written for any failure.  For more info on this function, see
## buildProcessor.pl.
##
## If you are not using execWMetrics to run system commands or if you have
## your own private error handling block for Perl failures, please add the
## following line to that error handler to the final status report from bP
## will reflect your module failure:
##	$results .= "<subroutine> FAILED to complete successfully!\n";

## Available functions provided by buildProcessor.pl:
##	<Name>		- <Where defined>
##	execWMetrics	- buildProcessor.pl
##      logMetrics	- buildProcessor.pl
##	print_and_log	- SCM_common.pm
##	process_error	- SCM_common.pm
##	time		- POSIX
##	write_to_script	- SCM_common.pm
##
## The SCM_common.pm API is here:
## http://compass.mot.com/go/lte_scm_common_api.doc


## Define "createView" to override the default createView behavior
#sub createView {
#} # end sub createView


## Define "preBuild" for any team-specific pre-build activities to be called
## by buildProcessor.pl.
## Notes: Will be called prior to any target processing.
##        This symbol must be added to the list of symbols to be exported.
sub preBuild {
    my $cmd     = '';        # Command we plan to execute
    my $sTime   = time();    # Current time (seconds) for metrics purposes
    
    ## Save the config spec and set the wuce version if set into a view
    #  Note: this is not perfect because if you did an "scstart" you are
    #  actually set into a view if you had not been before.  Our build
    #  process has us set into the official view before we get to this
    #  point anyway, so this is just an extra check.
    if (defined $ENV{'CLEARCASE_ROOT'}) {
    
      ## Unless merge is a step, update the WUCE build version
      unless (grep(/merge/, @buildSteps)) {
        # Update the build version
        $cmd = "/vob/ltescm/bin/update_version_number.pl -b $buildVer -vob "
             . $SCM_ADMIN_VOB;
        print_and_log($plcode, "Executing: $cmd\n\n");
        
        execWMetrics($cmd, $PREBLD_METRICS_FH, $sTime);
      } # end unless (grep...
      
      ## Save the config spec
      $cmd = "$ct catcs > ${logsDir}/${buildVer}_cs.wri";
      print_and_log($plcode, "Executing: $cmd\n\n");

      execWMetrics($cmd, $PREBLD_METRICS_FH, $sTime);

    } else { # Not set into a view
      process_error('mx',
         "You are not set into a view, so ${tool} cannot update the WUCE "
       . "version.\n", $maillist, "$tool failure (PID $$)");         
    } # end if (defined $ENV...
    
} # end sub preBuild


## Define "postInstrument" for any team-specific post-instrument activities
## to be called by buildProcessor.pl.
## Notes: Will be called after all target instrumentation is complete.
##        This symbol must be added to the list of symbols to be exported.
sub postInstrument {
    my $cmd     = '';        # Command we plan to execute
    my $sTime   = time();    # Current time (seconds) for metrics purposes

    # Call weave on nightlyKW to send out report
    # We apply the officialKW.sed script to nightlyKW to rip out the
    # section that executes the build since this now happens in bP.
    # For <TARGET> below, use any one valid "wbld" target (e.g. wbcssc,
    # ldapmodem, sdl ...).
    $cmd = "/vob/wuce/wuce/bin/weave -s -f /vob/ltescm/bin/sed/officialKW."
         . "sed /vob/ltescm/bin/nightlyKW -s lte -p $lcProd -l <TARGET> -m "
         . "$teamEmail -v $buildVer -r ${logsDir}/instrumentation >> "
         . "${logsDir}/instrumentation/${lcProd}-${buildVer}-kw_log_"
         . "${timeStamp}.txt 2>&1";
    print_and_log($plcode, "Executing: $cmd\n\n");

    execWMetrics($cmd, $INSTR_METRICS_FH, $sTime);
    
    # Now we upload the KW build data to the shared Oracle database
    # We do not want this done for nightly builds.  This is only for BLD's.
    $cmd = "/vob/ltescm/bin/4g_kwmetrics_upload.pl -prod $lcProd -v "
         . "$buildVer -path $releaseDir >> ${logsDir}/instrumentation/"
         . "${lcProd}-${buildVer}-kw_log_${timeStamp}.txt 2>&1";
    print_and_log($plcode, "Executing: $cmd\n\n");
    
    execWMetrics($cmd, $INSTR_METRICS_FH, $sTime);
    
} # end sub postInstrument


## Define "postMerge" for any team-specific post-merge activities to be
## called by buildProcessor.pl.
## Notes: Will be called after all build processing is complete.
##        This symbol must be added to the list of symbols to be exported.
sub postMerge {
    my $cmd     = '';        # Command we plan to execute
    my $sTime   = time();    # Current time (seconds) for metrics purposes
    
    ## Save the config spec and set the wuce version if set into a view
    #  Note: this is not perfect because if you did an "scstart" you are
    #  actually set into a view if you had not been before.  Our build
    #  process has us set into the official view before we get to this
    #  point anyway, so this is just an extra check.
    if (defined $ENV{'CLEARCASE_ROOT'}) {
      ## Update the build version
      $cmd = "/vob/ltescm/bin/update_version_number.pl -b $buildVer -vob "
           . $SCM_ADMIN_VOB;
      print_and_log($plcode, "Executing: $cmd\n\n");

      execWMetrics($cmd, $MERGE_METRICS_FH, $sTime);
    } # end if (defined...
 
} # end sub postMerge


## Define "postBuild" for any team-specific post-build activities to be
## called by buildProcessor.pl.
## Notes: Will be called after all build processing is complete.
##        This symbol must be added to the list of symbols to be exported.
#sub postBuild {
#} # end sub postBuild


1;

# EOF
