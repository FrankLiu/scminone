eval "exec $SSMT_PERL -I$SSMT_PERL5LIB $0 $@"
        if 0;

# this is the default AP script provided by SSMT team 
# for ORIG, OWNER, PURPOSE and ALANG

BEGIN {
    unshift(@INC,qq($ENV{SSMT_HOME}/src/lib));
}

use AP;

sub compFAsplit {

    #must be \ escape for : if not seperated    
	#if a:b:c a:b will be component and c will be fa
    if ( $_[0] =~ m#^\s*(.+)(?<!\\):\s*(.+)\s*$# ) {
        $ret = qq($1:~:$2); 
    } else {
        $ret = $_[0];
		$ret =~ s#:\s*$##; # no FA, but : remains
    }
    $ret =~ s#\\:#:#g;
    $ret =~ s#\s*:~:\s*#:~:#g;
    return $ret;

}

if ( $#ARGV >= 0 ) { #file list from the array
    &callAP({inArray => \@ARGV},\&compFAsplit);
} else {             #file list from stdin
    &callAP({},\&compFAsplit);
}
