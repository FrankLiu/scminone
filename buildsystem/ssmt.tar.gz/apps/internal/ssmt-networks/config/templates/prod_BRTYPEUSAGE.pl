eval "exec $SSMT_PERL -I$SSMT_PERL5LIB $0 $@"
        if 0;

# this is the default AP script provided by SSMT team 
# for BRTYPEUSAGE, it can be used for CMBP/CCM with
# attribute file ${SSMT_PROD}.BRTYPEUSAGE under attribhome directory

BEGIN {
    unshift(@INC,qq($ENV{SSMT_HOME}/src/lib));
}

use AP;

if ( $#ARGV >= 0 ) { #file list from the array
    &callAP({inArray=>\@ARGV},\&brtypeUsage);
} else {             #file list from stdin
    &callAP({},\&brtypeUsage);
}
