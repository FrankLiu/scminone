eval "exec $SSMT_PERL -I$SSMT_PERL5LIB -S $0 $*" 
	if 0;

########################################################
# This script is AP program for SSMT related to brtype 
# item in the project configuration file.
# it is used to return the brtype(s) associated with
# a CR/DR (could be CCM, CMBP or DDTS), 
#
# NOTE: 
#	* Return the original CR format for matching purposes.
#	  This implies that if a CR has no value, the CR will
#	  still be returned to SSMT core.
#	* This AP is applicable to any CQ/DDTS and CC integration
#	* This AP will ignore/exclude brtype that are obsolete
#	  in CC
#	* For -C cmd, this script is called only once by feeding
#	  list of crs from stdin
#
########################################################

BEGIN {
    unshift(@INC,qq($ENV{SSMT_HOME}/src/lib));
}

use strict;
use Config::Constant;
use Logging;
use CQ::ClearQuest;
use CC::ClearCase;
use AP;
use Util;

select(STDIN);
$|=1;
select(STDOUT);
$|=1;
select(STDERR);
$|=1;

my $retFlag = $SCRIPT_TRUE;

#
# crs = (
#   cr1 => {
#       bt1 => 1,
#       bt2 => 1,
#       ..
#   },
#   cr2 => {
#       bt3 => 1,
#       bt4 => 1,
#   },
#   ..
# );

my(%feedCRs) = ();
my($cr,%allbtypes,@bt)=();

$Logging::debugLevel = $ENV{SSMT_DEBUG} if ( $ENV{SSMT_DEBUG} );
my(%incrs,%outcrs) = ();

if ( $#ARGV >= 0 ) {

    map { $incrs{$_} = 1 } @ARGV;
    map { $outcrs{$_} = {} } keys %incrs;

} else {

    my @incrs=<STDIN>;
    foreach (@incrs) {
        chomp;
        next if ( /^\s*$/ || /^\s*#/ );
		s/$//;		#NT people
        $incrs{$_}=$_;
        $outcrs{$_}={};
	}
}

$retFlag = &findBRInfoWithAttrFile(\%outcrs,\%incrs);
foreach (keys %incrs) { print STDOUT join(${AP_PROG_SEP},($_,keys %{$outcrs{$_}})),"\n"}

exit($retFlag);

#
# get the valid brtype for CR
# Note that obsoleted branch type in CC will be ignored.  Refer to each function 
# within findBRInfoWithAttrFile() for more details.
#
sub findBRInfoWithAttrFile {

    my($retRef,$crRef) = @_;
    
    my($prefix,$number,$cr,$origCR)=();

	# since this script could be used for any VCT value
	# we should not validate too much about the format
	# unless we know it is against certain change management system
    for $origCR (keys %{$crRef}) {
		
        ($prefix,$number,$cr) = CRParse($origCR);

		# we assume all CM chg-mngt-ids are in format of prefix+digits
		if ( ! $cr ) {
			print STDERR "$0: ($origCR) is not a valid CR number!\n";
			$retFlag = $SCRIPT_WARNING;
			next;
		} 

		$feedCRs{$cr} = $origCR;

	}

	return($retFlag) if ( int(keys %feedCRs) < 1 );

	# call the attribute processing
	#
	my %crMatchLines=();
	my(%apParam) = (
		inArray 	=> [keys %feedCRs],
		noStdOut	=> $TRUE,
		retRef		=> \%crMatchLines,
	);

	my ($apRetFlag);	
	if ( ($apRetFlag = &callAP(\%apParam,\&crBranchAttrFile)) == $SCRIPT_FALSE ) {
		#error out if there is error in attr file
		return($SCRIPT_FALSE);
	} else {
		$retFlag = $apRetFlag if ( $retFlag == $SCRIPT_TRUE);
	}

	&Logging::ssmtDebug(10,"prod_BRTYPE.pl crMatchLines",\%crMatchLines);

	#don't process the returned default value __UNDEF__
	foreach (keys %crMatchLines) {
		if ( $crMatchLines{$_} eq $UNDEFINED ) {
			delete($crMatchLines{$_});
		}
	}

	return($retFlag) if ( int(keys %crMatchLines) < 1 );

	## Note: brtype that are deleted or obsoleted will be ignored
	## unless the lstype flag '-obsolete' is used.  Currently, this is
	## consistent with the standard of ignoring such brtype.
	my($v,$abt)=();
	if ( int(keys %allbtypes) <= 0 ) { ##get all types
		##get all brtype in all vobs (one cmd or multiple cmd?)
		for $v (split(/:/,$ENV{CLEARCASE_AVOBS})) {
			@bt = qx{$ENV{SSMT_CTCMD} lstype -short -kind brtype -invob $v};
			@bt = map { s/\s+.*$//;$_ } @bt;
			chomp(@bt);
			map { $allbtypes{$_} = 1 } @bt; 
		}
	}

	&Logging::ssmtDebug(10,"prod_BRTYPE.pl allbtypes",\%allbtypes);

	# call AP again to do the match on the returned brtype regexp
	# keep the fileAttr from the attribute file
	# allow a single brtype to be assigned to multiple CRs
	# the generated attr file has no duplicated lines due to the hash
	$apParam{inArray} 		= [keys %allbtypes];
	$apParam{inAttrArray} 	= [map { qq($crMatchLines{$_}:$_)  } keys %crMatchLines];
	$apParam{retRef} 		= \%outcrs;
	$apParam{allowMultRules}= $TRUE;


    if ( ($apRetFlag = &callAP(\%apParam,\&crBranches)) == $SCRIPT_FALSE ) {
		$retFlag = $SCRIPT_FALSE;	
	} else {
		($retFlag = $apRetFlag)  if ( $retFlag == $SCRIPT_TRUE );
	}

	return $retFlag;
}

#################################################
# PURPOSE:
#   do the post processing when a cr matched a rule in attr file
#
# INPUT:
#	my($retPattern,$feed,$feedPattern,$dAPref) = @_;
#   retPattern: the regex for the brtype of a cr
#   feed:		cr itself
#   feedPattern:the first field of inputfile or inAttrArray
#   dAPref:		reference to the defaultAP
#
# OUTPUT:
#	store data in $defaultAP{retRef}   
#  
# BEHAVIOR:
# 	do the actual backreference substitution or perl variable substitution
#
# ON ERROR:
#   print to STDERR
#
# NOTE:
#  no fields can contain < or >, they were used to do the start/end chars
#  refer to comments on 'callAP' routine regarding to prod.BRTYPE
#
#  this is used in config/templates/prod_BRTYPE.pl only
# 
#################################################

sub crBranchAttrFile {

	my($retPattern,$feed,$feedPattern,$dAPref) = @_;

	$retPattern =~ s/\\/\\\\/g;

	# if $ follows with non-digit or non-character, escape it
	# for the end pattern as in ^(.*)-dev_$1$
	# or for or pattern as in .*-dev-$1$|.*-INDEV$1
	$retPattern =~ s/\$(?!(\d|\w))/\\\$/g;

	my $ret;
	my $eStr = qq{\$feed =~ m<$feedPattern>;\$ret = qq<$retPattern>;};

	&Logging::ssmtDebug(10,"crBranchAttrFile feed($feed) feedPattern($feedPattern) retPattern($retPattern) eStr($eStr)");

	eval $eStr;

	if ($@) {
		my $inR = $dAPref->{fileAttr}->{$feedPattern};
		print STDERR qq{Eval eStr($eStr) error: $@with input feed($feed) feedPattern($feedPattern) and retPattern($retPattern) that traces back to line $inR->[1] {$inR->[2]} in file ($dAPref->{inputfile})!\n};
		return;
	}

	#two levels of original source, trace back to the original line for later use
	$dAPref->{fileAttr}->{qq($ret:$feed)} = $dAPref->{fileAttr}->{$feedPattern};

	$dAPref->{retRef}->{$feed} = $ret;

}

#################################################
# PURPOSE:
#   do the post processing when brtype matched a rule in inAttrArray
#
# INPUT:
#	my($cr,$brtype,$brtypePattern,$dAPref) = @_;	 (#current routine)
#	my($retPattern,$feed,$feedPattern,$dAPref) = @_; (#from above routine)
#   cr: 		the second field of dummy attr file from %crMatchLines
#   brtype:		matched brtype fed from inArray
#   brtypePattern:the first field of inputfile or inAttrArray
#   dAPref:		reference to the defaultAP
#
# OUTPUT:
#	store data in $defaultAP{retRef}   
#  
# BEHAVIOR:
# 	store data in the passed-in reference
#
# ON ERROR:
#
# NOTE:
#  no fields can contain < or >, they were used to do the start/end chars
#  refer to comments on 'callAP' routine regarding to prod.BRTYPE
#
#  this is used in config/templates/prod_BRTYPE.pl only
# 
#################################################

sub crBranches {

	my($cr,$brtype,$brtypePattern,$dAPref) = @_;

	&Logging::ssmtDebug(10,"crBranches brtypePattern($brtypePattern) cr($cr) brtype($brtype)");

	# put back the escaped \: 
	# trim the leading and ending spaces, but not in-between spaces
	$brtype =~ s/\\:/:/g;
	$brtype =~ s/^\s*//; $brtype =~ s/\s*$//;

	$dAPref->{retRef}->{$feedCRs{$cr}}->{$brtype} = 1;	
	return;

}

