eval "exec $SSMT_PERL -I$SSMT_PERL5LIB $0 $@"
        if 0;
 
# this is the default AP script provided by SSMT team 
# for AUTO

BEGIN {
    unshift(@INC,qq($ENV{SSMT_HOME}/src/lib));
}

use AP;

if ( $#ARGV >= 0 ) { #file list from the array
    &callAP({inArray => \@ARGV, defaultAttr => 'N' });
} else {             #file list from stdin
    &callAP({ defaultAttr => 'N' } );
}

