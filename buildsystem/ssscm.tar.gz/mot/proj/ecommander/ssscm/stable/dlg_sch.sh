#!/bin/bash -E
## .SH dlg_sch.sh
## .SS Author
## hqjr73@motorola.com on 05 March 2010

BN=`basename $0`
#DN=`dirname $0`

trap ssv_trap_err ERR

TMP_SCH=`${SSV_TMPFN} ${BN} sch`
TMP_SCRIPT=`${SSV_TMPFN} ${BN} spt`

dlg_ret=${DLG_CANCEL}
dlg_res=0
dlg_exit=0
sch=""  # !!!
proc_clean=0
proc_force=0
disabled=1
start_time_h=0
start_time_m=0
sch_proc=${AP_PROC_RUN_BUILD}
bld_type=${BLD_TYPE_AP} # !!! need to check if not specified

while getopts s:t: opt; do
  case ${opt} in
    s) sch="${OPTARG}" ;;
    t) bld_type="${OPTARG}" ;;
    *)
      echo "___assert"; # !!!
      ;;
  esac
done

# !!! check parameters
#if [[ "${sch}" = "" ]]; then
#  echo "__usage__2"
#  exit 1 # !!!
#fi

# !!!
#if [[ "${view}" = "" ]]; then
#  echo "__usage__3"
#  exit 1 # !!!
#fi

dlg_sch_dispatch()
{
  case ${dlg_ret} in
    ${DLG_ESC} | ${DLG_CANCEL}) ssv_quit; return $? ;;
    ${DLG_HELP}) ssv_help ${SSV_DIR}/doc/README_sch; return $? ;;
    ${DLG_OK})
      for item in ${dlg_res}; do
        case ${item} in
          ${ID_DLG_SCH_PROC_CLEAN}) proc_clean=1 ;;
          ${ID_DLG_SCH_PROC_FORCE}) proc_force=1 ;;
          *) p_err ${LINENO} ;; # !!!
        esac
      done

      if [[ "${proc_clean}" = "1" ]]; then
        if [[ "${proc_force}" = "1" ]]; then
          sch_proc="${AP_PROC_RUN_BUILD_CLEAN_FORCE}"
        else
          sch_proc="${AP_PROC_RUN_BUILD_CLEAN}"
        fi
      else
        if [[ "${proc_force}" = "1" ]]; then
          sch_proc="${AP_PROC_RUN_BUILD_FORCE}"
        else
          sch_proc="${AP_PROC_RUN_BUILD}"
        fi
      fi

      ${DLG_SCH_TIME} -s "${sch}" -f "${sch_proc}" -o "${start_time_h}" \
                      -m "${start_time_m}" -d "${disabled}"
      ret=$?
      [[ "${ret}" = "${SSV_CANCEL}" ]] && return ${SSV_OK}
      [[ "${ret}" = "${SSV_OK}" ]] && dlg_exit=${SSV_TRUE} # !!!!!!!!!!!!!!!!!
      return ${ret}
      ;;

    ${DLG_EXIT}) dlg_exit=${SSV_TRUE}; return ${SSV_OK} ;;
    *) p_err ${LINENO}; return ${SSV_EXIT} ;;
  esac
  return ${SSV_OK}
}

dlg_sch_show()
{
  cat > ${TMP_SCRIPT} <<EOF
${DIALOG} \
  --backtitle "Self Serve SCM > Builds > ${sch} > Schedule > Procedure" \
  --title " Procedure " \
  --help-button \
  --extra-button \
  --ok-label "Next" \
  --extra-label "Back" \
  --cancel-label "Exit" \
  --single-quoted \
  --checklist "Setup schedule procedure.\nTo select procedure option, use arrow keys to move to it and press [SPACE]. To de-select it, press [SPACE] again." \
    11 ${DLG_COMMON_WIDTH} 2 \\
EOF

  echo -n "\"${ID_DLG_SCH_PROC_CLEAN}\" \"Clean Build View\" " >> ${TMP_SCRIPT}
  if [[ "${sch_proc}" = "${AP_PROC_RUN_BUILD_CLEAN}" ||
        "${sch_proc}" = "${AP_PROC_RUN_BUILD_CLEAN_FORCE}" ]]; then
    echo -n "\"on\" " >> ${TMP_SCRIPT}
  else
    echo -n "\"off\" " >> ${TMP_SCRIPT}
  fi
  echo -n "\"${ID_DLG_SCH_PROC_FORCE}\" " >> ${TMP_SCRIPT}
  echo -n "\"Build even if config spec was not changed\" " >> ${TMP_SCRIPT}
  if [[ "${sch_proc}" = "${AP_PROC_RUN_BUILD_FORCE}" ||
        "${sch_proc}" = "${AP_PROC_RUN_BUILD_CLEAN_FORCE}" ]]; then
    echo -n "\"on\" 2>${TMP_RES}" >> ${TMP_SCRIPT}
  else
    echo -n "\"off\" 2>${TMP_RES}" >> ${TMP_SCRIPT}
  fi

  chmod 755 ${TMP_SCRIPT}
  ${TMP_SCRIPT}
  dlg_ret=$?
  [[ "${dlg_ret}" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  dlg_res=`cat ${TMP_RES}`
  return ${SSV_OK}
}

dlg_sch_run()
{
  ${SSV_DISP} --proc="getsch" --sch="$sch" > ${TMP_SCH}
  [[ "$?" != "${SSV_OK}" ]] && { p_err ${LINENO} "`cat ${TMP_SCHS}`"; return ${SSV_EXIT}; }

  disabled=`cat ${TMP_SCH} | cut -d '|' -f 1`
  start_time_h=`cat ${TMP_SCH} | cut -d '|' -f 2 | cut -d ':' -f 1`
  start_time_m=`cat ${TMP_SCH} | cut -d '|' -f 2 | cut -d ':' -f 2`
  sch_proc=`cat ${TMP_SCH} | cut -d '|' -f 3`

  [[ "${disabled}" = "" ]] && disabled=1
  [[ "${start_time_h}" = "" ]] && start_time_h=0
  [[ "${start_time_m}" = "" ]] && start_time_m=0

  case ${bld_type} in
    ${BLD_TYPE_AP})
      while [[ "${dlg_exit}" = "${SSV_FALSE}" ]]; do
        dlg_sch_show
        ret=$?
        [[ "${ret}" != "${SSV_OK}" ]] && break

        dlg_sch_dispatch
        ret=$?
        [[ "${ret}" != "${SSV_OK}" ]] && break
      done
      ;;

    ${BLD_TYPE_CAPC})
      ${DLG_SCH_TIME} -s "${sch}" -f "${sch_proc}" -o "${start_time_h}" \
                      -m "${start_time_m}" -d "${disabled}"
      ret=$?
      [[ "${ret}" = "${SSV_CANCEL}" ]] && ret=${SSV_OK}
      ;;

    *) p_err ${LINENO}; ret=${SSV_EXIT} ;;
  esac

  rm -f ${TMP_SCRIPT}
  rm -f ${TMP_SCH}
  return ${ret}
}

dlg_sch_run
