#!/usr/bin/perl -w

use Getopt::Long;
use File::Path;
use ElectricCommander;

#use Data::Dumper; # !!!
#print Data::Dumper->Dump(\@arr);
package ssv_util;

use strict;
use warnings;

use constant EC_OLD_CS_PROPS_NUM => 20; # !!!

use constant ERR_OK    => 0;
use constant ERR_FAIL  => 3;
use constant ERR_TRUE  => 1; # !!!
use constant ERR_FALSE => 0; # !!!
#use constant ERR_APP  => 2;
#use constant ERR_SYS  => 3;
#use constant ERR_INT  => 4;

my $TMPFILE;

sub new
{
  my ($class, $ec_server, $prj_utils, $prj, $proot) = @_;

  my $self = {
          _EC_SERVER => $ec_server,
          _PRJ_UTILS => $prj_utils,
          _PRJ => $prj,
          _PROOT => $proot,
        };

#    Getopt::Long::GetOptions(
#        'title'                  => \$self->{'_title'},
#        'js'                     => \$self->{'_js'},
#        'check-id=n'             => \$self->{'_check_id'},
#        'status-log1|st1=s'      => \$self->{'_ST1'},
#        );

#  $self->{'_DIR'} = "/home/hqjr73/work/scm/ec/ssv_v03";
  $self->{'_EC'} = new ElectricCommander->new($self->{'_EC_SERVER'}) ||
    die "Unable to create ElectricCommander"; # !!!
  $self->{'_EC'}->abortOnError(0); # !!!

  bless $self, $class;
  return $self;
}

sub p_err
{
  my ($self, $func, $line, $str) = @_;
  print STDERR __FILE__ . ":" . $line . ":" . $func . ":" . $str;
  return ERR_OK;
}

sub get_proc_names
{
  my ($self, $prj_type, $def_prj, $def_run_build, $def_run_build_force,
      $def_run_build_clean, $def_run_build_clean_force, $def_clean_view,
      $def_run_build_step, $def_clean_view_step, $def_set_cs,
      $def_set_cs_step, $def_tool_path) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code, $ret);
  my ($prj, $run_build, $run_build_force, $run_build_clean,
      $run_build_clean_force, $clean_view, $run_build_step,
      $clean_view_step, $set_cs, $set_cs_step, $tool_path);

  $ret = $self->get_prop_def(
    $self->{'_PROOT'} . "/projects/" . $prj_type . "/name", $def_prj, \$prj);
  if ($ret != ERR_OK) {
    $self->p_err("get_proc_names", __LINE__,
      $self->{'_PROOT'} . "/projects/" . $prj_type . "/name/" . $def_prj);
    return $ret;
  }

  $ret = $self->get_prop_def(
    $self->{'_PROOT'} . "/projects/" . $prj_type . "/run_build",
    $def_run_build, \$run_build);
  if ($ret != ERR_OK) {
    $self->p_err("get_proc_names", __LINE__,
      $self->{'_PROOT'} . "/projects/" . $prj_type . "/run_build/" . $def_run_build);
    return $ret;
  }

  $ret = $self->get_prop_def(
    $self->{'_PROOT'} . "/projects/" . $prj_type . "/run_build_force",
    $def_run_build_force, \$run_build_force);
  if ($ret != ERR_OK) {
    $self->p_err("get_proc_names", __LINE__,
      $self->{'_PROOT'} . "/projects/" . $prj_type .
      "/run_build_force/" . $def_run_build_force);
    return $ret;
  }

  $ret = $self->get_prop_def(
    $self->{'_PROOT'} . "/projects/" . $prj_type . "/run_build_clean",
    $def_run_build_clean, \$run_build_clean);
  if ($ret != ERR_OK) {
    $self->p_err("get_proc_names", __LINE__,
      $self->{'_PROOT'} . "/projects/" . $prj_type .
      "/run_build_clean/" . $def_run_build_clean);
    return $ret;
  }

  $ret = $self->get_prop_def(
    $self->{'_PROOT'} . "/projects/" . $prj_type . "/run_build_clean_force",
    $def_run_build_clean_force, \$run_build_clean_force);
  if ($ret != ERR_OK) {
    $self->p_err("get_proc_names", __LINE__,
      $self->{'_PROOT'} . "/projects/" . $prj_type . "/run_build_clean_force/" .
      $def_run_build_clean_force);
    return $ret;
  }

  $ret = $self->get_prop_def(
    $self->{'_PROOT'} . "/projects/" . $prj_type . "/clean_view",
    $def_clean_view, \$clean_view);
  if ($ret != ERR_OK) {
    $self->p_err("get_proc_names", __LINE__,
      $self->{'_PROOT'} . "/projects/" . $prj_type . "/clean_view/" . $def_clean_view);
    return $ret;
  }

  $ret = $self->get_prop_def(
    $self->{'_PROOT'} . "/projects/" . $prj_type . "/run_build_step",
    $def_run_build_step, \$run_build_step);
  if ($ret != ERR_OK) {
    $self->p_err("get_proc_names", __LINE__,
      $self->{'_PROOT'} . "/projects/" . $prj_type .
      "/run_build_step/" . $def_run_build_step);
    return $ret;
  }

  $ret = $self->get_prop_def(
    $self->{'_PROOT'} . "/projects/" . $prj_type . "/clean_view_step",
    $def_clean_view_step, \$clean_view_step);
  if ($ret != ERR_OK) {
    $self->p_err("get_proc_names", __LINE__,
      $self->{'_PROOT'} . "/projects/" . $prj_type .
      "/clean_view_step/" . $def_clean_view_step);
    return $ret;
  }

  $ret = $self->get_prop_def(
    $self->{'_PROOT'} . "/projects/" . $prj_type . "/set_cs", $def_set_cs, \$set_cs);
  if ($ret != ERR_OK) {
    $self->p_err("get_proc_names", __LINE__,
      $self->{'_PROOT'} . "/projects/" . $prj_type . "/set_cs/" . $def_set_cs);
    return $ret;
  }

  $ret = $self->get_prop_def(
    $self->{'_PROOT'} . "/projects/" . $prj_type . "/set_cs_step",
    $def_set_cs_step, \$set_cs_step);
  if ($ret != ERR_OK) {
    $self->p_err("get_proc_names",__LINE__,
      $self->{'_PROOT'} . "/projects/" . $prj_type .
      "/set_cs_step/" . $def_set_cs_step);
    return $ret;
  }

  $ret = $self->get_prop_def($self->{'_PROOT'} . "/path", $def_tool_path, \$tool_path);
  if ($ret != ERR_OK) {
    $self->p_err("get_proc_names", __LINE__,
      $self->{'_PROOT'} . "/path/". $def_tool_path);
    return $ret;
  }

  print $prj . '|' . $run_build . '|' . $run_build_force .
        '|' . $run_build_clean . '|' . $run_build_clean_force .
        '|' . $run_build_step . '|' . $clean_view . '|' . $clean_view_step .
        '|' . $set_cs . '|' . $set_cs_step;
  return ERR_OK;
}

sub get_build_type
{
  my ($self, $sch, $do_print) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code, $bld_proc, $proc_prop, $proc);
  my @ap_procs  = (
    $self->{'_PROOT'} . "/projects/AP/run_build",
    $self->{'_PROOT'} . "/projects/AP/run_build_force",
    $self->{'_PROOT'} . "/projects/AP/run_build_clean",
    $self->{'_PROOT'} . "/projects/AP/run_build_clean_force",
    $self->{'_PROOT'} . "/projects/AP/clean_view");
  my @capc_procs  = (
    $self->{'_PROOT'} . "/projects/CAPC/run_build");

  $xpath = $ec->getSchedule($self->{'_PRJ'}, $sch);
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("get_build_type", __LINE__, $code);
    return ERR_FAIL;
  }

  $bld_proc = $xpath->findvalue("//procedureName");
  foreach $proc_prop (@ap_procs) {
    $xpath = $ec->getProperty($proc_prop, { projectName => $self->{'_PRJ'} });
    $code = $xpath->findvalue("//code");
    if ($code ne "") {
      $self->p_err("get_prop", __LINE__, $code);
      return ERR_FAIL;
    }

    $proc = $xpath->findvalue("//value");
    if ($bld_proc eq $proc) {
      print "ap" if ($do_print == 1); # !!! need to use constant
      return ERR_OK;
    }
  }

  foreach $proc_prop (@capc_procs) {
    $xpath = $ec->getProperty($proc_prop, { projectName => $self->{'_PRJ'} });
    $code = $xpath->findvalue("//code");
    if ($code ne "") {
      $self->p_err("get_prop", __LINE__, $code);
      return ERR_FAIL;
    }

    $proc = $xpath->findvalue("//value");
    if ($bld_proc eq $proc) {
      print "capc" if ($do_print == 1); # !!! need to use constant
      return ERR_OK;
    }
  }
  return ERR_FAIL;
}

sub stop_build
{
  my ($self, $sch) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code, $job_id);
  my $job_complete = ERR_FALSE;
  my $wait_n = 0;

  $xpath = $ec->getProperty($self->{'_PROOT'} . "/schedules/" . $sch . "/job_id",
                            { projectName => $self->{'_PRJ'} });
  $code = $xpath->findvalue("//code");
  if ($code eq "") {
    $job_id = $xpath->findvalue("//value");
    $job_complete = $self->is_job_complete($job_id);
    return ERR_FAIL if ($job_complete == ERR_TRUE);
  }

  $xpath = $ec->abortJob($job_id);
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("stop_build", __LINE__, $code);
    return ERR_FAIL;
  }

  while ($job_complete != ERR_TRUE) {
    $job_complete = $self->is_job_complete($job_id);
    if ($job_complete == ERR_FALSE) {
      $wait_n++;
      return ERR_FAIL if ($wait_n >= 20); # !!!
      sleep(1);
    }
  }
  return ERR_OK;
}

sub call_ec_proc
{
  my ($self, $func, $wait, $cmd) = @_;
  my @arr;
  my ($code, $xpath, $job_id);
  my $ec = $self->{'_EC'};

  if ($cmd) {
    my @params = split(',', $cmd);
    foreach my $param (@params) {
      my @vals = split(':', $param);
      push(@arr, {'actualParameterName', $vals[0], 'value',  $vals[1]});
    }
  }

  if ($wait) {
    $xpath = $ec->runProcedure($self->{'_PRJ'},
                               { procedureName => $func,
                                 pollInterval => 2, # !!!
                                 timeout => 20, # !!!
                                 actualParameter => \@arr } ); # !!!
  } else {
    $xpath = $ec->runProcedure($self->{'_PRJ'},
                               { procedureName => $func,
                                 actualParameter => \@arr } );
  }
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("call_ec_proc", __LINE__, $code);
    return ERR_FAIL;
  }

  $code = $xpath->findvalue("//outcome");
  if ($code ne "success") {
    $self->p_err("call_ec_proc", __LINE__, $code);
    return ERR_FAIL;
  }

  $job_id = $xpath->findvalue("//jobId");
  if ($job_id eq "") {
    $self->p_err("call_ec_proc", __LINE__, $job_id);
    return ERR_FAIL;
  }
  print $job_id;
  return ERR_OK;
}

sub change_cs
{
  my ($self, $view, $cs) = @_;
  my $cmd = "cleartool setview -exec 'cleartool setcs " . $cs . "' " . $view;

  if (system($cmd)) {
    $self->p_err("change_cs", __LINE__, "");
    return ERR_FAIL;
  }
  return ERR_OK;
}

sub set_cs_prop
{
  my ($self, $view, $user, $cs) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code);
  my $cs_value = '';

  my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time);
  my $timestamp = sprintf("%4d-%02d-%02d_%02d:%02d:%02d", # !!!
                          $year+1900, $mon+1, $mday, $hour, $min, $sec);

  $xpath = $ec->setProperty(
    $self->{'_PROOT'} . "/views/" . $view . "/$timestamp/user", $user, # !!!
    { projectName => $self->{'_PRJ'} });
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("set_cs_prop", __LINE__, $code); # !!!!!!!
    return ERR_FAIL;
  }

  open(TMPFILE, $cs);
  while (<TMPFILE>) {
    $cs_value .= $_;
  }
  close(TMPFILE);

  $xpath = $ec->setProperty(
    $self->{'_PROOT'} . "/views/" . $view . "/$timestamp/cs", $cs_value,
    { projectName => $self->{'_PRJ'} });
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("set_cs_prop", __LINE__, $code);
    return ERR_FAIL;
  }
  return ERR_OK;
}

sub get_view_cs_list
{
  my ($self, $view) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code, $nodeset, $node);

  $xpath = $ec->getProperties({ projectName => $self->{'_PRJ'},
                                path => $self->{'_PROOT'} . "/views/" . $view });
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
#    $self->p_err("get_view_cs_list", __LINE__, $code);
    print $code;
    return ERR_FAIL;
  }

  $nodeset = $xpath->find("//propertyName");
  foreach $node ($nodeset->get_nodelist) {
    print $node->string_value() . "\n";
  }
  return ERR_OK;
}

sub remove_view_old_cs_prop
{
  my ($self, $view) = @_;
  my $ec = $self->{'_EC'};

  my $xpath = $ec->getProperties({ projectName => $self->{'_PRJ'},
                                   path => $self->{'_PROOT'} . "/views/" . $view });
  my $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("remove_view_old_cs_prop", __LINE__, $code);
    return ERR_FAIL;
  }

  my $nodeset = $xpath->find("//property");
  if ($nodeset->size() > EC_OLD_CS_PROPS_NUM) {
    my $value = $xpath->findvalue("//property[position()=1]/propertyName");
    if ($value ne "") {
      my $ret = $self->remove_prop(
        $self->{'_PROOT'} . "/views/" . $view . "/" . $value);
      return $ret;
    }
  }
  return ERR_OK;
}

sub get_step_log
{
  my ($self, $job_id, $step) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code, $dir, $log);

  $xpath = $ec->getJobDetails($job_id);
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("get_step_log", __LINE__, $code);
    return ERR_FAIL;
  }

  $dir = $xpath->findvalue("//workspace/unix");
  $log = $xpath->findvalue("(//jobStep[stepName = \"$step\"])[last()]/logFileName");
  print $dir . "/" . $log;
  return ERR_OK;
}

sub get_prop
{
  my ($self, $prop) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code);

  $xpath = $ec->getProperty($prop, { projectName => $self->{'_PRJ'} });
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("get_prop", __LINE__, $code);
    return ERR_FAIL;
  }

  $code = $xpath->findvalue("//value");
  print $code . "\n";
  return ERR_OK;
}

sub get_prop_def
{
  my ($self, $prop, $def_value, $rvalue) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code);

  $xpath = $ec->getProperty($prop, { projectName => $self->{'_PRJ'} });
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $xpath = $ec->setProperty($prop, $def_value, { projectName => $self->{'_PRJ'} });
    $code = $xpath->findvalue("//code");
    if ($code ne "") {
      $self->p_err("get_prop_def", __LINE__, $code . ";" . $prop . ";" . $def_value);
      return ERR_FAIL;
    }
    $$rvalue = $def_value;
  } else {
    $$rvalue = $xpath->findvalue("//value");
  }
  return ERR_OK;
}

sub remove_prop
{
  my ($self, $prop) = @_;
  my $ec = $self->{'_EC'};
  my $xpath;
  my $code;

  $xpath = $ec->deleteProperty($prop, { projectName => $self->{'_PRJ'} });
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("remove_prop", __LINE__, $code);
    return ERR_FAIL;
  }
  return ERR_OK;
}

sub set_term
{
  my ($self, $user, $value) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code);

  $xpath = $ec->setProperty(
    $self->{'_PROOT'} . "/users/" . $user . "/term", $value,
    { projectName => $self->{'_PRJ'} });
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("set_term", __LINE__, $code);
    return ERR_FAIL;
  }
  return ERR_OK;
}

sub get_term
{
  my ($self, $user) = @_;
  return $self->get_prop($self->{'_PROOT'} . "/users/" . $user . "/term");
}

sub set_color
{
  my ($self, $user, $value) = @_;
  my $ec = $self->{'_EC'};
  my $xpath;
  my $code;

  $xpath = $ec->setProperty(
    $self->{'_PROOT'} . "/users/" . $user . "/color", $value,
    { projectName => $self->{'_PRJ'} });
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("set_color", __LINE__, $code);
    return ERR_FAIL;
  }
  return ERR_OK;
}

sub get_color
{
  my ($self, $user) = @_;
  return $self->get_prop($self->{'_PROOT'} . "/users/" . $user . "/color");
}

sub set_log
{
  my ($self, $user, $value) = @_;
  my $ec = $self->{'_EC'};
  my $xpath;
  my $code;

  $xpath = $ec->setProperty(
    $self->{'_PROOT'} . "/users/" . $user . "/log", $value,
    { projectName => $self->{'_PRJ'} });
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("set_log", __LINE__, $code);
    return ERR_FAIL;
  }
  return ERR_OK;
}

sub get_log
{
  my ($self, $user) = @_;
  return $self->get_prop($self->{'_PROOT'} . "/users/" . $user . "/log");
}

sub get_sch
{
  my ($self, $sch) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code, $disabled, $start_time, $proc);

  $xpath = $ec->getSchedule($self->{'_PRJ'}, $sch);
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("get_sch", __LINE__, $code);
    return ERR_FAIL;
  }

  $disabled = $xpath->findvalue("//scheduleDisabled");
  $start_time = $xpath->findvalue("//startTime");
  $proc = $xpath->findvalue("//procedureName");

  print $disabled . "|" . $start_time . "|" . $proc;
  return ERR_OK;
}

sub get_sch_list
{
  my ($self) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code, $schset, $schn, $descr, $sch, $proc, $step, $view);

  $xpath = $ec->getSchedules($self->{'_PRJ'});
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("get_sch_list", __LINE__, $code);
    return ERR_FAIL;
  }

  $schset = $xpath->find('//response/schedule');
  foreach $schn ($schset->get_nodelist) {
    $descr = $schn->findvalue('description');
    $sch = $schn->findvalue('scheduleName');
    $proc = $schn->findvalue('procedureName');

    $xpath = $ec->getSteps($self->{'_PRJ'}, $proc);
    $code = $xpath->findvalue("//code");
    if ($code ne "") {
      $self->p_err("get_sch_list", __LINE__, $code);
      return ERR_FAIL;
    }

    $step = $xpath->findvalue('//response/step/stepName');
    $xpath = $ec->getActualParameter( { projectName => $self->{'_PRJ'},
                                        scheduleName => $sch,
                                        procedureName => $ENV{'AP_PROC_RUN_BUILD'}, # !!!
                                        stepName => $ENV{'AP_PROC_RUN_BUILD_STEP'} }); # !!!
    $code = $xpath->findvalue("//code");
    if ($code ne "") {
      $self->p_err("get_sch_list", __LINE__, $code);
      return ERR_FAIL;
    }

    $view = $xpath->findvalue(
      "//actualParameter[actualParameterName = \"view_name\"]/value");
#/vob/wuce/wuce/bin/cmbp_label dapsc
    print $sch . '@' . $descr . '@' . $view . "@\n"; # !!!!!!!!!! SPLITTER
  }
  return ERR_OK;
}

sub set_sch
{
  my ($self, $sch, $func, $start_time_h, $start_time_m, $disabled) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code);

  $xpath = $ec->modifySchedule($self->{'_PRJ'}, $sch,
                               { procedureName => $func,
                                 startTime => $start_time_h . ":" . $start_time_m,
                                 scheduleDisabled => $disabled } );
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("set_sch", __LINE__, $code);
    return ERR_FAIL;
  }
  return ERR_OK;
}

sub get_sch_by_job
{
  my ($self, $job_id, $rsch) = @_;
  my ($xpath, $code, $sch);
  my $ec = $self->{'_EC'};

  $xpath = $ec->getJobDetails($job_id);
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("get_sch_by_job", __LINE__, $code);
    return ERR_FAIL;
  }

  $$rsch = $xpath->findvalue('//response/job/scheduleName');
  if ($$rsch eq "") {
    $self->p_err("get_sch_by_job", __LINE__, "Schedule name is empty.");
    return ERR_FAIL;
  }
  return ERR_OK;
}

sub save_job_id
{
  my ($self, $sch, $job_id) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code, $ret);

  if ($sch eq "") {
    $ret = $self->get_sch_by_job($job_id, \$sch);
    if ($ret != ERR_OK)
    {
      $self->p_err("save_job_id", __LINE__, "Schedule name is empty.");
      return $ret;
    }
  }

  $xpath = $ec->setProperty(
    $self->{'_PROOT'} . "/schedules/" . $sch . "/job_id", $job_id,
    { projectName => $self->{'_PRJ'} });
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("save_job_id", __LINE__, $code);
    return ERR_FAIL;
  }
  return ERR_OK;
}

sub is_job_complete
{
  my ($self, $job_id) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code, $status);

  $xpath = $ec->getJobStatus($job_id);
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("is_job_complete", __LINE__, $code);
    return ERR_FALSE;
  }

  $status = $xpath->findvalue('//status');
  return ERR_TRUE if ($status eq "completed");
  return ERR_FALSE;
}

sub is_sch_ctx # !!!
{
  my ($self, $job_id) = @_;
  my $sch;
  return $self->get_sch_by_job($job_id, \$sch); # !!!
}

sub is_running # !!!
{
  my ($self, $sch, $ec_job_id, $ssv) = @_;
  my ($xpath, $code, $ssv_job_id, $jobs, $ret);
  my $ec = $self->{'_EC'};
  my $prj = $self->{'_PRJ'};

  if ($sch eq "") {
    $ret = $self->get_sch_by_job($ec_job_id, \$sch);
    return $ret if ($ret != ERR_OK);
  }

  $xpath = $ec->getProperty(
    $self->{'_PROOT'} . "/schedules/" . $sch . "/job_id",
    { projectName => $self->{'_PRJ'} });
  $code = $xpath->findvalue("//code");
  if ($code eq "") {
    $ssv_job_id = $xpath->findvalue("//value");
    $ret = $self->is_job_complete($ssv_job_id);
    return ERR_FAIL if ($ret != ERR_TRUE);
  }

  if ($ec_job_id) {
    $xpath = $ec->getJobInfo($ec_job_id); # !!!
    $code = $xpath->findvalue("//code");
    if ($code ne "") {
      $self->p_err("is_running", __LINE__, $code);
      return ERR_FAIL;
    }
    $prj = $xpath->findvalue("//projectName");
  }
  $xpath = $ec->getJobsForSchedule($prj, $sch);
  $jobs = $xpath->find('//response/job[status != "completed"]');

  return ERR_FAIL if ($jobs->size > 1 && !$ssv && $ec_job_id);
  return ERR_FAIL if ($jobs->size != 0 && $ssv && !$ec_job_id);
  return ERR_OK;
}

sub chk_ec_sch_names
{
  my ($self) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code, $schs, $schn, $name);
  my $ret = ERR_OK;

  $xpath = $ec->getSchedules($self->{'_PRJ'});
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("chk_ec_sch_names", __LINE__, $code);
    return ERR_FAIL;
  }

  $schs = $xpath->find("//schedule/scheduleName");
  foreach $schn ($schs->get_nodelist) {
    $name = $schn->string_value();
    if ($name =~ m/( |\x23|\/|\\|\*|\&|\'|\"|\`)/) {
      print "\"" . $name . "\"\n";
      $ret = ERR_FAIL;
    }
  }
  return $ret
}

sub chk_ec_proc_names
{
  my ($self) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code, $procs, $procn, $name);
  my $ret = ERR_OK;

  $xpath = $ec->getProcedures($self->{'_PRJ'});
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("chk_ec_proc_names", __LINE__, $code);
    return ERR_FAIL;
  }

  $procs = $xpath->find("//procedureName");
  foreach $procn ($procs->get_nodelist) {
    $name = $procn->string_value();
    if ($name =~ m/( |\x23|\/|\\|\*|\&|\'|\"|\`)/) {
      print "\"" . $name . "\"\n";
      $ret = ERR_FAIL;
    }
  }
  return $ret
}

sub chk_ec_proc_conf
{
  my ($self) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $xpath_proc, $code, $procs, $procn, $proc);
  my $ret = ERR_OK;

  $xpath_proc = $ec->getProcedures($self->{'_PRJ'});
  $code = $xpath_proc->findvalue("//code");
  if ($code ne "") {
    $self->p_err("chk_ec_proc_names", __LINE__, $code);
    return ERR_FAIL;
  }

  $xpath = $ec->getProperties({ projectName => $self->{'_PRJ'},
                                path => $self->{'_PROOT'} . "/projects/AP" });
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    print $code;
    return ERR_FAIL;
  }

  $procs = $xpath->find(
    "//property[propertyName != \"name\" and  " .
               "propertyName != \"run_build_step\" and " .
               "propertyName != \"set_cs_step\" and " .
               "propertyName != \"clean_view_step\"]/value");
  foreach $procn ($procs->get_nodelist) {
    $proc = $xpath_proc->find(
      "//procedure[procedureName = \"" . $procn->string_value() . "\"]/procedureName");
    if ($proc->size() == 0) {
      print "\"" . $procn->string_value() . "\"\n";
      $ret = ERR_FAIL;
    }
  }

  $xpath = $ec->getProperties({ projectName => $self->{'_PRJ'},
                                path => $self->{'_PROOT'} . "/projects/CAPC" });
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    print $code;
    return ERR_FAIL;
  }

  $procs = $xpath->find(
    "//property[propertyName != \"name\" and  " .
               "propertyName != \"run_build_step\" and " .
               "propertyName != \"set_cs_step\" and " .
               "propertyName != \"clean_view_step\" and " .
               "value != \"__empty__\"]/value");
  foreach $procn ($procs->get_nodelist) {
    $proc = $xpath_proc->find(
      "//procedure[procedureName = \"" . $procn->string_value() . "\"]/procedureName");
    if ($proc->size() == 0) {
      print "\"" . $procn->string_value() . "\"\n";
      $ret = ERR_FAIL;
    }
  }
  return $ret;
}

sub chk_ec_sch_types
{
  my ($self) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code, $schs, $schn, $sch);
  my $bld_type = "ap"; # !!!
  my $ret = ERR_OK;
  my $err = ERR_OK;

  $xpath = $ec->getSchedules($self->{'_PRJ'});
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    print $code;
    return ERR_FAIL;
  }

  $schs = $xpath->find("//response/schedule/scheduleName");
  foreach $schn ($schs->get_nodelist) {
    $err = $self->get_build_type($schn->string_value(), 0);
    if ($err != ERR_OK) {
      print "\"" . $schn->string_value() . "\"\n";
      $ret = ERR_FAIL;
    }
  }
  return $ret;
}

sub chk_ssscm_prop_perm
{
  my ($self) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code);
  my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time);
  my $prop = sprintf("%4d-%02d-%02d_%02d:%02d:%02d",
                     $year+1900, $mon+1, $mday, $hour, $min, $sec);

  $xpath = $ec->setProperty($self->{'_PROOT'} . "/tmp/" . $prop, "1",
                            { projectName => $self->{'_PRJ'} });
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("chk_ssscm_prop_perm", __LINE__, $code);
    return ERR_FAIL;
  }

  $xpath = $ec->deleteProperty($self->{'_PROOT'} . "/tmp/" . $prop,
                               { projectName => $self->{'_PRJ'} });
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("chk_ssscm_prop_perm", __LINE__, $code);
    return ERR_FAIL;
  }
  return ERR_OK;
}

sub chk_ssscm_sch_list
{
  my ($self) = @_;
  my $ec = $self->{'_EC'};
  my ($xpath, $code, $schs);

  $xpath = $ec->getSchedules($self->{'_PRJ'});
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("chk_ec_sch_list", __LINE__, $code);
    return ERR_FAIL;
  }

  $schs = $xpath->find("//response/schedule");
  return ERR_FAIL if ($schs->size() == 0);
  return ERR_OK;
}

sub is_view_unique
{
  my ($self, $view) = @_;
  my ($xpath, $code, $schset, $schn, $sch, $prjset, $prjn, $prj, $view_name);
  my $ec = $self->{'_EC'};

print "view: " . $view . "\n";

  $xpath = $ec->getProjects();
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("is_view_unique", __LINE__, $code);
    return ERR_FALSE;
  }

  $prjset = $xpath->find("//project[workspaceName = \"WiMAX\"]/projectName");
  foreach $prjn ($prjset->get_nodelist) {
    $prj = $prjn->string_value();
print "prj: " . $prj . "\n";
    $xpath = $ec->getSchedules($prj);
    $code = $xpath->findvalue("//code");
    if ($code ne "") {
      $self->p_err("is_view_unique", __LINE__, $code);
      return ERR_FALSE;
    }

    $schset = $xpath->find("//scheduleName");
    foreach $schn ($schset->get_nodelist) {
      $sch = $schn->string_value();
print "sch: " . $sch . "\n";
      $xpath = $ec->getActualParameter(
        { projectName => $prj,
          scheduleName => $sch,
          procedureName => $ENV{'AP_PROC_RUN_BUILD'}, # !!!
          stepName => $ENV{'AP_PROC_RUN_BUILD_STEP'} }); # !!!!!
      $view_name = $xpath->findvalue(
        "//actualParameter[actualParameterName = \"view_name\"]/value");
print "view_name: " . $view_name . "\n";
      return ERR_FALSE if ($view eq $view_name);
    }
  }
  return ERR_TRUE;
}

sub clean_view
{
  my ($self, $view) = @_;
  my ($line, $cmd);
  my $recovery = 0;

  while (<>) {
    $line = $_;
    chomp $line;
    unless ($line =~ /\/vob\/wuce\/emake/) {
      if ($line =~ m/<DIR-/) {
        $line =~ s/^.*<DIR-(.*)>.*/$1/;

        $cmd  = "set -xv\n";
        $cmd .= "cleartool recoverview -force -dir " . $line . " -tag " . $view . "\n";
        $cmd .= "vpath=`cleartool lsview |";
        $cmd .= " grep " . $view . " | sed 's/^[ |\*]//' | cut -d ' ' -f 3`\n";
        $cmd .= "rm -rf \${vpath}/.s/lost+found/*\n";
        system($cmd); # !!!
        $recovery = 1;
      } else {
        system("rm -rf " . $line . " 2>&1 | sed -e 's/^/(warning) &/'");
      }
    }
  }

  if ($recovery) {
    system("cleartool recoverview -force -tag " . $view); # !!!
#    system("cleartool setcs -current ");
  }
  return ERR_OK;
}

sub is_view_exists
{
  my ($self, $view) = @_;
  my ($ret, $cmd);

  $cmd  = "/usr/atria/bin/cleartool lsview " . $view . "> /dev/null\n";
  $cmd .= "exit \$?\n";

  $ret = system($cmd) >> 8;
  return  $ret;
}

sub is_label_exists
{
  my ($self, $view) = @_;
  my ($ret, $cmd);

  $cmd  = "CMBPLABEL=`/usr/atria/bin/cleartool setview -exe ";
  $cmd .= " \"/vob/wuce/wuce/bin/cmbp_label dapsc\" " . $view . "`\n";
  $cmd .= "/usr/atria/bin/cleartool lstype lbtype:";
  $cmd .= "\${CMBPLABEL}@/vob/wibb_bts 2>&1 > /dev/null\n";
  $cmd .= "exit \$?\n";

  $ret = system($cmd) >> 8;
  return  !$ret;
}

sub is_cs_changed
{
  my ($self, $view) = @_;
  my ($ret, $cmd);

  $cmd .= "v2=$view\n";
  $cmd .= "target=emake\n"; # !!!
  $cmd .= "smartbuilddir=/mot/proj/wibb_bts/daily/tmpsmartbuild/\${v2}_\${target}\n";
  $cmd .= "if [[ ! -d \$smartbuilddir ]]; then\n";
  $cmd .= "mkdir \$smartbuilddir\n";
  $cmd .= "chmod a+w \$smartbuilddir\n";
  $cmd .= "touch \$smartbuilddir/prev_cs_\$target\n";
  $cmd .= "touch \$smartbuilddir/prev_crlog_\$target\n";
  $cmd .= "fi\n";
  $cmd .= "prevcs=\$smartbuilddir/prev_cs_\$target\n";
  $cmd .= "currcs=\$smartbuilddir/curr_cs_\$target\n";
  $cmd .= "rm -f \$currcs\n";
  $cmd .= "/usr/atria/bin/cleartool setview -exe \"cleartool catcs -tag ";
  $cmd .= "\${v2} > \${currcs}\" \${v2}\n";
  $cmd .= "chmod ug+rw \$currcs\n";
  $cmd .= "cmp \$prevcs \$currcs > /dev/null 2>&1\n"; # !!!!!
  $cmd .= "diffcs=\$?\n";

  $cmd .= "prevlog=\$smartbuilddir/prev_crlog_\$target\n";
  $cmd .= "currlog=\$smartbuilddir/curr_crlog_\$target\n";
  $cmd .= "rm -f \$currlog\n";
  $cmd .= "/usr/atria/bin/cleartool setview -exe ";
  $cmd .= "\"cd /vob/wibb_bts; /mot/proj/wibb_bts/cmbp/wibb_bts/cm-policy/bin/mergestat | ";
  $cmd .= "grep -E '.*yes.*yes.*|.*no.*yes.*' > \${currlog}\" \${v2}\n";
  $cmd .= "chmod ug+rw \$currlog\n";
  $cmd .= "cmp \$prevlog \$currlog > /dev/null 2>&1\n"; # !!!!!
  $cmd .= "diffcr=\$?\n";

  $cmd .= "if [[ \$diffcs == 0 && \$diffcr == 0 ]]; then\n";
  $cmd .= "  exist=0\n";
  $cmd .= "else\n";
  $cmd .= "  exist=1\n";
  $cmd .= "fi\n";
  $cmd .= "exit \$exist\n";

  $ret = system($cmd) >> 8;
  return  $ret;
}

# !!!!!!!!!!!!!!!!!!!
sub is_view_clean # !!!!!!!!!!!!
{
  my ($self, $view) = @_;
  my ($ret, $cmd);

  $cmd  = "/usr/atria/bin/cleartool setview -exe ";
  $cmd .= "\"/bin/ksh -c '/usr/atria/bin/cleartool lsp | ";
  $cmd .= "grep -v /vob/wuce/emake | awk \\\"{exit 1}\\\"'\" $view";

  $ret = system($cmd) >> 8;
  return $ret;
}

sub test
{
  my ($self) = @_;
  my ($xpath, $code, $prjset, $prjn, $prj,
      $aclset, $acln, $schset, $schn, $sch);
  my $ec = $self->{'_EC'};

  $xpath = $ec->getProjects();
  $code = $xpath->findvalue("//code");
  if ($code ne "") {
    $self->p_err("test", __LINE__, $code);
    return ERR_FAIL;
  }

  print "<?xml version=\"1.0\" ?>\n";
  print "<?xml-stylesheet type=\"text/xsl\" href=\"test.xsl\"?>\n";
  print "<test>\n";
  $prjset = $xpath->find("//projectName");
  foreach $prjn ($prjset->get_nodelist) {
    $prj = $prjn->string_value();
    $xpath = $ec->getAccess({projectName => $prj});
    $code = $xpath->findvalue("//code");
    if ($code ne "") {
      $self->p_err("test", __LINE__, $code);
      return ERR_FAIL;
    }

    print "<ssscm_project>\n";
    $aclset = $xpath->find("//response");
    foreach $acln ($aclset->get_nodelist) {
      print XML::XPath::XMLParser::as_string($acln) . "\n";
    }

    $xpath = $ec->getSchedules($prj);
    $code = $xpath->findvalue("//code");
    if ($code ne "") {
      $self->p_err("test", __LINE__, $code);
      return ERR_FAIL;
    }

    print "<ssscm_schedule>\n";
    $schset = $xpath->find("//scheduleName");
    foreach $schn ($schset->get_nodelist) {
      $sch = $schn->string_value();
      $xpath = $ec->getAccess({projectName => $prj,
                               scheduleName => $sch});
      $code = $xpath->findvalue("//code");
      if ($code ne "") {
        $self->p_err("test", __LINE__, $code);
        return ERR_FAIL;
      }

      $aclset = $xpath->find("//response");
      foreach $acln ($aclset->get_nodelist) {
        print XML::XPath::XMLParser::as_string($acln) . "\n";
      }
    }
    print "</ssscm_schedule>\n";
    print "</ssscm_project>\n";
  }
  print "</test>\n";
  return ERR_OK;
}

1;
