#!/bin/bash
## .SH ssv.sh
## .SS Author
## hqjr73@motorola.com on 01 March 2010
#set -x

BN=`basename $0`
#DN=`dirname $0` # !!!

CMD="$*"

export SSV_VERSION="1.0"
#export SSV_DIR=/home/hqjr73/work/scm/ssv_sh
export SSV_DIR=/mot/proj/ecommander/ssscm/stable
#export SSV_TOOL_PATH=${SSV_DIR}/ssv.ksh
export SSV_DIR_TMP=/mot/proj/ecommander/ssscm/tmp
#export SSV_TOOL_PATH=/mot/proj/ecommander/ssscm/current/ssv.ksh  # !!!!!!!
export SSV_TOOL_PATH=${SSV_DIR}/ssv.sh # !!!
export SSV_PROOT=ssscm
export EC_PROJECT="WiMAX-testing"
#export EC_PROJECT="z ssscm dev_test"
#export EC_UTILS_PROJECT="ssscm_dev"
export EC_UTILS_PROJECT="ssscm"
export SSV_LOG_DIR=/mot/proj/ecommander/ssscm/log
export WHOAMI=`id -u -n`
export FINGER=/usr/bin/finger # !!!
export SSV_LOG_FILE=${SSV_LOG_DIR}/ssscm_${WHOAMI}.log # !!! assign path to EC prop for access

export EC_PROC_EMPTY="__empty__"
export AP_PROC_RUN_BUILD="run_build"
export AP_PROC_RUN_BUILD_FORCE="run_build_force"
export AP_PROC_RUN_BUILD_CLEAN="run_build_clean"
export AP_PROC_RUN_BUILD_CLEAN_FORCE="run_build_clean_force"
export AP_PROC_RUN_BUILD_STEP="run_build_step"
export AP_PROC_CLEAN_VIEW="clean_view"
export AP_PROC_CLEAN_VIEW_STEP="clean_view"
export AP_PROC_SET_CS="set_cs"
export AP_PROC_SET_CS_STEP="set_cs" # !!!!!!
export CAPC_PROC_RUN_BUILD="run_build_capc"
export CAPC_PROC_RUN_BUILD_FORCE=${EC_PROC_EMPTY}
export CAPC_PROC_RUN_BUILD_CLEAN=${EC_PROC_EMPTY}
export CAPC_PROC_RUN_BUILD_CLEAN_FORCE=${EC_PROC_EMPTY}
export CAPC_PROC_RUN_BUILD_STEP="run_build_step"
export CAPC_PROC_CLEAN_VIEW=${EC_PROC_EMPTY}
export CAPC_PROC_CLEAN_VIEW_STEP=${EC_PROC_EMPTY}
export CAPC_PROC_SET_CS="set_cs_capc"
export CAPC_PROC_SET_CS_STEP="set_cs"
export BLD_TYPE_AP="ap" # !!! need to synchrnoize with perl scrips
export BLD_TYPE_CAPC="capc" # !!! need to synchrnoize with perl scrips

export DIALOG=dialog
export EC_TOOL=/opt/electriccloud/electriccommander/bin/ectool
#export EC_TOOL=/opt/electriccloud-/electriccommander/bin/ectool
#export EC_SERVER=10.8.108.2
export EC_SERVER=10.0.37.45
export SSV_PERL=/usr/bin/perl
export SSV_PERL_LIB=/opt/electriccloud/electriccommander/perl/lib/site_perl/5.8.8
#export SSV_PERL_LIB=/opt/electriccloud-/electriccommander/perl/lib/site_perl/5.8.8
export SSV_PERL_LIB2=/apps/public/TWWfsw/perl586p/lib/5.8.6/i686-linux-thread-multi
#export SSV_LIB="-I$SSV_PERL_LIB -I$SSV_DIR" # !!!!
export SSV_LIB="-I$SSV_PERL_LIB -I$SSV_PERL_LIB2 -I$SSV_DIR"
export SSV_DISP="${SSV_PERL} ${SSV_LIB} ${SSV_DIR}/ssv_disp.pl"
export SSV_SPLITTER='@'

export SSV_OK=0
export SSV_CANCEL=2
export SSV_FAULT=3
export SSV_EXIT=4
export SSV_TRUE=1
export SSV_FALSE=0
export SSV_INFO_F=1
export SSV_WARN_F=1
export SSV_TRACE_F=1
export SSV_TRACE_FUNC_F=0 # !!!!!!!!!!!!!!!!!!
export DLG_OK=0
export DLG_CANCEL=1
export DLG_ERROR=255
export DLG_HELP=2
export DLG_EXIT=3
export DIALOG_ESC=254
export DLG_ESC=${DIALOG_ESC}
export DLG_COMMON_WIDTH=60

DLG_MAIN=${SSV_DIR}/dlg_main.sh
export DLG_BUILDS=${SSV_DIR}/dlg_builds.sh
export DLG_CONF=${SSV_DIR}/dlg_conf.sh
export DLG_CONF_TYPE=${SSV_DIR}/dlg_conf_type.sh
export DLG_CONF_COLOR=${SSV_DIR}/dlg_conf_color.sh
export DLG_VIEW_UTILS=${SSV_DIR}/dlg_view_utils.sh
export DLG_SPEC_UTILS=${SSV_DIR}/dlg_spec_utils.sh
export DLG_SPEC_RESTORE=${SSV_DIR}/dlg_spec_restore.sh
export DLG_SCH=${SSV_DIR}/dlg_sch.sh
export DLG_SCH_TIME=${SSV_DIR}/dlg_sch_time.sh
export DLG_SCH_EN=${SSV_DIR}/dlg_sch_en.sh
export DLG_MSG_BOX=${SSV_DIR}/dlg_msg_box.sh

export SSV_CHECK_CONF=${SSV_DIR}/ssv_check.sh
export SSV_TRACE=${SSV_DIR}/ssv_trace.sh # !!!!!!!
export SSV_ERROR="${SSV_DIR}/ssv_trace.sh -e" # !!!!!!
export SSV_INFO="${SSV_DIR}/ssv_trace.sh -i" # !!!!!!
export SSV_WARN="${SSV_DIR}/ssv_trace.sh -w" # !!!!!!
export SSV_TRACE_FUNC="${SSV_DIR}/ssv_trace.sh -f" # !!!!!!!

export ID_DLG_MAIN_BUILDS=Builds
export ID_DLG_MAIN_CONF=Configuration
export ID_DLG_MAIN_ABOUT=About
export ID_DLG_CONF_UT_TRMTYPE="Terminal Type"
export ID_DLG_CONF_UT_TRMCOLOR="Terminal Color Scheme"
export ID_DLG_CONF_UT_LOG="Log File"
export ID_DLG_CONF_TERM_DUMP=dump
export ID_DLG_CONF_TERM_XTERM=xterm
export ID_DLG_CONF_TERM_LINUX=linux
export ID_DLG_CONF_TERM_RXVT=rxvt
export ID_DLG_CONF_TERM_DTTERM=dtterm
export ID_DLG_CONF_TERM_CYGWIN=cygwin
export ID_DLG_CONF_TERM_MONOCHROME=Monochrome
export ID_DLG_CONF_TERM_COLOR=Color
export ID_DLG_VIEW_UTIL_INFO="Build Information"
export ID_DLG_VIEW_UTIL_RUN="Run Incremental Build"
export ID_DLG_VIEW_UTIL_RUN_CLEAN="Run Clean Build"
export ID_DLG_VIEW_UTIL_STOP="Stop Build"
export ID_DLG_VIEW_UTIL_SPEC="Change Configuration Specification"
export ID_DLG_VIEW_UTIL_SCH="Change Schedule Parameters"
export ID_DLG_VIEW_UTIL_CLEAN="Clean Build View"
export ID_DLG_SPEC_UTILS_SHOW="Show Config Spec"
export ID_DLG_SPEC_UTILS_EDIT="Change Config Spec"
export ID_DLG_SPEC_UTILS_RESTORE="Restore Config Spec"
export ID_DLG_SCH_PROC_CLEAN=Clean
export ID_DLG_SCH_PROC_FORCE=Force
export ID_DLG_SCH_ENABLE=Enable

touch ${SSV_LOG_FILE} # !!!
source ${SSV_DIR}/ssv.rc
trap ssv_trap_err ERR

export SSV_TMPFN=${SSV_DIR}/ssv_tmpfn.sh
export TMP_RES=`${SSV_TMPFN} ${BN} res` # !!!!
export ERR_M=yes
export ERR_T=no

do_check=0
passwordd_path="" # !!!
connected=0

while getopts echp: opt; do
  case ${opt} in
    e)
      ${SSV_DISP} ${CMD}
      exit $?
      ;;
    c) do_check=1 ;;
    p) password_path="${OPTARG}" ;;
    h)
      echo "usage: ${BN} [-ch] [-p path]"
      echo "  -c  Run configuration checks before start."
      echo "  -p  Path to file with password."
      exit ${SSV_OK}
      ;;
  esac
done

# check parameters
#if [[ "${cmd}" = "" ]]; then
#  echo "__usage__2"
#  exit ${SSV_FAULT} # !!!
#fi

#${SSV_TRACE} "__start"

ssv_logout()
{
  if [[ "${connected}" = "1" ]]; then
    ${EC_TOOL} --server "${EC_SERVER}" logout 1>${TMP_RES} 2>&1
    [[ "$?" != "${SSV_OK}" ]] && { ERR_M=no p_err ${LINENO}; }
  fi
}

SSV_HOST=`uname -n`
if [[ "${SSV_HOST}" != "isdlinux4" && "${SSV_HOST}" != "isdlinux5" ]]; then
  ${SSV_ERROR} "Unsupported launch host: `uname -a`"
  echo "ERROR. You can run SSSCM tool on isdlinux4 or isdlinux5 only."
  echo "Look at ${SSV_LOG_FILE} for more information."
  exit ${SSV_FAULT}
fi

if [[ "${password_path}" = "" ]]; then
  echo -n "OneIT password: "
  ${EC_TOOL} --server "${EC_SERVER}" login ${WHOAMI} 2>${TMP_RES} 1>/dev/null
else
  ${EC_TOOL} --server "${EC_SERVER}" login ${WHOAMI} < ${password_path} 2>${TMP_RES} 1>/dev/null
fi
[[ "$?" != "0" ]] && { ERR_M=no ERR_T=yes p_err ${LINENO} "Login failed"; exit ${SSV_FAULT}; }
connected=1

if [[ "${EDITOR}" = "" ]]; then
  echo "$(tput setaf 3)Warning$(tput sgr0): EDITOR environment variable is undefined."
  if [[ -e /usr/bin/vim ]]; then
    export SSV_EDITOR=/usr/bin/vim
  else
    if [[ -e /bin/vi ]]; then
      export SSV_EDITOR=/bin/vi
    else
      echo "$(tput setaf 1)Error$(tput sgr0): Default editor is undefined. Please setup your EDITOR evironment varibale before start SelfServeSCM tool."
      ERR_M=no ERR_T=no p_err ${LINENO} "EDITOR is undefined"
      ssv_logout
      exit ${SSV_FAULT};
    fi
  fi
else
  export SSV_EDITOR=${EDITOR}
fi

if [[ "${do_check}" = "1" ]]; then
  ${SSV_CHECK_CONF}
  case "$?" in
    ${SSV_OK}) ;;
    ${SSV_CANCEL})
      echo -n "There are issues in configuration. Press Enter to continue ..."
      read
      ;;
#    ${SSV_FAILED}) ssv_logout; exit ${SSV_FAULT} ;; # !!!
    *) ERR_M=no ERR_T=yes p_err ${LINENO}; ssv_logout; exit ${SSV_FAULT} ;; # !!!
  esac
fi

${SSV_DISP} --proc="getprocs" \
            --prtype="AP" \
            --drb="${AP_PROC_RUN_BUILD}" \
            --drbf="${AP_PROC_RUN_BUILD_FORCE}" \
            --drbc="${AP_PROC_RUN_BUILD_CLEAN}" \
            --drbcf="${AP_PROC_RUN_BUILD_CLEAN_FORCE}" \
            --drbs="${AP_PROC_RUN_BUILD_STEP}" \
            --dcv="${AP_PROC_CLEAN_VIEW}" \
            --dcvs="${AP_PROC_CLEAN_VIEW_STEP}" \
            --dsc="${AP_PROC_SET_CS}" \
            --dscs="${AP_PROC_SET_CS_STEP}" \
            --tpath="${SSV_TOOL_PATH}" 1>${TMP_RES} 2>&1
[[ "$?" != "${SSV_OK}" ]] && \
  { ERR_M=no ERR_T=yes p_err ${LINENO}; ssv_logout; exit ${SSV_FAULT}; }
export EC_PROJECT=`cat ${TMP_RES} | cut -d '|' -f 1`
export AP_PROC_RUN_BUILD=`cat ${TMP_RES} | cut -d '|' -f 2`
export AP_PROC_RUN_BUILD_FORCE=`cat ${TMP_RES} | cut -d '|' -f 3`
export AP_PROC_RUN_BUILD_CLEAN=`cat ${TMP_RES} | cut -d '|' -f 4`
export AP_PROC_RUN_BUILD_CLEAN_FORCE=`cat ${TMP_RES} | cut -d '|' -f 5`
export AP_PROC_RUN_BUILD_STEP=`cat ${TMP_RES} | cut -d '|' -f 6`
export AP_PROC_CLEAN_VIEW=`cat ${TMP_RES} | cut -d '|' -f 7`
export AP_PROC_CLEAN_VIEW_STEP=`cat ${TMP_RES} | cut -d '|' -f 8`
export AP_PROC_SET_CS=`cat ${TMP_RES} | cut -d '|' -f 9`
export AP_PROC_SET_CS_STEP=`cat ${TMP_RES} | cut -d '|' -f 10`
# export SSV_TOOL_PATH # !!!!!!!!!!!!!!!!!!!

${SSV_DISP} --proc="getprocs" \
            --prtype="CAPC" \
            --drb="${CAPC_PROC_RUN_BUILD}" \
            --drbf="${CAPC_PROC_RUN_BUILD_FORCE}" \
            --drbc="${CAPC_PROC_RUN_BUILD_CLEAN}" \
            --drbcf="${CAPC_PROC_RUN_BUILD_CLEAN_FORCE}" \
            --drbs="${CAPC_PROC_RUN_BUILD_STEP}" \
            --dcv="${CAPC_PROC_CLEAN_VIEW}" \
            --dcvs="${CAPC_PROC_CLEAN_VIEW_STEP}" \
            --dsc="${CAPC_PROC_SET_CS}" \
            --dscs="${CAPC_PROC_SET_CS_STEP}" \
            --tpath="${SSV_TOOL_PATH}" 1>${TMP_RES} 2>&1
[[ "$?" != "${SSV_OK}" ]] && \
  { ERR_M=no p_err ERR_T=yes ${LINENO}; ssv_logout; exit ${SSV_FAULT}; }
export EC_PROJECT=`cat ${TMP_RES} | cut -d '|' -f 1`
export CAPC_PROC_RUN_BUILD=`cat ${TMP_RES} | cut -d '|' -f 2`
export CAPC_PROC_RUN_BUILD_FORCE=`cat ${TMP_RES} | cut -d '|' -f 3`
export CAPC_PROC_RUN_BUILD_CLEAN=`cat ${TMP_RES} | cut -d '|' -f 4`
export CAPC_PROC_RUN_BUILD_CLEAN_FORCE=`cat ${TMP_RES} | cut -d '|' -f 5`
export CAPC_PROC_RUN_BUILD_STEP=`cat ${TMP_RES} | cut -d '|' -f 6`
export CAPC_PROC_CLEAN_VIEW=`cat ${TMP_RES} | cut -d '|' -f 7`
export CAPC_PROC_CLEAN_VIEW_STEP=`cat ${TMP_RES} | cut -d '|' -f 8`
export CAPC_PROC_SET_CS=`cat ${TMP_RES} | cut -d '|' -f 9`
export CAPC_PROC_SET_CS_STEP=`cat ${TMP_RES} | cut -d '|' -f 10`
# export SSV_TOOL_PATH # !!!!!!!!!!!!!!!!!!!

${SSV_DISP} --proc="getlog" --user="${WHOAMI}" 1>${TMP_RES} 2>&1
if [[ "$?" = "${SSV_OK}" ]]; then
  export SSV_LOG_FILE=`cat ${TMP_RES}`
else
  ${SSV_DISP} --proc="setlog" --user="${WHOAMI}" --value="${SSV_LOG_FILE}" 1>${TMP_RES} 2>&1
  [[ "$?" != "${SSV_OK}" ]] && { ERR_M=no p_err ${LINENO}; }
fi

${SSV_DISP} --proc="getterm" --user="${WHOAMI}" 1>${TMP_RES} 2>&1
if [[ "$?" = "${SSV_OK}" ]]; then
  export TERM=`cat ${TMP_RES}`
else
  export TERM="dtterm"
  ${SSV_DISP} --proc="setterm" --user="${WHOAMI}" --value="${TERM}" 1>${TMP_RES} 2>&1
  [[ "$?" != "${SSV_OK}" ]] && { ERR_M=no p_err ${LINENO}; }
fi
if [[ "${TERM}" != "dtterm" && "${TERM}" != "xterm" && "${TERM}" != "linux" ]]; then
  echo -n "$(tput setaf 3)Warning$(tput sgr0): "
  echo "\"${TERM}\" is a current terminal type. We suggest to use \"dtterm\" or \"xterm\"."
  echo "You can change current terminal type in \"Configuration\" dialog."
  echo -n "Press Enter to continue ..."
  read
fi

${SSV_DISP} --proc="getclr" --user="${WHOAMI}" 1>${TMP_RES} 2>&1
if [[ "$?" = "${SSV_OK}" ]]; then
  export TERM_COLOR=`cat ${TMP_RES}`
  if [[ "${TERM_COLOR}" = "${ID_DLG_CONF_TERM_MONOCHROME}" ]]; then
    export DIALOGRC="${SSV_DIR}/dlg.rc"
  fi
else
  export TERM_COLOR=${ID_DLG_CONF_TERM_COLOR}
  ${SSV_DISP} --proc="setclr" --user="${WHOAMI}" --value="${TERM_COLOR}" 1>${TMP_RES} 2>&1
  [[ "$?" != "${SSV_OK}" ]] && { ERR_M=no p_err ${LINENO}; }
fi

${DLG_MAIN} 2>${TMP_RES}
ret=$?
[[ "${ret}" != "${SSV_OK}" && "${ret}" != "${SSV_EXIT}" ]] && { p_err ${LINENO}; }

ssv_logout

rm -f ${TMP_RES}
exit ${SSV_OK}
