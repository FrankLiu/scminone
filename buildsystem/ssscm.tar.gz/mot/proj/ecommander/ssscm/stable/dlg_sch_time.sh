#!/bin/bash -E
## .SH dlg_sch_time.sh
## .SS Author
## hqjr73@motorola.com on 24 April 2010

BN=`basename $0`
#DN=`dirname $0`

trap ssv_trap_err ERR

dlg_ret=${DLG_CANCEL} # !!!
dlg_res=0
dlg_exit=0
sch=""  # !!!
func="${AP_PROC_RUN_BUILD}"
disabled=1
start_time_h=0
start_time_m=0

while getopts o:m:c:f:s:d: opt; do
  case ${opt} in
    s) sch="${OPTARG}" ;;
    f) func="${OPTARG}" ;;
    o) start_time_h="${OPTARG}" ;;
    m) start_time_m="${OPTARG}" ;;
    d) disabled="${OPTARG}" ;;
  esac
done

# !!! check parameters
#if [[ "${sch}" = "" ]]; then
#  echo "__usage__2"
#  exit 1 # !!!
#fi

# !!!
#if [[ "${view}" = "" ]]; then
#  echo "__usage__3"
#  exit 1 # !!!
#fi

dlg_sch_time_dispatch()
{
  case ${dlg_ret} in
    ${DLG_ESC} | ${DLG_CANCEL}) dlg_exit=${SSV_TRUE}; return ${SSV_CANCEL} ;;
    ${DLG_HELP}) ssv_quit; return $? ;;
    ${DLG_EXIT}) ssv_help ${SSV_DIR}/doc/README_sch_time; return $? ;;
    ${DLG_OK})
      start_time_h=`echo "${dlg_res}" | cut -d ':' -f 1`
      start_time_m=`echo "${dlg_res}" | cut -d ':' -f 2`
      ${DLG_SCH_EN} -s "${sch}" -f "${func}" -o "${start_time_h}" \
                    -m "${start_time_m}" -d "${disabled}"
      ret=$?
      [[ "${ret}" = "${SSV_CANCEL}" ]] && return ${SSV_OK}
      [[ "${ret}" = "${SSV_OK}" ]] && dlg_exit=${SSV_TRUE}
      return ${ret}
      ;;

    *) p_err ${LINENO}; return ${SSV_EXIT} ;;
  esac
  return ${SSV_OK}
}

dlg_sch_time_show()
{
  ${DIALOG} \
    --backtitle "Self Serve SCM > Builds > ${sch} > Schedule > Time" \
    --title " Change Start Time " \
    --help-button \
    --extra-button \
    --extra-label "Back" \
    --ok-label "Next" \
    --cancel-label "Exit" \
    --timebox "Change Start time (hh:mm:ss).\nUse [TAB] to move between controls. Use arrow keys to change values. To exit, use [TAB] to move to Exit." \
    5 ${DLG_COMMON_WIDTH} "${start_time_h}" "${start_time_m}" 0 2>${TMP_RES}
  dlg_ret=$?
  [[ "${dlg_ret}" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  dlg_res=`cat ${TMP_RES}`
  return ${SSV_OK}
}

dlg_sch_time_run()
{
  while [[ "${dlg_exit}" = "${SSV_FALSE}" ]]; do
    dlg_sch_time_show
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break

    dlg_sch_time_dispatch
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break
  done
  return ${ret}
}

dlg_sch_time_run
