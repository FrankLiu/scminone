#!/bin/bash -E
## .SH dlg_view_utils.sh
## .SS Author
## hqjr73@motorola.com on 02 March 2010

BN=`basename $0`
#DN=`dirname $0`

TMP_INFO=`${SSV_TMPFN} ${BN} info`
TMP_SCH=`${SSV_TMPFN} ${BN} sch`
TMP_JOB_ID=`${SSV_TMPFN} ${BN} job_id`
TMP_STR=`${SSV_TMPFN} ${BN} str`

dlg_ret=${DLG_CANCEL}
dlg_res=0
dlg_exit=0
job_status="STOPPED" # !!!!!!!!!!!!!!!!!!!!
def_item=0
sch="" # !!!
view="" # !!!
force_build=0 # !!! use constant
clean_build=0 # !!! use constant
was_asked=0 # !!! use constant
run_build_func_name="Run Build" # !!!

trap ssv_trap_err ERR

while getopts v:s: opt; do
  case ${opt} in
    v) view="${OPTARG}" ;;
    s) sch="${OPTARG}" ;;
#    ?|h) # !!!!!!
#     echo "usage: ${BN} -f <build-log> -p {aps|capc|cpe}"
#     echo "  Parse wuce build log (-f) by product family (-p)."
#      echo "__usage__1"
#      exit 1 # !!!
#      ;;
  esac
done

# check parameters
#if [[ "${cmd}" = "" ]]; then
#  echo "__usage__2"
#  exit 1 # !!!
#fi

is_job_running()
{
  ${SSV_DISP} --proc="isrun" --sch="$sch" --job_id=0 --ssv
  return $?
}

# !!! need to move to common module
message_box() # !!! need to rename
{
  step_name=$1
  msgbox_backtitle=$2
  msgbox_title=$3
  msgbox_msg=$4

# !!!! RACE CONDITION !!!!!!!!!
  ${SSV_DISP} --proc="getprop" \
              --prop="${SSV_PROOT}/schedules/${sch}/job_id" > ${TMP_STR}
  [[ "$?" != "${SSV_OK}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  job_id=`cat ${TMP_STR}`

  ${SSV_DISP} --proc="getslog" --job_id="${job_id}" \
              --step="${step_name}" > ${TMP_STR}
  [[ "$?" != "${SSV_OK}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

  step_log=`cat ${TMP_STR}`
  ${DLG_MSG_BOX} -b "${msgbox_backtitle}" \
                 -t "${msgbox_title}" \
                 -l 7 \
                 -m "${msgbox_msg}" \
                 -f ${step_log}
  [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  return ${SSV_OK}
}

run_build_ap_final()
{
  ${DIALOG} \
    --backtitle "Self Serve SCM > Builds > ${sch} > ${run_build_func_name}" \
    --infobox "\"${run_build_func_name}\" job launching.\nPlease wait ..." \
    4 ${DLG_COMMON_WIDTH}
  [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

  if [[ "${clean_build}" = "1" ]]; then # !!! use constant
    if [[ "${force_build}" = "1" ]]; then # !!! use constant
      func="${AP_PROC_RUN_BUILD_CLEAN_FORCE}"
    else
      func="${AP_PROC_RUN_BUILD_CLEAN}"
    fi
  else
    if [[ "${force_build}" = "1" ]]; then # !!! use constant
      func="${AP_PROC_RUN_BUILD_FORCE}"
    else
      func="${AP_PROC_RUN_BUILD}"
    fi
  fi

  ${SSV_DISP} --proc="call" --func="${func}" --wait \
              --cmd="view_name:${view},schedule_name:${sch}"
  if [[ "$?" = "${SSV_OK}" ]]; then
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > ${run_build_func_name}" \
      --title " ${run_build_func_name} " \
      --msgbox "SUCCESS. ${sch}.\n\"${run_build_func_name}\" job has been launched." \
      6 ${DLG_COMMON_WIDTH}
    [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  else
    message_box "${AP_PROC_RUN_BUILD_STEP}" \
                "Self Serve SCM > Builds > ${sch} > ${run_build_func_name}" \
                " ${run_build_func_name} " \
                "FAULT. ${sch}.\n\"${run_build_func_name}\" job was not launched."
    return $? # !!!!!!!!!!!!!!!!!!!!!!!!!
  fi
  return ${SSV_OK}
}

run_build_ap()
{
  force_build=0 # !!! use constant
  was_asked=0 # !!! use constant

  ${DIALOG} \
    --backtitle "Self Serve SCM > Builds > ${sch} > ${run_build_func_name}" \
    --infobox "Check new CRs list and config spec changes.\nPlease wait ..." \
    4 ${DLG_COMMON_WIDTH}
  [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

  ${SSV_DISP} --proc="iscsch" --view="${view}"
  if [[ "$?" = "${SSV_OK}" ]]; then
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > ${run_build_func_name}" \
      --title " ${run_build_func_name} " \
      --defaultno \
      --yesno "${sch}.\nConfig cspec is not changed.\n\nDo you want to launch \"${run_build_func_name}\" job anyway?" \
      9 ${DLG_COMMON_WIDTH}
    case $? in
      ${DLG_OK})
        force_build=1 # !!! constant
        was_asked=1 # !!! constant
        ;;
      ${DLG_CANCEL} | ${DLG_ESC}) return ${SSV_OK} ;;
      *) p_err ${LINENO}; return ${SSV_EXIT} ;;
    esac
  fi

#  ${SSV_DISP} --proc="isvcln" --view="${view}"
#  if [[ "$?" != "${SSV_OK}" ]]; then
#    ${DIALOG} \
#      --backtitle "Self Serve SCM > Builds > ${sch} > Run Build" \
#      --title " Run Build " \
#      --defaultno \
#      --yesno "${sch}.\nView is not clean.\nDoes the view need to be cleaned?" \
#      7 ${DLG_COMMON_WIDTH}
#    case $? in
#      ${DLG_OK})
#        clean_build=1
#        was_asked=1 # !!! constant
#        ;;
#      ${DLG_CANCEL} | ${DLG_ESC})
#        was_asked=1 # !!! constant
#        ;;
#      *) p_err ${LINENO}; return ${SSV_EXIT} ;;
#    esac
#  fi

  if [[ "${was_asked}" = "1" ]]; then # !!! constant
    run_build_ap_final
    return $?
  else
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > ${run_build_func_name}" \
      --title " ${run_build_func_name} " \
      --defaultno \
      --yesno "Are you sure you want to launch \"${run_build_func_name}\" job?" \
      6 ${DLG_COMMON_WIDTH}
    case $? in
      ${DLG_OK})
        run_build_ap_final
        return $?
        ;;
      ${DLG_CANCEL} | ${DLG_ESC}) return ${SSV_OK} ;; # !!!!!!!!!!!!!!!!!
      *) p_err ${LINENO}; return ${SSV_EXIT} ;;
    esac
  fi
  return ${SSV_OK}
}

run_build_capc()
{
  ${DIALOG} \
    --backtitle "Self Serve SCM > Builds > ${sch} >${run_build_func_name}" \
    --title " ${run_build_func_name} " \
    --defaultno \
    --yesno "${sch}\nAre you sure you want to launch \"${run_build_func_name}\" job?" \
    6 ${DLG_COMMON_WIDTH}
  case $? in
    ${DLG_OK})
      ${DIALOG} \
        --backtitle "Self Serve SCM > Builds > ${sch} > ${run_build_func_name}" \
        --infobox "\"${run_build_func_name}\" job launching.\nPlease wait ..." \
        4 ${DLG_COMMON_WIDTH}
      [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

      ${SSV_DISP} --proc="call" --func="${CAPC_PROC_RUN_BUILD}" --wait \
                  --cmd="view_name:${view},schedule_name:${sch}"
      if [[ "$?" = "${SSV_OK}" ]]; then
        ${DIALOG} \
          --backtitle "Self Serve SCM > Builds > ${sch} > Run Build" \
          --title " Run Build " \
          --msgbox "SUCCESS. ${sch}.\n\"${run_build_func_name}\" job has been launched." \
          6 ${DLG_COMMON_WIDTH}
        [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
      else
        message_box "${CAPC_PROC_RUN_BUILD_STEP}" \
                    "Self Serve SCM > Builds > ${sch} > Run Build" \
                    " Run Build " \
                    "FAULT. ${sch}.\n\"${run_build_func_name}\" job was not launched."
        return $? # !!!!!!!!!!!!!!!!!!!
      fi
      return ${SSV_OK}
      ;;

    ${DLG_CANCEL} | ${DLG_ESC}) return ${SSV_OK} ;; # !!!!!!!!!!!!!!!!!
    *) p_err ${LINENO}; return ${SSV_EXIT} ;;
  esac

  return ${SSV_OK}
}

run_build()
{
  if [[ "${bld_type}" = "${BLD_TYPE_AP}" ]]; then
    if [[ "${clean_build}" = "1" ]]; then
      run_build_func_name="Run Clean Build";
    else
      run_build_func_name="Run Incremental Build";
    fi
  else
    run_build_func_name="Run Build";
  fi

  if [[ "${bld_type}" = "${BLD_TYPE_CAPC}" && "${clean_build}" = "1" ]]; then
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > Run Clean Build" \
      --title " Run Clean Build " \
      --msgbox "There is no \"Run Clean Build\" procedure for CAPC build." \
      6 ${DLG_COMMON_WIDTH}
    [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
    return ${SSV_OK}
  fi

  is_job_running
  if [[ "$?" != "${SSV_OK}" ]]; then
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > Run Build" \
      --title " Run Build " \
      --msgbox "FAULT. ${sch}.\n\"${run_build_func_name}\" job could not be launched. Build is in progress." \
      7 ${DLG_COMMON_WIDTH}
    [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
    return ${SSV_OK}
  fi

  case ${bld_type} in
    ${BLD_TYPE_AP}) run_build_ap; return $? ;;
    ${BLD_TYPE_CAPC}) run_build_capc; return $? ;;
    *) p_err ${LINENO}; return ${SSV_EXIT} ;;
  esac
  return ${SSV_OK}
}

stop_build()
{
  is_job_running
  if [[ "$?" = "${SSV_OK}" ]]; then
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > Stop Build" \
      --title " Stop Build " \
      --msgbox "FAULT. Build \"${sch}\" it is already stopped." \
      6 ${DLG_COMMON_WIDTH}
    [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
    return ${SSV_OK}
  fi

  ${DIALOG} \
    --backtitle "Self Serve SCM > Builds > ${sch} > Stop Build" \
    --title " Stop Build " \
    --defaultno \
    --yesno "Are you sure you want to stop \"${sch}\" build?" \
    6 ${DLG_COMMON_WIDTH}
  case $? in
    ${DLG_OK})
      ${DIALOG} \
        --backtitle "Self Serve SCM > Builds > ${sch} > Stop Build" \
        --infobox "Aborting building job.\nPlease wait ..." \
        4 ${DLG_COMMON_WIDTH}
      [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

      ${SSV_DISP} --proc="stop" --sch="${sch}" --wait
      if [[ "$?" = "${SSV_OK}" ]]; then
        ${DIALOG} \
          --backtitle "Self Serv SCM > Builds > ${sch} > Stop Build" \
          --title " Stop Build " \
          --msgbox "SUCCESS. \"${sch}\" building job has been aborted." \
          6 ${DLG_COMMON_WIDTH}
        [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
      else
        ${DLG_MSG_BOX} -b "Self Serve SCM > Builds > ${sch} > Stop Build" \
                       -t " Stop Build " \
                       -l 7 -r \
                       -m "Fault. \"${sch}\" Build was not stopped." \
                       -f ${SSV_LOG_FILE}
        [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; } # !!!!!!!!
      fi
      return ${SSV_OK}
      ;;

    ${DLG_CANCEL} | ${DLG_ESC}) return ${SSV_OK} ;; # !!!!!!!!!!!!!!!
    *) p_err ${LINENO}; return ${SSV_EXIT} ;;
  esac
  return ${SSV_OK}
}

build_info()
{
  echo "Schedule:    ${sch}" > ${TMP_INFO}
  echo "Product:     ${bld_type}" >> ${TMP_INFO}
  echo "Build View:  ${view}" >> ${TMP_INFO}
  echo -n "Devint View: " >> ${TMP_INFO}
  /usr/atria/bin/cleartool setview -exe \
    "cleartool catcs | grep 'end mkbranch' | tail -1 | cut -d ' ' -f 3" \
    ${view} >> ${TMP_INFO}
  echo -n "Next Label:  " >> ${TMP_INFO}
  /usr/atria/bin/cleartool setview -exe \
    "/vob/wuce/wuce/bin/cmbp_label dapsc" ${view} >> ${TMP_INFO}
  echo "Job Status:  ${job_status}" >> ${TMP_INFO}
#  echo "Job ID:      ${job_id}" >> ${TMP_INFO}
#  echo "Job Outcome:" >> ${TMP_INFO}
#  echo "Job Error:" >> ${TMP_INFO}
#  echo "Launched By:" >> ${TMP_INFO}

  ${DIALOG} \
    --backtitle "Self Serve SCM > Builds > ${sch} > Build Information" \
    --title " Build Information " \
    --exit-label "Back" \
    --textbox ${TMP_INFO} 17 70
  [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  return ${SSV_OK}
}

clean_view_progress()
{
  while [[ "1" = "1" ]]; do # !!!! use true
    is_job_running
    [[ "$?" = "${SSV_OK}" ]] && return ${SSV_OK}

    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > Clean Build View" \
      --title " Clean Build View " \
      --keep-window \
      --ok-label "Abort" \
      --timeout 5 \
      --msgbox "Build View cleaning.\nPlease wait ..." \
      6 ${DLG_COMMON_WIDTH} 2>/dev/null # !!!!!!!!
    case $? in
      ${DLG_OK} | ${DLG_ESC} | ${DLG_CANCEL}) return ${SSV_CANCEL} ;;
#       ${DLG_EXIT})  # !!!
      *) ;; # !!!!!!!
    esac
  done
  return ${SSV_OK}
}

clean_view()
{
  if [[ "${bld_type}" = "${BLD_TYPE_CAPC}" ]]; then
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > Clean Build View" \
      --title " Clean Build View " \
      --msgbox "There is no \"Clean View\" procedure for CAPC build." \
      6 ${DLG_COMMON_WIDTH}
    [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
    return ${SSV_OK}
  fi

  is_job_running
  if [[ "$?" != "${SSV_OK}" ]]; then
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > Clean Build View" \
      --title " Clean Build View " \
      --msgbox "View could not be cleaned. Build is in progress." \
      6 ${DLG_COMMON_WIDTH}
    [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
    return ${SSV_OK}
  fi

  ${DIALOG} \
    --backtitle "Self Serve SCM > Builds > ${sch} >  Clean Build View" \
    --infobox "Retrieve view information.\nPlease wait ..." \
    4 ${DLG_COMMON_WIDTH}
  [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

  ${SSV_DISP} --proc="isvcln" --view=${view}
  if [[ "$?" = "${SSV_OK}" ]]; then
    ${DIALOG} \
      --backtitle "Self Serve SCM > Clean Build View" \
      --title " Clean Build View " \
      --msgbox "Build View is already clean." \
      6 ${DLG_COMMON_WIDTH}
    [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
    return ${SSV_OK}
  fi

  ${DIALOG} \
    --backtitle "Self Serve SCM > Builds > ${sch} > Clean Build View" \
    --title " Clean Build View " \
    --defaultno \
    --yesno "Are you sure you want to clean build view?" \
    6 ${DLG_COMMON_WIDTH}
  case $? in
    ${DLG_OK})
      ${DIALOG} \
        --backtitle "Self Serve SCM > Builds > ${sch} > Clean Build View" \
        --infobox "\"Clean View\" job launching.\nPlease wait ..." \
        4 ${DLG_COMMON_WIDTH}
      [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

      ${SSV_DISP} --proc="call" --func="${AP_PROC_CLEAN_VIEW}" --wait \
                  --cmd="view_name:${view},schedule_name:${sch}" > ${TMP_STR}
      if [[ "$?" != "${SSV_OK}" ]]; then
        message_box "${AP_PROC_CLEAN_VIEW_STEP}" \
                "Self Serve SCM > Builds > ${sch} > Clean Build View" \
                " Clean Build View " \
                "FAULT. ${sch}.\nBuild View was not cleaned."
        return $? # !!!!!!!!!!!!!!!!!
      fi

      clean_view_progress
      case $? in
        ${SSV_OK})
          job_id=`cat ${TMP_STR}`
          ${SSV_DISP} --proc="getslog" --job_id="${job_id}" \
                      --step="${AP_PROC_CLEAN_VIEW_STEP}" > ${TMP_STR}
          [[ "$?" != "${SSV_OK}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

          step_log=`cat ${TMP_STR}`
          err_n=`wc -l ${step_log} | cut -d ' ' -f 1`
          if [[ "${err_n}" = "" ]]; then
            ${DIALOG} \
              --backtitle "Self Serve SCM > Builds > ${sch} > Clean Build View" \
              --title " Clean Build View " \
              --msgbox "SUCCESS. ${sch}.\nBuild View has been cleaned." \
              6 ${DLG_COMMON_WIDTH}
            [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
          else
            message_box "${AP_PROC_CLEAN_VIEW_STEP}" \
                        "Self Serve SCM > Builds > ${sch} > Clean Build View" \
                        " Clean Build View " \
                        "FAULT. ${sch}.\nBuild View was not cleaned."
            return $? # !!!!!!
          fi
          ;;
        ${SSV_CANCEL})
          ${DIALOG} \
            --backtitle "Self Serve SCM > Builds > ${sch} > Clean Build View" \
            --infobox "Interrupting \"Clean View\" job.\nPlease wait ..." \
            4 ${DLG_COMMON_WIDTH}
          [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

          ${SSV_DISP} --proc="stop" --sch="${sch}" --wait
          if [[ "$?" = "${SSV_OK}" ]]; then
            ${DIALOG} \
              --backtitle "Self Serve SCM > Builds > ${sch} > Clean Build View" \
              --title " Clean Build View " \
              --msgbox "\"Clean View\" job was interrupted." \
              6 ${DLG_COMMON_WIDTH}
            [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
          else
            ${DIALOG} \
              --backtitle "Self Serve SCM > Builds > ${sch} > Clean Build View" \
              --title " Clean Build View " \
              --msgbox "FAULT. \"Clean View\" job was not interrupted." \
              6 ${DLG_COMMON_WIDTH}
            [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
          fi
          ;;
# !!!!!!!!!!!!!!!!
        *) p_err ${LINENO}; return ${SSV_EXIT} ;;
      esac
      return ${SSV_OK}
      ;;

    ${DLG_CANCEL} | ${DLG_ESC}) return ${SSV_OK} ;;
    *) p_err ${LINENO}; return ${SSV_EXIT} ;;
  esac

  return ${SSV_OK}
}

dlg_view_utils_dispatch()
{
  case ${dlg_ret} in
    ${DLG_CANCEL}) ssv_quit; return $? ;;
    ${DLG_HELP}) ssv_help ${SSV_DIR}/doc/README_view_utils; return $? ;;
    ${DLG_OK})
      def_item="${dlg_res}"
      case "${dlg_res}" in
        "${ID_DLG_VIEW_UTIL_INFO}") build_info; return $? ;;
        "${ID_DLG_VIEW_UTIL_RUN}")
          clean_build=0
          run_build
          return $?
          ;;
        "${ID_DLG_VIEW_UTIL_RUN_CLEAN}")
          clean_build=1
          run_build
          return $?
          ;;
        "${ID_DLG_VIEW_UTIL_STOP}") stop_build; return $? ;;
        "${ID_DLG_VIEW_UTIL_CLEAN}") clean_view; return $? ;;
        "${ID_DLG_VIEW_UTIL_SPEC}")
          ${DLG_SPEC_UTILS} -s "${sch}" -v "${view}" -t "${bld_type}"
          return $?
          ;;
        "${ID_DLG_VIEW_UTIL_SCH}")
          ${DLG_SCH} -s "${sch}" -t "${bld_type}"
          return $?
          ;;
        *) p_err ${LINENO}; return ${SSV_EXIT} ;;
      esac
      ;;

    ${DLG_ESC} | ${DLG_EXIT}) dlg_exit=${SSV_TRUE}; return ${SSV_OK} ;;
    *) p_err ${LINENO}; return ${SSV_EXIT} ;;
  esac

  return ${SSV_OK}
}

dlg_view_utils_show()
{
  is_job_running
# !!!!!!!!!!!!!!!!!!
  if [[ "$?" = "${SSV_OK}" ]]; then
    job_status="STOPPED" # !!!!!!
  else
    job_status="RUNNING" # !!!!!!
  fi

  ${DIALOG} \
    --backtitle "Self Serve SCM > Builds > ${sch}" \
    --title " ${sch} " \
    --help-button \
    --extra-button \
    --extra-label "Back" \
    --cancel-label "Exit" \
    --default-item "${def_item}" \
    --menu "${sch} - ${job_status}" 14 ${DLG_COMMON_WIDTH} 7 \
      "${ID_DLG_VIEW_UTIL_INFO}" "" \
      "${ID_DLG_VIEW_UTIL_RUN}" "" \
      "${ID_DLG_VIEW_UTIL_RUN_CLEAN}" "" \
      "${ID_DLG_VIEW_UTIL_STOP}" "" \
      "${ID_DLG_VIEW_UTIL_CLEAN}" "" \
      "${ID_DLG_VIEW_UTIL_SPEC}" "" \
      "${ID_DLG_VIEW_UTIL_SCH}" "" 2>${TMP_RES}
  dlg_ret=$?
  [[ "${dlg_ret}" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  dlg_res="`cat ${TMP_RES}`"
  return ${SSV_OK}
}

dlg_view_utils_run()
{
  ${SSV_DISP} --proc="getbtype" --sch="${sch}" > ${TMP_STR}
  [[ "$?" != "${SSV_OK}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; } # !!!
  bld_type=`cat ${TMP_STR}`

  while [[ "${dlg_exit}" = "${SSV_FALSE}" ]]; do
    dlg_view_utils_show
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break

    dlg_view_utils_dispatch
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break
  done

  rm -f ${TMP_INFO}
  rm -f ${TMP_SCH}
  rm -f ${TMP_JOB_ID}
  rm -f ${TMP_STR}
  return ${ret}
}

dlg_view_utils_run
