#!/bin/bash -E
## .SH ssv_trace.sh
## .SS Author
## hqjr73@motorola.com on 01 March 2010

trace_func=0
trace_error=0
trace_info=0
trace_warn=0

while getopts feiwh opt; do
  case ${opt} in
    f) trace_func=1 ;;
    e) trace_error=1 ;;
    i) trace_info=1 ;;
    w) trace_warn=1 ;;
    h|\?)
      print "__usage__"
      exit 0
      ;;
    *)
      print "__error"
      ;;
  esac
done

shift `expr ${OPTIND} - 1`

trace_str=$1 # !!! \n
if [[ "${trace_str}" = "" ]]; then
  echo "__empty_log_record"
  exit 0 # !!!
fi

if [[ "${trace_error}" = "1" ]]; then
  echo "`date '+%D %T'` (error): ${trace_str}" >> ${SSV_LOG_FILE}
  exit 0
fi

if [[ "${trace_func}" = "1" ]]; then
  if [[ "${SSV_TRACE_FUNC_F}" = "1" ]]; then
    echo "`date '+%D %T'` ${trace_str}" >> ${SSV_LOG_FILE}
  fi
  exit 0
fi

if [[ "${trace_info}" = "1" ]]; then
  if [[ "${SSV_INFO_F}" = "1" ]]; then
    echo "`date '+%D %T'` (info): ${trace_str}" >> ${SSV_LOG_FILE}
  fi
  exit 0
fi

if [[ "${trace_warn}" = "1" ]]; then
  if [[ "${SSV_WARN_F}" = "1" ]]; then
    echo "`date '+%D %T'` (warning): ${trace_str}" >> ${SSV_LOG_FILE}
  fi
  exit 0
fi

if [[ "${SSV_TRACE_F}" = "1" ]]; then
  echo "`date '+%D %T'` ${trace_str}" >> ${SSV_LOG_FILE}
fi
