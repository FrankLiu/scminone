#!/bin/bash -E
## .SH dlg_spec_restore.sh
## .SS Author
## hqjr73@motorola.com on 06 March 2010

BN=`basename $0`
#DN=`dirname $0`

TMP_CS=`${SSV_TMPFN} ${BN} cs ${SSV_DIR_TMP}` # !!!!!!!!
TMP_CS_HIST=`${SSV_TMPFN} ${BN} ch`
TMP_SCRIPT=`${SSV_TMPFN} ${BN} spt`
TMP_STR=`${SSV_TMPFN} ${BN} str` # !!!

dlg_ret=${DLG_CANCEL}
dlg_res=0
dlg_exit=0
def_item=0
sch=""  # !!!
view=""  # !!!
bld_type=${BLD_TYPE_AP}

trap ssv_trap_err ERR

while getopts v:s:t: opt; do
  case ${opt} in
    v) view="${OPTARG}" ;;
    s) sch="${OPTARG}" ;;
    t) bld_type="${OPTARG}" ;;
    ?|h) # !!!
#     echo "usage: ${BN} -f <build-log> -p {aps|capc|cpe}"
#     echo "  Parse wuce build log (-f) by product family (-p)."
      echo "__usage__1"
      exit 1 # !!!
      ;;
  esac
done

# !!! check parameters
#if [[ "${sch}" = "" ]]; then
#  echo "__usage__2"
#  exit 1 # !!!
#fi

# !!!
#if [[ "${view}" = "" ]]; then
#  echo "__usage__3"
#  exit 1 # !!!
#fi

show_cs()
{
  cs_date=`cat ${TMP_CS_HIST} | tr -s '\n' ' ' | cut -d ' ' -f ${dlg_res}`
  [[ "$?" != "0" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; } # !!!!!!!

  ${SSV_DISP} --proc="getprop" \
              --prop="${SSV_PROOT}/views/${view}/${cs_date}/cs" > ${TMP_CS}
  if [[ "$?" != "${SSV_OK}" ]]; then
# !!! warning string need to change
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > Config Spec > Restore" \
      --title " Restore Config Spec " \
      --msgbox "Can't find previous config spec saves." \
      6 ${DLG_COMMON_WIDTH}
    [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
    return ${SSV_OK}
  fi

  ssv_show_file ${TMP_CS} \
    "Self Serve SCM > Builds > ${sch} > Config Spec > Restore" " Restore " "Back"
  return $?
}

restore_cs()
{
  ${DIALOG} \
    --backtitle "Self Serve SCM > Builds > ${sch} > Config Spec > Restore" \
    --infobox "Config spec restoring.\nPlease wait ..."\
    4 ${DLG_COMMON_WIDTH}
  [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

  cs_date=`cat ${TMP_CS_HIST} | tr -s '\n' ' ' | cut -d ' ' -f ${dlg_res}`
  [[ "$?" != "0" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; } # !!!!!!!

  ${SSV_DISP} --proc="getprop" \
              --prop="${SSV_PROOT}/views/${view}/${cs_date}/cs" > ${TMP_CS}
  [[ "$?" != "${SSV_OK}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

  case "${bld_type}" in
    "${BLD_TYPE_AP}")
      func=${AP_PROC_SET_CS}
      step=${AP_PROC_SET_CS_STEP}
      ;;
    "${BLD_TYPE_CAPC}")
      func=${CAPC_PROC_SET_CS}
      step=${CAPC_PROC_SET_CS_STEP}
      ;;
    *) p_err ${LINENO}; return ${SSV_EXIT} ;;
  esac

  ${SSV_DISP} \
    --proc="call" --func="${func}" --wait \
    --cmd="view_name:${view},schedule_name:${sch},cs:${TMP_CS}"
  if [[ "$?" = "${SSV_OK}" ]]; then
# !!!! need to change message box
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > Config Spec > Restore" \
      --title " Restore Config Spec " \
      --msgbox "SUCCESS. ${sch}.\nBuild View config spec has been restored." \
      6 ${DLG_COMMON_WIDTH}
    [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  else
    message_box "${step}" \
                "Self Serve SCM > Builds > ${sch} > Config Spec > Restore" \
                " Run Build " \
                "FAULT. ${sch}.\nConfig Spec was not restored."
    return $? # !!!!!!!!!!!!!!!!!!!!!!!!!
  fi

  ${SSV_DISP} --proc="rmprop" \
              --prop="${SSV_PROOT}/views/${view}/${cs_date}"
  [[ "$?" != "${SSV_OK}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  return ${SSV_OK}
}

dlg_spec_restore_dispatch()
{
  def_item="${dlg_res}"
  case ${dlg_ret} in
    ${DLG_EXIT}) restore_cs; return $? ;;
    ${DLG_OK}) show_cs; return $? ;;
    ${DLG_HELP}) ssv_quit; return $? ;;
    ${DLG_CANCEL} | ${DLG_ESC}) dlg_exit=${SSV_TRUE}; return ${SSV_OK} ;;
    *) p_err ${LINENO}; return ${SSV_EXIT} ;;
  esac
  return ${SSV_OK}
}

dlg_spec_restore_show()
{
  ${SSV_DISP} --proc="gcsl" --view="${view}" > ${TMP_CS_HIST}
  ret=$?
  lines_n=`cat ${TMP_CS_HIST} | wc -l`
  [[ "$?" != "0" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  code=`cat ${TMP_CS_HIST}`
  [[ "$?" != "0" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  if [[ ("${ret}" != "${SSV_OK}" && "${code}" = "NoSuchProperty") || \
        ("${ret}"  = "${SSV_OK}" && "${lines_n}" = "0") ]]; then
# !!! change warning string
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > Config Spec > Restore" \
      --title " Restore Config Spec " \
      --msgbox "There are no cspec savings for \"${view}\" view." \
      6 ${DLG_COMMON_WIDTH}
    case $? in
      ${DLG_OK} | ${DLG_CANCEL} | ${DLG_ESC}) dlg_exit=${SSV_TRUE}; return ${SSV_OK} ;;
      # ${DLG_EXIT}) # !!!
      *) p_err ${LINENO}; return ${SSV_EXIT} ;;
    esac
  fi

  items=`awk \
    'BEGIN \
     { i=0 } \
     { \
       printf ++i " \"%s\" ", $1 \
     }' ${TMP_CS_HIST}`

  cat > ${TMP_SCRIPT} <<EOF
${DIALOG} \
  --backtitle "Self Serve SCM > Builds > ${sch} > Config Spec > Restore" \
  --title " Restore Config Spec " \
  --help-button \
  --extra-button \
  --extra-label "Restore" \
  --ok-label "Show" \
  --cancel-label "Back" \
  --help-label "Exit" \
  --default-item "${def_item}" \
  --menu "" 14 ${DLG_COMMON_WIDTH} 8 \
    ${items} 2>${TMP_STR} # !!!!!!!
EOF

  chmod 755 ${TMP_SCRIPT}
  ${TMP_SCRIPT}
  dlg_ret=$?
  [[ "${dlg_ret}" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  dlg_res=`cat ${TMP_STR}`

  return ${SSV_OK}
}

dlg_spec_restore_run()
{
  while [[ "${dlg_exit}" = "${SSV_FALSE}" ]]; do
    dlg_spec_restore_show
    ret=$?
    [[ "${ret}" != "${SSV_OK}" || "${dlg_exit}" = "${SSV_TRUE}" ]] && break

    dlg_spec_restore_dispatch
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break
  done

  rm -f ${TMP_CS}
  rm -f ${TMP_CS_HIST}
  rm -f ${TMP_SCRIPT}
  rm -f ${TMP_STR} # !!!
  return ${ret}
}

dlg_spec_restore_run
