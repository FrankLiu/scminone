#!/bin/bash
## .SH dlg_msg_box.sh
## .SS Author
## hqjr73@motorola.com on 13 April 2010
#set -x

BN=`basename $0`
#DN=`dirname $0`

TMP_LOG=`${SSV_TMPFN} ${BN} log` # !!!!!!!!!!!!!!!!

log_file=${SSV_LOG_FILE} # !!!!!!!!!!!!!!!!!!!!!!
dlg_ret=${DLG_CANCEL}
dlg_res=0
dlg_exit=0
message="" # !!!
dlg_h=0
backtitle=''
title=''
reorder=0

while getopts m:f:l:b:t:r opt; do
  case ${opt} in
    m) message="${OPTARG}" ;;
    f) log_file="${OPTARG}" ;; # !!!!!!!!!!!!!!!!!!!
    l) dlg_h="${OPTARG}" ;;
    b) backtitle="${OPTARG}" ;;
    t) title="${OPTARG}" ;;
    r) reorder=1 ;; # !!!!!!!!!!!!!!!!
    *) echo "___assert"; ;; # !!!!
  esac
done

# !!! check parameters
#if [[ "${sch}" = "" ]]; then
#  echo "__usage__2"
#  exit 1 # !!!
#fi

# !!!
#if [[ "${view}" = "" ]]; then
#  echo "__usage__3"
#  exit 1 # !!!
#fi

dlg_msg_box_p_err() # !!!!!!!!!
{
  ${SSV_ERROR} ${0##/*/}:$1 $2
  echo "ERROR. MessageBox internal. Look at ${SSV_LOG_FILE} for more information."
}

dlg_msg_box_dispatch()
{
  case ${dlg_ret} in
    ${DLG_EXIT} | ${DLG_HELP}) # !!!!!!!
      ${SSV_WARN} "Unexpected return: dlg_msg_box_dispatch, DLG_EXIT or DLG_HELP"
      dlg_exit=${SSV_TRUE}
      return ${SSV_OK}
      ;;

    ${DLG_OK})
      ${DIALOG} --print-maxsize --stderr 2>${TMP_RES}
      x=`cat ${TMP_RES} | cut -d ':' -f 2 | cut -d ',' -f 1 | sed 's/ //'`
      y=`cat ${TMP_RES} | cut -d ':' -f 2 | cut -d ',' -f 2 | sed 's/ //'`
      let x=x-5
      let y=y-5

      if [[ -e ${log_file} ]]; then
        if [[ "${reorder}" = "1" ]]; then
          perl -e 'print reverse <>' ${log_file} > ${TMP_LOG}
        else
          cat ${log_file} > ${TMP_LOG} # !!!!!!!!!!!!!! not effective
        fi
      else
        perl -e 'print reverse <>' ${SSV_LOG_FILE} > ${TMP_LOG}
      fi
      ${DIALOG} \
        --backtitle "${backtitle}" \
        --title "${title}" \
        --exit-label "Cancel" \
        --begin 3 2 \
        --tailbox "${TMP_LOG}" ${x} ${y} # !!!
      [[ "$?" = "${DLG_ERROR}" ]] && { dlg_msg_box_p_err ${LINENO}; return ${SSV_FAULT}; } # !!!
      dlg_exit=${SSV_TRUE}
      return ${SSV_OK}
      ;;

    ${DLG_CANCEL} | ${DLG_ESC}) dlg_exit=${SSV_TRUE}; return ${SSV_OK} ;;
    ${DLG_ERROR}) dlg_msg_box_p_err ${LINENO}; return ${SSV_FAULT} ;; # !!!
    *) dlg_msg_box_p_err ${LINENO}; return ${SSV_FAULT} ;; # !!!
  esac
  return ${SSV_OK}
}

dlg_msg_box_show()
{
  ${DIALOG} \
    --backtitle "${backtitle}" \
    --title "${title}" \
    --defaultno \
    --yesno "${message}\nDo you want to see error details?" \
    ${dlg_h} ${DLG_COMMON_WIDTH} 2>${TMP_RES} # !!!
  dlg_ret=$?
  [[ "${dlg_ret}" = "${DLG_ERROR}" ]] && { dlg_msg_box_p_err ${LINENO}; return ${SSV_FAULT}; }
  dlg_res=`cat ${TMP_RES}` # !!!
  return ${SSV_OK}
}

dlg_msg_box_run()
{
  while [[ "${dlg_exit}" = "${SSV_FALSE}" ]]; do
    dlg_msg_box_show
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break

    dlg_msg_box_dispatch
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break
  done

  rm -f ${TMP_LOG}
  return ${ret}
}

dlg_msg_box_run
