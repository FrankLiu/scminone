#!/bin/bash -E
## .SH dlg_spec_utils.sh
## .SS Author
## hqjr73@motorola.com on 05 March 2010

BN=`basename $0`
#DN=`dirname $0`
#BN2=`basename SSV_TOOL_PATH` # !!!!!!!!!!!!!!!!!!!!!

#DLG_ANS=`${SSV_TMPFN} ${BN} ans`
TMP_CS=`${SSV_TMPFN} ${BN} cs ${SSV_DIR_TMP}` # !!!!!
TMP_CS_BEFORE=`${SSV_TMPFN} ${BN} csb ${SSV_DIR_TMP}` # !!!!!!!!!!
TMP_STR=`${SSV_TMPFN} ${BN} str`

dlg_ret=${DLG_CANCEL}
dlg_res=0
dlg_exit=0
def_item=0
sch=""  # !!!
view=""  # !!!
bld_type=${BLD_TYPE_AP}

trap ssv_trap_err ERR

while getopts v:s:t:h opt; do
  case ${opt} in
    v) view="${OPTARG}" ;;
    s) sch="${OPTARG}" ;;
    t) bld_type="${OPTARG}" ;;
    ?|h) # !!!!!
#     echo "usage: ${BN} -f <build-log> -p {aps|capc|cpe}"
#     echo "  Parse wuce build log (-f) by product family (-p)."
      echo "__usage__1"
      exit 1 # !!!
      ;;
  esac
done

# !!! check parameters
#if [[ "${sch}" = "" ]]; then
#  echo "__usage__2"
#  exit 1 # !!!
#fi

# !!!
#if [[ "${view}" = "" ]]; then
#  echo "__usage__3"
#  exit 1 # !!!
#fi

is_job_running()
{
  ${SSV_DISP} --proc="isrun" --sch="$sch" --job_id=0 --ssv
  return $?
}

# !!!!! need to be moved to common module
message_box()
{
  step_name=$1
  msgbox_backtitle=$2
  msgbox_title=$3
  msgbox_msg=$4

# !!!! RACE CONDITION !!!!!!!!!
  ${SSV_DISP} --proc="getprop" \
              --prop="${SSV_PROOT}/schedules/${sch}/job_id" > ${TMP_STR}
  [[ "$?" != "${SSV_OK}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  job_id=`cat ${TMP_STR}`

  ${SSV_DISP} --proc="getslog" --job_id="${job_id}" \
              --step="${step_name}" > ${TMP_STR}
  [[ "$?" != "${SSV_OK}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

  step_log=`cat ${TMP_STR}`
  ${DLG_MSG_BOX} -b "${msgbox_backtitle}" \
                 -t "${msgbox_title}" \
                 -l 8 \
                 -m "${msgbox_msg}" \
                 -f ${step_log}
  [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  return ${SSV_OK}
}

cspec_show()
{
  cleartool catcs -tag $view > ${TMP_CS}
  [[ "$?" != "0" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; } # !!!!!!

  ssv_show_file ${TMP_CS} \
    "Self Serve SCM > Builds > ${sch} > Config Spec > Show" " Config Spec " "Back"
  return $?
}

cspec_change()
{
  is_job_running
  if [[ "$?" != "${SSV_OK}" ]]; then
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > Config Spec > Change" \
      --title " Change Config Spec " \
      --msgbox "FAULT. ${sch}.\nConfig Spec could not be changed. Build is in progress." \
      6 ${DLG_COMMON_WIDTH}
    [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
    return ${SSV_OK}
  fi

  ${DIALOG} \
    --backtitle "Self Serve SCM > Builds > ${sch} > Config Spec > Change" \
    --title " Change Config Spec " \
    --msgbox "WARNING! Please don't forget to raise an SR for synchronization of Build View config spec and Devint View config spec." \
    7 ${DLG_COMMON_WIDTH}
  [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

  cleartool catcs -tag "$view" > ${TMP_CS}
  [[ "$?" != "0" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; } # !!!!!!!
  cleartool catcs -tag "$view" > ${TMP_CS_BEFORE}
  [[ "$?" != "0" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; } # !!!!!!!
  ${SSV_EDITOR} ${TMP_CS} 2>&1 # !!!
  [[ "$?" != "0" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; } # !!!!!!!

  diff ${TMP_CS} ${TMP_CS_BEFORE} > /dev/null
  if [[ "$?" = "0" ]]; then
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > Config Spec > Change" \
      --title " Change Config Spec " \
      --msgbox "There is no changes in \"${view}\" config spec." \
      6 ${DLG_COMMON_WIDTH}
    [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  else
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > Change Config Spec" \
      --infobox "Setup config spec.\nPlease wait ..." \
      4 ${DLG_COMMON_WIDTH}
    [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

    case ${bld_type} in
      ${BLD_TYPE_AP})
        func=${AP_PROC_SET_CS}
        step=${AP_PROC_SET_CS_STEP}
        ;;
      ${BLD_TYPE_CAPC})
        func=${CAPC_PROC_SET_CS}
        step=${CAPC_PROC_SET_CS_STEP}
        ;;
      *) p_err ${LINENO}; return ${SSV_EXIT} ;;
    esac

    ${SSV_DISP} \
      --proc="call" --func="${func}" --wait \
      --cmd="view_name:${view},schedule_name:${sch},cs:${TMP_CS}" > /dev/null # !!!!!!
    if [[ "$?" = "${SSV_OK}" ]]; then
# !!!!!!! need a transaction
      ${SSV_DISP} --proc="setcsp" --view="${view}" --user="${WHOAMI}" \
                  --cs="${TMP_CS_BEFORE}"
      [[ "$?" != "${SSV_OK}" ]] && { p_err ${LINENO}; } # !!!!!!!!!!!!!!!!!

# !!!!!!! need to join them together
      ${SSV_DISP} --proc="rmoldprop" --view="${view}"
      [[ "$?" != "${SSV_OK}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; } # !!!!!!

      ${DIALOG} \
        --backtitle "Self Serve SCM > Builds > ${sch} > Config Spec > Change" \
        --title " Change Config Spec " \
        --msgbox "SUCCESS. ${sch}.\nBuild View Config Spec has been changed." \
        6 ${DLG_COMMON_WIDTH}
      [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
    else
      message_box "${step}" \
                  "Self Serve SCM > Builds > ${sch} > Config Spec > Change" \
                  " Error " \
                  "FAULT. ${sch}.\nConfig Spec was not changed.\n"
      return $? # !!!!!!!!!!!!!!!!!!!!!!!!!
    fi
  fi

  rm -f ${TMP_CS}
  rm -f ${TMP_CS_BEFORE}
  return ${SSV_OK}
}

cspec_restore()
{
  is_job_running
  if [[ "$?" != "${SSV_OK}" ]]; then
    ${DIALOG} \
      --backtitle "Self Serve SCM > Builds > ${sch} > Config Spec > Change" \
      --title " Restore Config Spec " \
      --msgbox "FAULT. ${sch}.\nConfig Spec could not be restored. Build is in progress." \
      6 ${DLG_COMMON_WIDTH}
    [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
    return ${SSV_OK}
  fi

  ${DLG_SPEC_RESTORE} -s "${sch}" -v "${view}" -t "${bld_type}"
  return $?
}

dlg_spec_utils_dispatch()
{
  case ${dlg_ret} in
    ${DLG_ESC} | ${DLG_EXIT}) dlg_exit=${SSV_TRUE}; return ${SSV_OK} ;;
    ${DLG_CANCEL}) ssv_quit; return $? ;;
    ${DLG_HELP}) ssv_help ${SSV_DIR}/doc/README_spec_utils; return $? ;;
    ${DLG_OK})
      def_item="${dlg_res}"
      case "${dlg_res}" in
        "${ID_DLG_SPEC_UTILS_SHOW}") cspec_show; return $? ;;
        "${ID_DLG_SPEC_UTILS_EDIT}") cspec_change; return $? ;;
        "${ID_DLG_SPEC_UTILS_RESTORE}") cspec_restore; return $? ;;
        *) p_err ${LINENO}; return ${SSV_EXIT} ;;
      esac
      ;;
    *) p_err ${LINENO}; return ${SSV_EXIT} ;;
  esac
  return ${SSV_OK}
}

dlg_spec_utils_show()
{
  ${DIALOG} \
    --backtitle "Self Serve SCM > Builds > ${sch} > Config Spec" \
    --title " Config Spec " \
    --help-button \
    --extra-button \
    --extra-label "Back" \
    --cancel-label "Exit" \
    --default-item "${def_item}" \
    --menu "" 9 ${DLG_COMMON_WIDTH} 3 \
      "${ID_DLG_SPEC_UTILS_SHOW}" "" \
      "${ID_DLG_SPEC_UTILS_EDIT}" "" \
      "${ID_DLG_SPEC_UTILS_RESTORE}" "" 2>${TMP_RES}
  dlg_ret=$?
  [[ "${dlg_ret}" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  dlg_res="`cat ${TMP_RES}`"
  return ${SSV_OK}
}

dlg_spec_utils_run()
{
  while [[ "${dlg_exit}" = "${SSV_FALSE}" ]]; do
    dlg_spec_utils_show
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break

    dlg_spec_utils_dispatch
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break
  done

  rm -f ${TMP_CS}
  rm -f ${TMP_CS_BEFORE}
  rm -f ${TMP_STR}
  return ${ret}
}

dlg_spec_utils_run
