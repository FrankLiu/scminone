#!/bin/bash
## .SH ssv.sh
## .SS Author
## hqjr73@motorola.com on 20 Luly 2010
#set -vx

BN=`basename $0`
#DN=`dirname $0` # !!!

TMP_NAMES=`${SSV_TMPFN} ${BN} nms` # !!!!
ret=${SSV_OK}

echo -n "Check permissions configuration ...    "
${SSV_DISP} --proc="chk_ssscm_prop_perm"
if [[ "$?" != "${SSV_OK}" ]]; then
  echo "[$(tput setaf 1)FAILED$(tput sgr0)]"
  echo "  $(tput setaf 1)Error$(tput sgr0): You have no enough permissions. "
  echo "Please contact SCM team to configure your permissions."
  echo "https://udp613156uds.am.mot.com/commander/accessControl.php?objectType=propertySheet&propertySheetId=568493&projectName=WiMAX-testing&accessControlDisplayType=project"
  ERR_M=no ERR_T=no p_err ${LINENO} "Not enough permissions. https://udp613156uds.am.mot.com/commander/accessControl.php?objectType=propertySheet&propertySheetId=568493&projectName=WiMAX-testing&accessControlDisplayType=project"
  ret=${SSV_FAULT}
else
  echo "[$(tput setaf 2)OK$(tput sgr0)]"
fi

echo -n "Check schedules assigned to you ...    "
${SSV_DISP} --proc="chk_ssscm_sch_list"
if [[ "$?" != "${SSV_OK}" ]]; then
  echo "[$(tput setaf 1)FAILED$(tput sgr0)]"
  echo "  $(tput setaf 3)Warning$(tput sgr0): There are no schedules assigned to you. "
  echo "Please contact SCM team to configure your permissions."
  ERR_M=no ERR_T=no p_err ${LINENO} "There are no schedules assigned to you."
  [[ ("${ret}" = "${SSV_OK}") && ("${ret}" != "${SSV_FAULT}") ]] && ret=${SSV_CANCEL}
else
  echo "[$(tput setaf 2)OK$(tput sgr0)]"
fi

echo -n "Check schedule names correctness ...   "
${SSV_DISP} --proc="chk_ec_sch_names" > ${TMP_NAMES}
if [[ "$?" != "${SSV_OK}" ]]; then
  echo "[$(tput setaf 3)FAILED$(tput sgr0)]"
  warn_str=`echo $(tput setaf 3)Warning$(tput sgr0)`
  cat ${TMP_NAMES} | sed -e 's/^/  '$warn_str': /' \
    -e 's%$% schedule name contains inappropriate symbols. Please contact SCM team to fix it.%'
  ERR_M=no ERR_T=no p_err ${LINENO} "Inappropriate shcedule names." # !!!
  [[ ("${ret}" = "${SSV_OK}") && ("${ret}" != "${SSV_FAULT}") ]] && ret=${SSV_CANCEL}
else
  echo "[$(tput setaf 2)OK$(tput sgr0)]"
fi
rm -f ${TMP_NAMES}

echo -n "Check procedures names correctness ... "
${SSV_DISP} --proc="chk_ec_proc_names" > ${TMP_NAMES}
if [[ "$?" != "${SSV_OK}" ]]; then
  echo "[$(tput setaf 3)FAILED$(tput sgr0)]"
  warn_str=`echo $(tput setaf 3)Warning$(tput sgr0)`
  cat ${TMP_NAMES} | sed -e 's/^/  '$warn_str': /' \
    -e 's/$/ procedure name contains inappropriate symbols. Please contact SCM team to fix it./'
  ERR_M=no ERR_T=no p_err ${LINENO} "Inappropriate procedure names." # !!!
  [[ ("${ret}" = "${SSV_OK}") && ("${ret}" != "${SSV_FAULT}") ]] && ret=${SSV_CANCEL}
else
  echo "[$(tput setaf 2)OK$(tput sgr0)]"
fi
rm -f ${TMP_NAMES}

echo -n "Check procedures configuration ...     "
${SSV_DISP} --proc="chk_ec_proc_conf" > ${TMP_NAMES}
if [[ "$?" != "${SSV_OK}" ]]; then
  echo "[$(tput setaf 1)FAILED$(tput sgr0)]"
  warn_str=`echo $(tput setaf 1)Error$(tput sgr0)`
  cat ${TMP_NAMES} | sed -e 's/^/  '$warn_str': /' -e 's%$% SSSCM procedure is undefined in the project. Please contact SCM team to fix it.\nhttps://udp613156uds.am.mot.com/commander/projectDetails.php?projectName=WiMAX-testing&objectId=project-22&filterName=projectsPageSearch&tabGroup=properties\nhttps://udp613156uds.am.mot.com/commander/projectDetails.php?projectName=WiMAX-testing&objectId=project-22&filterName=projectsPageSearch&tabGroup=properties%'
  ERR_M=no ERR_T=no p_err ${LINENO} "Inappropriate procedures configuration." # !!!!
  ret=${SSV_FAULT}
else
  echo "[$(tput setaf 2)OK$(tput sgr0)]"
fi
rm -f ${TMP_NAMES}

echo -n "Check schedules types ...              "
${SSV_DISP} --proc="chk_ec_sch_types" > ${TMP_NAMES}
if [[ "$?" != "${SSV_OK}" ]]; then
  echo "[$(tput setaf 3)FAILED$(tput sgr0)]"
  warn_str=`echo $(tput setaf 3)Warning$(tput sgr0)`
  cat ${TMP_NAMES} | sed -e 's/^/  '$warn_str': /' -e 's%$% schedule has undefined default SSSCM procedure. Please contact SCM team to fix it.\nDefault procedure must be selected depending on type of the build. See apporopriate procedures here: https://udp613156uds.am.mot.com/commander/projectDetails.php?projectName=WiMAX-testing&tabGroup=properties%'
  ERR_M=no ERR_T=no p_err ${LINENO} "Inappropriate schedule/procedure configuration." # !!!!
  [[ ("${ret}" = "${SSV_OK}") && ("${ret}" != "${SSV_FAULT}") ]] && ret=${SSV_CANCEL}
else
  echo "[$(tput setaf 2)OK$(tput sgr0)]"
fi
rm -f ${TMP_NAMES}

exit ${ret}
