#!/bin/bash -E
## .SH dlg_builds.sh
## .SS Author
## hqjr73@motorola.com on 01 March 2010

BN=`basename $0`

TMP_SCHS=`${SSV_TMPFN} ${BN} schs`
TMP_SCRIPT=`${SSV_TMPFN} ${BN} spt`

dlg_ret=${DLG_CANCEL}
dlg_res=0 # !!!
dlg_exit=0 # !!!
def_item=0 # !!!

trap ssv_trap_err ERR

dlg_builds_dispatch()
{
  case ${dlg_ret} in
    ${DLG_CANCEL}) ssv_quit; return $? ;;
    ${DLG_HELP}) ssv_help ${SSV_DIR}/doc/README_builds; return $? ;;
    ${DLG_OK})
      cmd=`cat ${TMP_SCHS} | grep "^${dlg_res}" | tr -d '\n' | cut -d ${SSV_SPLITTER} -f1-3`
      [[ "$?" != "0" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; } # !!!!!!!
      sch=`echo "${cmd}" | cut -d '@' -f 1`
      [[ "$?" != "0" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; } # !!!!!!!
      view=`echo "${cmd}" | cut -d '@' -f 3`
      [[ "$?" != "0" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; } # !!!!!!!
      def_item="${dlg_res}"
      if [[ "${view}" = "" ]]; then
        ${DIALOG} \
          --backtitle "Self Serve SCM > Builds" \
          --title " ERROR " \
          --msgbox "ERROR. ${sch}.\nView is not specified." \
          6 ${DLG_COMMON_WIDTH}
        [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
        return ${SSV_OK};
      fi
      ${DLG_VIEW_UTILS} -v "${view}" -s "${sch}"
      return $?
      ;;

    ${DLG_EXIT} | ${DLG_ESC}) dlg_exit=${SSV_TRUE}; return ${SSV_OK} ;;
    ${DLG_ERROR}) p_err ${LINENO}; return ${SSV_EXIT} ;;
    *) p_err ${LINENO}; return ${SSV_EXIT} ;;
  esac
  return ${SSV_OK}
}

dlg_builds_show()
{
  if [[ ! -e ${TMP_SCHS} ]]; then
    ${DIALOG} \
      --backtitle "Self Serve SCM" \
      --infobox "Retrieve builds information.\nPlease wait ..." \
      4 ${DLG_COMMON_WIDTH}
    [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

    ${SSV_DISP} --proc="getschs" > ${TMP_SCHS}
    [[ "$?" != "${SSV_OK}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  fi

  items=`awk \
    'BEGIN \
     { FS="@"; i=0 } \
     { \
       printf " \"%s\" \"\" ", $1 \
     }' ${TMP_SCHS}`

  cat > ${TMP_SCRIPT} <<EOF
${DIALOG} \
  --backtitle "Self Serve SCM > Builds" \
  --title " Builds " \
  --help-button \
  --extra-button \
  --extra-label "Back" \
  --cancel-label "Exit" \
  --default-item "${def_item}" \
  --menu "Choose the Build for processing." 17 ${DLG_COMMON_WIDTH} 10 \
    ${items} 2>${TMP_RES}
EOF

  chmod 755 ${TMP_SCRIPT}
  ${TMP_SCRIPT}
  dlg_ret=$?
  [[ "${dlg_ret}" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  dlg_res=`cat ${TMP_RES}`
  return ${SSV_OK}
}

dlg_builds_run()
{
  while [[ "${dlg_exit}" = "${SSV_FALSE}" ]]; do
    dlg_builds_show
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break

    dlg_builds_dispatch
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break
  done

  rm -f ${TMP_SCHS}
  rm -f ${TMP_SCRIPT}
  return ${ret}
}

dlg_builds_run
