#!/bin/bash -E
## .SH dlg_main.sh
## .SS Author
## hqjr73@motorola.com on 01 March 2010

BN=`basename $0`
#DN=`dirname $0`

dlg_ret=${DLG_CANCEL}
dlg_res=0
dlg_exit=0
def_item=0

trap ssv_trap_err ERR

about()
{
  ${DIALOG} \
    --backtitle "Self Serve SCM > About" \
    --title " About " \
    --msgbox "Self Serve SCM v${SSV_VERSION}.\n\n
Report bugs to:\n   hqjr73@motorola.com" \
    8 ${DLG_COMMON_WIDTH}
  [[ "$?" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; }
  return ${SSV_OK}
}

dlg_main_dispatch()
{
  case ${dlg_ret} in
    ${DLG_EXIT} | ${DLG_ESC} | ${DLG_CANCEL}) ssv_quit; return $? ;;
    ${DLG_HELP}) ssv_help ${SSV_DIR}/doc/README_main; return $? ;;
    ${DLG_OK})
      def_item="${dlg_res}"
      case "${dlg_res}" in
        "${ID_DLG_MAIN_BUILDS}") ${DLG_BUILDS}; return $? ;;
        "${ID_DLG_MAIN_CONF}") ${DLG_CONF}; return $? ;;
        "${ID_DLG_MAIN_ABOUT}") about; return $? ;;
        *) p_err ${LINENO}; return ${SSV_EXIT} ;;
      esac
      ;;
    *) p_err ${LINENO}; return ${SSV_EXIT} ;;
  esac
  return ${SSV_OK}
}

dlg_main_show()
{
  ${DIALOG} \
    --backtitle "Self Serve SCM" \
    --title " Self Serve SCM " \
    --help-button \
    --cancel-label "Exit" \
    --default-item "${def_item}" \
    --menu \
"Welcome to Self Serve SCM tool. Please select one of the options below by using arrow keys. Invoke an option with [ENTER]. To exit, use [TAB] to move to Exit." 12 ${DLG_COMMON_WIDTH} 3 \
      "${ID_DLG_MAIN_BUILDS}" "" \
      "${ID_DLG_MAIN_CONF}" "" \
      "${ID_DLG_MAIN_ABOUT}" "" 2>${TMP_RES}
  dlg_ret=$?
  [[ "${dlg_ret}" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  dlg_res=`cat ${TMP_RES}`
  return ${SSV_OK}
}

dlg_main_run()
{
  while [[ "${dlg_exit}" = "${SSV_FALSE}" ]]; do
    dlg_main_show
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break

    dlg_main_dispatch
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break
  done
  return ${ret}
}

dlg_main_run
