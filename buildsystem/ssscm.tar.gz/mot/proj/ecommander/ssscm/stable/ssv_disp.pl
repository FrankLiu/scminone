#!/usr/bin/perl -w

#use Env;
use Getopt::Long;
use ssv_util;
use strict;

#$| = 1; # !!!

my $ec_server = $ENV{'EC_SERVER'};
my $ec_project = $ENV{'EC_PROJECT'};
my $ec_utils_project = $ENV{'EC_UTILS_PROJECT'};
my $ssv_proot = $ENV{'SSV_PROOT'};

my $proc = '';
my $func = '';
my $prtype = '';
my $user = '';
my $view = '';
my $sch = '';
my $prop = '';
my $value = '';
my $job_id = '';
my $ssv = 0;
my $cmd = '';
my $step = '';
my $cs = '';
my $wait = 0;
my $start_time_h = 0;
my $start_time_m = 0;
my $disabled = 0;
my $ret = ssv_util::ERR_OK;
my $tool_path= '';
my ($drb, $drbf, $drbc, $drbcf, $drbs, $dcv, $dcvs, $dsc, $dscs);

GetOptions(
  'e' => sub {}, # !!!
  'proc=s' => \$proc,
  'prtype=s' => \$prtype,
  'func=s' => \$func,
  'sch=s' => \$sch,
  'view=s' => \$view,
  'user=s' => \$user, # !!!
  'prop=s' => \$prop, # !!!
  'job_id=s' => \$job_id,
  'wait' => \$wait,
  'ssv' => ,\$ssv,
  'cmd=s' => \$cmd,
  'step=s' => \$step,
  'value=s' => \$value,
  'timeh=s' => \$start_time_h,
  'timem=s' => \$start_time_m,
  'dis=s' => \$disabled,
  'cs=s' => \$cs,
  'drb=s' => \$drb,
  'drbf=s' => \$drbf,
  'drbc=s' => \$drbc,
  'drbcf=s' => \$drbcf,
  'drbs=s' => \$drbs,
  'dcv=s' => \$dcv,
  'dcvs=s' => \$dcvs,
  'dsc=s' => \$dsc,
  'dscs=s' => \$dscs,
  'tpath=s' => \$tool_path,
#           'help' => sub { pod2usage(-verbose => 0) },
#           'man'  => sub { pod2usage(-verbose => 2) },
          );

my $ut = ssv_util->new($ec_server, $ec_utils_project, $ec_project, $ssv_proot)
  || die "__ssv_util_new_error__"; # !!!

if ($proc eq "setcs") {
  $ret = $ut->change_cs($view, $cs); # !!!
}
elsif ($proc eq "setcsp") {
  $ret = $ut->set_cs_prop($view, $user, $cs);
}
elsif ($proc eq "getprocs") {
  $ret = $ut->get_proc_names($prtype, $ec_project, $drb,
                             $drbf, $drbc, $drbcf, $dcv, $drbs,
                             $dcvs, $dsc, $dscs, $tool_path);
}
elsif ($proc eq "savejobid") {
  $ret = $ut->save_job_id($sch, $job_id); # !!!
}
elsif ($proc eq "isrun") {
  $ret = $ut->is_running($sch, $job_id, $ssv);
}
elsif ($proc eq "islbexst") {
  $ret = $ut->is_label_exists($view);
}
elsif ($proc eq "iscsch") {
  $ret = $ut->is_cs_changed($view);
}
elsif ($proc eq "issch") {
  $ret = $ut->is_sch_ctx($job_id);
}
elsif ($proc eq "isvcln") {
  $ret = $ut->is_view_clean($view);
}
elsif ($proc eq "isvunq") {
  $ret = $ut->is_view_unique($view);
}
elsif ($proc eq "isvexst") {
  $ret = $ut->is_view_exists($view);
}
elsif ($proc eq "clnv") {
  $ret = $ut->clean_view($view);
}
elsif ($proc eq "gcsl") {
  $ret = $ut->get_view_cs_list($view);
}
elsif ($proc eq "rmoldprop") {
  $ret = $ut->remove_view_old_cs_prop($view);
}
elsif ($proc eq "getprop") {
  $ret = $ut->get_prop($prop);
}
elsif ($proc eq "rmprop") {
  $ret = $ut->remove_prop($prop); # !!! need to test
}
elsif ($proc eq "setterm") {
  $ret = $ut->set_term($user, $value);
}
elsif ($proc eq "getbtype") {
  $ret = $ut->get_build_type($sch, 1);
}
elsif ($proc eq "getterm") {
  $ret = $ut->get_term($user);
}
elsif ($proc eq "setclr") {
  $ret = $ut->set_color($user, $value);
}
elsif ($proc eq "getclr") {
  $ret = $ut->get_color($user);
}
elsif ($proc eq "setlog") {
  $ret = $ut->set_log($user, $value);
}
elsif ($proc eq "getlog") {
  $ret = $ut->get_log($user);
}
elsif ($proc eq "getslog") {
  $ret = $ut->get_step_log($job_id, $step);
}
elsif ($proc eq "getschs") {
  $ret = $ut->get_sch_list();
}
elsif ($proc eq "getsch") {
  $ret = $ut->get_sch($sch);
}
elsif ($proc eq "setsch") {
  $ret = $ut->set_sch($sch, $func, $start_time_h, $start_time_m, $disabled);
}
elsif ($proc eq "stop") {
  $ret = $ut->stop_build($sch);
}
elsif ($proc eq "call") {
  $ret = $ut->call_ec_proc($func, $wait, $cmd);
}
elsif ($proc eq "chk_ssscm_prop_perm") {
  $ret = $ut->chk_ssscm_prop_perm();
}
elsif ($proc eq "chk_ssscm_sch_list") {
  $ret = $ut->chk_ssscm_sch_list();
}
elsif ($proc eq "chk_ec_sch_names") {
  $ret = $ut->chk_ec_sch_names();
}
elsif ($proc eq "chk_ec_proc_names") {
  $ret = $ut->chk_ec_proc_names();
}
elsif ($proc eq "chk_ec_proc_conf") {
  $ret = $ut->chk_ec_proc_conf();
}
elsif ($proc eq "chk_ec_sch_types") {
  $ret = $ut->chk_ec_sch_types();
}
elsif ($proc eq "test") {
  $ret = $ut->test();
}
else {
  print "__error__\n"; # !!!
}

exit $ret if ($ret != ssv_util::ERR_OK);
exit ssv_util::ERR_OK;
