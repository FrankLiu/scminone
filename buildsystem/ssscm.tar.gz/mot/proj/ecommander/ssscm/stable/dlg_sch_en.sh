#!/bin/bash -E
## .SH dlg_sch_en.ksh
## .SS Author
## hqjr73@motorola.com on 24 April 2010

BN=`basename $0`
#DN=`dirname $0`

trap ssv_trap_err ERR

dlg_ret=${DLG_CANCEL} # !!!
dlg_res=0
dlg_exit=0
sch=""  # !!!
func=${AP_PROC_RUN_BUILD}
disabled=1
start_time_h=0
start_time_m=0

while getopts s:f:o:m:d: opt; do
  case ${opt} in
    s) sch="${OPTARG}" ;;
    f) func="${OPTARG}" ;;
    o) start_time_h="${OPTARG}" ;;
    m) start_time_m="${OPTARG}" ;;
    d) disabled="${OPTARG}" ;;
  esac
done

# !!! check parameters
#if [[ "${sch}" = "" ]]; then
#  echo "__usage__2"
#  exit 1 # !!!
#fi

# !!!
#if [[ "${view}" = "" ]]; then
#  echo "__usage__3"
#  exit 1 # !!!
#fi

dlg_sch_en_dispatch()
{
  case ${dlg_ret} in
    ${DLG_ESC} | ${DLG_CANCEL}) ssv_quit; return $? ;;
    ${DLG_HELP}) ssv_help ${SSV_DIR}/doc/README_sch_en; return $? ;;
    ${DLG_OK})
# !!!!!!!!!!!!!
      if [[ "${dlg_res}" = "${ID_DLG_SCH_ENABLE}" ]]; then
        disabled=0
      else
        disabled=1
      fi

      ${SSV_DISP} --proc="setsch" --sch="${sch}" --func="${func}" \
                  --timeh="${start_time_h}" --timem="${start_time_m}" \
                  --dis="${disabled}"
      [[ "$?" != "${SSV_OK}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

      ${DIALOG} \
        --backtitle "Self Serve SCM > Builds > ${sch} > Schedule" \
        --title " Schedule " \
        --msgbox "SUCCESS. ${sch}.\nSchedule parameters have been changed." \
        6 ${DLG_COMMON_WIDTH}
      [[ "${ret}" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }

      dlg_exit=${SSV_TRUE}
      return ${SSV_OK}
      ;;

    ${DLG_EXIT}) dlg_exit=${SSV_TRUE}; return ${SSV_CANCEL} ;;
    *) p_err ${LINENO}; return ${SSV_EXIT} ;;
  esac
  return ${SSV_OK}
}

dlg_sch_en_show()
{
# !!!!!!
  if [[ "${disabled}" = "1" ]]; then
    sch_st="off"
  else
    sch_st="on"
  fi

  ${DIALOG} \
    --backtitle "Self Serve SCM > Builds > ${sch} > Schedule > Startup" \
    --title " Change Start Time " \
    --help-button \
    --extra-button \
    --ok-label "Next" \
    --extra-label "Back" \
    --cancel-label "Exit" \
    --single-quoted \
    --checklist "Enable/Disable schedule startup.\nPress [SPACE] to change the option." \
      9 ${DLG_COMMON_WIDTH} 1 \
      ${ID_DLG_SCH_ENABLE} "Automatic start" "${sch_st}" 2>${TMP_RES}
  dlg_ret=$?
  [[ "$dlg_ret" = "${DLG_ERROR}" ]] && { p_err ${LINENO}; return ${SSV_EXIT}; }
  dlg_res=`cat ${TMP_RES}`
  return ${SSV_OK}
}

dlg_sch_en_run()
{
  while [[ "${dlg_exit}" = "${SSV_FALSE}" ]]; do
    dlg_sch_en_show
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break

    dlg_sch_en_dispatch
    ret=$?
    [[ "${ret}" != "${SSV_OK}" ]] && break
  done
  return ${ret}
}

dlg_sch_en_run
