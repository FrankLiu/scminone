BN=`basename $0`
PID=$$
DIR=/tmp

# works on Linux and Solaris, unlike whoami
UN=`id -u -n`

case $# in
  3)
    script=$1
    special=$2
    DIR=$3
    ;;
  2)
    script=$1
    special=$2
    ;;
  1)
    script=$1
    special=tmp
    ;;
  0)
    script=${BN}
    special=tmp
    ;;
  *)
    echo "usage: ${BN} [<script-name>] [<special-name>]"
    echo "  Return a temporary file name.  Please remove this file when you're done with"
    echo "it."
    exit
    ;;
esac

echo "${DIR}/${script}.${special}.${UN}.${PID}"
