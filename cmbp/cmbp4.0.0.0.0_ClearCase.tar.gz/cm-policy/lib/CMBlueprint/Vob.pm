
## Need the following variables from the main:: package
###############################################
# Use variables from $PROD_trigger.cfg        #
###############################################
use vars qw($CC_VOB_ELEM_OWNER $CC_VOB_ELEM_GROUP);

###############################################
# Use variables from $site.cfg        #
###############################################
package CMBlueprint::Vob;

#######################################################################

=head1 NAME

CMBlueprint::Vob - module to obtain information about a VOB or about CC types
in the Vob

=head1 EXPORTS

get_current_vob get_vob_owner_group GetUidOid get_ProductFamily getVOBSPCF describe_object
  
=head1 DESCRIPTION

B<CMBlueprint::Vob> is a module is used to obtain a Vob specific information 
such as the current Vob, the owner and the primary group of the Vob, the CC Object id
of the Vob. This module is also used to obtain information about various CC types 
(branch types, attribute types etc.) in the Vob .

=cut

#######################################################################

use strict;
use vars qw(@ISA @EXPORT);
use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(get_current_vob get_vob_owner_group GetUidOid get_ProductFamily getVOBSPCF describe_object);

use vars qw($CLEARTOOL $TMPDIR);

use CMBlueprint;
use CMBlueprint::Config;

################################################################
sub get_current_vob {

  return describe_object("vob:.");

};

#########################################################################

=head1 NAME

describe_object -- An interface to the cleartool describe command.

=head1 SYNOPSIS

 describe_object("brtype:main@/usr/vob/expdoc");
 describe_object("vob:."); # gets the current vob.
 describe_object("-aattr ProductVOB vob:."); # gets the ProductVOB attr
                                                     # on the current vob

# below line gets the originating cr attribute on the clearcase element
# if used during trigger context
 describe_object("-aattr OriginatingCR $ENV{'CLEARCASE_PN'}"); 

=head1 DESCRIPTION

Runs the cleartool describe on the given argument and returns the
description of the given object - element pname, brtype, lbtype, attype
or hltype.


=head1 RETURN VALUES

    Returns the output of the describe command on the given object.

=cut

##########################################################################
sub describe_object {
   my $cc_object = shift;

   ## get VOB info if possible
   if ( $cc_object =~ /(\w+type):([^@]+)(?:\@([^@]+))?/ ) {
      my ($type, $name, $vob) = ($1, $2, $3||"");
      my $type_ev = 'CLEARCASE_' . uc($type);
      $ENV{$type_ev} = $name  unless (exists $ENV{$type_ev});
      if ($vob) {
         my $vob_ev  = 'CLEARCASE_VOB_PN';
         $ENV{$vob_ev} = $vob  unless (exists $ENV{$vob_ev});
      }
   }
   
	my $tmpfile = "$TMPDIR/desc_obj$$.tmp";
	my $cmd = "$CLEARTOOL describe -s $cc_object 2> $tmpfile";
	prep_cmd(\$cmd);
	my $ret_val = `$cmd`;
	unlink $tmpfile;
	return $ret_val;

}

################################################################


=head1 NAME

get_vob_owner_group -- Get owner and primary group of the VOB.

=head1 SYNOPSIS

 get_vob_owner_group()

=head1 DESCRIPTION

Do a 'cleartool describe' on $ENV{'CLEARCASE_VOB_PN'}.
Return the owner and primary group of the VOB.


=head1 RETURN VALUES

Returns the owner and primary group of the VOB.

=cut

##########################################################################
sub get_vob_owner_group
{

  my $vob = $ENV{'CLEARCASE_VOB_PN'};

  read_configFile() unless ($::CC_VOB_ELEM_OWNER);

  # If vob is explicitly defined in CC_VOB_ELEM_OWNER_GROUP_BY_VOB hash,
  # override the owner and group values that are defined in
  # $CC_VOB_ELEM_OWNER and $CC_VOB_ELEM_GROUP
  if ($::CC_VOB_ELEM_OWNER_GROUP_BY_VOB{"$vob"}) {
     my ($vob_owner, $vob_group ) = split(/\#/,$::CC_VOB_ELEM_OWNER_GROUP_BY_VOB{"$vob"});
     dprint(1,"Getting owner and group from CC_VOB_ELEM_OWNER_GROUP_BY_VOB hash\n\t\$vob_owner=$vob_owner \$vob_group=$vob_group\n");
     if ($vob_group) {
            return ($vob_owner, $vob_group);
     }
     else {
            return ($vob_owner,$::CC_VOB_ELEM_GROUP);
     }
  }

  unless ($::CC_VOB_ELEM_OWNER) {
     dprint("perf",
     	"# could *not* get VOB elem owner/group from config-file!\n");
     dprint("# could *not* get VOB elem owner/group from config-file!\n");

     my $cmd = "$CLEARTOOL describe vob:$vob";
     #prep_cmd(\$cmd);

     my @desc  = `$cmd`;

     my $owner = (grep(/^\s+owner\s+(\S+)$/ && ($_ = $1), @desc))[0];
     my $group = (grep(/^\s+group\s+(.*)$/ && ($_ = $1), @desc))[0];

     #########################################################
     # CC 4.1 on UNIX displays owner and group or the VOB    #
     # along with the full hostname.                         #
     # Example:  owner  clearcase15.cig.mot.com/pnayak1      #
     #           group  clearcase15.cig.mot.com/CID          #
     #                                                       #
     # The following will strip out the hostname and '/'.    #
     #########################################################
     $owner = (split /\//, $owner)[-1];
     $group = (split /\//, $group)[-1];

     ($::CC_VOB_ELEM_OWNER, $::CC_VOB_ELEM_GROUP) = ($owner, $group);
     dprint("# VOB owner/group: owner=$owner group=$group\n");
  }

  return ($::CC_VOB_ELEM_OWNER, $::CC_VOB_ELEM_GROUP);
}

##########################################################################
#==============================================================================
# GET THE VOB OBJECT ID (oid) FOR THE CLEARCASE OBJECT (element, brtype) WE
# ARE WORKING WITH...
#==============================================================================
#################################################################

=head1 NAME

GetUidOid -- Returns the ClearCase oid of the VOB and that of the ClearCase object.

=head1 SYNOPSIS

 GetUidOid($CQname)

 where

       $CQname     - Name of the ClearCase object as would be displayed
                     in the ClearQuest interface.


=head1 DESCRIPTION

If the operation is 'mktype', the ClearCase object is $CQname prefixed by "brtype:".  
Otherwise, the ClearCase object is $ENV{CLEARCASE_PN}.  It gets the oids of the VOB and 
the ClearCase object by executing "cleartool dump" of $ENV{CLEARCASE_VOB_PN} and the ClearCase 
object.  The output of the dump is parsed for "oid=".  The VOB's oid is stored in $uuid, the 
object's oid is stored in $oid.

=head1 RETURN VALUES

 On SUCCESS, it returns 0, the VOB's oid and the object's oid.
 On FAILURE, it returns 1.


=head1 B<NOTES>

This function was provided by Rational in the out-of-the-box CQCC integration script.

=cut

#################################################################

sub GetUidOid {
    my $CQname = shift @_;
    my $VOstr;
    my ($uuid, $oid, $name);
    my $op = $ENV{CLEARCASE_OP_KIND};
    my $rc = 0;

    if ($op eq 'mktype' || $op =~ m/lock$/  || $op =~ m/scMergeList/ || $op =~ m/scBRMerge/) {
        # Need to specify branch type as "brtype:<name>@<vob_tag>"
        #----------------------------------------------------------
        $name = "brtype:" . $CQname;
    } else {
        $name = qq#"$ENV{CLEARCASE_PN}"#;
    }

    # Do CLEARTOOL DUMP, and parse the output for the vob oid and version oid.
    # Send stderr to the NULL device. That's because you can get an spurious
    # error message when you provide a view extended pathname when you don't
    # have a view set.
    #
    my $tmpfile = "$TMPDIR/gvobl$$.tmp";
    dprint "Using temp file $tmpfile\n";

	# We don't use $name anyway!
	#my $cmd = "$CLEARTOOL dump vob:$ENV{CLEARCASE_VOB_PN} $name";
	my $cmd = "$CLEARTOOL dump vob:$ENV{CLEARCASE_VOB_PN}";
    #prep_cmd(\$cmd);
    $cmd .= " 2>$tmpfile |";

    dprint "GetUidOid(): $cmd\n";

    open(DUMP, $cmd);
    while (<DUMP>) {
        if (/oid=(\S*)/) {
            if (!$uuid) {
                $uuid = $1;
            } elsif (!$oid) {
                $oid = $1;
            }
        }
    }
    close DUMP;
    unlink $tmpfile;
    dprint ("oid=$oid...uuid=$uuid\n");
	
	##if passed two arguments, not checking oid
    if (!$uuid || ( !$_[0] && !$oid) ) {
        #----------------------------------------------------------------------
        # FALLING INTO HERE WHEN RUNNING MKBRTYPE FROM GUI -- OID IS NULL!!
        # FIXED BY SPECIFYING BRANCH TYPE AS <BRTYPE>@<VOB_TAG>
        #----------------------------------------------------------------------
        dprint "GetUidOid() did not find uuid/oid -- uuid = $uuid, oid = $oid\n";
        $rc = 1;
    }
    return ($rc, $uuid, $oid);
}

############################################################################
sub get_ProductFamily {

  my $vob = shift || $ENV{CLEARCASE_VOB_PN} || '.' ;
  my $product_family = "";

    $product_family = describe_object("-aattr $PROD_FAMILY_ATTYPE vob:$vob");
    chomp($product_family); # remove trailing newline around the attribute.
    $product_family =~ s/"//g; # remove doublequotes around the attribute value

  $product_family =~ s/^\s+//; $product_family =~ s/\s+$//;
  return $product_family;

};

############################################################################
sub getVOBSPCF {
	my $vob = shift || $ENV{CLEARCASE_VOB_PN} || '.' ;
	my $component = "";
	
	$component = describe_object("-aattr $SPCF_ATTYPE vob:$vob");
	chomp($component); # remove trailing newline around the attribute.
	$component =~ s/"//g; # remove doublequotes around the attribute value
	
	$component =~ s/^\s+//;
	$component =~ s/\s+$//;
	return $component;

};

#################################################################



1;



