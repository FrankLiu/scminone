package CMBlueprint::ClearQuest;

#######################################################################

=head1 NAME

CMBlueprint::ClearQuest - provides interface to ClearQuest                 

=head1 EXPORTS

  GenerateCrId ParseCrId FormatCrId AuthorizedCR GetValidCRSet
  GetReleaseLoadlineforCR GetRelLLTTCRUforCR GetSPCFforCR GetCRFeature

=head1 DESCRIPTION

B<CMBlueprint::ClearQuest> provides an interface to ClearQuest. 
It provides functions to generate or parse a Change Record (CR)
ID using the format that ClearQuest uses.  It also has functions
to validate a CR, or log change set in the CR in ClearQuest.

=cut

###################################################################################
###############################################
# Use variables from site.cfg                 #
###############################################
use vars qw($CQ_REC_TYPE);

use CQIntegration::CQSession;

###############################################
# Use variables from $PROD_trigger.cfg        #
###############################################
use vars qw(@CQ_DB_LST $CQ_DEF_DB);



use strict;
use vars qw(@ISA @EXPORT);
use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(GenerateCrId ParseCrId FormatCrId AuthorizedCR 
	GetValidCRSet MVCsetLog CheckIsCRAssigned CheckIsCRClosed CheckIsCRPerformed GetLinkedCRs comm_AuthorizedCR GetParentLinkedCRs
	     clearcaseTabAction getVobObjectNameFromCQ getBaseLineRecord getBranchTypeFromCR GetReleaseLoadlineforCR IsAltMainReleaseforCR GetRelLLTTCRUforCR GetSPCFforCR GetCRFeature
	     getCRComponent getCRInfo
	     get_verifyBrtypeFromCR
	     relinkCStoCR
	     IsCRClosedAndCRInformation
	     getDepFromHlink
	     getuuidfromCQ
	     checkCRassignedAndNoOtherActiveBrtype
	     getReleaseIDs GetLogonParms regenerateCQParams promptUserPass);


use CMBlueprint;
use CMBlueprint::UI;
use CMBlueprint::Config;
use CMBlueprint::Vob;

=head1 NAME

GenerateCrId -- Formats ClearQuest CR ID.   

=head1 SYNOPSIS

 GenerateCrId($cqdb, $dbID, $cq_def_db, @cq_db_lst)

 where
     $cqdb      -  ClearQuest database name.  Can be blank.
     $dbID      -  ClearQuest CR number
     $cq_def_db -  Default ClearQuest database for the product.
     @cq_db_lst -  List of Valid ClearQuest databases for the product


=head1 DESCRIPTION

Given a ClearQuest database name and number, GenerateCrId generates a CR ID in the format as seen in ClearQuest.  If the ClearQuest database name is blank, it uses $cq_def_db as the database name.  If the ClearQuest database name is not blank, it checks if it exists in @cq_db_lst and matches the right character case for cqdb.  It $dbID is blank, it returns 1.  Otherwise, it 0-pads the dbID to 8-digits.

=head1 RETURN VALUES

 Returns 0 and the formatted $cqdb and $dbID on success.
 Returns 1 on failure.                


=cut

#################################################################
sub GenerateCrId {

   my ($cqdb, $dbID, $cq_def_db, @cq_db_lst) = @_;

   my $rc = 0;
   my $crid = 0;

   if (length $dbID) {
      ## 0-pad the dbid upto 8 digits
      $dbID = sprintf("%08d", $dbID);
   
      ## Match the right character-case for the cqdb
      $cqdb ||= $cq_def_db;
      my @matches = grep { (lc $_) eq (lc $cqdb) } @cq_db_lst;
      if (@matches == 1) {
         $cqdb = shift @matches;
      }
      else {
         $rc = 1;
      }
   }
   else{
      $rc = 1;
   }

   return ($rc, $cqdb, $dbID);
}

#################################################################

=head1 NAME

ParseCrId -- Gets the ClearQuest database name and number from a CR ID.

=head1 SYNOPSIS

 ParseCrId($crid)

 where
     $crid      -  ClearQuest CR ID.                        


=head1 DESCRIPTION

Gets the database name and number from a CR ID.

=head1 RETURN VALUES

 Returns 0 and the ClearQuest database name and number on success.
 Returns 1 on failure.                


=cut

#################################################################
sub ParseCrId {

   my $crid = shift @_;
   my $rc = 0;
   my ($cqdb, $crnum);

   if ( $crid =~ /^([A-Za-z]\w*[A-Za-z])?(\d+)$/){
      ($cqdb, $crnum) = ($1, $2);
   }
   else{
      $rc = 1;
   }

   return($rc, $cqdb, $crnum);
}


#########################################################################

=item B<FormatCrId>

Take a crid and output it in proper canonical format with
correct database name and character case and leading zeros.
Takes a $crid as its argument, and returns the list ($rc, $crid)
where $rc is 0 for success and non-zero otherwise.

=cut

sub FormatCrId ($) {
  my $crid = shift;
  my ($rc, $cqdb, $crnum) = ParseCrId($crid);

  # This part of the code is required to Create the CR ID in
  # correct format if user does not have it in correct format
  unless($rc){
    ($rc, $cqdb, $crnum) = GenerateCrId($cqdb,$crnum,$::CQ_DEF_DB, @::CQ_DB_LST);
    $crid = $cqdb.$crnum  unless($rc);
  }

  return ($rc, $crid);
}

####################################################################################

sub AuthorizedCR {
   my ($crid, $cq_rec_type,$cq_def_db, @cq_db_lst) =@_;

	   my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
	   if(!$cq)
	   {
	       return 1;
	   }

	   my ($rc, $cquser, $cqpwd) = GetLogonParms();
	   my( $result ) = $cq->xquery( record      => 'Development_CR',
				       id          => $crid,
				       fields      => 'state,technical_authority' );
	   unless($result)
           {
               return 1;
           }


	   my( %stuff ) = $cq->getResults();
       
	   if($stuff{technical_authority} =~ m/$cquser~/)
	   {
	       return 0;
	   }
           # Allow if current userid matches alsoe
           if($stuff{technical_authority} =~ m/$CURRENT_USER/)
           {
               return 0;
           }

	   return 1;
}
##################################################################################

=head1 NAME

MVCsetLog -- Log ClearCase Change set in different vob setup

=head1 SYNOPSIS

 MVCsetLog($cc_object, $crid,$cvalue)

 where

 $cc_object - brtype name
 $crid -  ClearQuest CRID
 $cvaule - WORK_STARTED/WORK_COMPLETED/BRTYPE_DELETED


=head1 DESCRIPTION

 1.  get the vob location where the trigger was fired
 2.  get the admin vob location associated with the vob if any
 3.  determin what vob will be used for logging the cset


=head1 RETURN VALUES

0 on success
1 on failure

=cut

#################################################################
sub MVCsetLog {

    my ($brtype, $crid,$cvalue) = @_;

    my ($rc, $cqdb, $crnum) = ParseCrId($crid);
    if ($rc){
      display_msg("Error: Invalid CR ID format.", 1);
      return 0;
    }

	my $ivob;	##vob passed in with brtype

	if ( $brtype =~ s/\@(.*)\s*$// ) {
		$ivob = $1;
	}
	$brtype =~ s/^brtype://;

	my $cvob = $ENV{CLEARCASE_VOB_PN};	##the vob where the trigger was fired
	
	##use the paased-in vob
	$cvob = $ivob if ( ! $cvob && $ivob  );

	## the admin vob associated with the vob where the trigger was fired
	my $admVob = (qx{$CLEARTOOL describe -s -ahlink AdminVOB vob:$cvob})[0];
	## the vob whose uuid will be used for logcset
	my $pickedVob;	

	if ( $admVob =~ /^\s*->\s+(vob:.*)\s*$/ ) {#invoking vob is not a admvob
		$pickedVob = $1;
	} elsif ( $admVob =~ /^\s*<-\s+(vob:.*)\s*$/ ) {#itself a admvob
		$pickedVob = $cvob;
	} else { #no admin vob
		$pickedVob = $cvob;
	}

	$pickedVob =~ s/^vob://;

	#we don't care oid, error happened inside GetUidOid
	#GetUidOid use this variable
	$ENV{CLEARCASE_VOB_PN} = $pickedVob;

    my ($uuid, $oid);
    ($rc, $uuid, $oid) = GetUidOid($brtype,$cvalue);

    my $replicaname = getReplicaNameFromVob($pickedVob);
    if($replicaname eq "")
    {
	$replicaname = "original";
    }

	    # first checking if the uuid which is the key exist in the database.
	    my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cq)
	    {
		return 1;
	    }

	    my( $result ) = $cq->listquery( record      => 'cc_vob_object',
					   filters      => "vob_family_uuid|EQ|$uuid,object_oid|EQ|$brtype",
					   fields      =>  'object_oid,dbid' );

	    unless($result)
	    {
		return 1;
	    }


	    my( %output ) = $cq->getResults();
	    if($ENV{CQCC_DEBUG})
	    {
		print "QUERY RESULT ->$output{object_oid}\n";
	    }

	    if($output{object_oid} ne "")
	    {
		# Object found in the db
		my( $_result ) = $cq->edit( record          => 'cc_vob_object',
					   name            => $cvalue,
					   replica_vob     => "$replicaname\@$pickedVob",
					   dbid            => $output{dbid} );
		unless( $_result )
		{
		    return 1;
		}

		$cq->getResults();

		#
		# Object exist ... but does it linked to the CR? If not will relink it...
		# 

		my( $result ) = $cq->xquery( record      => 'Development_CR',
					    id          => $crid,
					    fields      => 'cc_change_set.objects' );
		unless($result)
		{
		    return 1;
		}

		my( %op ) = $cq->getResults();
		if($op{'cc_change_set.objects'} eq "")
		{
		    my $rc;
		    dprint "HOUSTON WE HAVE A PROBLEM ... CCCHANGESET EXIST BUT IT IS NOT LINKED .. WILL LINK NOW! \n";

		    relinkCStoCR($crid,$uuid,$brtype, \$rc);
		    if($rc != 0)
		    {
			return 1;
		    }
		}
	    }
	    else
	    {
		# Object not found in the db

		my( $_result ) = $cq->create( record          => 'cc_vob_object',
					     name            => "$cvalue",
					     object_oid      => "$brtype",
					     replica_vob     => "$replicaname\@$pickedVob",
					     vob_family_uuid => "$uuid" );

		unless( $_result ){ 
		    return 1;
		}
		my( %createobj ) = $cq->getResults();
		my( $ccVobObj ) = $createobj{uid};

		unless( $ccVobObj )
                {
                    return 1;
                }

		# checking if the CR already has a cc_change_set_object
		my $ccChangeSet;

		$_result = $cq->xquery( record      => 'Development_CR',
				       id          => $crnum,
				       fields      => 'cc_change_set' );

		unless( $_result )
		{
		    return 1;
		}

		
		my( %cs ) = $cq->getResults();
		if($cs{cc_change_set} ne "")
		{
		    $ccChangeSet = $cs{cc_change_set};
		}
		else
		{
		    $_result = $cq->create( record          => 'cc_change_set' );
		    unless( $_result )
		    {
			return 1;
		    }

		    %cs = $cq->getResults();
		    $ccChangeSet  = $cs{uid};
		    unless( $ccChangeSet )
		    {
			return 1;
		    }
		}

		$_result  = $cq->edit( record          => 'CC_Change_Set',
				      dbid             => $ccChangeSet,
				      'objects'   => "$ccVobObj" );

		unless( $_result )
	        {
                    return 1;
                }

		my( %editoutput ) = $cq->getResults();
		$_result  = $cq->edit( record          => 'Development_CR',
				      id              => $crnum,
				      cc_change_set   => $ccChangeSet );

		unless( $_result )
                {
                    return 1;
                }

		#
		# Will verify the links went ok ...
		#
		dprint("Checking the links went ok .... \n");
		my( $result ) = $cq->xquery( record      => 'Development_CR',
					    id          => $crid,
					    fields      => 'cc_change_set.objects' );
		unless($result)
		{
		    return 1;
		}
		
		
		
		my( %op ) = $cq->getResults();
		if($op{'cc_change_set.objects'} eq "")
		{
		    my $rc;
		    dprint "HOUSTON WE HAVE A PROBLEM ... CCCHANGESET EXIST BUT IT IS NOT LINKED .. WILL LINK NOW! \n";
		    
		    relinkCStoCR($crid,$uuid,$brtype,\$rc);

		    if($rc != 0)
		    {
			return 1;
		    }
		}

	    } # end of else statment where object was not found.

    return 0;
}

##########################################################################
# checks CQ if the given CR is in the assigned state;
sub CheckIsCRAssigned {

    my ($int_cr)  = @_;

	    my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cq)
	    {
		return 0;
	    }


	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $int_cr,
					fields      => 'state' );

	    unless($result)
	    {
		return 0;
	    }


	    my( %output ) = $cq->getResults();
	
	    if($ENV{CQCC_DEBUG})
	    {
		print "STATE --> $output{'state'}\n";
	    }

	    if($output{'state'} =~ m/assigned/i)
	    {
		return 1;
	    }
    
        return 0;  # CR Not in Assigned state
}

# checks CQ if the given CR is in the performed state;
sub CheckIsCRPerformed {
    
    my ($int_cr, $rc)  = @_;

	    my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cq)
	    {
		return 0;
	    }

	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $int_cr,
					fields      => 'state' );

	    unless($result)
	    {
		return 0;
	    }

	    my( %output ) = $cq->getResults();
	    
	    if($ENV{CQCC_DEBUG})
	    {
		print "STATE --> $output{'state'}\n";
	    }

	    if($output{'state'} =~ m/performed/i)
	    {
		return 1;
	    }
        return 0;  # CR Not in Performed state
}

# checks CQ if the given CR is in the closed state;
sub CheckIsCRClosed {
    
    my ($int_cr, $rc)  = @_;
 
	    my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cq)
	    {
		return 0;
	    }

	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $int_cr,
					fields      => 'state' );

	    unless($result)
	    {
		return 0;
	    }

	    my( %output ) = $cq->getResults();
	    
	    if($ENV{CQCC_DEBUG})
	    {
		print "STATE --> $output{'state'}\n";
	    }

	    if($output{'state'} =~ m/Closed/i)
	    {
		return 1;
	    }
        return 0;  # CR Not in Closed state
}



# checks CQ if the given CR is in the performed state;
sub GetLinkedCRs {
    
    my ($int_cr, $rc)  = @_;
    my @crlist = ();

	    my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cq)
	    {
		$$rc = 1;
		return @crlist;
	    }
	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $int_cr,
					fields      => 'Child_CRs' );
	    unless($result)
	    {
		$$rc = 1;
		return @crlist;
            }

	    my( %output ) = $cq->getResults();
	    if($ENV{CQCC_DEBUG})
	    {
		print "Parent=$int_cr;  ChildCRs --> $output{'Child_CRs'}\n";
	    }

	    @crlist = split(",",$output{'Child_CRs'});			
	    $$rc = 0;
	    return @crlist;
}

# gets all the parent CRs for the given CR number
sub GetParentLinkedCRs {
    
    my ($int_cr, $rc)  = @_;
    my @crlist = ();

	    my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cq)
	    {
		$$rc = 1;
		return @crlist;
	    }
	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $int_cr,
					fields      => 'Parent_CRs' );
	    unless($result)
	    {
		$$rc = 1;
		return @crlist;
            }

	    my( %output ) = $cq->getResults();
	    dprint "ChildCRs=$int_cr;  ParentCRs --> $output{'Parent_CRs'}\n";

	    my @crlist = split(",",$output{'Parent_CRs'});			
	    $$rc = 0;
	    return @crlist;
}


#
# Function to otain the given CR's component ... the 'C' in SPCF...
#
sub getCRComponent
{
    my ($crnum,$rc) = @_;
    $$rc = 0;

    #
    # Padding the crid with 0's and placing the DB name if needed.
    #

    my $dbname;
    my $number;
    if($crnum =~ /^([a-zA-Z]+)(\d+)$/)
    {
        $dbname = $1;
        $number = $2;
	
        if($dbname !~ m/$::CQ_DEF_DB/i)
        {
            dprint("DBNAME $dbname is not default DB: $::CQ_DEF_DB\n");
	    $$rc = CQ_INVALID_CR;
            return ();
        }

        $crnum = sprintf("%s%08d",$::CQ_DEF_DB,$number);
    }
    elsif($crnum =~ /^(\d*)$/)
    {
        $number = $1;
        $crnum = sprintf("%s%08d",$::CQ_DEF_DB,$number);
    }
    else
    {
        $$rc = CQ_INVALID_CR;
        return ();  # Invalid CR given in the parameters.
    }

    dprint("crnumber = $crnum \n");

    my $comp;
	    # need to get the component of the CR...
	    my( $cqSession ) = CQIntegration::CQSession->new(useformatting => 1); 
	    if(!$cqSession)
	    {
		$$rc = 1;
		return ();
	    }


	    my ( $result ) = $cqSession->xquery( record      => 'Development_CR',
						id          => $crnum,
						fields      => 'CI_Component' );

	    unless($result)
	    {
		$$rc = 1;
		return ();
	    }

	    my %output = $cqSession->getResults();
	    $comp = $output{CI_Component};
    #
    # Getting rid of the namespace in the component name.
    #

    $comp =~ s/:.*$//;
    return $comp;
}


#
# Function to get the given CR's information:
#
# Assumes that two arguments are passed:
#
#  1) CRid (e.g. INDEV00066612)
#  2) Reference to a hash in which the CR query results will be returned
#         - the CR fields that will be queried in CQ will be the hash keys
#           that are currently set.
#         - the query results will be set in the values for each 
#           corresponding field name key
#
# Returns 0 upon success
#         1 upon failure
#
sub getCRInfo
{
        my $crid = shift;
	my ( $query_resultRef ) = shift ;

	my $fields = "";

	dprint ("In getCRInfo...  crid=$crid\n");
		my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
		if(!$cq)
		{
			return (1);
		}

		# Get query field list from list of valid keys in hash
		# This field list should be comma separated
		# Example: "CI_Component,State,Technical_Authority"
		my @field_keys = keys %$query_resultRef;
		if (! (scalar(@field_keys)) )
		{
			return (1);
		} 

		$fields = join (',',@field_keys);
		dprint ("Field list passed to CQ=$fields\n");

		my ($result) = $cq->xquery(record  => 'Development_CR',
					   id      => $crid,
					   fields  => "$fields" );

		unless($result)
		{
			return (1);
		}


		my( %output ) = $cq->getResults();

		foreach ( keys %output ) {
			dprint ( "key $_ = $output{$_}\n");
			$$query_resultRef{$_} = $output{$_};
		}
		return 0;
}


# 
# Function to obtain the all the CR linked to a given baseline record.
#

sub getBaseLineRecord
{
    my ($baselinerecord, $rc)  = @_;
    my @crlist =();

	    my( $cqSession ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cqSession)
	    {
		$$rc = 1;
		return @crlist;
	    }
	
	    my( $result ) = $cqSession->listquery( record      => 'Development_CR',
						  filters     => "BL_Actual_Target.Name|EQ|$baselinerecord",
						  fields     => 'id' );
	    unless($result)
	    {
		$$rc = 1;
		return @crlist;
	    }

	    my %op =  $cqSession->getResults();
	    @crlist	= split(/\,/, $op{id});

    $$rc = 0;
    return @crlist;
}


#
# Function to obtain the branch names for the given CR. The branch names is store in CQ.
#
sub getBranchTypeFromCR
{
    my($crid , $rc) = @_;
    $$rc = 0;
    my @crlist = ();
    my $deletedBranch = "BRTYPE_";

    #
    # Padding the crid with 0's and placing the DB name if needed.
    #

    my $dbname;
    my $number;
    if($crid =~ /^([a-zA-Z]+)(\d+)$/)
    {
        $dbname = $1;
        $number = $2;

        if($dbname =~ m/"$::CQ_DEF_DB"/i)
        {
            dprint("DBNAME $dbname is not default DB: $::CQ_DEF_DB\n");
	    $$rc = CQ_INVALID_CR;
            return ();
        }

        $crid = sprintf("%s%08d",$::CQ_DEF_DB,$number);
    }
    elsif($crid =~ /^(\d*)$/)
    {
        $number = $1;
        $crid = sprintf("%s%08d",$::CQ_DEF_DB,$number);
    }
    else
    {
        $$rc = CQ_INVALID_CR;
        return ();  # Invalid CR given in the parameters.
    }

    dprint("CRID = $crid\n");


	    my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cq)
	    {
		$$rc = 1;
		return ();
	    }
	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $crid,
					fields      => 'cc_change_set.objects' );

	    unless($result)
	    {
		$$rc = 1;
		return ();
	    }

	    my( %op ) = $cq->getResults();
	    my @cset = split(/\,/,$op{'cc_change_set.objects'});

	    my $j=0;
	    foreach(@cset)
	    {
		my $status;
		my $oid;
		my $branch;

		($oid,$status) = split(/\s/);
		
		#$cq =  CQIntegration::CQSession->new();
		$cq =  CQIntegration::CQSession->new(useformatting => 1);
		$result  = $cq->listquery( record      => 'cc_vob_object',
					  filters      => "dbid|EQ|$oid",
					  fields      =>  'object_oid' );

		%op = $cq->getResults();

		# ignoring brtype that have been deleted !! 
		if($status !~ m/$deletedBranch/)
		{
		    $crlist[$j++] = $op{'object_oid'};
		}
	    }

    if($#crlist == -1)
    {
	return ();
    }
    elsif($#crlist == 0 && $crlist[0] =~ /^\s*$/) # if only returns white space .... 
    {
	return ();
    }

    return @crlist;
}

sub IsAltMainReleaseforCR{
	my $crid = shift;
	my ($rel,$loadline) = ('','');
	my $rc;

	($rc, $rel,$loadline) = GetReleaseLoadlineforCR($crid);
	my $validRelease = getReleaseIDs();

	dprint ("Returned RC=$rc from GetReleaseloadline sub\n");
	if($rc == CQ_LOGIN_FAIL || $rc == CQ_QUERY_FAIL) {
		return ($rc, '','');
	}

	if(!$rel || ($rel and $$validRelease{$rel} eq 'main')) {
		$rc=0;
	}else{
		$rc=1;
	}
	return ($rc, $rel, $loadline);
}

sub GetReleaseLoadlineforCR {
    
    my $crid  = shift;
	read_configFile();
	return (0,'','')  unless ($::CQCC_INTEGRATION_ENABLED);
	my ($rc, $cqdb, $crnum) = ParseCrId($crid);
	unless($rc){
		my $cnt = $crnum =~ tr/0-9//;
		if($cnt < 8) {
			($rc, $cqdb, $crnum) = GenerateCrId($cqdb,$crnum,$::CQ_DEF_DB, @::CQ_DB_LST);
			$crid = $cqdb.$crnum unless($rc);
		}
	}
    

    #######
    #
    #  Getting the Predicted_Release and Loadline.
    # 
    #######
    my($rel);
    my($loadline);

	    use CQIntegration::CQSession;

	    my( $cqSession ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cqSession)
	    {
		return(CQ_QUERY_FAIL,'','');
	    }

	    my( $result ) = $cqSession->xquery( record      => 'Development_CR',
					       id          => $crid,
					       fields      => 'Proj_Predicted_Release.Name,Loadline');

	    unless($result)
	    {
		return(CQ_QUERY_FAIL,'','');
	    }

	    my( %output ) = $cqSession->getResults();

	    $rel = $output{'Proj_Predicted_Release.Name'};
	    $loadline = $output{'Loadline'};

    if(!$::ALLOWRELEASEALPHANUMERIC)
    {
	dprint("NO ALPHA LETTERS IN RELEASE NAME\n");
	if($rel =~ /(\d+(\.\d+)*)/) {
	    $rel = "r".$1;
	}
    }
    else
    {
	dprint("ALLOW ALPHA LETTERS IN RELEASE NAME\n");
	if($rel =~ /^\D*(.*)/)
	{
	    $rel = "r".$1;
	}

	$rel = lc($rel);
    }
    
    dprint("Releaseid = $rel \n");
    $loadline = uc $loadline;
    return ($rc, $rel, $loadline);
}

#
# Function to get CR fields (Release, Loadline, Target_Type, CR Usage)
#
sub GetRelLLTTCRUforCR {

    dprint (1,"Into GetRelLLTTCRUforCR....\n");
    my $crid  = shift;
	read_configFile();
	return (0,'','','','')  unless ($::CQCC_INTEGRATION_ENABLED);
	my ($rc, $cqdb, $crnum) = ParseCrId($crid);
	unless($rc){
		my $cnt = $crnum =~ tr/0-9//;
		if($cnt < 8) {
			($rc, $cqdb, $crnum) = GenerateCrId($cqdb,$crnum,$::CQ_DEF_DB, @::CQ_DB_LST);
			$crid = $cqdb.$crnum unless($rc);
		}
	}

    #######
    #
    #  Getting the Predicted_Release, Loadline, Target_Type, CR_Usage
    # 
    #######
    my($rel);
    my($loadline);
    my($targettype);
    my($crusage);

	    use CQIntegration::CQSession;

	    my( $cqSession ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cqSession)
	    {
		return(CQ_QUERY_FAIL,'','','','');
	    }

	    my( $result ) = $cqSession->xquery( record      => 'Development_CR',
					       id          => $crid,
					       fields      => 'Proj_Predicted_Release.Name,Loadline,Target_Type,CR_Usage');

            dprint ("\$result=$result");
	    unless($result)
	    {
		return(CQ_QUERY_FAIL,'','','','');
	    }

	    my( %output ) = $cqSession->getResults();

	    $rel = $output{'Proj_Predicted_Release.Name'};
	    $loadline = $output{'Loadline'};
	    $targettype = $output{'Target_Type'};
	    $crusage = $output{'CR_Usage'};

    if(!$::ALLOWRELEASEALPHANUMERIC)
    {
        dprint("NO ALPHA LETTERS IN RELEASE NAME\n");
        if($rel =~ /(\d+(\.\d+)*)/) {
            $rel = "r".$1;
        }
    }
    else
    {
        dprint("ALLOW ALPHA LETTERS IN RELEASE NAME\n");
        if($rel =~ /^\D*(.*)/)
        {
            $rel = "r".$1;
        }

        $rel = lc($rel);
    }

    dprint("Releaseid = $rel \n");
    $loadline = uc $loadline;

    dprint (1, "rel=$rel loadline=$loadline\n");
    dprint (1, "crusage=$crusage targettype=$targettype\n");
    dprint (1,"Leaving GetRelLLTTCRUforCR....\n");
    return ($rc, $rel, $loadline, $targettype, $crusage);

}

#
# Function to get SPCF CR fields (System, Product, Component, Feature)
#
sub GetSPCFforCR {
	
    dprint (1,"Into GetSPCFforCR....\n");
    my $crid  = shift;
	read_configFile();
	return (0,'')  unless ($::CQCC_INTEGRATION_ENABLED);
	my ($rc, $cqdb, $crnum) = ParseCrId($crid);
	unless($rc){
		my $cnt = $crnum =~ tr/0-9//;
		if($cnt < 8) {
			($rc, $cqdb, $crnum) = GenerateCrId($cqdb,$crnum,$::CQ_DEF_DB, @::CQ_DB_LST);
			$crid = $cqdb.$crnum unless($rc);
		}
	}

    #######
    #
    #  Getting the System, Product, Component, Feature
    # 
    #######
    my ($system, $product, $component, $feature);    

	    use CQIntegration::CQSession;

	    my( $cqSession ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cqSession)
	    {
		return(CQ_QUERY_FAIL,'');
	    }

	    my( $result ) = $cqSession->xquery( record      => 'Development_CR',
					       id          => $crid,
					       fields      => 'CI_System.Name,CI_Product.Name,CI_Component.Name,CI_Feature_Area.Name');

	    unless($result)
	    {
		return(CQ_QUERY_FAIL,'');
	    }

	    my( %output ) = $cqSession->getResults();
	
	    $system = $output{'CI_System.Name'};
	    $product = $output{'CI_Product.Name'};
	    $component = $output{'CI_Component.Name'};
	    $feature = $output{'CI_Feature_Area.Name'};	    
    
	# Parsing values
	my $parsedSPCF = parseSPCFHook($system, $product, $component, $feature);	
    
	chomp ($parsedSPCF);
	
    dprint (1,"Leaving GetSPCFforCR....\n");
    return ($rc, $parsedSPCF);

}

#
# Function to get CR Feature_Id field
#
sub GetCRFeature {
    
    my $crid  = shift;
	read_configFile();
	return (0,'')  unless ($::CQCC_INTEGRATION_ENABLED);
	my ($rc, $cqdb, $crnum) = ParseCrId($crid);
	unless($rc){
		my $cnt = $crnum =~ tr/0-9//;
		if($cnt < 8) {
			($rc, $cqdb, $crnum) = GenerateCrId($cqdb,$crnum,$::CQ_DEF_DB, @::CQ_DB_LST);
			$crid = $cqdb.$crnum unless($rc);
		}
	}
    
    my($feature);

	    use CQIntegration::CQSession;

	    my( $cqSession ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cqSession)
	    {
		return(CQ_QUERY_FAIL,'');
	    }

	    my( $result ) = $cqSession->xquery( record      => 'Development_CR',
					       id          => $crid,
					       fields      => 'Feature_Identifier');

	    unless($result)
	    {
		return(CQ_QUERY_FAIL,'');
	    }

	    my( %output ) = $cqSession->getResults();

	    $feature = $output{'Feature_Identifier'};

    return ($rc, $feature);
}

#
# Function to get the CQ DB name from the CR number.
#

sub getCQDB
{
    my($crid , $rc) = @_;

    my ($cqdb, $crnum); 
    ($$rc, $cqdb, $crnum) = ParseCrId($crid);
    if ($$rc){
	$$rc = CQ_INVALID_CR;
	return "";
    }

    my ($new_cqdb, $new_crnum);
    ($$rc, $new_cqdb, $new_crnum) = GenerateCrId($cqdb, $crnum, $::CQ_DEF_DB, @::CQ_DB_LST);
    if ($$rc){
	$$rc = CQ_INVALID_CR;
	return "";
    }
    return $new_cqdb;
}


#
# Function that will obtain the VobObject.name string from CQ (ie. WORK_STARTED, WORK_COMPLETED etc.)
#   Returns: 	name string.
#		NULL -- if empty.
#
#

sub getVobObjectNameFromCQ
{
    my ($uid,$branch,$vob,$norelink) = @_;

    dprint("sub:  getVobObjectNameFromCQ\n");

    #
    # Need to obtain the OriginatingCR from the branch.
    # 

    my $cmd = "$CLEARTOOL describe -short -aattr OriginatingCR brtype:$branch\@$vob 2>$ERRNULL";
    my $crid = qx($cmd);
    dprint("cmd = $cmd\n");
    if($?)
    {
	return 1,"", "";
    }

    chomp($crid);
    dprint("originatingCR = $crid\n");
    

    # getting rid of the '"' strings from the output;
    $crid =~ s/^\"//;
    $crid =~ s/\"$//;

	    my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
            if(!$cq)
            {
                return 1,"", "";
            }
            my( $result ) = $cq->xquery( record      => 'Development_CR',
                                        id          => $crid,
                                        fields      => 'cc_change_set.objects' );

            unless($result)
            {
                return 1,"", "";
            }

	    my( %op ) = $cq->getResults();
            my @cset = split(/\,/,$op{'cc_change_set.objects'});

	    if($#cset == -1 && !defined($norelink))
	    {
		my $rc;
		$cset[0] = relinkCStoCR($crid,$uid,$branch,\$rc);

		if($rc != 0)
		{
		    return 1,"", "";
		}
	    }

            foreach(@cset)
            {
                my $status;
                my $oid;

                ($oid,$status) = split(/\s/);
		$cq =  CQIntegration::CQSession->new(useformatting => 1);
                $result  = $cq->listquery( record      => 'cc_vob_object',
                                          filters      => "dbid|EQ|$oid",
                                          fields      =>  'object_oid,vob_family_uuid' );

                %op = $cq->getResults();
		if($uid eq $op{'vob_family_uuid'} && $op{'object_oid'} eq $branch)
		{
		    dprint("status of cr-> $crid = $status brtype = $op{'object_oid'} vob--> $op{'vob_family_uuid'}\n"); 
		    return 0,$status, $crid;
		}
	    }

    return 0, "", "";
}


#
# Function to update the ClearCase Tab.
#
sub clearcaseTabAction
{
    my($status,$originatingCR, $branch, $commandtype, $vob, $tobranch, $intBranch, $uuid, $desStatus) = @_;

    if($::USEMERGESTATES == 0)
    {
	return 0;
    }

    my $workcompleted = "WORK_COMPLETED:";
    my $workstarted = "WORK_STARTED";
    my $workintegrated = "WORK_INTEGRATED";
    my $worktargeted = "WORK_TARGETED";
    my $workpartialintegrated = "WORK_PARTIAL_INTEGRATED";
    my $worklockedpartintegrated = "WORK_LOCKED_PART_INT";

    my $branchlock = isBranchLockedForAllUsers($branch,$vob);
    dprint("BranchLock = $branchlock\n");

    my ($currentstate,$vobccsetbranch) = (split(/:/,$status))[0,1];
    dprint("currentstate=$currentstate vobccsetbranch=$vobccsetbranch\n");


    if($commandtype == ADDTARGETED)
    {
	if($branchlock == 0)
	{
	    $status = "$worktargeted:$tobranch";
	}
	else
	{
	    $status = "$workcompleted" . "$tobranch";
	}
    }
    elsif($commandtype == ADDTARGETEDSTRICT)
    {
	if($currentstate eq $workintegrated)
	{
	    $$intBranch = $vobccsetbranch;
	    return 1;
	}

	if($branchlock == 0)
	{
	    $status = "$worktargeted:$tobranch";
	}
	else
	{
	    $status = "$workcompleted" . "$tobranch";
	}
    }
    elsif($commandtype == RMINTEGRATED)
    {
	if(($currentstate eq $workintegrated) && ($vobccsetbranch ne $tobranch))
	{
	    $$intBranch = $vobccsetbranch;
	    return 1;
	    
	}

	if($branchlock == 0)
	{
	    $status = "$worktargeted:" . $tobranch;
	}
	else
	{
	    if(isDevIntCRBranch($tobranch))
	    {
		$status = "WORK_LOCKED_PART_INT:" . $tobranch;
	    }
	    else
	    {
		$status = "WORK_COMPLETED:" . $tobranch;
	    }
	}
    }
    elsif($commandtype == RMTARGETED)
    {
	if(($currentstate eq $workintegrated) && ($vobccsetbranch ne $tobranch))
	{
	    $$intBranch = $vobccsetbranch;
	    return 1;
	}

	if($branchlock == 0)
	{
	    $status = $workstarted;
	}
	else
	{
	    $status = $workcompleted;
	}
    }
    elsif($commandtype == ADDINTEGRATED)
    {
        if($currentstate eq $workintegrated)
        {
	    if($vobccsetbranch ne $tobranch)
	    {
		$$intBranch = $vobccsetbranch;
		return 1;
	    }
	    else
	    {
		return 0; ### Do nothing ... since it already marked integrated.
	    }
	}

	$status = "WORK_INTEGRATED:$tobranch";	
    }
    elsif($commandtype == ADDPARTIALINTEGRATED)
    {
	dprint("updating the clearcase tab to WORK_PARTIAL_INTEGRATED");
        if($currentstate eq $workpartialintegrated) 
	{ 
	    # need to make sure it is not partially merged into another branch...
	    if($vobccsetbranch ne $tobranch) 
	    { 
		$$intBranch = $vobccsetbranch; 
		return 1; 
	    } 
	    else
	    {
		return 0; ### Do nothing ... since it already marked partially integrated.
	    }
	}

	$status = "$workpartialintegrated:$tobranch";	
    }
    elsif($commandtype == ADDLOCKEDPARTINTEGRATED)
    {
	dprint("updating the clearcase tab to WORK_LOCKED_PART_INT");
        if($currentstate eq $worklockedpartintegrated) 
	{ 
	    # need to make sure it is not partially merged into another branch...
	    if($vobccsetbranch ne $tobranch) 
	    { 
		$$intBranch = $vobccsetbranch; 
		return 1; 
	    } 
	    else
	    {
		return 0; ### Do nothing ... since it already marked partially integrated.
	    }
	}

	$status = "$worklockedpartintegrated:$tobranch";	
    }
    elsif($commandtype == VERIFY_NOT_INTEGRATED_OTHER_BRANCHES)
    {
	dprint("Checking If Not Integrated With Other Branches.! \n");
        if($currentstate eq $workintegrated)
        {
	    if($vobccsetbranch ne $tobranch)
	    {
		$$intBranch = $vobccsetbranch;
		return 1;
	    }
	}

	return 0; # need to only check if integrated and not update the clearcase tab. 
    }
    elsif($commandtype == VERIFY_NOT_INTEGRATED)
    {
	dprint("Checking If Not In Integrated State \n");
        if($currentstate eq $workintegrated)
        {
	    $$intBranch = $vobccsetbranch;
	    return 1;
	}

	return 0; # need to only check if integrated and not update the clearcase tab. 
    }
    elsif($commandtype == ADDINTEGRATEDNOCHECK)
    {
	dprint("Updating Clearcase Tab No Precondition Checking ! \n");
	$status = "$workintegrated:$tobranch";
	
    }
    elsif($commandtype == ADDWORKCOMPLETED)
    {
	dprint("updating the clearcase tab to work_completed ! \n");

	if($vobccsetbranch ne "")
	{
	    $status = "$workcompleted" . "$vobccsetbranch";	
	}
	else
	{
	    $status = $workcompleted;
	}
    }
    elsif($commandtype == ADDWORKSTARTED)
    {
	dprint("updating the clearcase tab to work_started ! \n");

	if($vobccsetbranch ne "")
	{
	    $status = "$worktargeted:$vobccsetbranch";	
	}
	else
	{
	    $status = $workstarted;
	}
    }

	
    dprint("statusstring = $status\n");
    dprint("originatingCR = $originatingCR \n");
    MVCsetLog($branch,$originatingCR,$status);

	dprint ("uuid passed to sub clearcaseTabAction: $uuid\n");
    # If $uuid was passed as a parameter then make sure the desired change set has taken place
	if ($uuid ne "") {
	    dprint ("Getting new status for: uuid: $uuid branch: $branch vob: $vob\n");
	    my ($rc1, $new_status, $originatingCR) = getVobObjectNameFromCQ($uuid,$branch,$vob);
    	if($rc1) {
	  		display_msg("Error: Failed to obtain the current mergestate for brtype:$branch\n");
	  		return 1;
    	}
    	dprint ("status desired: $status current status: $new_status\n");

    	if ($new_status ne $status) {
        	$$desStatus = $status;
			return 1;
		}
    }      
    return 0;
}



#
sub comm_AuthorizedCR {
        my $crid = shift;
	my $cquser = shift;
	my ( $query_resultRef ) = shift ;


                        my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
                        if(!$cq)
                        {
                                return 1;
                        }

                        my( $result ) = $cq->xquery( record      => 'Development_CR',
                                                        id          => $crid,
                                                        fields      => 'State,Technical_Authority,cc_change_set.objects,Work_Product_ID' );
                        unless($result)
                        {
                                return 1;
                        }


                        my( %stuff ) = $cq->getResults();

			foreach ( keys %stuff ) {
				dprint ( "key $_ = $stuff{$_}\n");
			}

			foreach ( keys %stuff ) {
				$$query_resultRef{$_} = $stuff{$_};
			}
           		return 0;
}

#
# Function that gets Branch Type for CR number and validates that:
#   1. Only one active (WORK_*) development branch type exists for CR
#   2. Branch type exists for given VOB
#
# Parameters:
#	$cr	cr number
#	$vob	vob
#	$btref	reference to CR branch
#	$geterrFlag	return $errmsg if $geterrFlag set to 1; $errmsg is empty if 0
# Returns:  0 if successfully obtains a single valid branch type from CR
#           1 if CR invalid or CR branch type found invalid
#
sub get_verifyBrtypeFromCR()
{
    my ($cr, $vob, $btref,$geterrFlag) = @_;
	if ( !defined ( $geterrFlag )) {
		$geterrFlag=0;
	}
    my $errmsg='';
    my $rc='';
    @$btref = &getBranchTypeFromCR($cr, \$rc);

    if ( $rc != CQ_VALID_CR || $#$btref < 0 ) {
	if( $geterrFlag ) {
		$errmsg="Error: Did not find brtype associated with CR ($cr)!\n".
			"Please validate that the CR ($cr) specified on the command line is a valid CR\n".
			"and that it has an associated branch type in the CQ ClearCase tab.\n";
		return(1, $errmsg); 
	}
	else {
        	display_msg ("Error: Did not find brtype associated with CR ($cr)!\n".
                	"Please validate that the CR ($cr) specified on the command line is a valid CR\n".
                	"and that it has an associated branch type in the CQ ClearCase tab.\n");
        	return(1, $errmsg);
	}
    }

    @$btref = map { s/^\s*//; s/\s*$//; s/\@.*$//; chomp; if ( ! m/^\s*$/ ) { $_ } } @$btref;
    dprint (1, "CR ($cr) BT (" . join(" ",@$btref) . ")\n");

    # Should only have one associated (WORK_*) brtype per CR
    if ( $#$btref > 0 ) {
	if ( $geterrFlag ) { 
		$errmsg="Error: Found more than one active brtype (" . join(",",@$btref) .
			")\n\tassociated with CR ($cr) in the CQ ClearCase tab!\n".
			"Please delete or obsolete the invalid branch type in the appropriate VOB\n".
			"\tprior to reattempting this command.\n";
		return(1,$errmsg);
	}
	else {
        	display_msg ("Error: Found more than one active brtype (" . join(",",@$btref) .
            	")\n\tassociated with CR ($cr) in the CQ ClearCase tab!\n".
                "Please delete or obsolete the invalid branch type in the appropriate VOB\n".
            	"\tprior to reattempting this command.\n");
        	return(1, $errmsg);
	}
    }

    #
    # Verify Branch type is valid for current VOB family
    #
    my $brtype = @$btref[0];   # Already validated that there's only one brtype

    if (verifyBranch($brtype, $vob) != 0) {
	if ( $geterrFlag ) {
		$errmsg="Error: Branch Type [$brtype] for CR [$cr] is not a valid branch type\n".
			"in the VOB [$vob]\n";
		return(1, $errmsg);
	}
	else {
        	display_msg ("Error: Branch Type [$brtype] for CR [$cr] is not a valid branch type\n".
        	"in the VOB [$vob]\n");
        	return(1,$errmsg);
	}
    }

   return (0, $errmsg);  # Return success
}

#
# Function that will try to relink the ccchangeset. There are times the vob object change set exist but is not linked to the 
# back to the CR. If that is the case, this function will link them back. 
# Return struct relinkinfo which contains str, and a return code.
#
# Returns the dbid and WORK_* string;
#     if error: Will return error string instead.
#     will pass in the $rc ... 
#               rc = 0 -> No errors.
#               rc = 1 -> Error
# 

sub relinkCStoCR
{
    my($crid,$uid,$branch,$rc) = @_;

    dprint("SUB: relinkCStoCR \n");

    my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);

    # Nothing is listed in the ccchangeset, so will now verify if the cc_vob_object exist.
    my( $result ) = $cq->listquery( record      => 'cc_vob_object',
				   filters      => "vob_family_uuid|EQ|$uid,object_oid|EQ|$branch",
				   fields      =>  'object_oid,dbid,name' );

    my( %output ) = $cq->getResults();

    my $ccChangeSet;
    if($output{object_oid} ne "")
    {
	# need to check if the ccchangeset record exist also..
	$result = $cq->xquery( record      => 'Development_CR',
			      id          => $crid,
			      fields      => 'cc_change_set' );

	unless ($result)
	{
	    $$rc = 1;
	    return "query failed to obtain the cc_change_set for CR $crid","";
	}

	my( %cs ) = $cq->getResults();
	if($cs{cc_change_set} ne "")
	{
	    $ccChangeSet = $cs{cc_change_set};
	    dprint "NO CHANGESET $ccChangeSet\n";
	}
	else
	{
	    dprint "NEW CHANGESET \n";

	    $result = $cq->create( record          => 'cc_change_set' );

	    unless ($result)
	    {
		$$rc = 1;
		return "Failed to create the cc_change_set object \n", "";
	    }


	    %cs = $cq->getResults();
	    $ccChangeSet  = $cs{uid};
	}
	
	dprint "TTT vobobject = $output{dbid} cc_change_set=$ccChangeSet\n";
	$result  = $cq->edit( record          => 'CC_Change_Set',
			     dbid             => $ccChangeSet,
			     'objects'   => "$output{dbid} $output{name}" );

	unless ($result)
	{
	    $$rc = 1;
	    return "Edit failed on CC_Change_Set object cc_change_set object \n", "";
	}

	$result  = $cq->edit( record          => 'Development_CR',
			     id              => $crid,
			     cc_change_set   => $ccChangeSet );

	unless ($result)
	{
	    $$rc = 1;
	    return "Edit failed on CR: $crid \n", "";
	}
    }
    else
    {
	#
	# Getting the replica name for the admin vob.
	#
	my $adminvob = $NT ? $::CC_NT_ADMINVOB : $::CC_UNIX_ADMINVOB;
	my $replicaname = getReplicaNameFromVob($adminvob); 
	if($replicaname eq "") 
	{ 
	    $replicaname = "original"; 
	} 


	### Object does not exist ... Will now create the Object with WORK_STARTED....
	my( $_result ) = $cq->create( record          => 'cc_vob_object',
				     name            => "WORK_STARTED",
				     object_oid      => "$branch",
				     replica_vob     => "$replicaname\@$adminvob",
				     vob_family_uuid => "$uid" );

	unless( $_result )
	{ 
	    $$rc = 1;
	    return "Failed to create cc_vob_object \n", "";
	}

	my( %createobj ) = $cq->getResults();
	my( $ccVobObj ) = $createobj{uid};

	unless( $ccVobObj )
	{
	    $$rc = 1;
	    return "Failed to obtain cc_vob_object uid\n", "";

	}

	# checking if the CR already has a cc_change_set_object
	my $ccChangeSet;
	$_result = $cq->xquery( record      => 'Development_CR',
			       id          => $crid,
			       fields      => 'cc_change_set' );

	unless( $_result )
	{
	    $$rc = 1;
	    return "Failed to query cc_change_set object\n", "";

	}

	my( %cs ) = $cq->getResults();

	if($cs{cc_change_set} ne "")
	{
	    $ccChangeSet = $cs{cc_change_set};
	}
	else
	{
	    $_result = $cq->create( record          => 'cc_change_set' );
	    unless( $_result )
	    {
		$$rc = 1;
		return "Failed to create cc_change_set object\n", "";
	    }

	    %cs = $cq->getResults();
	    $ccChangeSet  = $cs{uid};
	    unless( $ccChangeSet )
	    {
		$$rc = 1;
		return "Failed to obtain cc_change_set uid\n", "";
	    }
	}

	$_result  = $cq->edit( record          => 'CC_Change_Set',
			      dbid             => $ccChangeSet,
			      'objects'   => "$ccVobObj" );

	unless( $_result )
	{
	    $$rc = 1;
	    return "Failed to edit the CC_Change_Set to ccVobObj.\n", "";
	}

	my( %editoutput ) = $cq->getResults();
	$_result  = $cq->edit( record          => 'Development_CR',
			      id              => $crid,
			      cc_change_set   => $ccChangeSet );

	unless( $_result )
	{
	    $$rc = 1;
	    return "Failed to edit the CC_Change_Set to CR.\n", "";
	}

	$$rc = 0;
	dprint "RETURNING FROM function relinkCStoCR --> \"$ccVobObj WORK_STARTED\"";
	return "$ccVobObj WORK_STARTED";
    }

    
    $$rc = 0;
    dprint "RETURNING FROM function relinkCStoCR --> \"$output{dbid} $output{name}\"";
    return "$output{dbid} $output{name}";
}

#
# Function that will obtain the vob family oid from the cc_change_set object that is linked in CQ for the given CR.
#

sub getuuidfromCQ
{
    my ($crid,$rc) = @_;

    $$rc = 0;

    dprint("SUB: getuuidfromCQ crid=$crid\n");

	    my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cq)
	    {
		$$rc = 1;
		return "";
	    }
	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $crid,
					fields      => 'cc_change_set.objects' );

	    unless($result)
	    {
		$$rc = 1;
		return "";
	    }

	    my( %op ) = $cq->getResults();
	    my @cset = split(/\,/,$op{'cc_change_set.objects'});
	    my $j=0;
	    foreach(@cset)
	    {
		my ($dbid,$string) = (split(/\s/))[0,1];
		if($string =~ /^WORK_/)
		{
		    ###
		    # CR has a ccchangeset associated with the CR. Will return the ccchangeset's vob uuid back to the caller.
		    ###
		    $result  = $cq->listquery( record      => 'cc_vob_object',
					      filters      => "dbid|EQ|$dbid",
					      fields      =>  'vob_family_uuid' );

		    %op = $cq->getResults();
		    return $op{vob_family_uuid};
		}
	    }
    
    ##
    # If it makes it this far, that means that there is no ccchangeset associated with the CR.
    ##
    
    dprint "NO ACTIVE CCCHANGESET FOR CR  $crid \n";
    return "";
}

# 
# Function that will obtain the dependency information from the CRdep hyperlinks that is attached to the given branchtype. 
# 
# Caller will pass the branchtype, vobadmin and associative arrays %alreadycheck and %crdep. 
# 
# Associative array alreadycheck is used as a flag to see if the   
# CR has been queried. The key will be the CR number and will be assigned a 1 if check 0 if not yet checked.  
#   i.e. $alreadycheck{MOTCM00000001} = 1  ; CR MOTCM00000001 has been checked.  
#        $alreadycheck{MOTCM00000002} = 0  ; CR MOTCM00000002 has not been checked.  
#  
# 
#  
# Associative array crdep will be used to show the dependencies of the given CRs.  
# The key will be the CR and will be assigned to a node which has 2 arrays, an array of dependent CR numbers and   
# an array of brtypes that is associated with the CR.  
#  
#        $crdp{MOTCM002}->{  
#                          CRnumber => (MOTCM001,MOTCM003),  
#                          Brtype =>   (r16.3_dev-001,r16.3_dev-003) 
#                          keybrtype => "r16.3_dev-002"; 
#                         }  
#  
#              MOTCM002->MOTCM001  
#              MOTCM002->MOTCM003  
 
#  Function will return 0 for success and 1 for failure. 


sub getDepFromHlink 
{ 
    my($brtype, $adminvob,$alreadycheck,$crdep) = @_; 
     
    my $cmd="$CLEARTOOL describe -long -ahlink $DEPHLINK brtype:$brtype\@$adminvob";   
    dprint("Executing $cmd \n");   
   
    my @output = qx($cmd);   
    if($?)   
    {   
        return 1; 
    }   
 
    #   
    # This describe command will have the following sample output:   
    #  arnie_r16.4.1_int-01
    #  Hyperlinks:
    #    CRdep@645@/usr/vob/sc/arnie ->  "MOTSB00060128->MOTSB00060127"
    #    CRdep@646@/usr/vob/sc/arnie ->  "MOTSB00060128->MOTSB00060129"
    #    CRdep@647@/usr/vob/sc/arnie ->  "MOTSB00060129->MOTSB00060910"
    #    
   
    my $line; 
    my $hlink;
    foreach $line (@output)   
    {   
        chomp($line);   
         
        # getting rid of the white space in the front of the string.   
        $line =~ s/^\s*//;   
   
   
        if($line =~ /^$DEPHLINK\@/)   
        {   
            # To obtain the text hyperlink by splitting on the \" character. Can assume  
            # this since the hyperlink will be created   
            # using -ttext option.   
                 
            ($hlink,$line) = (split(/\"/,$line))[0,1];   

	    # Getting the hlink by splitting  on string ->
	    $hlink = (split(/->/,$hlink))[0];
	    $hlink =~ s/\s*$//;
             
            # now getting the parent child CRs by splitting on the '->' character.    
   
            my ($pCR, $cCR) = (split(/->/,$line))[0,1];   # the parentCr and childCR.   
 
                 
            dprint("Hyperlink data pCR=$pCR cCr=$cCR\n");   
            push @{$$crdep{$pCR}->{CRnumber}} , $cCR;   
 
            # now getting the branch equiavalent. 
            my $rc; 
            my @branch = getBranchTypeFromCR($cCR, \$rc);  
            if($rc) 
            { 
                return 1; 
            } 
 
            push @{$$crdep{$pCR}->{Brtype}} , $branch[0];   

	    # Adding the hyperlink information
            push @{$$crdep{$pCR}->{hlink}} , $hlink;   

	    # now getting the brtype of the key.
            if($$alreadycheck{$pCR} != 1)
	    {
		$rc; 
		@branch = getBranchTypeFromCR($pCR, \$rc);  
		if($rc) 
		{ 
		    return 1; 
		} 
 
		$$crdep{$pCR}->{keybrtype} = $branch[0];


		$$alreadycheck{$pCR} = 1;   
	    }
        }   
    }   
 
    return 0; 
} 

# checks CQ if the given CR is in the closed state and also get's CR information;
sub IsCRClosedAndCRInformation {
    
    my ($int_cr, $rc, $fieldArray,$fieldoutput)  = @_;
 
	    my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cq)
	    {
		return 0;
	    }

	    my $fieldtoQuery = join(',', @$fieldArray);
	    $fieldtoQuery .= ",state";

	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $int_cr,
					fields      => $fieldtoQuery);

	    unless($result)
	    {
		if($ENV{CQCC_DEBUG})
		{
		    print 'ERROR: [', $cq->getError(), "]\n";
		    print "\n";
		}

		return 0;
	    }

	    my( %output ) = $cq->getResults();
	    
	    if($ENV{CQCC_DEBUG})
	    {
		foreach (keys %output)
		{
		    print "$_ --> $output{$_}\n";
		}
	    }

	    %$fieldoutput = %output;
	    if($output{'state'} =~ m/Closed/i)
	    {
		return 1;
	    }

	    return 0;  # CR State NOT Closed
}

#
# Name: checkCRassignedAndNoOtherActiveBrtype
# Parameters: CR - Full CQ CR number.
#             Brtype - the brtype in CC.
#             uuid - The current vob uuid.
#
# Function that will verify that the CR is still in the assigned state and 
# no other active working branch is listed in the CC Tab.
#
# Returns: NULL - CR is in the right state and no other active brtype exist.
#          ErrorStr - Will give the error statement back to the caller stating either the CR is not in the Assigned state or other working branches are around.
#          
#

sub checkCRassignedAndNoOtherActiveBrtype
{
    my($cr, $brtype, $uuid, %retval_hash)  = @_;
    my $msg;

      
    dprint("IN FUNCTION : checkCRassignedAndNoOtherActiveBrtype \n");
	    my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
	    if(!$cq)
	    {
		$msg = "Failed to create a CQ Session in order to query CR record! \n";
		dprint($msg);
		return $msg;
	    }

	    my( $result ) = $cq->xquery( record      => 'Development_CR',
			id          => $cr,
			fields      => 'state,cc_change_set.objects,Target_Type,CR_Usage' );

	    unless($result)
	    {
		$msg = "Failed to query CR record in CQ! \n";
		dprint($msg);
		return $msg;
	    }

	    my( %stuff ) = $cq->getResults();

	    my @ccchangeset = split(/,/, $stuff{'cc_change_set.objects'});

	    #
	    # Verify the CR is in the assigned state.
	    #
	    dprint("STATE -> $stuff{'state'} \n");

	    if($stuff{'state'} !~ m/assigned/i)
	    {
		$msg = "CR ($cr) is currently in the $stuff{'state'} state. CR must be in the assigned state to execute command \n";
		dprint($msg);
		return $msg;
	    }

	    # If the branch type when created had CR Usage Dev-Integration, check 
            # if developer changed the CR Usage to other than Dev-Integration
	    dprint ("CR_Usage: $stuff{'CR_Usage'}\n");

	    if($retval_hash{IS_DEVINT_USAGE}) {
	      if($stuff{'CR_Usage'} !~ m/Dev-Integration/i) {
		$msg = "CR ($cr) has Usage $stuff{'CR_Usage'} state. Since brtype: $brtype has devint usage tag CR Usage must be Dev-Integration.\n";
		dprint($msg);
		return $msg;
	      }
	    }
	    else {
	      # Also make sure for CR Usage of Dev-Integration the branchtype also has
	      # usage tag of Dev-Integration. This check is to make sure CRs of Usage other
	      # than Dev-Integration were not changed to Dev-Integration after obsoleting 
              # the brtype

	      if ($stuff{'CR_Usage'} =~ m/Dev-Integration/i) {
		$msg = "CR ($cr) has Usage Dev-Integration but branch does not have devint/devbld usage tag in $brtype.Usage of CR must be changed from Dev-Integration to unlock the branch\n";
		dprint($msg);
		return $msg;
	      }

	      # For Dev-CRs that does not have TT=Dev-Build, make sure they have release 
	      # in their brtype. Only time it can happen is if branch type was created 
              # with TT=Dev-Build, the branch type is obsoleted, the CR TT is changed to
              # something other than Dev-Build.
	      dprint ("Target_Type: $stuff{'Target_Type'} REL_ID:$retval_hash{REL_ID}\n");		
              if ($retval_hash{IS_DEV_USAGE}) {
		if (($stuff{'Target_Type'} !~ /Dev-Build/) && ($retval_hash{REL_ID} eq "")) {
		  $msg = "CR ($cr) does not have Target Type Dev-Build. Still it does not have release in the brtype. This CR must have TT Dev-Build to continue\n";
		  dprint($msg);
		  return $msg;
		}
	      }
		
	    }
		

	    #
	    # Go through each change set and verify there is no other active branch.
	    #
	    foreach (@ccchangeset)
	    {
		if(/WORK_/)
		{
		    #
		    # Found active branch .. Will verify it is not the same branch and vob the current trigger is trying to unlock. 
		    # If that is the case that is ok.... 
		    #

		    my $dbid = (split(/\s+/))[0];
		    dprint "dbid from $_ is  $dbid \n";
		    $cq->{_formatResults} = undef;
		    $result = $cq->listquery(record      => 'cc_vob_object',
					     filters	 => "dbid|EQ|$dbid",
					     fields      => "name,object_oid,vob_family_uuid,replica_vob");

		    my( %output ) = $cq->getResults();

		    dprint "$output{object_oid}\n";
		    dprint "$output{replica_vob}\n";

		    if($brtype ne $output{object_oid}  || $uuid ne $output{vob_family_uuid})
		    {
			# Ok .. Found out there is another active branch around ... Will formulate an error message and send back to the caller.
			if($output{replica_vob} ne "")
			{
			    dprint("Ok .. Found out there is another active branch around ... Will formulate an error message and send back to the caller. \n");
			    # if the replica_vob information is there, will use it as part of the message.
			    $msg = "There is currently an active branch ($output{object_oid}) for CR($cr) in vob replica:$output{replica_vob} \n";
			    dprint "$msg \n";

			    return $msg;
			}
			else
			{
			    $msg = "There is currently an active branch ($output{object_oid}) for CR($cr).\n";
			    dprint "$msg \n";
			    return $msg;

			}
		    }
		}
	    }

    return "";
} # end of function......


=head1 NAME

GetValidCRSet -- Presents a list of all assigned CRs for ClearQuest user.

=head1 SYNOPSIS

 GetValidCRSet( $db, $cquser)

 where 

 $db        - ClearQuest database
 $cquser    - CQ Username


=head1 DESCRIPTION

Calls listquery() to query CQ database.  It displays the list of CRs returned from listquery() function.

=head1 RETURN VALUES

 Returns CMBP_SUCCESS and the CRs and their headlines on success.
 Returns CMBP_FAIL on failure.


=cut

#################################################################
sub GetValidCRSet{

   my $db = shift;
   my $cquser = shift;

   my $listCRSonly = 0;
   my $error_message = "";


       my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
       if(!$cq) {
	 return (CMBP_FAIL,"");
       }
    
       my ($result) = $cq->listquery(record   => 'Development_CR',
		     filters	 => "technical_authority|LIKE|$cquser~,State|EQ|Assigned",
		     fields      => "id,Headline");

       unless($result) {
	 return (CMBP_FAIL,"");
       }

       my (%output) = $cq->getResults();
       dprint ("id: $output{id} \n");
       dprint ("headline: $output{Headline}\n");

       my @new_crlist = split(/\,/, $output{id});
       my @headline_list = split(/\,/, $output{Headline});

       # If the two arrays size do not match we have a problem
       # This is okay since that means that there may be a comma in Headline of one of the CRs
       # If this is the case, just return the CR list without the Headlines
       if ($#headline_list != $#new_crlist ) {
	 #return (CMBP_FAIL,"");
         $listCRSonly = 1;
       }

       # If there are no CRs assigned then we can return to calling function

       if (!(scalar(@new_crlist))) {
	 $error_message = "Warning: Query returned no Assigned CRs for user $cquser.\n";
	 return (CMBP_SUCCESS, $error_message);
       }

       $error_message = "The following are CR(s) assigned to you:\n\n";

       my $num;
       for($num=0; $num <= $#new_crlist; $num++) {
         if ($listCRSonly) {
	    $error_message .= "$new_crlist[$num]" . "\n";
         } else {
	    $error_message .= "$new_crlist[$num]" . "\t" . "$headline_list[$num]" . "\n";
         }
       }

       dprint ("crlist from SERVER: $error_message \n");
       return ("CMBP_SUCCESS", $error_message);
	
}

#################################################################
#==============================================================================
# Get ClearQuest Login Information from ".cqparams" file. If this file does
# not exist, then prompt for the information and save it in "~/.cqparams".
#==============================================================================
#################################################################

=head1 NAME

GetLogonParms -- Get the ClearQuest ID and password.

=head1 SYNOPSIS

 GetLogonParms()


=head1 DESCRIPTION

The function checks if .cqparams file exists in $ENV{HOME} on the UNIX client or in $ENV{USERPROFILE} 
on the Windows NT client.  If the file exists, it returns the ClearQuest id and password from the file.  
If the file does not exist,  it prompts the user to enter the ClearQuest id and password, separated by 
spaces.  It then saves the id and encrypted password in the .cqparams file in $ENV{HOME} on UNIX and 
$ENV{USERPROFILE} on Windows NT.

=head1 RETURN VALUES

 Returns ($rc, $user, $pass)

 where

           $rc - 0 on success, 1 on failure
         $user - ClearQuest user id              
         $pass - encrypted ClearQuest password


=head1 B<NOTES>

This function was provided by Rational in the out-of-the-box CQCC integration script.  
The path to .cqparams file was modified to work on Windows NT.

=cut

#################################################################
sub GetLogonParms {
    # look for a file '.cqparams' that will have logon info for the CQ database.

    my $parmfile = "$CQPARAM/.cqparams";
    my ($rc, $user, $token);
	my $saveEuid = $>;
	$> = $<;	##scMergeList

    $SIG{'INT'} = \&CLEANUP;
    $SIG{'QUIT'} = \&CLEANUP;
    if (-s $parmfile) {
        open(PARM, $parmfile);
        while (<PARM>) {
          ($user, $token) = split(" ", $_, 2);
        }
        close PARM;
        # Verify cqparams data
        my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
        if(!$cq) {
            display_msg("Unable to create new CQSession to verify user credentials.\n");
            exit 1;
        }
        my $result = $cq->verifyAuthentication( record => '', cqusername => "$user", osusername => "$CURRENT_USER", cqparamtoken => "$token");
        dprint ("Result of verifyAuthentication=$result");

        if ( $result ) {
            $rc = 0;
        } else {  # Invalid token, so generate new cqparams file
            display_msg("Invalid token in local .cqparams file.\n" .
                "Please re-authenticate your user credentials.\n");
            regenerateCQParams(\$user,\$token,$parmfile);
        }
    }else{  # No cqparams file
        regenerateCQParams(\$user,\$token,$parmfile);
    }

    $> = $saveEuid;	
    return ($rc, $user,$token);
}

sub regenerateCQParams {
    my ($userref,$tokenref,$parmfile) = @_;
    my $maxAttempts = 5;
    my $pass;
    my $rc;

    $SIG{'INT'} = \&CLEANUP;
    $SIG{'QUIT'} = \&CLEANUP;
    # Prompt user 5 times maximum before exiting
    while ($maxAttempts > 0) {
       $maxAttempts--;
       ($rc, $$userref, $pass) = promptUserPass();
       if ($rc != 0){
             last;
       }
       elsif (length($$userref)) {
          if (not length($pass)) {
             display_msg("You have not entered your ClearQuest password. \n" .
                    "Please re-enter your username and password\n", 0);
             $rc = 1;
          }
          else {
             # Verify user and password that has been entered
             my( $cq ) = CQIntegration::CQSession->new(useformatting => 1);
             if(!$cq) {
                    display_msg("Unable to create new CQSession to verify user credentials.\n");
                    $rc = 1;
                    last;
             }

             my $result = $cq->getAuthentication( record => '', cqusername => "$$userref", osusername => "$CURRENT_USER", encryptedpassword => "$pass");

             # Not done unless authentication successful
             if ($result) {
                 my( %stuff ) = $cq->getResults();

                 $$tokenref = $stuff{cqparamsdata};
                 dprint ("Return code of getAuthentication=$result");
                 dprint ("Result of getAuthentication=$$tokenref\n");

                 my $encrpass = $pass;
                 open (PWC,">$parmfile") or die( "Error: can't open $parmfile");
                 chmod(0600,$parmfile) if not $NT;
                 print PWC "$$userref $$tokenref";
                 close PWC;
                 $rc = 0;
                 last;
             }
             # Invalid username and/or password
             else {
                 display_msg("You have entered an invalid CQ username and/or password!\n" .
                     "Please re-enter your username and password\n");
                 $rc = 1;
             }
                 
          }         
       } else {   # Username not provided
          if (not length($pass)){
             display_msg("You have not entered your ClearQuest username and password.\n" .
                    "Please enter your username and password\n", 0);
             $rc = 1;
          }
          else {
             display_msg("You have not entered your ClearQuest username.\n" .
                    "Please re-enter your username and password\n", 0);
             $rc = 1;
          }
       }

          display_msg("You currently have $maxAttempts more attempts.\n");

    }
    if ($rc) {
        display_msg("Authentication of CQ username and password failed!\n");
        exit $rc;
    }
}

sub promptUserPass {

    dprint ("Into promptUserPass...\n");

    my $rc=0;
    my $username="";
    my $passwd="";
    my $enc_passwd="";

    $SIG{'INT'} = \&CLEANUP;
    $SIG{'QUIT'} = \&CLEANUP;

    if (! $NT) {
        if(($ENV{ATRIA_FORCE_GUI} == 1) || ($ENV{XC_HAS_COMMAND} eq "TRUE"))
        {
             display_msg("Authentication of your user credentials cannot be performed from the Unix graphical interface.\n" .
                "Please execute the equivalent command from the command line.\n");
             exit 1;
        }
        # Prompt on Unix CLI
        $|=1;  # Don't buffer STDOUT
        print "Please enter your CQ username: ";
        chop ($username = <STDIN>);

        system "/bin/stty -echo";
        print "Please enter your CQ password: ";
        chop ($passwd = <STDIN>);
        print "\n";
        system "/bin/stty echo";

    } else {   # Executed from Windows client
        eval {
            require Term::ReadKey;
            import Term::ReadKey;
            require Tk;
            import Tk;
        };

        # If executed from GUI rather than CLI
        if(($ENV{ATRIA_FORCE_GUI} == 1) || ($ENV{XC_HAS_COMMAND} eq "TRUE"))
        {
            my $vu_win = MainWindow->new();
            $vu_win->configure(-title=>'Verify CQ User', -background=>'blue');
            $vu_win->geometry('+100+300');

            my $vu_frm1 = $vu_win->Frame(-relief => 'groove',
                                         -borderwidth => 3,
                                         -background => 'blue',
                                         )->pack(-side => 'top',
                                                 -padx => 4,
                                                 -pady => 4,
                                                 -fill => 'x');
            my $vu_lb1 = $vu_frm1->Label(-text => 'Enter Username',
                                         -background => 'blue',
                                         -foreground => 'white',
                                         )->pack(-side => 'left');
            my $vu_en1 = $vu_frm1->Entry(-width => 8,
                                         -background => 'white'
                                         )->pack(-side => 'left',
                                                 -pady => 3);

            my $vu_frm2 = $vu_win->Frame(-relief => 'groove',
                                         -borderwidth => 3,
                                         -background => 'blue',
                                         )->pack(-side => 'top',
                                                 -padx => 4,
                                                 -pady => 4,
                                                 -fill => 'x');
            my $vu_lb2 = $vu_frm2->Label(-text => 'Enter Password',
                                         -background => 'blue',
                                         -foreground => 'white',
                                         )->pack(-side => 'left');
            my $vu_en2 = $vu_frm2->Entry(-show => '*',
                                         -width => 12,
                                         -background => 'white'
                                         )->pack(-side => 'left',
                                                 -pady => 3);

            my $vu_frm3 = $vu_win->Frame(-borderwidth => 3,
                                         -background => 'blue',
                                         )->pack(-side => 'bottom',
                                                 -padx => 4,
                                                 -pady => 4,
                                                 -fill => 'x');

            # 'Cancel' Click Button
            my $vu_button2 = $vu_frm3->Button(-text => 'Cancel',
                                              -background => 'white',
                                              -command => sub {$vu_win->destroy,exit(2)}
                                              )->pack(-side => 'right',
                                              -ipadx => 5,
                                              -ipady => 3,
                                              -padx => 10,
                                              -pady => 3);
            # 'Ok' Click Button
            my $vu_button1 = $vu_frm3->Button(-text => 'Ok',
                                              -background => 'white',
                                              -command => sub { $username=$vu_en1->get,
                                                                $passwd=$vu_en2->get,
                                                                $vu_win->destroy
                                                              }
                                              )->pack(-side => 'right',
                                                      -ipadx => 5,
                                                      -ipady => 3,
                                                      -padx => 10,
                                                      -pady => 1);

            # Hitting Return/Enter key performs same actions as 'Ok' button
            $vu_en2->bind('<Return>' => sub{ $username=$vu_en1->get,
                                             $passwd=$vu_en2->get,
                                             $vu_win->destroy 
                                           });

            MainLoop();
        } else {  # Windows CLI prompt

        $|=1;  # Don't buffer STDOUT
        print "Please enter your CQ username: ";
        chop ($username = <STDIN>);
        print "Please enter your CQ password: ";

        my $curChar = 0;
        while (ord($curChar) != 13) {
            $curChar = ReadKey(-1);
             $passwd .= $curChar;
        }

        $passwd = substr($passwd,0,length($passwd)-1); #$ remove last character.
        print "\n";
        }
    }

    # Return encrypted password
    ($rc, $enc_passwd) = CQIntegration::CQSession::encryptPW($passwd);
    if ($rc) {
        return (CMBP_SUCCESS, $username, $enc_passwd);
    } else {
        return (CMBP_FAIL, $username, $enc_passwd);
    }
}

sub CLEANUP {
    display_msg("Caught Interrupt (^C), Aborting...\n");
    if (! $NT) {
        # For Unix, also reset stty echo
        system "/bin/stty echo";
    }
    exit(1);
}

1;


