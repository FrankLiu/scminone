###############################################
# Use variables from site.cfg                 #
###############################################
use vars qw($CC_VOBADM_LST);

package CMBlueprint::Branch;

#######################################################################

=head1 NAME

CMBlueprint::Branch - module to obtain information or to perform CC operations 
on branches

=head1 EXPORTS

has_vers_subbranches has_branch_instances LockBrtype RmBrtype RenameBrtype
  
=head1 DESCRIPTION

B<CMBlueprint::Branch> is a module is used to obtain branch specific information 
such as finding if a branch type has instances or if an element has versions on
a branch.

This module is also used to perform branch specific CC operations such as removing, 
renaming or locking a branch type.

=cut

#######################################################################

use strict;
use vars qw(@ISA @EXPORT);
use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(has_vers_subbranches has_branch_instances LockBrtype RmBrtype RenameBrtype);


use vars qw($CLEARTOOL $TMPDIR);
use CMBlueprint;
use CMBlueprint::ClearQuest;

###########################################################################

=head1 NAME

has_vers_subbranches -- Returns 1 if the branch has versions or subbranches.

=head1 SYNOPSIS

 has_vers_subbranches($branch)

 where $branch is the name of the branch


=head1 DESCRIPTION

Do a 'cleartool lsbranch' on $branch.  If the branch has
only the 0th version, t'cleartool lsbranch' returns exactly
2 lines.  Return 0 if the output consists of only 2 lines.
Return 1 otherwise.

=head1 RETURN VALUES

 Return 1 if there are versions or subbranches on the branch
 Return 0 otherwise.


=cut

##########################################################################
sub has_vers_subbranches
{
  my $branch = shift @_;

  my $cmd = "$CLEARTOOL ls \"$branch\"";
  prep_cmd(\$cmd);

  my $output = `$cmd`;

  my @vers   = split("\n", $output);

  if (@vers == 2){
     return 0;
  }
  else{
     return 1;
  }
}

##########################################################################


=head1 NAME

LockBrtype -- Lock the Branch type for everybody except the TA and the VOBADMs.

=head1 SYNOPSIS

  LockBrtype($brtype)

  where $brtype is the name of the branch type.


=head1 DESCRIPTION

Get the list of excluded users: $ENV{CLEARCASE_USER} and users in
@::CC_VOBADM_LST in site.cfg file.  Lock the branch type with '-nusers' option.

=head1 RETURN VALUES

NONE

=cut

#################################################################
sub LockBrtype {
    my $brtype = shift;

	##if there is an admin vob, the instance type will share the lock
	##with the type obj in the admin vob
	##skip it if it has been locked in either vob
	my @lock = qx{$CLEARTOOL lslock -s brtype:$brtype};
	return if ( $#lock >= 0 );

    ###########################################
    # Add the user to the CC_VOBADM_LST       #
    # so that the user and the users in the   #
    # CC_VOBADM_LST are excluded from the lock#
    ###########################################
    push(@::CC_VOBADM_LST, $ENV{CLEARCASE_USER});

    my $nusers = uc(join(",", @::CC_VOBADM_LST)) . "," .
                 lc(join(",", @::CC_VOBADM_LST));

    my $cmd = qq#$CLEARTOOL lock -nusers $nusers brtype:$brtype#;
    dprint($cmd . "\n");
    prep_cmd(\$cmd);
    `$cmd`;
}

#################################################################

=head1 NAME

RmBrtype -- Remove the specified branch type.

=head1 SYNOPSIS

 RmBrtype($brtype)

 where

 $brtype - name of the branch type

=head1 DESCRIPTION

Removes the specified branch type.

=head1 RETURN VALUES

NONE

=cut

#################################################################
sub RmBrtype {
    my $brtype = shift @_;

    display_msg("The post mkbrtype trigger " .
          "will attempt to remove branch type $brtype.\n" .
          "(ClearCase may display some error messages after this;\n" .
          "they are expected and can be ignored).",2);
    my $cmd = qq#$CLEARTOOL rmtype brtype:$brtype#;
    dprint $cmd . "\n";
    prep_cmd(\$cmd);
    `$cmd`;
}

#################################################################

=head1 NAME

RenameBrtype -- Rename a branch type.

=head1 SYNOPSIS

 RmBrtype(\%orig_brtype_info, $new_crid)

 where

 \%orig_brtype_info - reference to a hash containing old branch info.

      The hash must have the following keys:

        ORIG_CQDB - CQ database name as entered by the user.
        ORIG_DBID - CQ CR number as entered by the user.

 $new_crid - New ClearQuest CR ID,
             containing the CQ database name and 8-digit CR number.


=head1 DESCRIPTION

Generates a new branch type name by replacing the old CQ database name and the old CQ DBID with the
new CQ database name and the new CQ DBID.  If the old branch type name did not contain the CQ database 
name and if the actual CQ database name is the same as the new CQ database name, the new branch type 
name does not contain the CQ database name.  If the ORIG_DBID in the old branch type name does not 
have the leading zeros, the leading zeros in the DBID in the generated branch type are dropped off.  
The function checks if the new branch type already exists in the VOB.  If it does, the function returns 
with fail status.  If not, it renames the old branch type with the new name.

=head1 RETURN VALUES

NONE

  Returns 0 and the new branch type name on SUCCESS
  Returns 1 on FAILURE

=cut

#################################################################
sub RenameBrtype {
   my ($orig_brtype_info, $act_cqdb, $act_crnum, $new_crid) = @_;
   my ($orig_brtype, $new_brtype);
   my $rc = 0;

   $orig_brtype = $ENV{CLEARCASE_BRTYPE};
   $new_brtype = $orig_brtype;

   my ($new_cqdb, $new_crnum);
   ($rc, $new_cqdb, $new_crnum) = ParseCrId($new_crid);
   return ($rc, $new_brtype) if $rc;

   my ($orig_cqdb, $orig_crnum) = ($$orig_brtype_info{ORIG_CQDB},
                                   $$orig_brtype_info{ORIG_DBID});

   dprint("Rename Brtype: orig_cqdb = $orig_cqdb, orig_crnum = $orig_crnum, act_cqdb  = $act_cqdb, act_crnum = $act_crnum, new_cqdb  = $new_cqdb, new_crnum = $new_crnum\n");

   my $cnt = $orig_crnum =~ tr/0-9//;
   $new_crnum = sprintf("%0$cnt" . "d", $new_crnum);

   if (not length($orig_cqdb)){
       if ($act_cqdb eq $new_cqdb){
          $new_brtype =~ s/(-)?\d+$/$1$new_crnum/;
       }
       else{
          $new_brtype =~ s/(-)?\d+$/-$new_cqdb$new_crnum/;
       }
   }
   else{
      $new_brtype =~ s/-[A-Za-z]+\d+$/-$new_cqdb$new_crnum/;
   }

   $orig_brtype .= "@" . $ENV{CLEARCASE_VOB_PN};
   $new_brtype .= "@" . $ENV{CLEARCASE_VOB_PN};

   display_msg("Renaming branch type $orig_brtype to $new_brtype ....",3);

   my $tmpfile = "$TMPDIR/rename$$.tmp";
   my $cmd = qq#$CLEARTOOL lstype -short brtype:$new_brtype 2>$tmpfile#;
   prep_cmd(\$cmd);
   `$cmd`;
   if ( $? == 0){
      $rc = 1;
      display_msg("Branch type $new_brtype already exists.",1);
      unlink $tmpfile;
      return($rc, $orig_brtype);
   }
   else {
#     $cmd = qq#$CLEARTOOL rename -c "Rename by postMkbrtype trigger" brtype:$orig_brtype brtype:$new_brtype#;
      $cmd = qq#$CLEARTOOL rmtype brtype:$orig_brtype#;
      dprint $cmd . "\n";
      prep_cmd(\$cmd);
      `$cmd`;
      if ( $? == 0){
         $cmd = qq#$CLEARTOOL mkbrtype -c "$ENV{CLEARCASE_COMMENT}" brtype:$new_brtype#;
         prep_cmd(\$cmd);
         `$cmd`;
      }

      unlink $tmpfile;
      return ($rc, $new_brtype);
   }
}


##########################################################################

=head1 NAME

has_branch_instances -- Checks if a branch type has instances

=head1 SYNOPSIS

 has_branch_instances($brtype, $view_xpn)

 where

      $brtype   - ClearCase branch type
      $view_xpn - ClearCase View-extended path


=head1 DESCRIPTION

Do a 'cleartool find $view_xpn -branch brtype\($brtype\) -print'.  If the find command returns something, it means brtype has instances. Otherwise return 0.

=head1 RETURN VALUES

Returns 1 if branch type has instances.  Returns 0 otherwise.

=cut

#################################################################
sub has_branch_instances
{
    my ($brtype, $view_xpn) = @_;

    my $cmd = "$CLEARTOOL find $view_xpn -branch brtype\($brtype\) -print";
    prep_cmd(\$cmd);

    my $output = `$cmd`;

    length($output)?return 1:return 0;
}

##########################################################################

1;
