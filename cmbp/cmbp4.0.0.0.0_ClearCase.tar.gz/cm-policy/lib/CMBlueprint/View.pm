package CMBlueprint::View;

#######################################################################

=head1 NAME

CMBlueprint::View - module to obtain information on CC views

=head1 EXPORTS

GetViewExtendedRoot get_active_view get_view_extended_path
  
=head1 DESCRIPTION

B<CMBlueprint::View> is a module is used to obtain view specific information 
such as getting the view root, the view extended path, getting an active view. 

=cut

#######################################################################


use strict;
use vars qw(@ISA @EXPORT);
use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(GetViewExtendedRoot get_active_view get_view_extended_path);

use vars qw($CLEARTOOL);
use CMBlueprint;

######################################################################
sub GetViewExtendedRoot {

    my $default_view_root = shift @_;
    my $view_root;

    if ( $NT) {
       $view_root = $default_view_root if defined $default_view_root;
       $view_root = "M:" unless length($view_root);
    }
    else {
       $view_root = "/view";
    }
    return $view_root;
}

##########################################################################
=head1 NAME

get_active_view -- Returns an active view on the CC client

=head1 SYNOPSIS

 get_active_view()

=head1 DESCRIPTION

Do a 'cleartool lsview' to get a list of views on the client.  Views with an '*' in the 
first column are active views (views that have been started on the client).  Return the 
first active view in the list.

=head1 RETURN VALUES

Returns an active view on the client.  If no active views, then returns an empty string.

=cut

#################################################################
sub get_active_view
{
    my $cmd = "$CLEARTOOL lsview";
    my $view_tag;

    if (open CMD, "$cmd |"){
      while (<CMD>){
        next unless /^\*\s(\S+)/;
        $view_tag = $1;
        last;
      }
    }
    close CMD;

    return $view_tag;
}

#####################################################################
=head1 NAME

get_view_extended_path -- Get the view extended path          

=head1 SYNOPSIS

 get_view_extended_path($vob_tag, $view_tag)

 where

      $vob_tag - ClearCase VOB tag
      $view_tag - ClearCase View tag


=head1 DESCRIPTION

Append the view_tag and the vob_tag to the VIEW_DRIVE to get the view extended path.                                                          

=head1 RETURN VALUES

Returns view_extended_path.  

=cut

#################################################################
sub get_view_extended_path($ $)
{
    my ($vob_tag, $view_tag) = @_;

    my $view_extended_path = "";

    my $view_drive = GetViewExtendedRoot();

    $view_extended_path = "$view_drive/$view_tag" . $vob_tag;

    return $view_extended_path;
}

##########################################################################

1;