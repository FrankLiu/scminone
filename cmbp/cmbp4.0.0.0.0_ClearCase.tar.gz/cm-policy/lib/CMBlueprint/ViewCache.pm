package CMBlueprint::ViewCache;

#######################################################################

=head1 NAME

CMBlueprint::ViewCache - module to cache CC operation info in view storage

=head1 EXPORTS

fetch_opcache finalize_opcache Get_View_Storage Is_Process_Running
  
=head1 DESCRIPTION

B<CMBlueprint::ViewCache> is a module to create an maintain a
"cache" of information about a given ClearCase operation that
takes place in a view.

During execution of a single ClearCase command, many
triggers may fire for individual elements or element
versions. Information often needs to be recalculated for each
element/version affected by a single command, even though the
information stays constant throughout the execution of the
command across all items it affects. A common example is the
CR-ID associated with a checkout. If that information could be
stored somewhere once near the beginning of the command, and
then looked up later during the command's operation (even across
trigger invocations) it would greatly improve the performance
and usability of the ClearQuest/ClearCase integration.

This is the purpose of the B<CMBlueprint::ViewCache> module: to
realize the implementation of an "operation information cache"
that can be stored in the view storage area and looked-up and
refreshed across trigger invocations for the same command.

=cut

###################################################################################

use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);
use constant SUPPORTED_PERL => 5.006;

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(Get_View_Storage Is_Process_Running fetch_opcache finalize_opcache);

BEGIN {
  use File::Basename;
  my $dirname = dirname($0);
  unshift(@INC, "$dirname/../../lib");
 };

#######################################################

use CMBlueprint qw(:DEFAULT) ;
use CMBlueprint::ClearQuest;

#######################################################
# Variables used in fetch_opcache and finalize_opcache
my $OPCACHE_FETCHED = 0;
my $OpCache_FileName = '';
my %OpCache_Data = ();
########################################################

=head1 NAME

Get_OpCache_FileName - Return the filename with the complete
path where the operation cache information has to be stored

=head1 SYNOPSIS

 Get_OpCache_FileName($view_tag)

=head1 DESCRIPTION

This function is used to return the complete file name of where
to store the cache information if required for a clearcase
operation the data stored in this file will be used to read it
later and verify if the information is valid and whether it can
be used for doing the deisred cc operations without prompting
user for a cr id. The file will be stored in the view private
storage area and will be named using the following convention
username_opcache.dat - username is the name of the user doing
the operation

=head1 RETURN VALUES

 returns $opcache_filename
 example of a sample value returned is
 \\il27-1988\CCDATA\JSHAH2_DefaultView.vws\JSHAH2_opcache.dat

 \\il27-1988\CCDATA\JSHAH2_DefaultView.vws - is the location of view storage
 JSHAH2_opcache.dat - file name in which the information will be stored

=cut

sub Get_OpCache_FileName{
    my ($view_tag, $viewstore) = @_;
    dprint("Viewstore is $viewstore \n");
    my ($opcache_filename, $opcache_dir, $view_storage_path);
    if($NT){
        $opcache_dir = $TMPDIR;
        if(-e $opcache_dir){
            $opcache_filename = $opcache_dir.$PATH_DELIMITER.$CURRENT_USER."_opcache.dat";
            dprint("The Opcache file for NT will be written at $opcache_filename \n");
            return $opcache_filename;
        }
    }else{
        my $unix_viewstore = (split(',', $viewstore))[0];
        $opcache_dir = $unix_viewstore.$PATH_DELIMITER.$view_tag.".vws";
        dprint("The Opcache dir for unix is $opcache_dir \n");
        if(-e $opcache_dir){
            $opcache_filename = $opcache_dir.$PATH_DELIMITER.$CURRENT_USER."_opcache.dat";
            dprint("The Opcache file for unix will be written at $opcache_filename \n");
            return $opcache_filename;
        }

    }

    $view_storage_path = Get_View_Storage($view_tag);
    $opcache_filename = $view_storage_path.$PATH_DELIMITER.$CURRENT_USER."_opcache.dat";
    dprint ("\n*File name in which data will be written using lsview is $opcache_filename \n");
    return $opcache_filename;
}
##################################################################################################

=head1 NAME

Get_View_Storage - Get the path to where the specified view_tag is located

=head1 SYNOPSIS

Get_View_Storage($view_tag)

=head1 DESCRIPTION

Returns the path where the specified view_tag is located by
executing the command "CLEARTOOL lsview $view_name" and then
parse the result to get the path where the view is stored,
if no view_tag name is specified then the the view_tag of the
current view is used

=head1 RETURN VALUES

returns the path where the specifed view is located

=cut

sub Get_View_Storage {
    #In this function pass the view_tag as a parameter and
    #if not passed then use the environment variable

    my $view_tag = shift @_;
    #If view tag is not passed as a parameter then default it
    #to the view tag of current view
    if(!length($view_tag)){
        $view_tag = $ENV{'CLEARCASE_VIEW_TAG'};
    }

    ################################
    #need to use ct_subcmd in future
    ################################
    dprint("Just before executing the lsview command \n");

    my $cmd = "$CLEARTOOL lsview $view_tag";
    my $result = `$cmd`;
    #######################################################
    #Need to verify what happens when view name has a space
    #######################################################
    $result =~ /^[\* \s{1}]\s+\S+\s+(\S+)$/;
    return $1;
}
###################################################################################

=head1 NAME

Write_OpCache - Write the information in to a cache file

=head1 SYNOPSIS

Write_OpCache($hashref, $opcache_filename)

=head1 ARGUMENTS

The C<$hashref> parameter should be a reference to a hash. The
C<$opcache_filename> parameter should be the path to the file
to which the view-cache information shold be written.

The associative array (hash) referenced by the C<$hashref> parameter
should contain the following key/value pairs:

=over 5

=item C<CRID>

The value corresponding to this keyword should be the ClearQuest
ID of a CR corresponding to the current ClearCase operation.

=item C<CRID_ORIGIN>

The value corresponding to this keyword should indicate the
item or mechanism used to automatically determine the CR ID
(if it could be automatically determined).  It should be one of
"viewtag", "brtype", or "mergelock".

=back

=head1 DESCRIPTION

Write the following information in the op cache data file

 *) CR ID - CR ID to be used for subsequent operations of the same command
 *) CR ID origin - identifies the item or mechanism used to automatically
    determine the CR ID (if it could be automatically determined). It might
    have been obtained from a viewtag, a brtype, a brname, or a mergelock.
 *) hostid - host from which the command is being executed
 *) PPID(Parent process ID) - process ID of the parent process
 *) Timestamp - time when the file was written

this data will be later queried to verify whether the
information stored in this file can be used. The Data::Dumper
module is used to write the information to the file, this
module takes care of writing the hash in the correct format
in the file. The information stored in the file can easily be
read back and by doing an eval the hash can be recreated

=head1 RETURN VALUES

return 0 if the information could be written in the file
return 1 if the information could not be written in the file

=cut

sub Write_OpCache{

    use Data::Dumper;
    my ($hashref,$opcache_filename) = @_;

    my %cache_data= ();
    my ($crid, $crid_origin);

    if (ref $hashref) {
       $crid = $hashref->{'CRID'} || "";
       $crid_origin = $hashref->{'CRID_ORIGIN'} || "";
    }
    else {
       $crid = $hashref || "";
       $crid_origin = "";
    }

    $cache_data{'CRID'} = $crid;
    $cache_data{'CRID_ORIGIN'} = $crid_origin;
    $cache_data{'HOSTID'} = $HOSTNAME;
    $cache_data{'PPID'} = $ENV{'CLEARCASE_PPID'};
    $cache_data{'TIMESTAMP'} = time();

    if(open (FILE, "> $opcache_filename")){
        print FILE Data::Dumper->Dump([\%cache_data], ["*cache_data"]);
        close FILE;
        return 0;
    }else{
        display_msg( "Warning: can't open $opcache_filename for writing $!",2);
        return 1;
    }

}
##############################################################################

=head1 NAME

Is_OpCacheWriteable - This function verifies whether it is ok
to overwrite the existing opcache file

=head1 SYNOPSIS

Is_OpCacheWriteable($opcache_filename)

=head1 DESCRIPTION

Function determines whether to write the opcache file. The
following logic is used:

 if the opcache file does not exist write the file

 if the file exists and the time stamp has expired overwrite the file

 if the file exists and the hostid from which the command is
 executed is same as the hostid stored in the opcache file
 and the PPID specified in the cache file is still running
 then donot overwrite the file

 else if process with PPID is not running overwrite the file.

=head1 RETURN VALUES

 return 1 - if Ok to overwrite
 return 0 - if cannot overwrite

=cut

sub Is_OpCacheWriteable{
    my (%cache_data,$rc);

    my ($opcache_filename, $opcache_timeout) = @_;

    #Verify the file name exists
    unless(-e $opcache_filename) {
        dprint("It is safe to overwrite the file because file does not exist\n");
        return 1;
    }else{
        ($rc,%cache_data) = Eval_OpCacheFile($opcache_filename);
        unless($rc){
            #Now need to verify all the constraints when to overwrite the file
            my $time_interval = abs(time() - $cache_data{'TIMESTAMP'});
            #If the below condition is true then it the CR ID can be used
            if($time_interval > $opcache_timeout){
                #It is safe to overwrite the file because the time stamp on the file has expired
                dprint("It is safe to overwrite the file \n");
                return 1;
            }elsif( lc($cache_data{'HOSTID'})eq lc($HOSTNAME) and Is_Process_Running($cache_data{'PPID'})) {
                #Do not overwrite the file because the PID is still running
                dprint("It is not safe to overwrite the file \n");
                return 0;
            }else{
                #The PID has terminated so ok to overwrite the file
                dprint("It is safe to overwrite the file because process which wrote the file terminated\n");
                return 1;
            }
        }else{
            #Eval Opcache returned error so do not overwrite the file
            dprint("It is not safe to overwrite the file because eval opcache returned error\n");
            return 0;
        }

    }
}
################################################################################################

=head1 NAME

Is_OpCacheDeletable - This function verifies whether it is ok
to overwrite the existing opcache file

=head1 SYNOPSIS

Is_OpCacheDeletable($opcache_filename)

=head1 DESCRIPTION

Function determines whether the current operation can delete
the opcache file. The following logic is used

 if the opcache file does not exist no need to delete the file

 if the file exists and hostid and PPID match, ok to delete the file

 else do not delete the file

=head1 RETURN VALUES

returns 1 if the current operation can delete the opcache file
retunrs 0 if the current operation cannot delete the opcache file

=cut

sub Is_OpCacheDeleteable{

    return 0 unless $NT;

    my (%cache_data,$rc);
    my $opcache_filename = shift @_;

    if(-e $opcache_filename){

        ($rc,%cache_data) = Eval_OpCacheFile($opcache_filename);
        unless($rc){
            #The file can be deleted by a process if the PID that wrote the file is same as the PID which
            #is trying to delete the file
            if($cache_data{'PPID'} == $ENV{'CLEARCASE_PPID'} and lc($cache_data{'HOSTID'}) eq lc($HOSTNAME) ){
                dprint("Can delete the file \n");
                return 1;
            }else{
                dprint("Cannot delete the file \n");
                return 0;
            }
        }else{
            #Cannot delete the file Because eval_opcache returned error
            dprint("Cannot delete the file because eval_opcache returned error\n");
            return 0;
        }
    }else{
        dprint("No need delete the file because file does not exist\n");
        return 0;
    }
}
################################################################################################

=head1 NAME

Eval_OpCacheFile

=head1 SYNOPSIS

Eval_OpCacheFile($opcache_filename)

=head1 DESCRIPTION

This subroutine evals the opcache file and recreates the hash

=head1 RETURN VALUES

 ($rc, %cache_data)

$rc = 1 if Eval_OpCache failed else $rc = 0;

%cache_data = Hash containing the data read from the OpCache
file, information in this hash should only be used if $rc == 0

=cut

sub Eval_OpCacheFile{

    my $opcache_filename = shift @_;
    my %cache_data = ();
    my $rc = 0;

    unless (open (FILE, "< $opcache_filename")) {
        display_msg( "Warning: can't open data file $!",2);
        $rc = 1;
    }else{
        local $/ = undef;
        eval <FILE>;

        if($@){
            dprint ("error encountered during eval file error is $@ \n");
            $rc = 1;
        }

        close FILE or display_msg( "Warning: can't close the data file $!" ,2);
    }

    return ($rc, %cache_data);
}
################################################################################################

=head1 NAME

Is_Process_Running - check whether the process with specified pid is running

=head1 SYNOPSIS

=head1 DESCRIPTION

This subroutine will be passed a pid and will return a value of
0 or 1 depending on whether the process is running or has died.

The logic to check whether the process is running will be
different depending on the perl version used and the platform
on which the trigger is being executed. The kill funtion with
a signal number 0 passed to it returns checks whether the
process is alive this will be used for the following environment

 NT + only perl 5.6
 Unix + any perl version above 5.0

For NT + any perl version above 5.0 but less than 5.6 need
to use different logic because kill function with a signal
number 0 passed to it actually kills the process

=head1 RETURN VALUES

 0 - If the process is not running and hence can overwrite the existing file
 1 - If the process is running and cannot overwrite the existing file

=cut

sub Is_Process_Running {

    my $pid = shift @_;
    dprint("Perl version is $] \n");
    if($NT and $] < SUPPORTED_PERL){
        #If client is NT and perl version being used is less than 5.6 then the
        #kill function actually kills the process so kill cannot be used
        # so we use the Win32::API perl module to figure this out ...
        dprint ("Client is NT and perl version being used is less than 5.6 \n");
        return _NT_522_Is_Process_Running($pid);
    }else{
        dprint ("It is safe to use kill to find out whether the process is running or has died \n");
        return kill (0,$pid);
    }
}

################################################################################################

=head1 NAME

Query_OpCache - query the cache file stored in view storage area and
return the cache-information if it is relevant.

=head1 SYNOPSIS

 my $hashref = Query_OpCache($opcache_filename)

=head1 DESCRIPTION

The following logic is used to determine whether the information
stored in opcache file if it exists is relevant:

 if file does not exist then return '' indicating the CR ID
 cannot be retrieved from the opcache file

 if file exists eval the file to retrieve the information and
 then need to verify whether the information is relevant using
 the logic below

    if hostid is same and the PPID stored in the file is same
       as current PPID and time_interval is less than expiry_time
    then CRID stored is relevant and use it
    else return ''

=head1 RETURN VALUES

 '' If information is not found or is not relevant

 $hashref (a reference to a hash containing the cache-data) otherwise

=head1 NOTES

=cut

sub Query_OpCache{

    #First need to verify if the opcache data file exists, if
    #the file does not exist then set a flag so that opcache
    #file is written at the end of postco command

    #3 Things can happen when Op Cache is queried,
    # a either the file does not exist
    #   - In this case create the file and write info
    # b the information stored is not relevant
    #    - In this case update the info stored
    # c Information stored is relevant and can be used
    #    - Get the CR ID and other info and continue

    my (%cache_data, $rc);
    my ($opcache_filename,$opcache_timeout) = @_;

    #Verify the file name exists
    if (-e $opcache_filename) {

        ($rc, %cache_data) = Eval_OpCacheFile($opcache_filename);
        unless($rc){
            #The value of hash key CR ID is pertinent
            #Do all the validation over here to make sure whether
            #the information stored in the opcache data file is relevant
            #If everything is fine return the crid

            #here we check whether it is ok to use the
            #information stored in the file the information
            #can be used only if the ppid and hostid is the
            #same and the difference between the current time
            #and the time stamp on the file time interval is
            #less than the specified expiry time.

            my $time_interval = abs(time() - $cache_data{'TIMESTAMP'});
            dprint ("\$HOSTNAME => $HOSTNAME , \$time_interval => $time_interval, PPID => $ENV{CLEARCASE_PPID} \n ");
            #If the below condition is true then it the CR ID can be used
            if(lc($cache_data{'HOSTID'}) eq lc($HOSTNAME) and $cache_data{'PPID'} == $ENV{'CLEARCASE_PPID'} and $time_interval <= $opcache_timeout){
                dprint ("CRID retrieved from cache is $cache_data{'CRID'} \n");
                return  { %cache_data };

            }else{
                #The information stored in the file is not valid
                #and it is some other process trying to access
                #the file, in such scenario need to overwrite
                #the file, but the file can be overwritten only
                #if the process with the PID specified in the
                #file is complete else do not overwrite the file
                dprint ("Information did not match so returning \n");
                return '';
            }
        }else{
            #Eval_Opcache returned error hence returning ''
            dprint("Eval_OpCache returned error in Query_OpCache so returning \n");
            return '';
        }

    }else{
        #The file does not exist and need to recreate the file
        dprint ("File does not exist so returning \n");
        return '';
    }

}
#############################################################################################


=head1 NAME

fetch_opcache - obtain the cache file that is stored in the view storage area 
and return the ref to the hash formed with the cache-information.

=head1 SYNOPSIS

 $hashref = fetch_opcache()

=head1 DESCRIPTION

This subroutine is one of the interfaces for the ViewCache package.
If the cache file, stored in view storage area, was not already fetched 
earlier during the clearcase operation, it obtains the cache file and
stores the information in a global hash and returns the reference (not a copy) 
to this hash.

Calls the Get_OpCache_FileName and the Query_OpCache subroutines of the same 
package, to obtain the path to the cache file and a copy of the reference to the hash 
containing the cache data, respectively. Once the cache data has been obtained, 
it sets a variable OPCACHE_FETCHED so as to avoid the clearcase operation the overhead 
of a file I/O to obtain the same information again.

=head1 RETURN VALUES

 $hashref - Reference (not a copy of the reference) to the hash containing information stored 
 in the cache file. 

=cut

sub fetch_opcache ( ;$ ) {
   
   return  \%OpCache_Data if ($OPCACHE_FETCHED);
   my $viewtag = shift || $ENV{CLEARCASE_VIEW_TAG};

   $OpCache_FileName = Get_OpCache_FileName($viewtag, $::UNIX_VIEWSTORE);
   my $cache_ref = Query_OpCache($OpCache_FileName, $::OPCACHE_TIMEOUT);
   if (ref $cache_ref) {
      %OpCache_Data = %$cache_ref;
   }
   else {
      $OpCache_Data{'CRID'} = $cache_ref || "";
   }

   if ($OpCache_Data{'CRID_ORIGIN'}) {
      dprint "perf", "# fetched opcache for CR $OpCache_Data{'CRID'} " .
                     "w/crid-origin == $OpCache_Data{'CRID_ORIGIN'}\n";
   }

   $OPCACHE_FETCHED = 1;
   return \%OpCache_Data;
}

##############################################################################################

=head1 NAME

finalize_opcache - this subroutine either writes cache-data to a file in the 
view storage area or if NT then deletes this file.

=head1 SYNOPSIS

 finalize_opcache ($MustWrite_OpCache)

  where
  $MustWrite_OpCache - parameter to indicate if the cache data file is to be written or not. 
					  Has values of 1 or 0.

=head1 DESCRIPTION

This subroutine is one of the interfaces for the ViewCache package. if the paramater 
passed to this sub has a value '1', then this function either writes (or overwrites) 
the cache data to the file in the view storage area. However if the environment variable,
CLEARCASE_END_SERIES is 1, meaning that the CC operation is on the last file, then for 
NT, checks if the cache file in the view storage is deletable and if it is then deletes 
the file.

=head1 RETURN VALUES

NONE 

=cut

sub finalize_opcache {
  my $MustWrite_OpCache = shift;
  if ($MustWrite_OpCache and $OpCache_Data{'CRID'}) {
     unless ($OpCache_FileName) {
        $OpCache_FileName = Get_OpCache_FileName($ENV{CLEARCASE_VIEW_TAG},
                                                 $::UNIX_VIEWSTORE);
     }
     if (Is_OpCacheWriteable($OpCache_FileName, $::OPCACHE_TIMEOUT)) {
        # Write Opcache will verify whether to overwrite the existing data by
        # using a particular logic along with use of function Is_Process_Running
        dprint ("before writing Opcache \n");
        Write_OpCache(\%OpCache_Data, $OpCache_FileName);
        dprint "perf", "# wrote opcache for CR $OpCache_Data{'CRID'} " .
                       "w/crid-origin == $OpCache_Data{'CRID_ORIGIN'}\n";
     }
  }
  # Only if the file exists and NT and Clearcase end series variable is 1
  # i.e this is the last in the series of file and the process trying to
  # delete the file is same as the process that wrote the file then allow
  # deletion of the file
  # Is_OpCacheDeleteable
  unless ($OpCache_FileName) {
     $OpCache_FileName = Get_OpCache_FileName($ENV{CLEARCASE_VIEW_TAG},
                                              $::UNIX_VIEWSTORE);
  }

  if($ENV{'CLEARCASE_END_SERIES'} == 1 and  length($OpCache_FileName)
                         and Is_OpCacheDeleteable($OpCache_FileName)){
     #Delete the opcache file
     dprint('Before deleting opcache');
     unlink($OpCache_FileName) or die( "Error: can't delete file $OpCache_FileName $! \n"); 
  }
}

#################################################################################################

=begin INTERNAL_FUNCTION 

_NT_522_Is_Process_Running - Checks if the process is running by using the NT
Win32::API module. Used only for NT ActiveState Perl build 522. Since this
function is only a temporary solution and this should not be called from any
other customer triggers or scripts, this function is not being documented explicitly!!!

=end INTERNAL_FUNCTION 

=cut

sub _NT_522_Is_Process_Running {

  # use this function only for NT, return 1 just in case someone tried
  # to call this from a UNIX script.
  
  return 1 unless ($NT); 
  
  # this function requires the Win32::API perl module, so if the module has not
  # been required yet, then add the appropriate location the to @INC variable
  # and require the module.

  unless (defined &Win32::API::new) {

    # find location of this current file CMBlueprint/ViewCache.pm,
    # $INC{'CMBlueprint/ViewCache.pm'} should exist if the current file has been
    # used or required.
    my $dirname = dirname($INC{'CMBlueprint/ViewCache.pm'});
    
    # push the site/lib directory to the @INC where the Win32::API is present in
    # case the user does not have it installed.
    push(@INC, "$dirname/../../site/lib");

    eval {
      require Win32::API;
    };

    if ($@) {

      # if we got any eval errors, then return 1;
      dprint("error occured when trying to require Win32::API module :$!: \n Hence
      returning 1 for this function \n");

      # print the current INC hash and @INC array...
      if (DEBUGGING) {
        print("\@INC array has the value @INC and the \%INC hash has the following keys and values:\n");
        foreach (keys %INC) {
          print("key of \$INC{$_}  = $INC{$_} \n");
        }
      }
      return 1;
      
    } else {
      dprint("require Win32::API succeded! \n");
    }
  } else {
    dprint("Win32::API already required... \n");
  }

  my $pid = $_[0];

  # be paranoid, by default the process exists do not overwrite file..
  my $retval = 1; 

  # this is just me being paranoid here, just checking if the module has been
  # required correctly...
  if (defined &Win32::API::new) {
    my $call_win32api_func = new Win32::API("kernel32","OpenProcess",['N','I','N'],'N');
    if ($pid =~ /^\d*$/) {
      $retval = $call_win32api_func->Call(0x0010,0,$pid);
      if ($retval) {
       dprint "process $pid exists on this system \n";
       # $retval = 1;
      } else {
        dprint "process $pid does **NOT** exist on this system \n";
        $retval = 0;       
      }
    } else {
      dprint "the argument \"$pid\" is not a valid process id \n";
    }
  } else {
    dprint("require Win32::API did not work quite right, Win32::API::new is not
    defined, so returning 1.. \n");
  }
  return $retval;
}

################################################################################################

1;
