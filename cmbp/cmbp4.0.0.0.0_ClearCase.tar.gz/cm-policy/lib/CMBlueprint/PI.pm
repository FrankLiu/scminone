package CMBlueprint::PI;

use strict;
use vars qw(@ISA @EXPORT);
use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(isFromMergeManager);

BEGIN {
  use File::Basename;
  my $dirname = dirname($0);
  unshift(@INC, "$dirname/../lib");
  unshift(@INC, "$dirname/../site/lib");
};

use CMBlueprint;
use vars qw($NT);

use Win32::Process::Info;

##whether co is the result of merge from merge manager
sub isFromMergeManager {

	if (  $ENV{ATRIA_FORCE_GUI} != 1 ) {
		return 0;
	} else {

		my $ppid = $ENV{CLEARCASE_PPID};
		return 0 if ( ! $ppid );
		
		if ( $NT ) {

			my $infoRef;	
			my $pi = Win32::Process::Info->new();
			$infoRef = ($pi->GetProcInfo($ppid))[0];
			
			dprint("PPID cmdline ($infoRef->{Name})");

			if ( $infoRef->{Name} =~ /clearmrgman\.exe/i
				|| $infoRef->{ExecutablePath} =~ /clearmrgman\.exe/i ) {
				return 1;
			} else {
				return 0;
			}

		} else { #Unix
			
			##IRIX6.2 and SunOS5
			my $cmdout= (qx(/bin/ps -p $ppid -o args))[1];
			return 1 if ( $cmdout =~ /clearmrgman/i );

			#SunOS 4.1.3_U1
			$cmdout = (qx(/bin/ps -w$ppid))[1];
			return 1 if ( $cmdout =~ /clearmrgman/i );

			#IRIX 5.3
			$cmdout= (qx(/bin/ps -f -p $ppid ))[1];
			return 1 if ( $cmdout =~ /clearmrgman/i );


			return 0;

		}
	}

}

1;
