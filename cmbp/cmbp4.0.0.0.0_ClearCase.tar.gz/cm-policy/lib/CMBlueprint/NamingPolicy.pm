
## Need to predeclare variables used from 'main' package
use vars qw(
  @DISABLE_USAGE_TAGS
  $USAGE_TAG_IS_PREFIX
  $NAME_SEGMENT_DELIMITER
  $USAGE_TAG_DELIMITER_REQD
  %PARSE_NAME 
);


package CMBlueprint::NamingPolicy;

#######################################################################

=head1 NAME

CMBlueprint::NamingPolicy - module used to ensure that naming
policies are followed and to return specific information from
the CC types.

=head1 EXPORTS

ParseBrtypeName
  
=head1 DESCRIPTION

B<CMBlueprint::NamingPolicy> is a module that provides
subroutines to ensure that CC types like the branch type follow
the naming policy described for the process.

=cut

#######################################################################

use strict;
use vars qw(@ISA @EXPORT);
use Exporter;
@ISA = qw(Exporter);

######################################

use vars qw(
  %CR_REQD_TAGS
  %DEV_USAGE_TAGS
  %DEVINT_USAGE_TAGS
  %DISABLED_USAGE_TAGS
  %INT_USAGE_TAGS
  %RELorCR_ID_REQD_TAGS
  %REL_ID_REQD_TAGS
  %SANDBOX_USAGE_TAGS
  %USAGE_TAGS 
);

@EXPORT = qw(
  ParseBrtypeName
  ParseLbtypeName
  ParseViewTag
  CMBP131_ParseComCMName
  IsIntegrationTag
  IsDevelopmentTag
  IsSandboxTag
  getReleaseIDs
  %CR_REQD_TAGS
  %DEV_USAGE_TAGS
  %DEVINT_USAGE_TAGS
  %DISABLED_USAGE_TAGS
  %INT_USAGE_TAGS
  %RELorCR_ID_REQD_TAGS
  %REL_ID_REQD_TAGS
  %SANDBOX_USAGE_TAGS
  %USAGE_TAGS 
);

use CMBlueprint;
use CMBlueprint::ClearQuest;
use CMBlueprint::ViewCache;
use CMBlueprint::Config;

#################################################################

use constant  BRTYPE => "brtype";
use constant  LBTYPE => "lbtype";
use constant  VWTAG  => "viewtag";
use constant  BEFORE_TAG => "before";
use constant  AFTER_TAG  => "after";

#################################################################

=head1 NAME

%DEV_USAGE_TAGS -- hash containing development usage tags.

=head1 DESCRIPTION

Used by ParseBrtypeName() to determine if the branch type is
a development branch.

=cut

##########################################################################

%DEV_USAGE_TAGS = map { ($_ => 1) } qw(dev feat fix enh doc);

#################################################################

=head1 NAME

%DEVINT_USAGE_TAGS -- hash containing Dev-Int usage tags.

=head1 DESCRIPTION

Used by ParseBrtypeName() to determine if the branch type is
a Dev-Int branch.

=cut

##########################################################################

%DEVINT_USAGE_TAGS = map { ($_ => 1) } qw(devint devbld);

##########################################################################

=head1 NAME

%INT_USAGE_TAGS -- Hash containing integration usage tags.  

=head1 DESCRIPTION

Used by ParseBrtypeName() to determine if the branch type is an integration branch type.

=cut

##########################################################################

%INT_USAGE_TAGS = map { ($_ => 1) } qw(bld int rel mrg main);

##########################################################################

=head1 NAME

%SANDBOX_USAGE_TAGS -- Hash containing sandbox development usage tags.
Branch types with these prefixes do not require a CR-ID (not
even for checkins/checkouts on the branch).

=cut

##########################################################################

%SANDBOX_USAGE_TAGS = map { ($_ => 1) } qw(tmp pkg);

##########################################################################

=head1 NAME

%USAGE_TAGS

=head1 DESCRIPTION

=cut

#######################################################################

%USAGE_TAGS = (%INT_USAGE_TAGS, %DEV_USAGE_TAGS, %DEVINT_USAGE_TAGS, %SANDBOX_USAGE_TAGS);

#######################################################################

=head1 NAME

%CR_REQD_TAGS -- Hash containing development usage tags.
Branch types with these prefixes require a CR id in the
branch name.

=head1 DESCRIPTION

Used by ParseBrtypeName() to determine if CR id is required in the branch name.

=cut

##########################################################################

%CR_REQD_TAGS    = map { ($_ => 1) } qw(dev devint devbld feat fix enh doc);

##########################################################################

=head1 NAME

%REL_ID_REQD_TAGS -- Hash containing integration usage tags.  Branch types with these 
prefixes require a Release ID in the branch name.

=head1 DESCRIPTION

Used by ParseBrtypeName() to determine if a Release ID is required in the branchname.

=cut

##########################################################################

%REL_ID_REQD_TAGS = map { ($_ => 1) } qw(bld rel int);

##########################################################################

=head1 NAME

%RELorCR_ID_REQD_TAGS -- Hash containing integration branch
prefixes.  Branch types with these prefixes require either a
Release ID or a CR-ID in the branch name. They dont have to always
have of release-id, but they need to have at least one of the two.

=head1 DESCRIPTION

Used by ParseBrtypeName() to determine if a Release ID or a
CR ID is required in the branchname.

=cut

##########################################################################

%RELorCR_ID_REQD_TAGS = map { ($_ => 1) } qw();

#######################################################################

=head1 NAME

ParseBrtypeName -- Parse branch type names in accordance with
specified naming conventions.


=head1 SYNOPSIS

  my %brinfo = ParseBrtypeName($branch_name);

  where 
    
    $branch_name is the branch type name to be parsed

=head1 DESCRIPTION

B<ParseBrtypeName> provides a customizable way to parse branch
type names. If a custom code/code reference is specified in
the <prod>_trigger config file as the 'parseBrtype' key value
of the hash %PARSE_NAME, uses that to parse the branch type
name else uses a local parsing function.

=head1 RETURN VALUES

Returns a Hash. The hash definition is provided in the pods
for the B<ParseComCMName> subroutine below.

=cut

sub ParseBrtypeName {
   my ($name, $getCRRel) = @_;
   my $type = BRTYPE;
   my %retval=();
   my $status=0;
   
   read_configFile();
   
   ## Look here for a config variable specifying
   ## some other code to invoke instead

   my $parseHookVal;
   my $parseHookKey = 'parseBrtype';
    
   ## Should have to return a hash reference from the customizable code.
   if ( $parseHookVal = $::PARSE_NAME{$parseHookKey} ) {
      ## invoke custom-function instead
      ($status, %retval) = invokeParseElmtTypeHook($name, $type, $parseHookVal);
      if($status !=0){
        display_msg( "Error: Hook for parsing $type:$name failed:$parseHookVal. \n");
      }
   }
   else {
      ## invoke our own default function
      %retval = ParseComCMName($name, $type, $getCRRel);
      ## now check status, and character case
      my $usage_tag = $retval{USAGE_TAG};
      if($usage_tag =~ /[A-Z]+/){
        $retval{'ERROR'} = 1;
        $retval{'ERRMSG'} .= "Usage '$usage_tag' in the branch".
                             " type '$name' should be all lower case";     
      }
      
   }

   return %retval;
}

sub ParseLbtypeName {
    my $name = shift;
    my $type = LBTYPE;
    my %retval=();
    my $status=0;
    
    read_configFile();
    
    my $parseHookVal;
    my $parseHookKey = 'parseLbtype';
   
    ## Look here for a config variable specifying
    ## some other code to invoke instead
    if ( $parseHookVal = $::PARSE_NAME{$parseHookKey} ) {
      ## invoke custom-function instead
      ($status, %retval) = invokeParseElmtTypeHook($name, $type, $parseHookVal);
      if($status !=0){
        display_msg( "Error: Hook for parsing $type:$name failed:$parseHookVal. \n");
      }
    }   else {
      ## invoke our own default function
      %retval = ParseComCMName($name, $type);
      ## now check status, and character case
      my $usage_tag = $retval{USAGE_TAG};
      if($usage_tag =~ /[a-z]+/){
        $retval{'ERROR'} = 1;
        $retval{'ERRMSG'} .= "Usage '$usage_tag' in the label".
                             " type '$name' should be all upper case";     
      }
    }
    return %retval;
}

sub ParseViewTag {
    my ($name,$getCRRel) = @_;
    my $type = VWTAG;
    my %retval=();
    my $status=0;
    
    read_configFile();

    my $parseHookVal;
    my $parseHookKey = 'parseVwtag';
   ## Look here for a config variable specifying
   ## some other code to invoke instead
   if ( $parseHookVal = $::PARSE_NAME{$parseHookKey} ) {
      ## invoke custom-function instead
      ($status, %retval) = invokeParseElmtTypeHook($name, $type, $parseHookVal);
      if($status !=0){
        $retval{'ERROR'} = 1;
        $retval{'ERRMSG'} = "Hook for parsing $type:$name failed:$parseHookVal.";
      }
   }
   else {
      ## invoke our own default function
      %retval = ParseComCMName($name, $type,$getCRRel);
      ## now check status, and character case
      my $usage_tag = $retval{USAGE_TAG};
      if($usage_tag =~ /[A-Z]+/){
        $retval{'ERROR'} = 1;
        $retval{'ERRMSG'} .= "Usage '$usage_tag' in the view-tag '$name'".
                             " should be all lower case";     
      }
   }
   return %retval;
}

################################################################

=head1 NAME

ParseComCMName -- Parse branch type names, label type names and view tags 
in accordance with specified naming conventions.

=head1 SYNOPSIS

  my %brinfo = ParseComCMName($element_name, $element_type, $query_CR_Rel);

  where 

    $element_name is the name of the branch type or label type
    or view tag

    $element_type is element type whose name has to be parsed,
    i.e. one of brtype, lbtype, vwtag.

	$query_CR_Rel is a flag to indicate if the sub should query CQ for the CR
	Release.


=head1 DESCRIPTION

B<ParseComCMName> will parse branch-type, label-type or view tag
names to see if they conform to local naming conventions. It
uses parameters specified in the <prod>_triggers config
file ($NAME_SEGMENT_DELIMITER, $USAGE_TAG_DELIMITER,
$USAGE_TAG_IS_PREFIX, $USAGE_TAG_DELIMITER_REQD,
@DISABLE_USAGE_TAGS) to parse the element type name.

=head1 RETURN VALUES

  Returns a hash.
  The hash has the following keys:

  ERROR -  error status.  
           Can have the following values:

    '0' if element type follows naming convention
    '1' if it does not follow naming convention, 
        or 
        if element type follows naming convention, but has
        missing required components in the name.
        or 
        if element type name has a disabled usage tag (usage prefix/suffix).
    
  ERRMSG -  error message.

  USAGE_TAG  - element type usage prefix/suffix based on specified naming
               conventions.  Can have the following values:
   
    'dev', 'feat', 'fix', 'enh', 'bld', 'int' 'rel' 'tmp'
    'mrg', 'main'. A subset of this list can be specified as a
    valid list of values, by specifying the not needed values
    in the @DISABLE_USAGE_TAGS parameter in the <prod>_trigger
    config file.

  REL_ID -  Contains release Identifier if USAGE_PFX is 'bld',
            'int' or 'rel'.

  IS_INT_USAGE - true if the branch-type usage prefix indicates
            a branch that corresponds to an integration branch

  IS_MAIN_USAGE - true if the branch-type usage indicates a branch
            that corresponds to a main or alternate main branch

  IS_DEV_USAGE - true if the branch-type usage prefix indicates
            a branch that corresponds to a development-task branch

  IS_DEVINT_USAGE - true if the branch-type usage prefix indicates
            a branch that corresponds to a Dev-Int branch

  IS_SANDBOX_USAGE - true if the branch-type usage prefix indicates
            a branch that corresponds to a sandbox-development branch

  ORIG_CQDB - ClearQuest database name as entered by the user.

  ORIG_DBID - ClearQuest CR number as entered by the user.


=cut

#################################################################


sub ParseComCMName {
   my %retval = map { ($_ => '') } qw(ERROR ERRMSG
                                      USAGE_TAG REL_ID LOADLINE
                                      REC_ID ORIG_CQDB ORIG_DBID);
	$retval{'REL_FROM_CR'} = 0;
   my ($name, $type, $getCRRel) = @_;


	dprint (1, "name=$name type=$type getCRRel=$getCRRel");

	dprint ("Into ParseCOmCMName sub \n");
	
	# remove vob-tag from the element name
	$name =~ s/@.*$//;

   ##read supplementary integration branch tag from config file
	%INT_USAGE_TAGS = (%INT_USAGE_TAGS,map { ($_ => 1) } @::INT_BRANCH_TAG_LST);
	%USAGE_TAGS = (%USAGE_TAGS,map { ($_ => 1) } @::INT_BRANCH_TAG_LST);

   
   my @name_segments = (split /\Q$::NAME_SEGMENT_DELIMITER\E+/, $name);
   
	my ($release, $loadline) =("","");
   ($release, $loadline) = (split /\Q$::USAGE_TAG_DELIMITER\E+/, $name_segments[-2]);
   dprint(1, "rel=$release loadline=$loadline");



	# Allow main branch names that end in 'main' or '-main'
	if ( $name_segments[-1] =~ m/[_-]?main$/ ) {
		$retval{IS_MAIN_USAGE} = 1;
		$retval{LOADLINE} = $loadline;
		return %retval;
	}

	## Get last segment of the given name
	local $_ = $name_segments[-1];

   ## First extract the usage-tag suffix or prefix
   my ($usage_tag, $delimited, $where) = ("", "", "");


   if ($::USAGE_TAG_IS_PREFIX  and /^([a-zA-Z]+)/ ) {
      ($usage_tag, $where) = ($1, AFTER_TAG);
      $_ = substr($_, length($usage_tag));
      $delimited = s/^\Q$::USAGE_TAG_DELIMITER\E+//;
   }
   elsif ( /\Q$::USAGE_TAG_DELIMITER\E+([a-zA-Z]+)$/ ) {
      ## tag is suffix
      ($usage_tag, $where) = ($1, BEFORE_TAG);
      $_ = substr($_, 0, length($_) - length($usage_tag));
      $delimited = s/\Q$::USAGE_TAG_DELIMITER\E+$//;
   }

   ## Make sure a delimiter was specified if it was required
   if (! $delimited  and  $::USAGE_TAG_DELIMITER_REQD) {
      $retval{'ERROR'} = 1;
      $retval{'ERRMSG'} = "A '$::USAGE_TAG_DELIMITER' is required $where ".
                          "the usage-tag in \"$name\"\.\n".
                          "where valid usage-tags must be one of the following values:\n".
                          join(",", sort(keys %USAGE_TAGS));
      return %retval;
   }
    $retval{'USAGE_TAG'} = $usage_tag;
   dprint (1,"usage_tag = $usage_tag \n");
   ## Make sure Usage tag is proper character-case
   my $lc_usage = lc $usage_tag;
    
    unless(exists $USAGE_TAGS{$lc_usage}) {
        $retval{'ERROR'} = 1;
        $retval{'ERRMSG'} = sprintf("%s usage-tag%s in $name",
                             (length $usage_tag) ? "Invalid" : "Missing",
                             (length $usage_tag) ? " \"$usage_tag\"" : "");
        $retval{'ERRMSG'} .= "\nwhere valid usage-tags must be one of the following values:\n".
                             join(",", sort(keys %USAGE_TAGS));
        return %retval;
   }
   
   #Verify if the usage tag is disabled.
   my $disabled_tag = IsDisabledUsageTags($lc_usage);
   
   if ($disabled_tag) {
     $retval{'ERROR'} = 1;
     $retval{'ERRMSG'} = "Disabled usage-tag \"$usage_tag\" in $type name $name";
     $retval{'ERRMSG'} .= "\nPlease use another valid usage-tag from one of the following values:\n".
                             join(",", sort(keys %USAGE_TAGS));
    
     return %retval;
   }

   if($::ALLOWRELEASEALPHANUMERIC)
   {
       unless($release =~ /(pre|r)(\d+(\.\d+.*)*)/) {
	   $release = '' ;
	   $loadline='';
       }
   }
   else
   {
       unless($release =~ /(pre|r)(\d+(\.\d+)*)/) {
	   $release = '' ;
	   $loadline='';
       }
   }
	my $rel_id = $2;
	
	# Checking for RELID in $_
	my ($rec_id, $cqdb, $dbid) = ("", "");
   
   if ($CR_REQD_TAGS{$lc_usage}) {
		if ( /([a-zA-Z]\w*[a-zA-Z]+)?(\d+)$/ ) {
			# See if there is something that looks like a CR-ID at the end
			($cqdb, $dbid) = ($1||"", $2);
			$rec_id = $1.$2;
			 $_ = substr($_, 0, length($_) - length($rec_id));
			s/$::USAGE_TAG_DELIMITER+$//;  ## Remove any '-' before the CR-ID
		}else {
			$retval{'ERROR'} = 1;
			$retval{'ERRMSG'} = "CR-ID required in \"$name\" for ".
                          "a \"$usage_tag\" usage-tag.";
			return %retval;
		}
   }
   
 
  ## Make sure we have at least one of rel-id or rec-id if needed
   if ($RELorCR_ID_REQD_TAGS{$lc_usage}  and  !length($release)
                                         and  !length($rec_id)) {
    
      $retval{'ERROR'} = 1;
      $retval{'ERRMSG'} = "At least one of Release-ID or CR-ID is required ".
                          "in \"$name\" for a \"$usage_tag\" usage-tag.";
      return %retval;
   }
   my ($rc, $cr_rel, $cr_loadline, $cr_target_type, $cr_usage)=('','','','','');
   if ( exists $INT_USAGE_TAGS{$lc_usage} ) { 
	   	$retval{IS_INT_USAGE} = 1;
		unless(length $release) {
			$retval{'ERROR'} = 1;
			$retval{'ERRMSG'} = "The second last segment:$name_segments[-2] of $name must contain ".
							"a valid Release ID";
			return %retval;			
		}
		my $validrelease = getReleaseIDs();
		unless(grep{$_ =~ /$rel_id$/} keys %$validrelease){
			$retval{'ERROR'} = 1;
			$retval{'ERRMSG'} = "The Release ID in the second last segment:$name_segments[-2] of $name ".
							"is not a valid Release ID";
			return %retval;
		}
         
   }

   elsif ( exists $DEVINT_USAGE_TAGS{$lc_usage} ) {
         $retval{IS_DEVINT_USAGE} = 1;		 

   }

   elsif ( exists $DEV_USAGE_TAGS{$lc_usage} ) {
         $retval{IS_DEV_USAGE} = 1;		 
		 if(length $release) {
			($rc, $cr_rel, $cr_loadline, $cr_target_type, $cr_usage) = GetRelLLTTCRUforCR($rec_id) if($getCRRel);
			if($rc == CQ_LOGIN_FAIL || $rc == CQ_QUERY_FAIL) {
				$retval{'ERROR'} = 1;
				$retval{'ERRMSG'} = "Query to obtain release/loadline/target_type/cr_usage of the CR:$rec_id failed";
				return %retval;
			}			

			# Give Error if TT=Dev-Build AND CRU=Dev-Integration
			if(($cr_usage =~ /Dev-Integration/) and ($cr_target_type =~ /Dev-Build/)) {
				$retval{'ERROR'} = 1;
				$retval{'ERRMSG'} = "Error:The CQ CR_Usage value [$cr_usage] AND Target_Type value [$cr_target_type]\ncannot be set to both of these values.  The CR_Usage may be set\n to Dev-Integration OR the CR Target_Type may be set to Dev-Build, but not both.\n";
				return %retval;
			}
			# Dev-Int CRs must use devint usage tags
			if($cr_usage =~ /Dev-Integration/) {
				$retval{'ERROR'} = 1;
				$retval{'ERRMSG'} = "Error:The CQ CR_Usage value [$cr_usage] defines this CR for Dev-Integration purposes.\nYou must use Dev-Int usage tags such as devint rather than dev.\nOtherwise, the CQ CR_Usage field should be changed to something else.\n";
				return %retval;
			}
			if(length $cr_rel and $release ne $cr_rel){
				$retval{'ERROR'} = 1;
				$retval{'ERRMSG'} = "The release ($release) specified in the brtype name is ".
								"not same as the CR release ($cr_rel)";
				return %retval;
			}
			my $lc_loadline = lc $cr_loadline;			
			if(length $lc_loadline){
				if(length $loadline) {
					dprint(1,"CHECKING LOADLINE  $LOADLINEMAP{$lc_loadline} eq $loadline???");
					if((exists $LOADLINEMAP{$lc_loadline} and $LOADLINEMAP{$lc_loadline} ne $loadline)||$lc_loadline eq 'global'){
						$retval{'ERROR'} = 1;
						$retval{'ERRMSG'} = "The loadline ($loadline) specified in the brtype name is ".
							"not same as the CR loadline ($LOADLINEMAP{$lc_loadline}:$cr_loadline)";
						return %retval;
					}elsif (!exists $LOADLINEMAP{$lc_loadline} and $lc_loadline ne 'global') {						
						$retval{'ERROR'} = 1;
						$retval{'ERRMSG'} = "The loadline ($cr_loadline) of the CR of the brtype name is ".
							"not valid, i.e. it does not exist in the LOADLINEMAP hash. Contact your CC Admin";
						return %retval;
					}
				}elsif($lc_loadline ne 'global') {
					$retval{'ERROR'} = 1;
					$retval{'ERRMSG'} = "The name:$name must contain a loadline as the ".
							"CR has a loadline ($LOADLINEMAP{$lc_loadline}:$cr_loadline)";
					return %retval;
				}
			}

		 }
   }
   elsif ( exists $SANDBOX_USAGE_TAGS{$lc_usage} ) {
         $retval{IS_SANDBOX_USAGE} = 1;
   }
   
## Assign what we have so far
   @retval{qw(REL_ID REC_ID ORIG_CQDB ORIG_DBID LOADLINE)} =
             ($release, $rec_id, $cqdb, $dbid, $loadline);

   dprint (1,"LEAVING FUNCTION ParseComCMName");
   return %retval;
}

#########################################################################

=head1 NAME

IsDisabledUsageTags -- Verifies if the usage tag i.e., the
usage prefix (or suffix) in the branch type, label type or
view tag names has been disabled (or marked invalid).


=head1 SYNOPSIS

  if (IsDisabledUsageTags($usage_tag)) {
     print "tag '$usage_tag' is disabled!\n";
  }

  where 
    
    $usage_tag is the usage prefix (or suffix) in the branch
    type, label type or view tag names

=head1 DESCRIPTION

B<IsDisabledUsageTags> takes a usage tag as a parameter and
uses the @DISABLE_USAGE_TAGS, specified in the <prod>_trigger
config file, to verify if the usage tag is disabled or not.

=head1 RETURN VALUES

    $rc is a boolean 
        1 - if tag is disabled
        0 - if tag is not disabled

=cut

#############################################################################

sub IsDisabledUsageTags( $ ) {
    my $tag = lc(shift);
    unless(%DISABLED_USAGE_TAGS) {
        %DISABLED_USAGE_TAGS = map { ($_ => 1) } @::DISABLE_USAGE_TAGS;
    }
    return $DISABLED_USAGE_TAGS{$tag} ? 1 : 0;
}

#########################################################################

=head1 NAME

IsIntegrationTag -- Verifies if the usage tag i.e., the
usage prefix (or suffix) in the branch type, label type or
view tag names corresponds to integration use.


=head1 SYNOPSIS

  if (IsIntegrationTag($usage_tag)) {
     print "tag '$usage_tag' is for integration work!\n";
  }

  where 
    
    $usage_tag is the usage prefix (or suffix) in the branch
    type, label type or view tag names

=head1 RETURN VALUES

    $rc is a boolean 
        1 - if tag is for integration use
        0 - otherwise

=cut

#########################################################################

sub IsIntegrationTag( $ ) {
   my $tag = lc(shift);
   return ( exists $INT_USAGE_TAGS{$tag} );
}

#########################################################################

=head1 NAME

IsDevelopmentTag -- Verifies if the usage tag i.e., the
usage prefix (or suffix) in the branch type, label type or
view tag names corresponds to development use.


=head1 SYNOPSIS

  if (IsDevelopmentTag($usage_tag)) {
     print "tag '$usage_tag' is for development work!\n";
  }

  where 
    
    $usage_tag is the usage prefix (or suffix) in the branch
    type, label type or view tag names

=head1 RETURN VALUES

    $rc is a boolean 
        1 - if tag is for development use
        0 - otherwise

=cut

#########################################################################

sub IsDevelopmentTag( $ ) {
   my $tag = lc(shift);
   return ( exists $DEV_USAGE_TAGS{$tag} );
}

#########################################################################

=head1 NAME

IsSandboxTag -- Verifies if the usage tag i.e., the
usage prefix (or suffix) in the branch type, label type or
view tag names corresponds to sandbox development.


=head1 SYNOPSIS

  if (IsSandboxTag($usage_tag)) {
     print "tag '$usage_tag' is for sandbox development!\n";
  }

  where 
    
    $usage_tag is the usage prefix (or suffix) in the branch
    type, label type or view tag names

=head1 RETURN VALUES

    $rc is a boolean 
        1 - if tag is for sandbox development
        0 - otherwise

=cut

#########################################################################

sub IsSandboxTag( $ ) {
   my $tag = lc(shift);
   return ( exists $SANDBOX_USAGE_TAGS{$tag} );
}

#########################################################################

sub invokeParseElmtTypeHook {
    my ($elName, $type, $parseHookVal) = @_;
	
    my ($parseHook, @hookArgs) = ($parseHookVal);
	 
    my $hookRefType = (ref $parseHookVal) || "";
    $type =~ s/([A-Za-z])([A-Za-z]+)/\U$1\L$2/g;
    my $parseHookKey = 'parse'.$type;
    ## Execute the hook
    my $hookStatus = 0;
    my $hookStatusMsg = "";
    my $retval;

    $hookRefType = (ref $parseHookVal) || "";
    if ($hookRefType eq 'ARRAY') {
        ($parseHook, @hookArgs) = @$parseHookVal;
        $hookRefType = (ref $parseHook) || "";
    }

	unshift (@hookArgs, $elName, $type);
    if ($hookRefType eq 'CODE') {
        ## Must be a ref to a function to invoke. Just invoke the function
        ## with the specified arguments. Use an eval just in case the given
        ## function is invalid or unknown/undefined.
        eval { ($hookStatus, $retval) = &{$parseHook}(@hookArgs) };
        if($@) {
            $hookStatus = 255; ## error invoking function
            $hookStatusMsg = "Perl Code for key \"$parseHookKey\" specified".
                             " in hash \$PARSE_NAME Failed: $@";
        }else {
            unless(defined $retval) {
                $hookStatus = 255; ## error in return val of the function
                $hookStatusMsg = "Perl Code for key \"$parseHookKey\"".
                                 " specified in hash \$PARSE_NAME should".
                                 " return a reference to a hash. For this".
                                 " hash definition, please refer to the".
                                 " pods for the ParseComCMName subroutine".
                                 " in CMBlueprint/NamingPolicy.pm package\n";
            }
        }
    }
    else {
      ## Unknown value-type in PARSE_NAME!!
      $hookStatus = 255;
      $hookStatusMsg = "Specification error!! Please check the \%PARSE_NAME".
                       " hash for any errors in defining the value for the".
                       " key \"$parseHookKey\". \n";
    }

    
   ## See if the hook succeeded or failed
   if ($hookStatus != 0) {
      ## parse-hook failed or aborted!!
      display_msg( "Error: $hookStatusMsg");
   }

   return ($hookStatus, %{$retval});

}


sub CMBP131_ParseComCMName {
	dprint ("INTO 131 Parse commonCM funtion\n");
   my %retval = map { ($_ => '') } qw(ERROR ERRMSG
                                      USAGE_TAG REL_ID
                                      REC_ID ORIG_CQDB ORIG_DBID);

   my $name = shift;
   my $type = shift;

   ##read supplementary integration branch tag from config file
	%INT_USAGE_TAGS = (%INT_USAGE_TAGS,map { ($_ => 1) } @::INT_BRANCH_TAG_LST);
	%USAGE_TAGS = (%USAGE_TAGS,map { ($_ => 1) } @::INT_BRANCH_TAG_LST);

   ## Get last segment of the given name
   local $_ = (split /\Q$::NAME_SEGMENT_DELIMITER\E+/, $name)[-1];

   ## First extract the usage-tag suffix or prefix
   my ($usage_tag, $delimited, $where) = ("", "", "");
   if ($::USAGE_TAG_IS_PREFIX  and /^([a-zA-Z]+)/ ) {
      ($usage_tag, $where) = ($1, AFTER_TAG);
      $_ = substr($_, length($usage_tag));
      $delimited = s/^\Q$::USAGE_TAG_DELIMITER\E+//;
   }
   elsif ( /\Q$::USAGE_TAG_DELIMITER\E+([a-zA-Z]+)$/ ) {
      ## tag is suffix
      ($usage_tag, $where) = ($1, BEFORE_TAG);
      $_ = substr($_, 0, length($_) - length($usage_tag));
      $delimited = s/\Q$::USAGE_TAG_DELIMITER\E+$//;
   }

   ## Make sure a delimiter was specified if it was required
   if (! $delimited  and  $::USAGE_TAG_DELIMITER_REQD) {
      $retval{'ERROR'} = 1;
      $retval{'ERRMSG'} = "A '$::USAGE_TAG_DELIMITER' is required $where ".
                          "the usage-tag in \"$name\".";
      return (0, \%retval);
   }
    $retval{'USAGE_TAG'} = $usage_tag;
   ## Make sure Usage tag is proper character-case
   my $lc_usage = lc $usage_tag;
    
    unless(exists $USAGE_TAGS{$lc_usage}) {
        $retval{'ERROR'} = 1;
        $retval{'ERRMSG'} = sprintf("%s usage-tag%s in $name",
                             (length $usage_tag) ? "Invalid" : "Missing",
                             (length $usage_tag) ? " \"$usage_tag\"" : "");
        return (0, \%retval);
   }
   
   #Verify if the usage tag is disabled.
   my $disabled_tag = IsDisabledUsageTags($lc_usage);
   
   if ($disabled_tag) {
     $retval{'ERROR'} = 1;
     $retval{'ERRMSG'} = "Disabled usage-tag \"$usage_tag\" in $type name $name";
    
     return (0, \%retval);
   }

   if ( exists $INT_USAGE_TAGS{$lc_usage} ) { 
         $retval{IS_INT_USAGE} = 1;
   }
   elsif ( exists $DEV_USAGE_TAGS{$lc_usage} ) {
         $retval{IS_DEV_USAGE} = 1;
   }
   elsif ( exists $SANDBOX_USAGE_TAGS{$lc_usage} ) {
         $retval{IS_SANDBOX_USAGE} = 1;
   }
   
   # Checking for RELID in $_
   my ($rec_id, $cqdb, $dbid) = ("", "");

   my $rel_id;
   
   if ($REL_ID_REQD_TAGS{$lc_usage}  or  /\w+\.\w+/) {
      $rel_id = $_;
      $_ = "";
   }
   elsif ( /([a-zA-Z]\w*[a-zA-Z]+)?(\d+)$/ ) {
     # See if there is something that looks like a CR-ID at the end
      ($cqdb, $dbid) = ($1||"", $2);
      $rec_id = $cqdb.$dbid;
      $_ = substr($_, 0, length($_) - length($rec_id));
      s/$::USAGE_TAG_DELIMITER+$//;  ## Remove any '-' before the CR-ID

   }
   else {
     # Assume this is a release-id
      $rel_id = $_;
      $_ = "";
   }

   ## If a release-id is required but wasnt given, then maybe
   ## the cr-id is really supposed to be a release-id
   if ($REL_ID_REQD_TAGS{$lc_usage}  and  !length($rel_id)) {
      if (length $rec_id) {
         ## See if this looks too darn much like a cr-id for us
         ## to believe it is a release-id
         $rel_id = $rec_id;
         $rec_id = $cqdb = $dbid = "";
      }
      unless (length $rel_id) {
         $retval{'ERROR'} = 1;
         $retval{'ERRMSG'} = "Release-ID required in \"$name\" for ".
                             "a \"$usage_tag\" usage-tag.";
         return (0, \%retval);
      }
   }

   ## If a cr-id is required but wasnt given,
   if ($CR_REQD_TAGS{$lc_usage}  and  !length($rec_id)) {
      $retval{'ERROR'} = 1;
      $retval{'ERRMSG'} = "CR-ID required in \"$name\" for ".
                          "a \"$usage_tag\" usage-tag.";
      return (0, \%retval);
   }

   ## Make sure we have at least one of rel-id or rec-id if needed
   if ($RELorCR_ID_REQD_TAGS{$lc_usage}  and  !length($rel_id)
                                         and  !length($rec_id)) {
    
      $retval{'ERROR'} = 1;
      $retval{'ERRMSG'} = "At least one of Release-ID or CR-ID is required ".
                          "in \"$name\" for a \"$usage_tag\" usage-tag.";
      return (0, \%retval);
   }
   ## Assign what we have so far
   @retval{qw(REC_ID ORIG_CQDB ORIG_DBID)} =
             ($rec_id, $cqdb, $dbid);


   return (0, \%retval);
}

1;
