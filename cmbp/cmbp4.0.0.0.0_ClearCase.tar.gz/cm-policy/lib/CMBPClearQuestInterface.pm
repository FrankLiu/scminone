package CMBPClearQuestInterface;


use strict;
use vars '$AUTOLOAD';


{
    # Default values for attributes
    my( %_attrData ) = ( _uri       => undef,
                         _proxy     => undef,
                         _soap      => undef,
                         _soapTrace => [],
                       );

    sub _defaultKeys{ keys( %_attrData ); }

    sub _setDefault{ $_attrData{$_[1]}; }
}


###############################################################################
#
# Method: new (public)
#
# Arguments: Any attribute
#
# Description: Creates a new instance of a CMBPClearQuestInterface object.
#
# Returns: A reference to the new object.
#
##############################################################################
sub new {

    my( $caller ) = shift;
    my( %arg )    = @_;

    my( $class ) = ref( $caller ) || $caller;
    my( $self ) = bless( {}, $class );

	my( $attrib );

	foreach $attrib ( _defaultKeys() ) {
		my( $argname ) = ($attrib =~ /^_(.*)/);

		if( exists( $arg{$argname} ) )	{ $self->{$attrib} = $arg{$argname}; }
		elsif( ref( $caller ) )		    { $self->{$attrib} = $caller->{$attrib}; }
		else				            { $self->{$attrib} = _setDefault( $attrib ); }
	}

    unless( $self->{_soap} ){
        # Fetch a new SOAP object. . .
        $self->_initialize();
    }
     
    unless( ref( $self->{_soap} ) eq 'SOAP::Lite' ){

        $self->{_error} = 'Provided parameter is not a SOAP::Lite object, it appears to be a [' 
                        . ref( $self->{_soap} )
                        . ']. Creating a new SOAP::Lite object. . .';
        $self->_initialize();
    }
    
	return( $self );
}


###############################################################################
#
# Method: _initialize (private)
#
# Arguments: n/a
#
# Description: Validate presents of uri and proxy attributes and attempts to 
#               create a new SOAP::Lite object.
#
# Returns: n/a
#
##############################################################################
sub _initialize{

    my( $self ) = shift;
    
    my( $paramValidate );

    # Unless explicitly provided, use the CMBP CC env. vars    
    unless( $self->{_uri} ||= $ENV{CQAPI_WEB_SERVICE_URI} ){
        $paramValidate = ' Missing required parameter [uri]';
    }
    unless( $self->{_proxy} ||= $ENV{CQAPI_WEB_SERVICE_PROXY} ){
        $paramValidate = ' Missing required parameter [proxy]';    
    }
    if( $paramValidate ){ 
        $self->{_error} = ( $paramValidate );
        return( 1 );
    }

    # Run time decision since trace is a global setting
    if( $self->{_soapTrace} ){
        eval "use SOAP::Lite ( +trace => [qw(headers fault debug)], ); 1";
    }
    else{
        eval "use SOAP::Lite; 1";
    }
   
    if( @_ ){  
        $self->{_error} = @_;
        return( 1 );
    }
    
    eval{    
        $self->{_soap} = SOAP::Lite->new(
                          uri => $self->{_uri},
                          proxy => $self->{_proxy},
                          on_action => sub { 
                                              my( $uri );
                                              ( $uri = $self->{_uri} ) =~ s#/$##; 
                                              join( '/', $uri, $_[1] ); 
                                           }, 
                          );
    };
    
    if( @_ ){  
        $self->{_error} = @_;
        return( 1 );
    }

    $self->_algo();
    
    return();  
}


###############################################################################
#
# Method: algo (private)
#
# Arguments: string
#
# Description: (Very) Simple encryption
#
# Returns: string
#
##############################################################################
sub _algo{

    my( $self ) = shift;
    my( $str ) = shift;

    $str =~ tr/A-Za-z0-9/M-Za-v0-5A-L6-9w-z/;

    return( $str );
}


###############################################################################
#
# Method: AUTOLOAD (public)
#
# Arguments: Any attribute
#
# Description: Creates an anonymous function to set the value of any attribute.
#               Writes a reference to the function on the symbol table.  Runs
#               The function to set the value.
#
# Returns: NONE
#
##############################################################################
sub AUTOLOAD {

	no strict "refs";

	my( $self, $val ) = @_;

	# Which attribute are we trying to set? Save it in $1
    if( $AUTOLOAD =~ /.*::set(_\w+)/ ){

	    my( $attrib ) = $1;

	    # Create a ref to an anonymous function on the symbol table
	    # Note that after the ref is created on the symbol table, any subsequent calls to
	    # the function will be directed - AUTOLOAD will not be called again.
	    *{$AUTOLOAD} = sub{ $self->{$attrib} = $_[1]; }; 
	    $self->{$attrib} = $val;
        return( 0 );
    }
    elsif( $AUTOLOAD =~ /.*::get(_\w+)/ ){

	    my( $attrib ) = $1;

	    # Create a ref to an anonymous function on the symbol table
	    # Note that after the ref is created on the symbol table, any subsequent calls to
	    # the function will be directed - AUTOLOAD will not be called again.
	    *{$AUTOLOAD} = sub{ return( $self->{$attrib} ); };

	    return( $self->{$attrib} );
    }
    else{ 
        $self->{_error} = "No such method: $AUTOLOAD for $self";
		return( 1 );
    }    
}

1;

__END__

=head1 NAME

CMBPClearQuestIntegration.pm -- Base class for interface to CMBP ClearQuest API Web Service

=head1 SYNOPSIS

SEE DOCUMENTATION FOR B<CMBPClearQuestInterface::Session> FOR DETAILS ON USING THIS MODULE

use CMBPClearQuestIntegration;

$cq = CMBPClearQuestIntegration->new( uri   => 'http://motorola.com/cmbp_webservices',
                                      proxy => 'http://motcmcqweb.cig.mot.com/CommonWebServices/CMBPCQService.asmx' );
                                    );
                                               
$cq = CMBPClearQuestIntegration->new();



# if the uri and proxy parameters are not provided, CMBPClearQuestIntegration will use the values found for the CQAPI_WEB_SERVICE_URI and CQAPI_WEB_SERVICE_PROXY environment variables.


=head1 DESCRIPTION

The CMBPClearQuestInterface.pm module provides access to the CMBP ClearQuest Web Service.  


=head1 PROGRAMMING STYLE

CMBPClearQuestInterface.pm provides an object-oriented interface. 

=head2 CREATING A CMBPClearQuestInterface OBJECT


    my( $request ) = CMBPClearQuestInterface->new( uri       => $CQAPI_WEB_SERVICE_URI,
                                                   proxy     => $CQAPI_WEB_SERVICE_PROXY,
                                                 );
                                                            

A CMBPClearQuestInterface object requires 2 parameters:

1. uri: URI for the CMBP CQ Web Service.

2. proxy: Proxy for the CMBP CQ Web Service.


=head2 SEE DOCUMENTATION FOR B<CMBPClearQuestInterface::Session> FOR DETAILS ON USING THIS MODULE


=head1 REVISION HISTORY

=item 1. INDEV00082318

Initial release.

=cut
