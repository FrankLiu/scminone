package CQIntegration;


=head1 NAME

CQIntegration.pm -- Base class for CQ integration.  Creates a socket connected to a CQ Integration server.

=head1 SYNOPSIS

use CQIntegration;

# Can be constructed with no explicit values.  The values for the $CQ_SERVER and $CQ_SERVERPORT environment variables will be used (provided as part of CMBP). 

$cq = CQIntegration->new();

$cq = CQIntegration::->new( serverName => 'il27app17.cig.mot.com',
                                     serverPort => '10002' );

=head1 DESCRIPTION

The CQIntegration.pm module provides a socket connection to a CQ Integration server to be used by child modules.

=head1 PROGRAMMING STYLE

CQIntegration.pm provides an object-oriented interface.  Multiple Session objects can be created to use with multiple CQ databases. Interface methods are provided to post queries and retrive results and error messages.

=cut

=head2 CREATING A CQIntegation OBJECT

=over 3

A CQIntegation object requires 2 parameters:

=item 1. Name of the ClearQuest Integration server.

This can also be the IP address.  Both 'il27app17.cig.mot.com' and '136.182.21.158' will work.  If this value is not explicitly provided to new(), the constructor will assign the value stored in the $CQ_SERVER environment variable.

=item 2. Port number on the ClearQuest Integration server.

If this value is not explicitly provided to new(), the constructor will assign the value stored in the $CQ_SERVERPORT environment variable.


=item 3. Use diagnostic error messages to STDERR (Optional).

If a non-zero value is set for stderrMsg, the Perl Carp module is used to die with an error message to STDERR.  Since this tends to alarm end users, the default is "off" (0).  If you intend to use the default setting, be sure to check the value returned by new() and handle any failures appropriately.

=cut

=head1 REVISION HISTORY

=item 1. INDEV00007448 (IJONES1)

Initial.  Prototyped in DCML/CQ integration.  Converted existing DCML logic into modules.

=cut


use strict;
use Carp;

# Block hides default values
{

    # Default values for attributes
    my(%_attrData) = (  _serverName => undef,
                        _serverPort => undef,
                        _stderrMsg  => undef ); 

    sub _defaultKeys{ keys(%_attrData); }

    sub _setDefault{  $_attrData{$_[1]}; }
}


sub new{

    my($caller) = shift;
    my( %arg ) = @_;

    my($class) = ref(  $caller ) || $caller;
    my($self) = bless( {}, $class );

    my($attrib);

    foreach $attrib (_defaultKeys()) {
        my($argname) = ($attrib =~ /^_(.*)/);

        if   (exists($arg{$argname})) { $self->{$attrib} = $arg{$argname}; }
        elsif(ref($caller))           { $self->{$attrib} = $caller->{$argname}; }
        else                          { $self->{$attrib} = _setDefault($argname); }
    }

    $self->_initialize();

    return($self);
}

################################################################################
#
# _setup
#
# make sure the required values have been defined 
#
################################################################################
sub _initialize{

    my( $self ) = shift;

    unless( $self->{_serverName} ){
        unless( $self->{_serverName} = $ENV{'CQ_SERVER'} ){
            $self->{_stderrMsg} ? carp( "No value for serverName. Must explicitly set value, or set \$CQ_SERVER." )
                                : return();
        }
    }
    unless( $self->{_serverPort} ){
        unless( $self->{_serverPort} = $ENV{'CQ_SERVERPORT'} ){
            $self->{_stderrMsg} ? carp( "No value for serverPort. Must explicitly set value, or set \$CQ_SERVERPORT." )
                                : return();
        }
    }
}

1;
