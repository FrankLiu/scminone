package CQIntegration::CQSession;


use base qw(CQIntegration);
use CQIntegration;

use constant ENCRYPT_BLOCK_SIZE => 8;

=head1 NAME

CQSession.pm -- ClearQuest user session class for CQ integration.  Allows simple query and extended query (xquery) of CQ records.

=head1 SYNOPSIS

use CQIntegration::CQSession;

# Can be constructed with no explicit values.  The values for the $CQ_SERVER and $CQ_SERVERPORT environment variables will be used (provided as part of CMBP). 

$cq = CQIntegration::CQSession->new();

$cq = CQIntegration::CQSession->new( serverName => 'il27app17.cig.mot.com',
                                     serverPort => '10002',
				     querystring => "select distinct Work_Product_ID from development_cr where title='DCML Release Notes' ",
				     exitValue => 1,
				     errorMessage => 'Work Product info not found' ,
				     rawResults => 'string1;string2;string3;............,string(n)' ,
				     formatResults => 'value1,value2,value3,............,value(n)' , # used for a field which holds multiple values
				     $logwriter => \$loggerObj............# $loggerObj is a perl Object (reference to HASH that implements prelog and postlog) ,
				     useformatting => 'either 0(disable) or 1(enable) format logging capability' );

# query() tests if matching values exist for given fields in a record. Returns 0 or 1.

$cq->query( record => 'Development_CR',
            id     => 'MOTSB00001234',
            state  => 'Assigned' );

# xquery() returns values for given fields for a record. Returns 0 or 1.

$cq->xquery( record => 'Development_CR',
             id     => 'MOTSB00001234',
             fields => 'state,technical_authority' );

# listquery() returns values for given fields for a given record type. Returns 0 or 1.

$cq->listquery( record      => 'Development_CR',
                filters     => 'state|EQ|Closed',
                fields      => 'id' );

# sqlquery() returns the output for a 'select' SQL statement

$cq->sqlquery( record => 'Development_CR',
               sql    => 'select this from that' );

# If a failure occured, the error is accessible through getError().

print $cq->getError(), "\n";

# xquery, listquery and sqlquery results are accessible through getResults().

%results = $cq->getResults();

=head1 DESCRIPTION

The CQSession.pm module provides a simple and fast interface to CQ, through which 2 types of queries can be posted.  A query() will determine if "field 'a' has value 'x' for record 'z'" (i.e. "is the state of CR MOTSB00001234 Assigned?").  An xquery will return the values for specified fields for the given record (i.e. "What are the values for the 'state' and 'technical_authority' fields for CR MOTSB00001234?").

=head1 PROGRAMMING STYLE

CQSession.pm provides an object-oriented interface. Interface methods are provided to post queries and retrive results and error messages.

=cut

=head2 CREATING A SESSION OBJECT

=over 3

A Session object requires 2 parameters:

=item 1. Name of the ClearCase/ClearQuest Integration server.

This can also be the IP address.  Both 'il27app17.cig.mot.com' and '136.182.21.158' will work.  If this value is not explicitly provided to new(), the constructor will assign the value stored in the $CQ_SERVER environment variable.

=item 2. Port number on the ClearCase/ClearQuest Integration server.

If this value is not explicitly provided to new(), the constructor will assign the value stored in the $CQ_SERVERPORT environment variable.

=item 3. Use diagnostic error messages to STDERR (Optional).

If a non-zero value is set for stderrMsg, the Perl Carp module is used to die with an error message to STDERR.  Since this tends to alarm end users, the default is "off" (0).  If you intend to use the default setting, be sure to check the value returned by new() and handle any failures appropriately.


=cut

=head2 POSTING A QUERY

The query method can be used to determine if the field values for a given record match those provided.  query returns a '1' if the values match, '0' if they do not, or there was an error.

$cq->query( record => 'Development_CR',
            id     => 'MOTSB00001234',
            state  => 'Assigned' );

All query parameters are entered as <field_name> => '<field_value>'.  Each combination is comma seperated.

=head2 CREATING A RECORD

The create method can be used to create a new Work_Product record.  create() returns a '1' if the record is created, '0' if it is not, or there was an error.

$cq->create( record             => 'Work_Product',
             identifier         => 'Some_WP_ID',
             configuration_item => 'DCML:WSG_SCM_DE',
             product_family     => 'WSG_Metrics_Dev',
             description        => 'A descriptive description',
             title              => 'The Really Big Title' );

All create() parameters are entered as <field_name> => '<field_value>'.  Each combination is comma seperated.

REQUIRED PARAMETERS:

=item 1. record 

Currently, only the 'Development_CR' and 'Work_Product' record types are supported.

=item 2. identifier

The unique identifier for the new Work_Product.

=item 3. configuration_item

The configuration_item to associate with the new Work_Product record.

=item 4. product_family

The product_family to associate with the new Work_Product record.

=item 5. description

A description of the new Work_Product record.

=item 6.

The title of the new Work_Product record.

=back

=cut

=head2 EDITING A RECORD

The edit method can be used to edit field values for a given record.  edit() returns a '1' if the edit succeeds, '0' if there was an error. NOTE: At this time, only Developemnt_CR and Work_Product record types can be edited.

$cq->edit( record   => 'Development_CR',
           id       => 'MOTSB00001234',
           abstract => 'Some new abstract information' );

All edit() parameters are entered as <field_name> => '<field_value>'.  Each combination is comma seperated.

REQUIRED PARAMETERS:

=item 1. record 

Currently, only the 'Development_CR' and 'Work_Product' record types are supported.

=item 2. id or identifier

The unique id for the record type.  This is 'id' for Development_CR's and 'identifier' for Work_Product's.

OPTIONAL PARAMETERS:

=item 1. additional field

Any additional field.

=back

=cut

=head2 POSTING AN EXTENDED QUERY (xquery)

The xquery method can be used to return field values for a given record.  xquery returns a '1' if the query succeeds, '0' if there was an error.

$cq->xquery( record => 'Development_CR',
             id     => 'MOTSB00001234',
             fields => 'state,technical_authority' );

All query parameters are entered as <field_name> => '<field_value>'.  Each combination is comma seperated.

REQUIRED PARAMETERS:

=item 1. record 

Currently, only the 'Development_CR' and 'Work_Product' record types are supported.

=item 2. id or identifier

The unique id for the record type.  This is 'id' for Development_CR's and 'identifier' for Work_Product's.

=item 3. fields

A comma seperated list of fields whose values should be retrieved

abstract => 'Some new abstract information'

=head2 POSTING A LIST QUERY (listquery)

The list method can be used to return field values for a given record type.  listquery returns a '1' if the query succeeds, '0' if there was an error.

$cq->listquery( record      => 'Development_CR',
                filters     => 'state|EQ|Closed',
                fields      => 'id' );

This example is requesting 'All ids for Development_CR records where state is equal to Closed'

REQUIRED PARAMETERS:

=item 1. record 

Currently, only the 'Development_CR' and 'Work_Product' record types are supported.

=item 2. filters

Each filter consists of 3 parts, pipe ('|') seperated.  The first part is the field identifier, the second part is a boolean operator (EQ, NEQ, LIKE, etc.), and the third part is the value.  For example, a filter to identify records assigned to 'cquser1' would be 'technical_authority|LIKE|cquser1'.  In order to be useful, the record parameter would be set to 'Development_CR'.

=item 3. fields

Like xquery, the fields parameter is a comma seperated list of field values to return for records that match the filter parameter.

=head2 POSTING A SQL QUERY (sqlquery)

The sqlquery method can be used to return the results of a SQL 'select' statement.  sqlquery returns a '1' if the SQL query succeeded, a '0' if it did not.

$cq->sqlquery( record => 'Development_CR',
               sql    => 'select this from that' );

Note that only 'select' statements are supported.

REQUIRED PARAMETERS:

=item 1. record

The record type the SQL statement will be looking at.

=item 2. sql

The SQL 'select' statement to post.

=head2 RETRIEVING EXTENDED QUERY AND LISTQUERY RESULTS:

The getResults method will return a hash containing the results from the last call to xquery() or listquery().  The hash is keyed on the field names provided fields parameter.

my( %results ) = $cq->getResults();

foreach( keys( %results ) ){
    print( "$_=$results{_};    
}

NOTE: For fields that contain multiple values, all values will be captured in a comma separated string.

i.e. Targetted_CRs => 'MOTSB00001234,MOTSB00009876'

=head2 RETRIEVING SQLQUERY RESULTS:

The getResults method will return a hash table containing the results from the last call to sqlquery().  The record sets are initially keyed by result number (1, 2, 3, etc.).  The hash containing the values for each set is keyed on the field names requested in the sql parameter.

my( %results ) = $cq->getResults();

foreach $record ( sort keys( %results ) ){
    foreach( keys( %{$results{$record}} ) ){
        print "$_=${$results{$record}}{$_}\n";
    }
}

=head2 RETRIEVING ERRORS

The error generated from the last call to query() or xquery() can be retrieved by getError().

print( "Something bad happened! ", getError(), "\n" );

=head3 GET AUTHENTICATION

The getAuthentication method returns data for the cqparams file after decrypting the encrypted password and making sure that it matches either the OneIT password or CQ password for the user.

=head4 VERIFY AUTHENTICATION

The verifyAuthentication method takes the info from the user's cqparams file, decrypts the token and returns a 1 if successful or 0 if failure.

=cut

=head1 REVISION HISTORY

=item 1. INDEV00007448 (IJONES1)

Initial.  Prototyped in DCML/CQ integration.  Converted existing DCML logic into modules.

=cut


use strict;
use Carp;
use Socket;

$| = 1;

{
	# Default values for attributes
	my(%_attrData) = ( _socket	  => undef,
                       _querystring   => undef,
                       _exitValue     => undef,
                       _errorMessage  => undef,
                       _rawResults    => undef,
                       _formatResults => {},
		           _logwriter     => undef,
		           _useformatting => 0 );

	sub _defaultKeys { keys(%_attrData); }

	sub _setDefault { $_attrData{$_[1]}; }
}


############################################################################
#
# + new
#
# Create a new instance of a Session object
#
############################################################################
sub new{

	my($caller, %arg) = @_;
	my($self) = shift()->SUPER::new(@_);
	my($attrib) = 0;
  
        # User may want 'silent' failures (_stderrMsg is NULL).
        #  Check if paernt constructor returned NULL
        unless( $self ){ return( 0 ); }

	foreach $attrib (_defaultKeys()) {
		my($argname) = ($attrib =~ /^_(.*)/);
        
		if (exists($arg{$argname}))	{ $self->{$attrib} = $arg{$argname}; }
		elsif (ref($caller))		{ $self->{$attrib} = $caller->{$argname}; }
		else				        { $self->{$attrib} = _setDefault($argname); }
	}
    
        $self->_setup();

        # _errorMessage just signals a problem.  It serves no use to the user, since
        #  the returned value (a ref to our object) will be undef.  Set stderrMsg to
        #  non-zero (!=0) for error messages (from Carp) to stderr.
        $self->{_errorMessage} ? return( )
                               : return( $self );
}


############################################################################
#
# + _setup
#
# Create a socket to the specified server and port
#
############################################################################
sub _setup{

    my( $self ) = shift;
    
    # Socket setup
    my( $sockaddr ) = 'S n a4 x8';
    my($proto) = getprotobyname('tcp');
   
    my( $thataddr ) = (gethostbyname( $self->{_serverName} ))[4];
    my( $there ) = pack( $sockaddr, AF_INET, $self->{_serverPort}, $thataddr );
    
    unless( socket( RSVR, PF_INET, SOCK_STREAM, $proto ) ){
       if( $self->{_stderrMsg} ){ carp( "Can't create server socket: $! from application " . "caller(1)[0]" ); }
        $self->{_errorMessage} = "Can't create server socket: $!";
        return();
    }

    unless( connect( RSVR, $there ) ){
        if( $self->{_stderrMsg} ){ carp( "Can't connect to CQ server [$self->{_serverName}] [$self->{_serverPort}]: '$!'  from application " . "caller(1)[0]" ); }
        $self->{_errorMessage} = "Can't connect to CQ server [$self->{_serverName}]: '$!'";
        return();
    }

    select( RSVR ); $| = 1; select( STDOUT );
    
    $self->{_socket} = *RSVR;
}


############################################################################
#
# + _setQuery
#
# Parse the user's request into the format required by the server
#
############################################################################
sub _setQuery{

    my( $self )    = shift;
    my( $hashRef ) = shift;

    # Protocol requires action and rectype to be the first 2 parameters
    $self->{_queryString} = 'action=' . $$hashRef{action} . ';';
    delete( $$hashRef{action} );
    $self->{_queryString} .= 'rectype=' . $$hashRef{record} . ';';
    delete( $$hashRef{record} );
             
    foreach( keys( %$hashRef ) ){
     
      # Swap reserved chars
      $$hashRef{$_} =~ s/\\2/"/go;
      $$hashRef{$_} =~ s/\\1/;/go;
      $$hashRef{$_} =~ s/\\0/\n/go;
      $$hashRef{$_} =~ s/"/__CQ_INT_DBLQUOT__/g;
      $$hashRef{$_} =~ s/;/__CQ_INT_SEMICOL__/g;
      $$hashRef{$_} =~ s/\n/__CQ_INT_NEWLINE__/g;
      
      $self->{_queryString} .= $_ . '=' . $$hashRef{$_} . ';'; 
    }
    $self->{_queryString} .= "\n";
}

############################################################################
#
# + _processRequest
#
# Transmit the user's request to the server, and get the results
#
############################################################################
sub _processRequest{

    my( $self ) = shift;
    my( $pattern, $set, $field, $val );
    
    my( %logHash ) = {
                         commandString => $self->{'_queryString'},
			 commandOutput => $self->{'_rawResults'},
			 commandErrorMessage => $self->{'_errorMessage'},
			 commandReturnValue => $self->{'_exitValue'}
                     };

    # Flush to prepare for new request results
    undef( $self->{_errorMessage} );
    undef( $self->{_exitValue} );
    undef( $self->{_rawResults} );
    undef( $self->{_formatResults} ); 

    # Reset the socket.  Do it this way until the blocking issue is resolved. . .
    $self->_setup();

    if( $self->{_errorMessage} ){
        # If setup fails, _errorMessage will be set.  Set exit value, so the calling method can
        #  throw an appropriate error.
        $self->{_rawResults} = $self->{_errorMessage};
        $self->{_exitValue} = '999';
        return();
    }

    my( $socketRef ) = $self->{_socket};

    eval {
       $self->{'_logwriter'}->prelog( \%logHash ) if ( defined($self->{'_logwriter'}) );
    };

    print $socketRef $self->{_queryString};

    my( $buffer );
    undef( $buffer );

    while( defined( $buffer = <$socketRef> ) ){

        chomp $buffer; 

	unless( defined( $self->{_exitValue} ) ){ 
        	# If the request gets mangled or there's a fatal error, the server will return a single '0'
        	$buffer =~ s/^(\d)://;
        	$self->{_exitValue} = $1;
	}

        # In case there's multi-line output
        $self->{_rawResults} .= $buffer;
    }
    
    unless( defined( $self->{_exitValue} ) ){ $self->{_exitValue} = '999'; }
    
    if ( $self->{_useformatting} )
    {
        foreach( split( /;/, $self->{_rawResults} ) ){
           my( $field, $value ) = split( /=/, $_ );
        
           $value =~ s/\\2/"/go;
           $value =~ s/\\1/;/go;
           $value =~ s/\\0/\n/go;
           $value =~ s#__CQ_INT_SEMICOL__#;#go;
           $value =~ s#__CQ_INT_DBLQUOT__#"#go;
           $value =~ s#__CQ_INT_NEWLINE__#\n#go;
              
           # If a field contained multiple values, they will have the same key.  Create
           #  a comma seperated string to hold all the values.        
           if( $self->{_formatResults}{$field} ){
              $self->{_formatResults}{$field} .= ',' . $value;
           }
           else{ $self->{_formatResults}{$field}  = $value; }
        }
    }

    eval {
       $self->{'_logwriter'}->postlog( \%logHash ) if ( defined($self->{'_logwriter'}) );
    };

}


############################################################################
#
# + query
#
# Parse the server output for a query request
#
############################################################################
sub query{
    my( $self ) = shift;
    return $self->_performActionRequest( 'query', @_ );

}

############################################################################
#
# + xquery
#
# Parse the server output for an xquery request
#
############################################################################
sub xquery{
    my( $self ) = shift;
    return $self->_performActionRequest( 'xquery', @_ );
        
}


############################################################################
#
# + listquery
#
# Parse the server output for a listquery request
#
############################################################################
sub listquery{
    my( $self ) = shift;
    return $self->_performActionRequest( 'listquery', @_ );

}

############################################################################
#
# + sqlquery
#
# Post a raw SQL query
#
############################################################################
sub sqlquery {
    my( $self ) = shift;
    return $self->_performActionRequest( 'sqlquery', @_ );
    
}

############################################################################
#
# + getError
#
# Access method for last error message sent by server
#
############################################################################
sub getError{
    my( $self ) = shift;
    return( $self->{_errorMessage} );
}

####################################################################################
#
# + getResults
#
# Access method for _formatResults and rawResults (formatted and raw server output)
#
####################################################################################
sub getResults{

    my( $self ) = shift;
    
    if( ref( $self->{_formatResults} ) ){ return( %{$self->{_formatResults}} ); }
    elsif( length( $self->{_rawResults} ) ){ return( $self->{_rawResults} ); }
    else{                                 return( my( %empty ) ); }
}


############################################################################
#
# + edit
#
# Parse the server output for an edit request
#
############################################################################
sub edit{
    my( $self ) = shift;
    return $self->_performActionRequest( 'edit', @_ );

}


############################################################################
#
# + create
#
# Parse the server output for a create request
#
############################################################################
sub create{
    my( $self ) = shift;
    return $self->_performActionRequest( 'create', @_ );

}


############################################################################
#
# + delete
#
# Parse the server output for a delete request
#
############################################################################
sub delete{
    my( $self ) = shift;
    return $self->_performActionRequest( 'delete', @_ );

}

############################################################################
#
# + getExitValueResult
#
# Return Exit value of all actions
#
############################################################################
sub _getExitValueResult{

    my( $self ) = shift;
    # If the request gets mangled, the server will return a single '0'
    # For query - returns a single '0' (fatal error), '1' (query success), or '2' (query fail)
    # For all others - '0' (fatal error), or '1:<field1>=<value1>;<field2>=<value2>...' 
    if(    $self->{_exitValue} eq '0' ){ $self->{_errorMessage} = 'Cannot complete requested action [' . $self->{_rawResults} . ']'; return( 0 ); }
    elsif( $self->{_exitValue} eq '1' ){ $self->{_errorMessage} = ''; return( 1 ); }
    elsif( $self->{_exitValue} eq '2' ){ $self->{_errorMessage} = 'Error: No records found to match query parameters ' . $self->{_rawResults}; return( 0 ); }
    else                               { $self->{_errorMessage} = 'Cannot complete requested action, ClearQuest returned an unknown value [' . $self->{_rawResults} . ']'; return( 0 ); }
}


############################################################################
#
# + getAuthentication
#
# Return 1 if sucessful
#
############################################################################
sub getAuthentication {
    my( $self ) = shift;
    return $self->_performActionRequest( 'getAuth', @_ );

}

############################################################################
#
# + verifyAuthenication
#
# Return 1 if successful
#
############################################################################
sub verifyAuthentication {
    my( $self ) = shift;
    return $self->_performActionRequest( 'verifyAuth', @_ );

}

############################################################################
#
# + performActionRequest
#
# This function performs the action request for the client side
#
############################################################################
sub _performActionRequest {

    my( $self ) = shift;
    my( $actionName, %argHash ) = @_;
    
    $argHash{action} = $actionName;
    
    $self->_setQuery( \%argHash );    
    $self->_processRequest();

    # If the request gets mangled, the server will return a single '0'
    # For query - returns a single '0' (fatal error), '1' (query success), or '2' (query fail)
    # For all others - '0' (fatal error), or '1:<field1>=<value1>;<fieled2>=<value2>...' 
    return $self->_getExitValueResult();

}

sub encryptPW {

   use Crypt::Blowfish_PP;
   
   my $pw = shift @_;
   my $rc = 1;
   my $ciphertextBlock = "";
   our $CLIENT_ENCRYPTION_KEY = pack("H96","079F57E245112F64AB9EFFA07146B2E97F93B7ED965ECC0C40EC0D63A1D369CE01FFB45C0A9AAD2C69624B41A8310BF0");
   unless ($pw) {
      return ($rc, "");
   }
   
   my $blowfish = new Crypt::Blowfish_PP($CLIENT_ENCRYPTION_KEY);
   if (!$blowfish) {
      $rc = 0;
      return ($rc,"");
   }
   
   $ciphertextBlock = _encryptStr("$pw",$blowfish);
   unless ($ciphertextBlock) {
      $rc = 0;
      return ($rc,"");
   }

   return ($rc, $ciphertextBlock);
}

#################################################################
# encrypt the current token to send back to cqparams file
#################################################################
sub _encryptStr {
  my ($plainText,$blowFishObj) = @_;
  my $curTok = $plainText;
  my $encStr;
  my $substr;
  while ($substr = substr($curTok, 0, ENCRYPT_BLOCK_SIZE)) {
    my $ciphertextBlock=$blowFishObj->encrypt($substr);
    $curTok = substr($curTok, ENCRYPT_BLOCK_SIZE);
    my $len = length($ciphertextBlock);
    $len = $len*2;
    my $newciphertextBlock =unpack("H$len",$ciphertextBlock);
    $encStr .= $newciphertextBlock;
  }
  
  return $encStr;
}


1;
