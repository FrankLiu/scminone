package CMBPClearQuestInterface::Session;

###############################################################################
#
# CMBPClearQuestInterface::Session
#
# Description: Class to handle all communication with the CMBP ClearQuest
#               API Web Service
#
##############################################################################

use base qw( CMBPClearQuestInterface );

use strict;
use vars qw( $AUTOLOAD );


# Data hiding
{
    my( %_attrData ) = ( _userName       => undef,
                         _passWord       => undef,
                         _database       => undef,
                         _encrypt        => undef,
                         _requestResults => undef,
                         _request        => undef,
                         _requestRecords => [],
                         _operation      => undef,
                         _soapResults    => undef,
                         _results        => [],
                         _error          => undef,
                       );

  sub _defaultKeys{ keys( %_attrData ); }

  sub _setDefault { $_attrData{$_[1]}; }
}


###############################################################################
#
# Method: new (public)
#
# Arguments: Any attribute
#
# Description: Creates a new instance of CMBPClearQuestInterface::Session.
#
# Returns: A ref. to the new object.
#
##############################################################################
sub new {

	my( $caller, %arg ) = @_;
	my( $self ) = shift()->SUPER::new( @_ );
	my( $attrib );

	foreach $attrib ( _defaultKeys() ) {
		my( $argname ) = ($attrib =~ /^_(.*)/);

		if( exists( $arg{$argname} ) )	{ $self->{$attrib} = $arg{$argname}; }
		elsif( ref( $caller ) )		    { $self->{$attrib} = $caller->{$attrib}; }
		else				            { $self->{$attrib} = _setDefault( $attrib ); }
	}
   
	return( $self );
}


###############################################################################
#
# closeCR
#
# Sets the CMBPClearQuestService operation to 'CloseCR'
#
###############################################################################
sub closeCR{

    my( $self ) = shift;
    
    $self->{_operation} = 'closeCR';    
    $self->_processRequest();
}


###############################################################################
#
# closeCRByBaseline
#
# Sets the CMBPClearQuestService operation to 'CloseCRByBaseline'
#
###############################################################################
sub closeCRByBaseline{

    my( $self ) = shift;
    
    $self->{_operation} = 'closeCRByBaseline';
    $self->_processRequest();
}


###############################################################################
#
# editRecord
#
# Sets the CMBPClearQuestService operation to 'EditRecord'
#
###############################################################################
sub editRecord{

    my( $self ) = shift;
     
    $self->{_operation} = 'editRecord';   
    $self->_processRequest();
}


###############################################################################
#
# createBL
#
# Sets the CMBPClearQuestService operation to 'CreateBL'
#
###############################################################################
sub createBL{

    my( $self ) = shift;
    
    $self->{_operation} = 'createSuccessorBL'; #'createSuccessorBL'??   
    $self->_processRequest();
}


###############################################################################
#
# linkSuccessorBL
#
# Sets the CMBPClearQuestService operation to 'LinkSuccessorBL'
#
###############################################################################
sub linkSuccessorBL{

    my( $self ) = shift;
     
    $self->{_operation} = 'linkSuccessorBL';    
    $self->_processRequest();
}


###############################################################################
#
# linkPredecessorBL
#
# Sets the CMBPClearQuestService operation to 'LinkPredecessorBL'
#
###############################################################################
sub linkPredecessorBL{

    my( $self ) = shift;
     
    $self->{_operation} = 'linkPredecessorBL';    
    $self->_processRequest();
}


###############################################################################
#
# linkChildBL
#
# Sets the CMBPClearQuestService operation to 'LinkChildBL'
#
###############################################################################
sub linkChildBL{

    my( $self ) = shift;
     
    $self->{_operation} = 'linkChildBL';    
    $self->_processRequest();
}


###############################################################################
#
# linkParentBL
#
# Sets the CMBPClearQuestService operation to 'LinkParentBL'
#
###############################################################################
sub linkParentBL{

    my( $self ) = shift;
     
    $self->{_operation} = 'linkParentBL';    
    $self->_processRequest();
}


###############################################################################
#
# closeBL
#
# Sets the CMBPClearQuestService operation to 'CloseBL'
#
###############################################################################
sub closeBL{

    my( $self ) = shift;
    
    $self->{_operation} = 'closeBaseline';    
    $self->_processRequest();
}


###############################################################################
#
# blReport
#
# Sets the CMBPClearQuestService operation to 'BLReport'
#
###############################################################################
sub blReport{

    my( $self ) = shift;
    
    $self->{_operation} = 'blReport';    
    $self->_processRequest();
}


###############################################################################
#
# queryRecord
#
# Sets the CMBPClearQuestService operation to 'QueryRecord'
#
###############################################################################
sub queryRecord{

    my( $self ) = shift;
    
    $self->{_operation} = 'queryRecord';    
    $self->_processRequest();
}


###############################################################################
#
# prepareRecords
#
# Accepts a list of hashes, or refs to hashes.  Each hash represents a record,
#  with each field name as the key, and any associated values:
#
# { uuid  => 'ABC123456',
#   type  => 'Development_CR',
#   state => 'Assigned',
#   title => 'This is a very important CR',
#   notes => 'Updating this very important CR',
#   cclist => [ 'jqpublic1', 'jmotorola' ] }
#
# The hash *MUST* contain "uuid" and "type" key/value pairs!
#
###############################################################################
sub prepareRecords{

    my( $self ) = shift;

    my( @fieldValueSOAPObjs,
        @fieldSOAPObjs );

    my( $recordType,
        $recordUUID );
            
    foreach my $record ( @_ ){

        $recordType = $record->{type};
        $recordUUID = $record->{uuid};
        
        unless( $recordType && $recordUUID ){
            $self->{_error} = 'Missing parameters: "type" and "uuid" and both are required for each record';
            return( 1 );
        }
        
        delete( $record->{type} );
        delete( $record->{uuid} );
       
        undef( @fieldSOAPObjs );
                                   
        # We now have a SOAP::Lite object for a single record, and have added
        #  it to the requestRecords list
        foreach my $field ( keys( %$record ) ){
            
            undef( @fieldValueSOAPObjs );      

            if( ref( $record->{$field} ) eq 'ARRAY' ){

                foreach( @{$record->{$field}} ){
                    push( @fieldValueSOAPObjs, SOAP::Data->name( 'Value' => $_ ) );
                }
            }
            else{
                @fieldValueSOAPObjs = SOAP::Data->name( 'Value' => $record->{$field} );
            }
            push( @fieldSOAPObjs, SOAP::Data->name( 'FieldData' => \SOAP::Data->value( @fieldValueSOAPObjs ) )->attr({Name => $field}) );
            # We now have a SOAP::Lite object for a single field, and have added 
            #  it to the fieldSOAPObjs list
        }
        push( @{$self->{_requestRecords}}, SOAP::Data->name( 'Record' => \SOAP::Data->value( @fieldSOAPObjs ) )->attr({Type => $recordType, UUID => $recordUUID}) );
    }
    return( 0 );
}


###############################################################################
#
# processRequest
#
# Completes the creation of the required SOAP objects, and passes them to 
#  the appropriate SOAP::Lite method to transmit the user's request. 
#
#
###############################################################################
sub _processRequest{

    my( $self ) = shift;

    my( @missing );
    
    $self->{_request};

    if( $ENV{SOAP_TRACE} ){ $self->{_soap}->readable( 1 ); }
    
    unless( $self->{_userName} ){ push( @missing, 'userName' ); } 
    unless( $self->{_passWord} ){ push( @missing, 'passWord' ); }
    unless( $self->{_database} ){ push( @missing, 'database' ); } 

    if( @missing ){ 
        $self->{_error} = 'CMBPClearQuestInterface::Session - Missing parameter(s) [' . join( '][', @missing ) . ']';
        return( 1 );
    }
   
    if( $self->{_encrypt} ){
        $self->{_passWord} = $self->_algo( $self->{_passWord} );      
    }

    if( $self->{_timeout} ){
        $self->{_soap}->transport->timeout( $self->{_timeout} );
    }
   
    @{$self->{_request}} = ( SOAP::Data->name( 'login' => \SOAP::Data->value( SOAP::Data->name( 'UserID' => $self->{_userName} )->type( 'string' ),
                                                                              SOAP::Data->name( 'Password' => $self->{_passWord} )->type( 'string' ),
                                                                              SOAP::Data->name( 'DataBase' => $self->{_database} )->type( 'string' ),
                                                                              SOAP::Data->name( 'schemaRepo' => '2003.06.00' )->type( 'string' ),
                                                                            ),
                                        ),
                             SOAP::Data->name( 'recordList' => \SOAP::Data->value( @{$self->{_requestRecords}} ), ),
                        ); # close _request

    $self->{_soapResults} = $self->{_soap}->call(SOAP::Data->name( $self->{_operation} )->attr({xmlns => $self->{_uri}})=>(@{$self->{_request}}));
    
    return( $self->_compileResults() );
}


###############################################################################
#
# _compileResults
#
# De-serializes the SOAP message received from the Service
# Constructs the corresponding data structures 
#
#  $results = { actionResult  => '',
#               actionMessage => '',
#               recordList    => [ { recordResult  => '',
#                                    recordMessage => ''
#                                    uuid          => '',
#                                    type          => '',
#                                    field1        => '', # fieldn may be a scalar 
#                                    field2        => [], #  or array ref
#                                     ...
#                                  },
#                                  { recordResult  => '',
#                                    recordMessage => ''
#                                    uuid          => '',
#                                    type          => '',
#                                    field1        => '',
#                                    field2        => [],
#                                     ...
#                                  },                                
#                                ],
#             };
#
###############################################################################
sub _compileResults{

    my( $self ) = shift;
    
    my( $fault );
    
    if( $fault = $self->{_soapResults}->fault() ){

        $self->{_results}->{actionMessage} = $fault->{faultstring};
        $self->{_results}->{actionResult} = 'fail';
        return( 1 );
    }


    unless( $self->{_soapResults}->match( '//ActionResult' ) ){       
        return( 1 );
    }
    
    my( $ActionResult ) = $self->{_soapResults}->dataof( '//ActionResult' );
    
    my( $attrs ) = $ActionResult->attr();
    
    $self->{_results}->{actionMessage} = $attrs->{'ActionMessage'};

    $self->{_results}->{actionResult} = $attrs->{'ActionDisposition'};

    if( $self->{_results}->{actionResult} eq 'true' ){ $self->{_results}->{actionResult} = 'success'; }
    else{                                              $self->{_results}->{actionResult} = 'fail'; }

    # A series of nested 'for' loops to parse (depth first) the SOM tree containing the request results
    #  XPath notation is used to set the relative path within the tree
    #  The match() method tells us if a node exists
    #  The dataof() method allows access to the node 
    #  The attr() method allows access to the node's attribute data
    for ( my $recordActionResults = 1; $self->{_soapResults}->match("//ActionResult/[$recordActionResults]"); $recordActionResults++ ) {

        my( $recordData ) = $self->{_soapResults}->dataof( "//ActionResult/[$recordActionResults]" );
        my( $recordDataAttrs ) = $recordData->attr();
        ${$self->{_results}->{recordList}}[$recordActionResults - 1]->{recordResult} = $recordDataAttrs->{'RecordActionDisposition'};
        ${$self->{_results}->{recordList}}[$recordActionResults - 1]->{recordMessage} = $recordDataAttrs->{'RecordActionMessage'};

        # Extract values for the Record node (one Record node per RecordActionResults node)
        my( $recAttrs ) = $self->{_soapResults}->dataof( "//ActionResult/[$recordActionResults]/Record" )->attr();
        
        ${$self->{_results}->{recordList}}[$recordActionResults - 1]->{uuid} = $recAttrs->{'UUID'};
        ${$self->{_results}->{recordList}}[$recordActionResults - 1]->{type} = $recAttrs->{'Type'};

        # This loop will extract the values for a particular FieldData node
        for ( my $fieldData = 1; $self->{_soapResults}->match("//ActionResult/[$recordActionResults]/Record/[$fieldData]"); $fieldData++ ) {

            my( $fieldNameAttr ) = $self->{_soapResults}->dataof("//ActionResult/[$recordActionResults]/Record/[$fieldData]")->attr();

            # This loop will extract the values for the Value nodes       
            for ( my $value = 1; $self->{_soapResults}->match("//ActionResult/[$recordActionResults]/Record/[$fieldData]/[$value]"); $value++ ) {

                my( $value ) = $self->{_soapResults}->dataof("//ActionResult/[$recordActionResults]/Record/[$fieldData]/[$value]");
  
                ${$self->{_results}->{recordList}}[$recordActionResults - 1]->{$fieldNameAttr->{Name}} = join( "\n ", @{$value->{_value}} );
            }  # End for( $value
        } # End for( $fieldData  
    } # End for( $recordActionResults   

    return( 0 );
}


###############################################################################
#
# results
#
# Completes the creation of the required SOAP objects, and passes them to 
#  the appropriate SOAP::Lite method to transmit the user's request. 
#
#
###############################################################################
sub results{

    my( $self ) = shift;
    return( $self->{_results} );
}


DESTROY{}


1;
__END__


=head1 NAME

Session.pm -- Interface to CMBP ClearQuest API Web Service

=head1 SYNOPSIS

use CMBPClearQuestIntegration::Session;

$cq = CMBPClearQuestIntegration::Session->new( uri   => 'http://motorola.com/cmbp_webservices',
                                               proxy => 'http://motcmcqweb.cig.mot.com/CommonWebServices/CMBPCQService.asmx' );
                                               userName  => 'cquser',
                                               passWord  => 'cquser_pwd',
                                               database  => 'CQDB' );
                                               
$cq = CMBPClearQuestIntegration::Session->new();

$cq->prepareRecords();

$cq->closeCR();

$cq->closeCRByBaseline();

$cq->editRecord();

$cq->createBL();

$cq->linkBL();

$cq->closeBL();

$cq->blReport();

$cq->getFieldValidSet();

$cq->queryRecord();

$cq->results();

$cq->get_error();

# if the uri and proxy parameters are not provided, Session will use the values found for the CQAPI_WEB_SERVICE_URI and CQAPI_WEB_SERVICE_PROXY environment variables.


=head1 DESCRIPTION

The Session.pm module provides access to the CMBP ClearQuest Web Service.  

Although abstracted, the methods available through this module mimic the actions available through the CMBP ClearQuest GUI interface.  The module provides minimal validation of field names and values, instead relying on the ClearQuest application an associated business logic.

=head1 PROGRAMMING STYLE

Session.pm provides an object-oriented interface.  Multiple Session objects can be created to use with multiple CQ databases, multiple users, or any combination.  A Session object represents a user's session when logged into the ClearQuest GUI.

=head2 CREATING A SESSION OBJECT


    my( $request ) = CMBPClearQuestInterface::Session->new( uri       => $CQAPI_WEB_SERVICE_URI,
                                                            proxy     => $CQAPI_WEB_SERVICE_PROXY,
                                                            userName  => 'cq_usr',
                                                            passWord  => 'cq_usr_pwd',
                                                            encrypt   => 0,
                                                            database  => 'CQDB' );
                                                            

A Session object requires 6 parameters:

1. uri: URI for the CMBP CQ Web Service.

2. proxy: Proxy for the CMBP CQ Web Service.

3. userName: CMBP ClearQuest user name.

4. passWord: CMBP ClearQuest user password.

5. encrypt: Encryption flag.  ( 0 eq 'Do Not Encrypt', 1 eq 'Encrypt' ).  If the user password is not encrypted (as in the user's .cqparams file), Session will provide simple encryption.

6. database: The CMBP ClearQuest database to access.



=head2 PREPARING RECORDS

Each ClearQuest record (CR, SR, etc) is represented as a HASH.  Each HASH will be serialized as a Record with in the SOAP message that will be sent to the CMBP CQ Web Service.

The HASH has the following structure:

 { uuid  => 'ABC123456',
   type  => 'Development_CR',
   state => 'Assigned',
   title => 'This is a very important CR',
   notes => 'Updating this very important CR',
   xxlist => [ 'jqpublic1', 'jmotorola' ] }

The uuid and type key/value pairs are required execpt where noted.

All other keys are a CMBP CQ field name.  The associated value is the new value to apply to the field.

IMPORTANT NOTE:

Most field values are single strings.  To add multiple values, they must be included in an array (see xxlist, above).
This is different from a short string field that takes a comma seperated list of values (i.e. "Copy_To_Emails")!

You must first prepare each record before calling any of the action methods. 


=head2 CMBP CLEARQUEST ACTIONS


closeCR

Take the "Close" transitory action on a CR.  To Close multiple CRs in the same request, prepare a record for each.

closeCRByBaseline

Take the "Close" transitory action on the group of CRs associated with the given Baseline.

editRecord

Apply the given values to the associated fields.

createBL

Create a new baseline.

linkBL

Link baselines.

closeBL

"Close" ("Baseline") a Baseline record.

blReport

Return information on the state of a baseline and the state of the associated CRs.


=head2 RETRIEVING RESULTS:

The results method will return a hash containing the results from the last call. 

my( %results ) = $cq->results();

The results HASH structure:
  
             { actionResult  => '',
               actionMessage => '',
               recordList    => [ { recordResult  => '',
                                    recordMessage => ''
                                    uuid          => '',
                                    type          => '',
                                    field1        => '', # fieldn may be a scalar (single value)
                                    field2        => [], #  or array ref (multi-value)
                                     ...
                                  },
                                  { recordResult  => '',
                                    recordMessage => ''
                                    uuid          => '',
                                    type          => '',
                                    field1        => '',
                                    field2        => [],
                                     ...
                                  },                                
                                ],
             };

results HASH keys:

=item 1. actionResult

The over-all disposition of the request.  cqtool will attempt to complete the requested action on all records, regardless of the outcome of the action on any given record.  If the action is successful for all records, the disposition will be a success, if the action fails for one or more records, the disposition is failure. 

=item 2. actionMessage

A message describing the over-all outcome of the request.

=item 3. recordList

A list (array) of records involved in the request.  

Each record within recordList is represented as a HASH with the following keys:

=item 1. recordResult

The disposition of the action for the record (empty for query actions)

=item 2. recordMessage

A message describing the outcome of the requested action taken on this particular record. (empty for query actions)

=item 3. uuid

The unique identifier of the record

=item 4. type

The record type

=item 5. "field"

The fields and associated values involved in the action taken on the record.  If the action is to edit a record, the values represent the "new" values for each field.

The key for each field is identical to the key provided to B<prepareRecords()>.  If you provided "Title", you will get back "Title".

=head2 RETRIEVING ERRORS

All Session methods return a "1" on failure, "0" on success.

Error messages can be retrieved by calling get_error():

print( "Something bad happened! ", $cqtool->get_error(), "\n" );

=cut

=head1 REVISION HISTORY

=item 1. INDEV00082318

Initial release.

=cut
