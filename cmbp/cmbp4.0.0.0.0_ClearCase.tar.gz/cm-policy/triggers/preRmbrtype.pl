#VERSION CMBP 2.2
#
###############################################################################
##
## Program: preRmbrtype    
##
## Summary: trigger fired before remove branch type
##
## Description:
##
##       Allow 'rmbrtype' operation                              
##       - if the user is the VOB owner 
##       - if the branch type is not an integration or mainline type
##
###############################################################################

package PreRmbrtype;

use strict;

use vars qw(@ISA @EXPORT);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(prermbrtype);

BEGIN {
  use File::Basename;
  my $SCRIPT_ROOT = dirname $0;
  push(@INC, "$SCRIPT_ROOT/../lib");
  push(@INC, "$SCRIPT_ROOT/../config");
}

use CMBlueprint;
use CMBlueprint::NamingPolicy;
use CMBlueprint::Vob;
use CMBlueprint::ClearQuest;

use vars qw($CLEARTOOL);

################## ACE TRIGGER ###########################################

=head1 NAME

prermbrtype -- function called on pre-op of 'cleartool rmbrtype' command.  

=head1 SYNOPSIS

 If the user is the VOB owner, then allow removal of branch type.  If the user
 is not the VOB owner, then allow removal only if the branch type is not an
 integration or mainline type. 

=head1 INSTALLATION COMMAND

 Install trigger using the following command:

 cleartool mktrtype -type -preop rmtype -brtype -all \
   -execunix $UNIX_PERL "$UNIX_INSTALL_DIR/triggers/triggerMain.pl -t preRmbrtype" \
   -execwin  $NT_PERL   "$NT_INSTALL_DIR\triggers\triggerMain.pl -t preRmbrtype" \
 preRmbrtype

=head1 DESCRIPTION

=over 3

=item 1.

Get the owner of the VOB. If $ENV{'CLEARCASE_USER'} is the owner
of the VOB, then allow the rmbrtype operation.            

=item 2.

Only the VOB owner is allowed to remove integration and mainline 
branch types.

=item 3.

Users shall be able to remove own sandbox (tmp) branch types.

=item 4.

Users shall also be able to remove CR branch types as long as
user owns the branch type, branch type has local mastership, CR 
is in assigned state in ClearQuest and CR has not been merged to
any integration branch. CR in assigned state implicitly requires
that the CR branch is unlocked for the owner. 

=back

=head1 RETURN VALUES

  0 if allow the 'rmbrtype' operation
  1 if do not allow the 'rmbrtype' operation

=cut

##########################################################################

sub prermbrtype {

  #############################################
  # Allow operation is user is VOB owner      #
  #############################################
  my ($owner, $group) = &get_vob_owner_group;
  if (lc($owner) eq lc($ENV{"CLEARCASE_USER"})){
     return 0;
  }

  # Allow rmbrtype, if CQCC Integration NOT Enabled
  return 0 if ( ! $::CQCC_INTEGRATION_ENABLED );

  my $brtype = $ENV{"CLEARCASE_BRTYPE"};

  dprint ("CLEARCASE_BRTYPE=$brtype");

  # Don't allow main branch types to be removed
  if ( $brtype =~ m/[_-]?main$/ ) {
     display_msg("Only the VOB owner is permitted to remove main branch type $brtype");
     return 1;
  }

  # Make sure branchtype has local mastership
  my $errmsg;
  my $object = "brtype:$brtype";

  if($NT) {
    $ENV{CLEARCASE_VOB_PN} = "$::CC_NT_ADMINVOB";
  }
  else{
    $ENV{CLEARCASE_VOB_PN} = "$::CC_UNIX_ADMINVOB";
  }

  if(!isTypeMasterReplica($object, $ENV{CLEARCASE_VOB_PN}, \$errmsg)) {
    display_msg("$errmsg\n");
    return 1;
  }

  # Get type of branch (e.g. integration, sandbox, or dev)
  my %retval = ParseBrtypeName($brtype);

  # Don't allow integration branch types to be removed
  if ( $retval{ERROR} == 0 && $retval{IS_INT_USAGE} ) {
     display_msg("Only the VOB owner is permitted to remove Integration branch types");
     return 1;
  }

  # Don't allow Dev-Int branch types to be removed
  if ( $retval{ERROR} == 0 && $retval{IS_DEVINT_USAGE} ) {
     display_msg("Only the VOB owner is permitted to remove Dev-Int branch types");
     return 1;
  }

  # For Development branch types 
  if ( $retval{ERROR} == 0 && ($retval{IS_DEV_USAGE} or $retval{IS_DEVINT_USAGE}) ) {

    my $lbrname = qq(brtype:$brtype\@vob:$ENV{CLEARCASE_VOB_PN});
    dprint("Check lbrname:$lbrname \n");

    my $crid  = (qx{$CLEARTOOL desc -s -aattr OriginatingCR $lbrname})[0];
    $crid =~ s/["']//g; chomp($crid);
    return 0 if ( $crid eq '' || $crid !~ m/\d{6,}$/ );

    dprint("lbrname ($lbrname) crid ($crid)");

    # Make sure CR is in assigned state
    if(!CheckIsCRAssigned($crid)) {
      display_msg("CQ CR $crid is not is Assigned state. Cannot remove the branch type:$brtype");
      return 1;
    }

    # Verify CQ credentials before allowing removal of CR branch type
    my ($rc, $cquser, $cqpwd) = GetLogonParms();

    if($::USEMERGESTATES) {

      dprint("brtype:$brtype CLEARCASE_VOB_PN:$ENV{CLEARCASE_VOB_PN}\n");

      my ($rc, $uuid, $oid) = GetUidOid($brtype,$ENV{CLEARCASE_VOB_PN});

      if($rc) {
	display_msg("Failed to obtain the vob_family uid from branch $brtype.\n");
	return 1;
      }

      my ($rc,$status,$originatingCR) = getVobObjectNameFromCQ($uuid,$brtype,$ENV{CLEARCASE_VOB_PN});
      if($rc) {
	display_msg("Failed to obtain the current mergestate from brtype:$brtype\n");
	return 1;
      }

      dprint("status: $status originatingCR:$originatingCR \n");

      if($status =~ /:/) {
	my($work_status, $integrated_branch) = (split(/:/,$status))[0,1];

	if ($work_status =~ /WORK_COMPLETED/i) {
	  display_msg("Can not Remove branch type. The change has WORK_COMPLETED status\n.");
	  return 1;
	}
	  
	if($integrated_branch ne ""){
	  display_msg("Can not Remove branch type. Branch has been already targeted or integrated with $integrated_branch.");
	  return 1;
	}
      }
    }#endif USEMERGESTATES

  } # endif IS_DEV_USAGE

  # Allow other branch types (sandbox and dev)
  if ( $retval{ERROR} != 0 ) {
     display_msg("Error parsing brtype - $retval{ERRMSG}");
     return 1;
  } elsif ( $retval{IS_DEV_USAGE} && $::NO_USER_RM_BRTYPE != 0 ) {
	 display_msg("Normal user has not been permitted to remove their own dev branch type!");
	 return 1;
  }
  else {
     return 0;
  }
}

1;

