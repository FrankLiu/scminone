#VERSION CMBP 3.1
#
###############################################################################
##
## Program: rmhlink.pl
##
## Summary: trigger fired before rmhlink operation on a brtype
##
## Description:
##
## Trigger will verify that only FAC's can remove Ok_to_remove hyperlink.
##
###############################################################################

package RmHlinkBrtype;

use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(preRmHlinkBrtype);

BEGIN {
	use File::Basename;
	my $SCRIPT_ROOT = dirname $0;
	push(@INC, "$SCRIPT_ROOT/../lib");
}

use CMBlueprint;


use vars qw($CLEARTOOL);

sub preRmHlinkBrtype
{
    my %restrictedHLinkType = (
			       Ok_to_merge => 1,
			       Merged_done => 1,
			       Merged_ready_to_build => 1,
			       );

    if($restrictedHLinkType{$ENV{CLEARCASE_HLTYPE}} != 0)
    {
	my @fullFAC = getFACList();
	
	# will see if the current owner of the branch is the user.
	my $brtype = $ENV{CLEARCASE_MOD_TYPE};
	$brtype =~ s/^brtype://;

	my $browner = getBrOwner($brtype,$ENV{CLEARCASE_VOB_PN});
	if($browner =~ m/$CURRENT_USER/i)
	{
	    return 0; 
	}

	foreach (@fullFAC)
	{
	    if(m/$CURRENT_USER/i)
	    {
		return 0;
	    }
	}

	display_msg("User is not authorize to execute command \n");
	return 1;
    }

    return 0;
}

1;


