#VERSION CMBP 2.2
#
###############################################################################
##
## Program: preMklbtype       
##
## Summary: trigger fired before creating a label type
##
## Description:
##
##       Do not allow 'mklbtype' operation                              
##       - if the label type contains lowercase characters.
##
###############################################################################

package PreMkLbtype;

use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(premklbtype);

BEGIN {
	use File::Basename;
	my $SCRIPT_ROOT = dirname $0;
	push(@INC, "$SCRIPT_ROOT/../lib");
}

use CMBlueprint;
use CMBlueprint::Vob;


################## ACE TRIGGER ###########################################

=head1 NAME

preMklbtype -- function called on pre-op of 'cleartool mklbtype' command.  

=head1 SYNOPSIS

  mklbtype will not be allowed if the label type contains lowercase characters.

=head1 INSTALLATION COMMAND

 Install trigger using the following command:

 cleartool mktrtype -elem -all -preop mklbtype  \
   -execunix $UNIX_PERL "$UNIX_INSTALL_DIR/triggers/triggerMain.pl -t preMklbtype" \
   -execwin  $NT_PERL   "$NT_INSTALL_DIR\triggers\triggerMain.pl -t preMklbtype" \
 preMklbtype

=head1 DESCRIPTION

=over 3

=item 1.

Get the owner of the VOB. If $ENV{'CLEARCASE_USER'} is the owner
of the VOB, then allow the mklbtype operation.            


=back

=head1 RETURN VALUES

  0 if allow the 'mklbtype' operation
  1 if do not allow the 'mklbtype' operation


=cut

##########################################################################

sub premklbtype{

   #############################################
   # Allow operation is user is VOB owner      #
   #############################################
   my ($owner, $group) = &get_vob_owner_group;
   if ((lc($owner) eq lc($ENV{"CLEARCASE_USER"})) || 
       (uc($owner) eq uc($ENV{"CLEARCASE_USER"}))){
      return 0;
   }

   my $lbtype = $ENV{CLEARCASE_LBTYPE};

   if($lbtype =~ /[a-z]/)
   {
       display_msg("Label type contains lowercase characters. Only uppercase characters are allowed.\n");
       return 1;
   }

   return 0;
}

1;

