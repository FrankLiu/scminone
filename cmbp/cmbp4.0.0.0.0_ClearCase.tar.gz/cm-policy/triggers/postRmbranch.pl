#VERSION CMBP 2.2
#
###############################################################################
##
## Program: postRmbranch
##
## Summary: trigger fired after post rmbranch operation
##
## Description:
##
##       If the user is not the vob owner, allow the rmbranch operation only if
##       - the 0th version is the latest version on the branch
##       - the branch has no sub-branches.              
##
##
###############################################################################

package PostRmbranch;

use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(postrmbranch);

BEGIN {
	use File::Basename;
	my $SCRIPT_ROOT = dirname $0;
	push(@INC, "$SCRIPT_ROOT/../lib");
}

use CMBlueprint;
use CMBlueprint::Branch;

use vars qw($CLEARTOOL $TMPDIR);

################## ACE TRIGGER ###########################################


=head1 NAME

postRmbranch -- Function to remove the branch of the predecessor version, if the predecessor 
version is 0 and if the branch does not have any versions or sub-branches.

=head1 SYNOPSIS

postRmbranch

=head1 INSTALLATION COMMAND

  Create the trigger type using the following command:

  cleartool mktrtype -elem -all -postop rmbranch  \
    -execunix $UNIX_PERL "$UNIX_INSTALL_DIR/triggers/triggerMain.pl -t postRmbranch" \
    -execwin  $NT_PERL   "$NT_INSTALL_DIR\triggers\triggerMain.pl -t postRmbranch" \
  postRmbranch

=head1 DESCRIPTION

=over 3

=item 1.

The preRmbranch trigger writes the name of the predecessor version
in a temporary file.                                  

=item 2.

Read the temporary file.  If the predecessor branch is /main, then exit.    
If the predecessor branch is not /main and if it does not have versions and    
sub-branches, then remove the predecessor branch.

=back

=head1 RETURN VALUES

  0 on success
  1 on failure


=cut

##########################################################################

sub postrmbranch {

   ##################################################
   # Get the predecessor version from the temporary #
   # file (this file was created by the preRmbranch #
   # trigger).                                      #
   ##################################################
   my ($predecessor_ver, $predecessor_branch);
   my $parentPid = $ENV{'CLEARCASE_PPID'};
   my $tmpfile = "$TMPDIR/rmbranch.$parentPid";

   open (TMP, "$tmpfile") or die( "Error: Cannot open file: $tmpfile\n");
   while (<TMP>){
     $predecessor_ver = $_;
   }
   close TMP;
   unlink $tmpfile;

   ##############################################
   # Check if the predecessor version is the    #
   # 0th version.                               #
   # If predecessor is the 0th version, then    #
   #    check the corresponding branch.         #
   #    Do not remove the branch if -           #
   #       - it is /main or                     # 
   #       - it has versions or sub-branches    # 
   ##############################################
   if ( $predecessor_ver =~ m#^(.*)[/|\\]0$#o ){
      my $predecessor_branch = $1;
      my $predecessor_xpn = "\"$ENV{'CLEARCASE_PN'}\"\@\@$predecessor_branch";

      ###########################################
      # if $predecessor_branch is not /main,    #
      # check if it has sub-branches or versions#
      # If notif $predecessor_branch is /main   #
      # Removeif $predecessor_branch is /main   #
      ###########################################
      if ( ($predecessor_branch !~ m#^[/|\\]main$#o)
      &&   (not has_vers_subbranches($predecessor_xpn))){
         dprint("Removing branch: $predecessor_xpn\n");
         my $cmd = "$CLEARTOOL rmbranch -force \"$predecessor_xpn\"";
         #prep_cmd(\$cmd);
         `$cmd`;
      }
   }

   return 0;
}

1;

