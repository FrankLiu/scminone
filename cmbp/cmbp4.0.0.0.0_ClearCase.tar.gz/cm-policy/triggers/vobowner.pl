#VERSION CMBP 2.2
#
###############################################################################
##
## Program: vobowner 
##
## Summary: trigger fired before mktrigger, rmtrigger and chtype operation
##
## Description:
##
##       Only the VOB owner can execute mktrigger, rmtrigger and chtype
##       operations.     
##
###############################################################################

package VobOwner;

use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(vobowner);

BEGIN {
	use File::Basename;
	my $SCRIPT_ROOT = dirname $0;
	push(@INC, "$SCRIPT_ROOT/../lib");
}

use CMBlueprint;
use CMBlueprint::Vob;

##########################################################################

=head1 NAME

vobowner -- function called on pre-op mktrigger,rmtrigger,chtype,rmhlink, rmlabel, rmattr 
and rename branchtype operations.  Only the VOB owner can execute these operations.

=head1 SYNOPSIS

 vobowner()

=head1 INSTALLATION COMMAND

 Install the trigger using the following command:

 cleartool mktrtype -elem -all -preop mktrigger  \
   -execunix $UNIX_PERL "$UNIX_INSTALL_DIR/triggers/triggerMain.pl -t preVobOwnerOnly"\
   -execwin  $NT_PERL   "$NT_INSTALL_DIR\triggers\triggerMain.pl -t preVobOwnerOnly" \
 preVobOwnerOnly

=head1 DESCRIPTION

Get the owner of the VOB. If $ENV{'CLEARCASE_USER'} is the owner of the VOB, then return 0; else return 1.

=head1 RETURN VALUES

 0 if user is the VOB owner
 1 if user is not the VOB owner. 


=cut

##########################################################################
sub vobowner {

   my $user = $ENV{'CLEARCASE_USER'};

   my ($owner, $group) = &get_vob_owner_group;
   if ((lc($owner) ne lc($user)) && (uc($owner) ne uc($user))){
      display_msg("Only the VOB owner $owner can execute this command\n", 1);
      return 1;
   }

   return 0;
}

1;
