#VERSION CMBP 2.2
#
###############################################################################
##
## Program: postRmbrtype  
##
## Summary: trigger fired after rmtype brtype:xxx operation
##
## Description:
##
##		write to CQ cc_change_set the value 'BRTYPE_DELETED'
##
###############################################################################

package PostRmbrtype;
use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(premkelem);

BEGIN {
	use File::Basename;
	my $SCRIPT_ROOT = dirname $0;
	push(@INC, "$SCRIPT_ROOT/../lib");
}

use CMBlueprint;
use CMBlueprint::ClearQuest;
use CMBlueprint::NamingPolicy;

sub postRmbrtype {
	
	my $cvalue	= 'BRTYPE_DELETED';	
	my $brtype	= $ENV{CLEARCASE_BRTYPE};
	return 0 if ( ! $::CQCC_INTEGRATION_ENABLED );
	my %retval = ParseBrtypeName($brtype);

	##return 0 for ALL except dev branch (int/sandbox/rel pass through)
	return 0 if ( $retval{ERROR} == 0 && ! ($retval{IS_DEV_USAGE} or $retval{IS_DEVINT_USAGE})) ;

	my($rc,$crid) = FormatCrId($retval{REC_ID});

	if ( $rc ) {
		display_msg("Can't get CQ CR number for brtype $brtype!");
		return 1;
	}

	MVCsetLog($brtype,$crid,$cvalue);	

	return 0;

}

1;
