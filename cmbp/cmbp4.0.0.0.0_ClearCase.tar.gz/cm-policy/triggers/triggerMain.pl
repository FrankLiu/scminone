#!/usr/misc/bin/perl -U 

#VERSION CMBP 2.2
#
require 5.002;

use strict;
use Socket;
use File::Basename;
use Config;

BEGIN {
  use File::Basename;
  my $dirname = dirname($0);
  unshift(@INC, "$dirname/../lib");
  unshift(@INC, "$dirname/../triggers");
};

use vars qw(%triggerMap);

use CMBlueprint;
use CMBlueprint::Config;
use Getopt::Long;

my @SAVE_ARGV = @ARGV;
GetOptions("-t:s");

use vars qw($opt_t);
my $trtype = $opt_t;

################## ACE TRIGGER ###########################################

=head1 NAME

triggerMain -- This script is a wrapper for all the trigger functions.  

=head1 SYNOPSIS

 triggerMain.pl -t <trtype>

 where <trtype> is the name of the trigger type.


=head1 INSTALLATION COMMAND

 Install trigger using the following command:

 cleartool mktrtype -elem -all -preop <ClearCase operations>  \
   -execunix $UNIX_PERL "$UNIX_INSTALL_DIR/triggers/triggerMain.pl -t <trtype> \
   -execwin  $NT_PERL   "$NT_INSTALL_DIR\triggers\triggerMain.pl -t <trtype>" \
 <trtype>

=head1 DESCRIPTION

  -  Get the corresponding function for the <trtype> by using 
     $triggerMap, which is defined in "trigger.pm".                          

  -  The <trtype> is prefixed with "pre" or a "post" if it is a 
     preop trigger or a postop trigger respectively. 
     Based on the prefix, determine if it is a preop or a postop trigger.

  -  Check if there is $TRIGGER_HOOK{'before-<trtype>'} defined in the 
     product config file.  If there is, then invoke that function.  

     If it is a 'preop' trigger type, 
        - check the return status of the function.  
        - If the return status is non-zero, then exit with non-zero status.
          (ClearCase will not permit the operation, if a preop trigger 
           on the operation returns a non-zero value).

     If it is a 'postop' trigger type,
        - Ignore the return status of the function.
          (In a post-op trigger, ClearCase has already performed the 
           operation.  A non-zero status only serves as a warning).

  -  Execute the corresponding Common CM function.  Exit with a non-zero
     status if it is a preop trigger and if the function returns a non-zero
     status.

  -  Check if the product has defined a after-<trtype> function in the 
     product config file.  If so, execute that function.  Exit with a 
     non-zero status if it is a preop trigger and if the function returns 
     a non-zero status.
     

=head1 RETURN VALUES

  0 if all the called functions succeed
  1 if any of the called functions do not succeed.


=cut

##########################################################################

my ($func, $script)    = @{$triggerMap{$trtype}};

my $op_type = ($trtype =~ /^pre/ ? 'pre' : 'post');
$ENV{CMBP_TRTYPE} = $trtype;

################## SEE IF WE SHOULD INVOKE THE DEBUGGER #################

##----------------------------------------------------------------
## If the $ENV{CQCC_DEBUG_WITH_PERL_DEBUGGER} variable is set,
## then re-invoke ourselves under the perl debugger. The value
## that its set to should be either 1,'*','All' (for all triggers)
## or else it should be a comma (or semicolon) separated list
## of trtypes to debug, or else it should be a string indicating
## that the debugger is already running!
##----------------------------------------------------------------

my $perl_debugger  = $ENV{CQCC_DEBUG_WITH_PERL_DEBUGGER} || "";
my $already_debugging = "*** ALREADY IN USE ***";
if ($perl_debugger  and  $perl_debugger ne $already_debugging) {
   my @to_debug = (split /[+,;\s]+/, $perl_debugger);
   my $invoke_debugger = ( $perl_debugger =~ /^(\d+|[Aa][Ll][Ll]|\*)$/
                           or  grep { lc($trtype) eq lc($_) } @to_debug );
   if ($invoke_debugger) {
      ## Make sure we dont try to debug ourselves again
      $ENV{CQCC_DEBUG_WITH_PERL_DEBUGGER} = $already_debugging;

      ## Invoke the debugger
      print STDERR "*** Invoking Perl debugger for $trtype trigger! ***\n";
      my $debug_opts = ($^W) ? "-wd" : "-d" ;
      my @debug_cmd = ( $Config{'perlpath'}, $debug_opts, $0, @SAVE_ARGV );
      print STDERR "*** Executing @debug_cmd\n";
      my $status = system(@debug_cmd);
      exit $status;
   }
}

################## READ THE CONFIGURATION FILES #################

use vars qw(
        $PARALLEL_DEV_WARN_ENABLED
        $FORBID_TWIN_ELEMS_ENABLED
        $INTBRANCH_MERGELOCK_LOOKUP_ENABLED
        $DEVBRANCH_MERGELOCK_LOOKUP_ENABLED
        $PROMPT_ON_CR_MISMATCH
        $PER_CO_AUTH_REQD
        $OPCACHE_TIMEOUT
        $CQCC_INTEGRATION_ENABLED
        $CQCC_CSET_LOGGING_ENABLED
        $NAME_SEGMENT_DELIMITER
        $USAGE_TAG_DELIMITER
        $USAGE_TAG_DELIMITER_REQD
        $USAGE_TAG_IS_PREFIX
		%ADMIN_TRIGGER_PARAM
		%NO_USER_TRIGGER_PARAM
		@CC_VOBADM_LST
);

## Default values for undefined configuration variables
my %DEFAULT_CONFIG_VALS = (
        PARALLEL_DEV_WARN_ENABLED => 1,
        FORBID_TWIN_ELEMS_ENABLED => 1,
        PROMPT_ON_CR_MISMATCH     => 1,
        PER_CO_AUTH_REQD          => 1,
        OPCACHE_TIMEOUT           => 8*60*60,
        CQCC_INTEGRATION_ENABLED  => 1,
        CQCC_CSET_LOGGING_ENABLED => 0,
        INTBRANCH_MERGELOCK_LOOKUP_ENABLED => 1,
        DEVBRANCH_MERGELOCK_LOOKUP_ENABLED => 0,
        NAME_SEGMENT_DELIMITER    => "_",
        USAGE_TAG_DELIMITER       => "-",
        USAGE_TAG_DELIMITER_REQD  => 0,
        USAGE_TAG_IS_PREFIX       => 1
);

read_configFile();

## Default configuration flags
for (keys %DEFAULT_CONFIG_VALS) {
  unless (defined ${$::{$_}}) {
     ${$::{$_}} = $DEFAULT_CONFIG_VALS{$_};
     dprint "cfg", "Defaulting $_ to $DEFAULT_CONFIG_VALS{$_}\n";
  }
}

## Debugging configuration flags
if ($ENV{CQCC_DEBUG}||"") {
  my $dbg_cfg_pfx = 'CQCC_DEBUG_CONFIG_';
  for (grep /^$dbg_cfg_pfx\w+/, (keys %ENV)) {
     my $ev_key = $_;
     s/^$dbg_cfg_pfx//;
     if (defined $ENV{"$ev_key"}) {
        ${$::{$_}} = $ENV{$ev_key};
        dprint "cfg", "Setting $_ to $ENV{$ev_key} for debugging!\n";
     }
  }
}

$::CQCC_INTEGRATION_ENABLED  or  $::CQCC_CSET_LOGGING_ENABLED = 0;

################## CALL THE PRE-TRIGGER-HOOK #################
my $isAdmin=0;
foreach (@CC_VOBADM_LST) {
	if ( lc($ENV{CLEARCASE_USER}) eq lc($_) ) {
		$isAdmin=1;
		last;
	}
}

##disable triggers for admin if NO_ADMIN_TRIGGER has been exported.
##such as in the middle of trigger installing time
##or any time after installation
exit(0) if ( $isAdmin == 1 && $ENV{NO_ADMIN_TRIGGER} != 0 );

## disable triggers if ENV{HAKUNAMATA} is set.
dprint("ENV ---> COPYMERGE = $ENV{HAKUNAMATA}\n");
exit(0) if($ENV{HAKUNAMATA} != 0);

$ADMIN_TRIGGER_PARAM{$trtype}= [] if ( ! exists($ADMIN_TRIGGER_PARAM{$trtype}) );
$NO_USER_TRIGGER_PARAM{$trtype} = [] if ( ! exists($NO_USER_TRIGGER_PARAM{$trtype}) );

dprint("isAdmin ($isAdmin) trtype($trtype) ADMIN_TRIGGER_PARAM(" . join("-",@{$ADMIN_TRIGGER_PARAM{$trtype}}). ") NO_USER_TRIGGER_PARAM(" . join("-",@{$NO_USER_TRIGGER_PARAM{$trtype}}) . ")");
my $triggerHookSeq = 'BEFORE';
my $status;
if ( ( $isAdmin == 0  && $NO_USER_TRIGGER_PARAM{$trtype}->[0] != 1 )
  || ( $isAdmin == 1  && $ADMIN_TRIGGER_PARAM{$trtype}->[0] != 0) ) {
	dprint("CALL preHook isAdmin($isAdmin) trtype($trtype)");
	$status = invokeTriggerHook($triggerHookSeq, $trtype);
	if (($op_type eq 'pre') && ($status != 0)){
	display_msg( "Error: Hook failed:$triggerHookSeq-$trtype. \n");
	exit $status;
	}
}

################## COMMONCM TRIGGER ###############################

if ( ( $isAdmin == 0 && $NO_USER_TRIGGER_PARAM{$trtype}->[1] != 1 )
  || ( $isAdmin == 1 && $ADMIN_TRIGGER_PARAM{$trtype}->[1] != 0) ) {
	eval { require "$script" };
	die( "Error: Cannot do require of $script: $@:$!:") if($@);

	dprint("CALL trigger isAdmin($isAdmin) trtype($trtype) ($script)");
	$status = &$func();
	if (($op_type eq 'pre') && ($status != 0)){
	display_msg( "Error: Trigger script failed to execute \n");
	exit $status;
	}
}

################## CALL THE POST-TRIGGER-HOOK #################
if ( ( $isAdmin == 0  && $NO_USER_TRIGGER_PARAM{$trtype}->[2] != 1 )
  || ( $isAdmin == 1  && $ADMIN_TRIGGER_PARAM{$trtype}->[2] != 0) ) {
	dprint("CALL postHook isAdmin($isAdmin) trtype($trtype)");
	$triggerHookSeq = 'AFTER';
	$status = invokeTriggerHook($triggerHookSeq, $trtype);
	if ($status != 0) {
	display_msg( "Error: Hook failed:$triggerHookSeq-$trtype \n");
	}
}
exit $status;
