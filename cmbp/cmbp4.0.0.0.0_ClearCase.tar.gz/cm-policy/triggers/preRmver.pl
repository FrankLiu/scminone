#VERSION CMBP 2.2
#
###############################################################################
##
## Program: preRmver       
##
## Summary: trigger fired before remove version
##
## Description:
##
##       Do not allow 'rmver' operation                              
##       - if the branch is an alternate main branch.
##       - if the version is not the latest version on the branch.
##
###############################################################################

package PreRmver;

use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(prermver);

BEGIN {
	use File::Basename;
	my $SCRIPT_ROOT = dirname $0;
	push(@INC, "$SCRIPT_ROOT/../lib");
}

use CMBlueprint;
use CMBlueprint::Vob;


################## ACE TRIGGER ###########################################

=head1 NAME

preRmver -- function called on pre-op of 'cleartool rmver' command.  

=head1 SYNOPSIS

  rmver will not be allowed if the version in on a main branch or it is not the lasted version.

=head1 INSTALLATION COMMAND

 Install trigger using the following command:

 cleartool mktrtype -elem -all -preop rmver  \
   -execunix $UNIX_PERL "$UNIX_INSTALL_DIR/triggers/triggerMain.pl -t preRmver" \
   -execwin  $NT_PERL   "$NT_INSTALL_DIR\triggers\triggerMain.pl -t preRmver" \
 preRmver

=head1 DESCRIPTION

=over 3

=item 1.

Get the owner of the VOB. If $ENV{'CLEARCASE_USER'} is the owner
of the VOB, then allow the rmver operation.            


=back

=head1 RETURN VALUES

  0 if allow the 'rmver' operation
  1 if do not allow the 'rmver' operation


=cut

##########################################################################

sub prermver{
   #############################################
   # Allow operation is user is VOB owner      #
   #############################################
   my ($owner, $group) = &get_vob_owner_group;
   if ((lc($owner) eq lc($ENV{"CLEARCASE_USER"})) || 
       (uc($owner) eq uc($ENV{"CLEARCASE_USER"}))){
      return 0;
   }

   my $file = $ENV{CLEARCASE_XPN};
   my $brtype = $ENV{CLEARCASE_BRTYPE};

   if(isBuildBranch($brtype,$ENV{CLEARCASE_VOB_PN}))
   {
       display_msg("Removing version $file is not allowed since branch $ENV{CLEARCASE_BRTYPE} is an integration branch\n");
       return 1;
   }

   if ( $brtype =~ m/[_-]?main$/ ) 
   {
       display_msg("Only the VOB owner is permitted to remove a version from a main branch.\n");
       exit(1);
   }

   return 0;
}

1;

