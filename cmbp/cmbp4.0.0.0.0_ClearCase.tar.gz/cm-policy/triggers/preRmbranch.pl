#VERSION CMBP 2.2
#
###############################################################################
##
## Program: preRmbranch
##
## Summary: trigger fired before rmbranch operation
##
## Description:
##
##       If the user is not the vob owner, allow the rmbranch operation only if
##       - the 0th version is the latest version on the branch
##       - the branch has no sub-branches.              
##
##
###############################################################################
package PreRmbranch;

use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(prermbranch);

BEGIN {
	use File::Basename;
	my $SCRIPT_ROOT = dirname $0;
	push(@INC, "$SCRIPT_ROOT/../lib");
}

use CMBlueprint;
use CMBlueprint::Vob;
use CMBlueprint::Branch;

use vars qw($CLEARTOOL $TMPDIR);

################## ACE TRIGGER ###########################################

=head1 NAME

preRmbranch -- trigger script called on pre-op of 'cleartool rmbranch' command.  
If the user is not the VOB owner, allow 'rmbranch' operation if the 0th version 
is the LATEST version on the branch and the branch has no sub-branches.

=head1 SYNOPSIS

 prermbranch()

=head1 INSTALLATION COMMAND

  Install the trigger using the following command:

 cleartool mktrtype -elem -all -preop rmbranch  \
   -execunix $UNIX_PERL "$UNIX_INSTALL_DIR/triggers/triggerMain.pl -t preRmbranch"\
   -execwin  $NT_PERL   "$NT_INSTALL_DIR\triggers\triggerMain.pl -t preRmbranch" \
 preRmbranch

=head1 DESCRIPTION

=over 3

=item 1.

Get the owner of the VOB. If $ENV{'CLEARCASE_USER'} is the owner
of the VOB, then allow rmbranch operation.            

=item 2.

If the branch type is "main", then do not allow the I<cleartool rmbranch> 
operation.

=item 3.

$ENV{'CLEARCASE_XPN'} contains the name of the branch.  If the branch has no
versions and no sub-branches, then allow the I<cleartool rmbranch> operation.

=item 4.

Save the predecessor version in a temporary file.  The postRmbranch trigger
will read this file and remove the predecessor branch if it's not the main 
branch and if it does not have versions or sub-branches.

=back

=head1 RETURN_VALUES

  0 on success
  1 on success


=cut

##########################################################################

sub prermbranch {

   ##################################################
   # Save the predecessor version in a temporary    #
   # file so that the postRmbranch trigger can use  #
   # to recursively remove parent branches which    #
   # have only the 0th version on them.             #
   ##################################################
   my $parentPid = $ENV{'CLEARCASE_PPID'};
   my $tmpfile = "$TMPDIR/rmbranch.$parentPid";

   my $cmd = "$CLEARTOOL describe -short -predecessor \"$ENV{'CLEARCASE_XPN'}\"/0";
   #prep_cmd(\$cmd);
   my $output = `$cmd`;
   chomp($output);
   open (TMP, ">$tmpfile") or die( "Error: Cannot open file: $tmpfile\n"); 
   print TMP "$output";
   close TMP;

   ################################################
   # Get the VOB owner.  If the user is the       #
   # VOB owner, then allow rmbranch operation.    #
   ################################################
   my ($vob_owner, $vob_group) = &get_vob_owner_group;
   if ($ENV{'CLEARCASE_USER'} eq $vob_owner){
      return 0;
   }

   ################################################
   # If the branch type is 'main', then do not    #
   # allow the rmbranch operation.                #
   ################################################
   if ($ENV{'CLEARCASE_BRTYPE'} eq "main"){
      display_msg("Error:  Cannot remove /main branch\n", 1);
      unlink $tmpfile;
      return 1;
   }

   ##################################################
   # $ENV{'CLEARCASE_XPN'} contains the name of     #
   # the branch.  Check if it has versions or       #
   # sub-branches.  If it does, then do not allow   #
   # the rmbranch operation.                        #
   ##################################################
   if ( has_vers_subbranches($ENV{'CLEARCASE_XPN'})){
      display_msg("Error:  rmbranch operation denied because -");
      display_msg("        $ENV{'CLEARCASE_XPN'} has versions/sub-branches"); 
      unlink $tmpfile;
      return 1;
   }
   return 0;
}

1;
