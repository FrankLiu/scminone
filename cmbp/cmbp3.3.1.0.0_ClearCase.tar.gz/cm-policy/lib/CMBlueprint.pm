## Need to use the following vars from the main:: package
use vars qw($SITE_CONFIG @VOBFAMILY_LST $CQ_REC_TYPE
			$CC_VOB_ELEM_OWNER $CC_VOB_ELEM_GROUP            
			@CQ_DB_LST $CQ_DEF_DB            
			$PROD_CONFIG $CC_CLIENT_PLATFORM %TRIGGER_HOOKS
			$CC_UNIX_ADMINVOB $CC_NT_ADMINVOB);
			
package CMBlueprint;

#######################################################################

=head1 NAME

CMBlueprint - module used to maintain generic information or perform generic 
operations

=head1 EXPORTS

prep_cmd display_msg ct_subcmd dprint _get_debug_reply
get_timestamp show_help display_help invokeTriggerHook

=head1 DESCRIPTION

B<CMBlueprint> is a module is a placeholder for variables and subroutines that
are used across many modules and trigger functions.  

=cut

#######################################################################


use strict;

use Socket;
use vars qw(@ISA @EXPORT @EXPORT_OK);
use Exporter;
@ISA = qw(Exporter);

use vars qw($NT $ATRIAHOME  %LOADLINEMAP  $CQCC_HLTYPE $CQCC_ATTYPE $DEVINT_MERGELIST_ATTYPE $MERGE_LOCK_HLTYPE $PROD_FAMILY_ATTYPE $SPCF_ATTYPE
			$CLEARTOOL $CLEARPROMPT $TMPDIR $DEVNULL $ERRNULL $HOME $CQPARAM $PATH_DELIMITER $LOCKHLINK  $DEPHLINK
			$CURRENT_USER $HOSTNAME $VIEW_DRIVE $NAME_SEGMENT_DELIMITER  $USAGE_TAG_DELIMITER  $USAGE_TAG_DELIMITER_REQD $USAGE_TAG_IS_PREFIX $USEMERGESTATES
	    $NAME_SEGMENT_DELIMITER $USAGE_TAG_DELIMITER @INT_BRANCH_TAG_LST); 
use vars qw(%CQ_QUERY_FILTER @CQ_QUERY_FIELDS %CQ_WEB_PARAMS);

use vars qw(%TRIGGER_HOOKS %triggerMap);            
use constant BEFORE => 'before';
use constant AFTER => 'after';

use File::Copy;

@EXPORT = qw(
   $NT $ATRIAHOME $CQCC_HLTYPE $CQCC_ATTYPE $DEVINT_MERGELIST_ATTYPE $MERGE_LOCK_HLTYPE $DEPHLINK
   $PROD_FAMILY_ATTYPE $SPCF_ATTYPE $CLEARTOOL $CLEARPROMPT $TMPDIR $DEVNULL %LOADLINEMAP $LOCKHLINK RMINTEGRATED ADDTARGETED ADDINTEGRATEDNOCHECK VERIFY_NOT_INTEGRATED_OTHER_BRANCHES ADDINTEGRATED RMTARGETED ADDTARGETEDSTRICT VERIFY_NOT_INTEGRATED ADDWORKCOMPLETED  ADDWORKSTARTED ADDPARTIALINTEGRATED ADDLOCKEDPARTINTEGRATED
   $ERRNULL $HOME $CQPARAM $PATH_DELIMITER %CQ_QUERY_FILTER
   %CQ_WEB_PARAMS @CQ_QUERY_FIELDS $VIEW_DRIVE DEBUGGING
   prep_cmd display_msg ct_subcmd dprint _get_debug_reply
   get_timestamp show_help display_help invokeTriggerHook
   %TRIGGER_HOOKS %triggerMap BEFORE AFTER $CURRENT_USER
   $HOSTNAME CQ_VALID_CR CQ_INVALID_CR CQ_LOGIN_FAIL
   CQ_QUERY_FAIL CMBP_SUCCESS CMBP_FAIL 
   createtexthlink lockhlexist isBuildBranch isDevIntCRBranch getBrOwner verifyHyperLink delhlink addhlink addhlinkwithftext  verifyBranch getReleaseIDs isBranchLockedForAllUsers isBranchUnLockedForUser getBranchFromCS
   $NAME_SEGMENT_DELIMITER $USAGE_TAG_DELIMITER @INT_BRANCH_TAG_LST $USAGE_TAG_IS_PREFIX $USAGE_TAG_DELIMITER_REQD $USEMERGESTATES
   requireProdVobCfg getEmailLocation setAview setCCAVOBS isTypeMasterReplica getCRNumFromBrtype getIndexFromArray
   getVobsBrtypeTouched
   getReplicaNameFromVob	   
   getMarkedCRBranch
   exeFindMergeWithScriptTillDone
   getFACList
   convertCQReleaseToCCRelease
   getFeatureIDFromBranch	
 
	     
	     
); 

# @EXPORT_OK = qw();

# %EXPORT_TAGS = ( ); # not used for now, can be used later for providing better export facilites

use Config;
use File::Basename qw(dirname);

##########################################################################

=head1 NAME

$triggerMap -- maps all the trigger types with the corresponding functions.

=head1 DESCRIPTION

Used by triggerMain.pl to determine which function to execute
for a given trigger type.

=cut

##########################################################################
%triggerMap  = (
   'preVobOwnerOnly'       => [\&VobOwner::vobowner,             "vobowner.pl"],
   'preMkeltype'           => [\&VobOwner::vobowner,             "vobowner.pl"],
   'preRmbranch'           => [\&PreRmbranch::prermbranch,       "preRmbranch.pl"],
   'postRmbranch'          => [\&PostRmbranch::postrmbranch,     "postRmbranch.pl"],
   'preRmver'              => [\&PreRmver::prermver,             "preRmver.pl"],
   'postRmversion'         => [\&PostUncheckoutRmver::postuncheckoutrmver,   "postUncheckoutRmversion.pl"],
   'postUncheckout'        => [\&PostUncheckoutRmver::postuncheckoutrmver,   "postUncheckoutRmversion.pl"],
   'preCheckin'            => [\&PreCheckin::precheckin,         "preCheckin.pl"],
   'preCheckout'           => [\&PreCheckout::precheckout,       "preCheckout.pl"],
   'preRestrictCheckout'   => [\&PreRestrictCheckout::preRestrictcheckout,     "preRestrictCheckout.pl"],
   'preMkelem'             => [\&PreMkelem::premkelem,           "preMkelem.pl"],
   'postMkelem'            => [\&PostMkelem::postmkelem,         "postMkelem.pl"],
   'postCoCqCcInt'         => [\&CqCcInt::cqcc_int,              "cqcc_int.pl"],
   'preCiUncoCqCcInt'      => [\&CqCcInt::cqcc_int,              "cqcc_int.pl"],
   'preMklbtype'          => [\&PreMkLbtype::premklbtype,       "preMklbtype.pl"],
   'postMktype'            => [\&PostMktype::postmktype,         "postMktype.pl"],
   'preRmbrtype'           => [\&PreRmbrtype::prermbrtype,       "preRmbrtype.pl"],
   'postRmbrtype'          => [\&PostRmbrtype::postRmbrtype,     "postRmbrtype.pl"],
   'preRnbrtype'           => [\&VobOwner::vobowner,             "vobowner.pl"],
   'postMkbrtypeCqCcInt'   => [\&PostMkBrtype::postMkbrtype,     "postMkbrtype.pl"],
   'preMkbrtypeCqCcInt'    => [\&CqCcInt::cqcc_int,              "cqcc_int.pl"],
   'preLock'   			   => [\&LockBrtype::preLock,            "cqcc_lock.pl"],
   'postLockCqCcInt'   	   => [\&LockBrtype::postLockCqCcInt,    "cqcc_lock.pl"],
   'preUnlockCqCcInt'      => [\&LockBrtype::preUnlockCqCcInt,   "cqcc_lock.pl"],
   'postUnlockCqCcInt'     => [\&LockBrtype::postUnlockCqCcInt,  "cqcc_lock.pl"],
   'preRmHlink'            => [\&RmHlinkBrtype::preRmHlinkBrtype, "rmhlink.pl"],
);

##########################################################################

=head1 NAME

%CQ_QUERY_FILTER -- Hash containing filter for a ClearQuest query.

=head1 DESCRIPTION

The keys in %CQ_QUERY_FILTER are ClearQuest fields.  The values
contain the operator and the value.  For example, to query
all CRs, which are in assigned state and are assigned to the
ClearQuest user, %CQ_QUERY_FILTER is populated as,

%CQ_QUERY_FILTER = ( Technical_Authority  => ['like','[CURRENT_USER]~'], 
                     State                => ['eq','Assigned']);

If '_CQUSER' is specified as the Technical_Authority, the query function will replace it with the ClearQuest user id.
Note: The above condition is not required as we can use [CURRENT_USER] in a CQ
query to get the current CQ user.

=cut

##########################################################################
%CQ_QUERY_FILTER = ( Technical_Authority  => ['like','[CURRENT_USER]~'], 
                     State                => ['eq','Assigned']);

##########################################################################

=head1 NAME

@CQ_QUERY_FIELDS -- Array containing fields to selected in a ClearQuest query.

=head1 DESCRIPTION

 The @CQ_QUERY_FIELDS lists the fields of the queried record type (in most cases
 a CR) that need to be selected in a CQ query performed from the CC trigger

=cut

##########################################################################
@CQ_QUERY_FIELDS = qw(id headline);

##########################################################################

=head1 NAME

%CQ_WEB_PARAMS -- Hash containing parameters for communicating with ClearQuest via the WEB.

=head1 DESCRIPTION


   Contains the following keys: 

   url         -  URL of the ClearQuest WEB Server
   cqdb        -  ClearQuest database name
   cquser      -  ClearQuest User id
   cqpwd       -  ClearQuest Password
   cq_rec_type -  ClearQuest Record Type.  
   keepsession -  'TRUE' indicates that the CQ session will be kept alive 
                  after the operation.
                  'FALSE' indicates that the CQ session will not be kept alive 
                  after the operation.
   trace       -  'TRUE' will enable debugging mode.  'FALSE' will disable
                  debugging mode.
   cookie      -  cookie returned from the WEB server.  
   volist      -  url-encoded string of VOB's and ClearCase object's oid.  
                  Used for writing to and removing change set from a CR.


=cut

##########################################################################
%CQ_WEB_PARAMS = map { ($_ => '') } qw(url cqdb  cquser cqpwd cq_rec_type
                                       keepsession trace cookie volist);


##########################################################################

=head1 NAME

trigger.pm -- Contains global variables and functions for use
in the trigger scripts.

=head1 SYNOPSIS

 use trigger;


=head1 DESCRIPTION

Based on the OS, set the values of the variables appropriately.
Provide functions for use in the trigger scripts.

=head1 AUTHOR

ACE Common CM Dev Team

=cut

##########################################################################

$NT = !defined($Config{osname}) || $Config{osname} eq "MSWin32";
$ATRIAHOME = $ENV{'ATRIAHOME'} ? $ENV{'ATRIAHOME'} : '/usr/atria';
$CQCC_HLTYPE = "CrmRequest";
$CQCC_ATTYPE = "OriginatingCR";
$DEVINT_MERGELIST_ATTYPE = "devint-merge-list-required";
$MERGE_LOCK_HLTYPE = "MergeLock";
$PROD_FAMILY_ATTYPE = "ProductVOB";
$SPCF_ATTYPE = "SPCF";


########################################################
# The following parameters are used by name-parsing    #
# hooks to parse branch type names, label type names   #
# and view tags. These paramaters allow you to fine    #
# tune certain aspects of the naming conventions       #
# implemented by ACE.                                  #
#                                                      #
# NAME:     $NAME_SEGMENT_DELIMITER                    #
#                                                      #
# USAGE: Specifies the character that separates        #
#        segments within a name. For example if        #
#        the username and the CR-ID are in the         #
#        name, they might typically be separated       #
#        by an underscore ('_'). Some might prefer     #
#        to use some other character instead of        #
#        '_' to separate these parts of a name.        #
#                                                      #
#------------------------------------------------------#
#                                                      #
# NAME:     $USAGE_TAG_DELIMITER                       #
#                                                      #
# USAGE: Delimiter that separates the usage tag in     #
#        segment containing it in the branch type      #
#        names, label type names and view tags.        #
#        For example, a '-' is often used to           #
#        separate a tag of 'dev' or 'int' from a       #
#        CR-ID or release ID.                          #
#                                                      #
#------------------------------------------------------#
#                                                      #
# NAME:     $USAGE_TAG_DELIMITER_REQD                  #
#                                                      #
# USAGE: Boolean to specify if the usage tag           #
#        delimiter is required in the branch type      #
#        names, label type names and view tags. If     #
#        set to 1, then element-type name should       #
#        have the $USAGE_TAG_DELIMITER                 #
#                                                      #
#------------------------------------------------------#
#                                                      #
# NAME:     $USAGE_TAG_IS_PREFIX                       #
#                                                      #
# USAGE: Boolean to specify if the usage tag in        #
#       the branch type names, label type names        #
#       and view tags is a prefix or a suffix.         #
#                                                      #
#------------------------------------------------------#
#                                                      #
# So, here are some examples of these flags in action  #
# for usage-tags of 'dev', 'int', and 'rel'            #
#                                                      #
# If the segment delimiter is '_' and the usage-tag    #
# is a prefix whose delimiter is '-' and is optional   #
# then the following would be examples of this:        #
#    username_dev-123                                  #
#    username_dev123                                   #
#    dev-123                                           #
#    dev123                                            #
#    main_int-r1.0                                     #
#    johnb_fix-cqdb0438                                #
#                                                      #
# We could alos allow the same as above, but make the  #
# usage-tag delimiter be required. That would leave us #
# with the following:                                  #
#    username_dev-123                                  #
#    dev-123                                           #
#    main_int-r1.0                                     #
#    johnb_fix-cqdb0438                                #
#                                                      #
# We could instead have the usage-tag be a suffix      #
# rather than a prefix, which would allow these:       #
#    username_123-dev                                  #
#    cqdb123-dev                                       #
#    main_r1.0-int                                     #
#    johnb_cqdb0438-fix                                #
#                                                      #
# And if we wanted to use a tag delimiter of '.'       #
# instead of '-', then we would have the following:    #
#    username_123.dev                                  #
#    cqdb123.dev                                       #
#    main_r1.0.int                                     #
#    johnb_cqdb0438.fix                                #
#                                                      #
# Lastly, in addition to the above, we could make      #
# the character '-' be the segment delimiter (since    #
# it is no longer the usage-tag delimiter). That       #
# would look something like the following:             #
#    username-123.dev                                  #
#    cqdb123.dev                                       #
#    main-r1.0.int                                     #
#    johnb-cqdb0438.fix                                #
#                                                      #
# So you see, there is a lot of flexibility in how one #
# can fine tune the default naming conventions!        #
#                                                      #
########################################################
$NAME_SEGMENT_DELIMITER   = "_";

$USAGE_TAG_DELIMITER      = "-";

$USAGE_TAG_DELIMITER_REQD = 1;

$USAGE_TAG_IS_PREFIX      = 1;

####################################################
# NAME:  $USEMERGESTATES                           #
#                                                  #
# USAGE:  Used to determine whether the VOB family #
#         set want to enforce the use of           #
#         mergestates in CQ. This should be        #
#         enabled for all groups.                  #
# EXAMPLE:                                         #
#                                                  #
#   $USEMERGESTATES = 1                            #
####################################################

$USEMERGESTATES = 1;


# lock hyperlink to signify if the branch is locked from a remote site.
$LOCKHLINK = "work_completed";

if (! $NT) {
	$CURRENT_USER = getpwuid($<) || getlogin();
}
else {
	$CURRENT_USER = getlogin();
} 

### 
# LOADLINE mappings.
#
# Mapping from the CQ loadlines to CC branch and label names.
#
###
%LOADLINEMAP = (
	'beta' => "mkt0",
	'sprint' => "mkt1",
	'verizon' => "mkt2",
	'alltel' => "mkt3",
	'kddi' => "mkt4",
	'china' => "mkt5",
	'tuka' => "mkt6",

	'sdu' => "mkt51",
	'vpu' => "mkt52",
	'ivpu' => "mkt53",
	'linuxdev' => "mkt54",
	'nodeb' => "mkt55",
	'crnb' => "mkt56",
	'mm2' => "mkt57",
);




if ($NT) {
  $HOSTNAME = $ENV{COMPUTERNAME} || "";
  chomp($HOSTNAME = `hostname`)  unless length($HOSTNAME);
}
else {
  ## Must be on Unix
  $HOSTNAME = $ENV{HOSTNAME} || "";
  chomp($HOSTNAME = `hostname`)  unless length($HOSTNAME);
  chomp($HOSTNAME = `uname -n`)  unless length($HOSTNAME);
}



if ($NT){
   $CLEARTOOL   = qq#cleartool#;
   $CLEARPROMPT = qq#clearprompt#;
   $TMPDIR      = $ENV{'TMP'} || $ENV{'TEMP'};
	$DEVNULL     = "$TMPDIR/devnull.$$";
	$ERRNULL     = "$TMPDIR/errnull.$$";
   $HOME        = "$ENV{HOMEDRIVE}$ENV{HOMEPATH}";
   $CQPARAM     = "$ENV{USERPROFILE}";
   $PATH_DELIMITER = "\\";

   qx($CLEARTOOL -ver);
   if($?)
   {
       display_msg("Either ClearCase is not installed on your client machine or ATRIAHOME path is not in your PATH environment. \n");
       exit 1;
   }
}
else{
   $CLEARTOOL   = "$ATRIAHOME/bin/cleartool";
   $CLEARPROMPT = "$ATRIAHOME/bin/clearprompt";
   $TMPDIR      = "/tmp";
   $DEVNULL     = "/dev/null";
   $ERRNULL     = "/dev/null";
   $HOME        = "$ENV{HOME}";
   $CQPARAM     = $HOME;
   $PATH_DELIMITER = "/";
}

use constant ADDTARGETED => 1;
use constant ADDINTEGRATED => 2;
use constant ADDTARGETEDSTRICT => 3;
use constant RMTARGETED => 4;
use constant VERIFY_NOT_INTEGRATED_OTHER_BRANCHES => 5;
use constant ADDINTEGRATEDNOCHECK => 6;
use constant RMINTEGRATED => 7;
use constant VERIFY_NOT_INTEGRATED => 8;
use constant ADDWORKCOMPLETED => 9;
use constant ADDWORKSTARTED => 10;
use constant ADDPARTIALINTEGRATED => 11;
use constant ADDLOCKEDPARTINTEGRATED => 12;

# Debug printing
use constant DEBUGGING => ($ENV{CQCC_DEBUG}||0);
my @DBGFLAGS = split /[+,;\s]+/, DEBUGGING;

# Return codes
use constant CQ_VALID_CR => 0;
use constant CQ_INVALID_CR => 1;
use constant CQ_LOGIN_FAIL => 2;
use constant CQ_QUERY_FAIL => 3;
use constant CMBP_SUCCESS => 0;
use constant CMBP_FAIL => 1;

$DEPHLINK = "CRdep";

sub dprint {
   my $dbgflag = 1;
   ## If first arg is a lone name or number, its a flag for us
   ($_[0] =~ /^(\d+|[-\w]+)$/)  and  $dbgflag = shift;

   my $output = shift;
   my $pfx = $ENV{CMBP_TRTYPE}||"";
   $pfx and  $pfx .= ": ";

   if ($dbgflag !~ /^\d+$/) {
      ## string flag - print if we match it
      warn( "$pfx$output")  if (grep {lc $_ eq lc $dbgflag} @DBGFLAGS);
   }
   else {
      ## numeric flag - print if are greater than it
      warn( "$pfx$output" ) if (DEBUGGING > $dbgflag);
   }
}


##########################################################################

=head1 NAME

display_msg -- Displays a message using clearprompt

=head1 SYNOPSIS

 display_msg($msg, $error)

 where

      $msg - message to be displayed
      $error - 1 if it's an error message, 0 otherwise


=head1 DESCRIPTION

Displays the message using clearprompt.  $error is used to
determine how the message is displayed and is used as an
argument to 'clearprompt'.

=head1 RETURN VALUES

NONE

=cut

#################################################################

sub display_msg
{
    # post a message, if running from CLI, use 'warn' so that the 
    # terminal doesn't stop while waiting for a response....

    my $msg = shift;
    my $error = shift;
    my ($custom_msg);

    if (defined $::CUSTOM_MESSAGE && $::CUSTOM_MESSAGE ne "") {
      # Get rid of white spaces
      $custom_msg = $::CUSTOM_MESSAGE;
      $custom_msg =~ s/^\s+//;
      $custom_msg =~ s/\s+$//;
    }

    if ($ENV{'CMBP_FORCE_CLI'}){
        warn "$msg\n";
    } else {
       my $typeparms = "warning";
	if( ! $error or $error == 1) {
                #it is error
                $typeparms = "error";
		$msg =~ m#^\s*(error\:)?(.*)$#is ;
                my ($errortype, $remaining ) = ( $1, $2) ;
		if( $errortype ) {
                        $msg = 'Error: ' . $remaining ;
                }
                else {
                        $msg = 'Error: '. $msg ;
                }
		
		$msg .= "\n$custom_msg\n" if ($custom_msg ne "");
		
        }
        elsif ( $error == 2 ) {
                #it is warning
                $msg =~ m#^\s*(warning\:)?(.*)$#is ;
                 my ($warningtype, $remaining ) = ( $1, $2) ;
                if ( $warningtype ) {
                        $msg = 'Warning: ' . $remaining ;
                }
                else {
                        $msg = 'Warning: ' . $msg ;
                }
        }


       if(($ENV{ATRIA_FORCE_GUI} == 1) || ($ENV{XC_HAS_COMMAND} eq "TRUE"))
       {
	   $msg =~ s#\"#\\\"#g;
	   $NT and $msg =~ s#\n# #g;  #replace \n with space character 
        
           my $cmd ="$CLEARPROMPT proceed -type \"$typeparms\" -prompt \"$msg\" -mask proceed -pre";
	   prep_cmd(\$cmd);
	   `$cmd`;
       }
       else
       {
	   # do a regular print statement....
	   if(!(print STDERR "$msg \n"))
	   {
	       $msg =~ s#\"#\\\"#g;
	       $NT and $msg =~ s#\n# #g;  #replace \n with space character 
        
               my $cmd ="$CLEARPROMPT proceed -type \"$typeparms\" -prompt \"$msg\" -mask proceed -pre";
	       prep_cmd(\$cmd);
	       `$cmd`;
	   }
       }
    }
}

##########################################################################


=head1 NAME

prep_cmd -- Prompt for text input from the user.  Return the user's input.

=head1 SYNOPSIS

 prep_cmd(\$cmd)

 where
    $comment is the prompt


=head1 DESCRIPTION

Prompt the user for text input. Return the user's input.

=head1 RETURN VALUES

 Return ($rc, $text) 

 where

        $rc - return value from clearprompt
      $text - user's input


=cut

##########################################################################
sub prep_cmd
{
	
	##"command arg" or "command 'arg'" or "command "arg""
	##not working on NT
	##return;

    my $cmd = shift @_;

    $$cmd = qq#"$$cmd"# if $NT;

    return;
}

##########################################################################

=head1 NAME

ct_subcmd -- Invoke a cleartool subcommand and check the status (if desired)

=head1 SYNOPSIS

 my $rc = ct_subcmd("lsco", "-all", "-me");
 $rc = ct_subcmd("lsco -all -me");

 my $output = ct_subcmd( { -saveout => 1, -abort => "cmd failed" },
                         "lsco -all -me" );
 my @output = ct_subcmd( { -saveout => 1, -abort => "cmd failed" },
                         "lsco -all -me" );

=head1 DESCRIPTION

Run the given cleartool subcommand with the given command-line
arguments. If the first argument is a hash-ref, then it
specifies options affecting the behavior and return value
of the subroutine.  All remaining arguments correspond to
the subcommand name and its options and arguments and may be
specified all in a single string or in separate arguments (just
as one would specify a command to the B<system()> builtin).

When the first argument is  hash-ref, the following keywords
and their values are recognized and interpreted as follows:

=over 4

=item B<-stdout>

A value of C<undef> means redirect standard-output to the null device.
A value of 1 means STDOUT, 2 means STDERR, anything else non-empty 
specifies a filename where output should be redirected. If this
option is not specified, the default is to use STDOUT.

=item B<-stderr>

A value of C<undef> means redirect standard diagnostic output to the
null device. A value of 1 means STDOUT, 2 means STDERR, anything
else non-empty specifies a filename where diagnostics should be
redirected. If this option is not specified, the default is to
use STDERR.

=item B<-abort>

A value of C<undef> or 0 means dont abort on error status. A
number means dont abort unless the status is greater than the
given number. A non-empty string means abort if status is
non-zero and use the given string as the error message.

=item B<-errmsg>

Specify the error message to use if we are to abort the program
(appended to any text specified by B<-abort>).

=item B<-saveout>

A value of C<undef> or false means use B<system> and return thge
exit-status; anything non-zero and non-empty means use backticks
(`ct subcmd ...`). If true, then output is returned, else exit
status is returned (and was already divided by 256)

=item B<-noexec>

A value of C<undef> or false means really execute the command;
anything non-zero and non-empty means just print it, dont execute it.

=back

=head1 RETURN VALUES

Returns the exit-status (already divided by 256) of the
subcommand unless the B<-saveout> option was given. If
B<-saveopt> was specified, then it returns the standard
output of the subcommand. The behavior will be similar to qx()
(backticks) in that it will returns a single string in a scalar
context, or an array of output-lines in a list context.

=cut

sub ct_subcmd {
  local $_ = shift;
  my %opts = ();

  ## See if first arg was a hash-ref
  if (ref eq 'HASH') {
     ## It is, record the options and get the subcmd
     %opts = %$_;
     $_ = shift;
  }

  ## Set any default options
  ##---------------------------------------------------------------
  ##   -stdout ==> undef means null, 1 means STDOUT, 2 means STDERR
  ##               anything else non-empty means a filename
  $opts{'-stdout'}  = 1  unless (exists $opts{'-stdout'});
  ##---------------------------------------------------------------
  ##   -stderr ==> undef means null, 1 means STDOUT, 2 means STDERR
  ##               anything else non-empty means a filename
  $opts{'-stderr'}  = 2  unless (exists $opts{'-stderr'});
  ##---------------------------------------------------------------
  ##   -abort ==> undef|0 means dont abort on error status, A number
  ##              means dont abort unless the status is greater than
  ##              the given number. A non-empty string means abort
  ##              if status is is non-zero and use the string as
  ##              the error message.
  ##
  $opts{'-abort'}   ||= "";
  ##---------------------------------------------------------------
  ##   -errmsg ==> error message to use if we are to abort the program
  ##               (appended to '-abort' msg if it was a string)
  $opts{'-errmsg'}  ||= "";
  ##---------------------------------------------------------------
  ##   -saveout ==> undef|false means use system; anything non-zero and
  ##                non-empty means use backticks (`ct subcmd ...`)
  ##                If true, then output is returned, else exit status
  ##                is returned (and was already divided by 256)
  $opts{'-saveout'} ||= "";
  ##---------------------------------------------------------------
  ##   -noexec ==> undef|false means really execute it; anything non-zero
  ##                and non-empty means just print it, dont execute it.
  $opts{'-noexec'}  ||= "";
  ##---------------------------------------------------------------

  ## Set up the cleartool invocation
  my $cmd = "$CLEARTOOL $_";

  ## Do any requested needed i/o redirection
  if (! defined $opts{'-stdout'}  or  !$opts{'-stdout'}) {
     $cmd .= " >$DEVNULL";
  } elsif ($opts{'-stdout'} ne 1) {
     $cmd .= " >".$opts{'-stdout'};
  }
  if (! defined $opts{'-stderr'}  or  !$opts{'-stderr'}) {
    $cmd .= " 2>$ERRNULL";
  } elsif ($opts{'-stderr'} ne 2) {
     $cmd .= " 2>".$opts{'-stderr'};
  }

  my $vcmd = qq#$cmd#;
  ## Handle any quoting of arguments
  prep_cmd(\$vcmd);

  ## Now execute the command
  my $retval = undef;
  my @retval = ();
  dprint ("cmd is :".$cmd.": \n");
  if ($opts{'-noexec'}) {
     dprint ("# $cmd\n");
  }
  elsif ($opts{'-saveout'}) {
     wantarray  and  @retval = `$cmd`  or  $retval = `$cmd`;
  }
  else {
     system($vcmd);
  }
  dprint ("COMMAND executed is :$cmd:******\n");
  ## Now interpret any exit status and abort if desired
  my $exit_status = $opts{'-noexec'} ? 0 : ($? >> 8);
  my $msg = $opts{'-errmsg'}||"";
  $_ = $opts{'-abort'}||"";
  if (length  and  ! /^\d+$/) {
     $msg = $_ . ($NT ? "\r\n" : "\n") . $msg;
     $_ = 0;
  }
  if (length  and  $exit_status > $_) {
     print STDERR "Error: $msg\n";
     exit(2);
  }
  
  ## Now return to the caller (if we havent aborted)
  if ($opts{-saveout}) {
     return  wantarray ? @retval : $retval;
  }
  return $exit_status;
}

##########################################################################

=head1 NAME

%TRIGGER_HOOKS - hash containing pre and post trigger-hooks.

=head1 SYNOPSIS

  %TRIGGER_HOOKS = (
      'before-preCheckout'  => q(/some/cmd1 -opt1 arg1 -opt2 arg2 ...),
      'after-preCheckout'   => [ '/some/cmd2', $arg1, $arg2, @moreArgs ],
      'before-postMktype'   => \&myfunc,
      'after-postMktype'    => [ \&myfunc, $arg1, $arg2, @moreArgs ]
  );


=head1 DESCRIPTION

C<%TRIGGER_HOOKS> is a hash that allows add-on actions to the
front or back end of the execution of an existing ClearCase
trigger. This is the mechanism provided to product-groups to
extend and customize the functionality of an existing trigger
type in the ACE CQ/CC integration.

Each value in the hash corresponds to a "hook" to be executed
before or after some trigger. The corresponding trigger,
and the corresponding execution sequence are encoded in the
hash-key of the "hook." The corresponding execution sequence
should be indicated by the string "before" or "after" and is
the very beginning of the key. The corresponding trigger is
indicated by the name of the ACE CQ/CC ClearCase trigger-type
and is the end of the key. The full key is constructed by
joining the sequence-string and the trigger-name with a minus
character ("-") in between them (e.g., C<before-preCheckout>,
C<after-preCheckout>).

The corresponding hook value may be a string, a code-reference,
or an array-reference. If it is a string, then it must
correspond to a command-line invocation suitable for passing
to the B<system()> function using the single-string argument
form of invocation (e.g., C<system "/bin/true">). If it is a
code-reference, then it must correspond to a perl subroutine
that returns a numeric status. If it is an array-reference, then
the first element of the referenced array must be a string or
a code-ref, and the remaining elements are the arguments to
the command or function).

The specified hook command or function invocation should return
a zero value for success and non-zero for failure.  If a
trigger-hook fails for a preop trigger, then the ClearCase
operation will not be permitted.  In a post-op trigger,
ClearCase has already performed the operation.  So, if the
trigger-hook fails for a post-op trigger, it could only serve
as a warning.


=cut

##########################################################################

*TRIGGER_HOOKS = *::TRIGGER_HOOKS;
     ## gets (re)defined in prod-config
defined %TRIGGER_HOOKS  or  %TRIGGER_HOOKS = ();


##########################################################################

=head1 NAME

invokeTriggerHook -- function that invokes pre/post-trigger hooks

=head1 SYNOPSIS

my $status = &invokeTriggerHook( $sequence, $trigger );

=head1 DESCRIPTION   

Checks if the product group has defined a before/after trigger
type hook in the product specific config file.  If so, it
executes it and returns the status. Returns 0 if no "hook"
was specified.

The C<$sequence> parameter should be the string "before"
or the string "after", depending on if this hook should be
executed before or after the named trigger type. The C<$trigger>
parameter should be the name of the corresponding trigger-type
(e.g., "preCheckout", "postCheckin", etc.).

Makes use of the global %TRIGGER_HOOKS which is where
product-groups are allowed to custom-specify their own "add-on"
actions to the existing ACE triggers.

=cut

##########################################################################
sub invokeTriggerHook ( $ $ ) {
   my $trigHookSeq = shift;  ## should be 'before' or 'after';
   my $triggerType = shift;  ## name of trigger *including* pre/post prefix

   ## Find the hook value from the hash
   my $trigHookKey = $trigHookSeq . '-' . $triggerType;
   my $trigHookVal = $TRIGGER_HOOKS{$trigHookKey}  or  return 0;

   ## Get the hook command/function and any arguments
   my ($trigHook, @hookArgs) = ($trigHookVal);
   my $hookRefType = (ref $trigHookVal) || "";
   if ($hookRefType eq 'ARRAY') {
      ($trigHook, @hookArgs) = @$trigHookVal;
      $hookRefType = (ref $trigHook) || "";
   }

   
   ## Execute the hook
   my $hookStatus = 0;
   my $hookStatusMsg = "";
   if ($hookRefType eq 'CODE') {
      ## Must be a ref to a function to invoke. Just invoke the function
      ## with the specified arguments. Use an eval just in case the given
      ## function is invalid or unknown/undefined.

      eval { $hookStatus = &{$trigHook}(@hookArgs) };
      $hookStatus = 255  if ($@); ## error invoking function
      $hookStatusMsg = "Perl Code for key \"$trigHookKey\" of hash \$TRIGGERS_HOOK Failed: $@";
   }
   elsif (! $hookRefType) {
      ## Must be a command-invocation or pathname and args. If it is a
      ## single string, invoke 'system' using the "string" form. Otherwise
      ## use the array-form of system. Check the status, and dont forget
      ## to look for a coredump or an abort due to a signal.

      ## **NOTE**: May need to do special escaping or "quoting"!
      @hookArgs  and  system($trigHook, @hookArgs)  or  system "$trigHook";
      $hookStatus = $? >> 8;
      my ($signal, $coredump) = ($? & 127, $? & 128);
      $hookStatus = 255 if (!$hookStatus and ($signal || $coredump));
      $hookStatusMsg = "Command Failed: $trigHook @hookArgs :$!\n";
   }
   else {
      ## Unknown value-type in TRIGGER_HOOKS!!
      ## PUT CODE HERE TO HANDLE/PRINT ERROR
      $hookStatusMsg = "Specification error!! Please check the \%TRIGGER_HOOKS \
      hash for any errors in defining the value for the key \"$trigHookKey\". \n";
   }

   ## See if the hook succeeded or failed
   if ($hookStatus != 0) {
      ## trigger-hook failed or aborted!!
      ## PUT CODE HERE TO HANDLE/PRINT ERROR
      display_msg( "Error: $hookStatusMsg");
   }

   return $hookStatus;
}


##############################################################################
## small utility routine to get interactive replies from an
## environment variable for testing/debugging purposes. returns
## empty string if no reply-text was available.

sub _get_debug_reply {
  my ($prompt, $object_name) = @_;
  return "" unless (defined $object_name  and  length $object_name);

  my $env_name = 'CQCC_DEBUG_PROMPT_' . $object_name;
  return "" unless (exists $ENV{$env_name}  and  length $ENV{$env_name});

  my $reply = $ENV{$env_name};
  $reply =~ s/^\s+//; $reply =~ s/\s+$//;

  print STDERR  "$prompt$reply\n" if (length $reply);
  return $reply;
}

##########################################################################
sub get_timestamp {

  use Time::localtime;
  my($Weekday, $Month, $Day, $Time, $Year);
  ($Weekday, $Month, $Day, $Time, $Year) = split(' ',&ctime());
  $Year = ($Year < 2000) ? ($Year - 1900) : ($Year - 2000); # total hack here.. needs to be changed.
  return sprintf("%02d-%s-%02d.%s",$Day,$Month,$Year,$Time);

}
###################################################################

sub show_help {
     use Config;
     system( "perldoc $0");
#     system( "$Config{bin}/perldoc ",__FILE__ );
}

##########################################################################

=head1 NAME

display_help -- Displays help 

=head1 SYNOPSIS

 display_help($script)

 where

      $script - name of the script for which help is to be displayed


=head1 DESCRIPTION

Displays help text using perldoc on $script.

=head1 RETURN VALUES

NONE

=cut

#################################################################

sub display_help
{
    # post a message, if running from CLI, use 'warn' so that the 
    # terminal doesn't stop while waiting for a response....

    my $script = shift || $0;

    use Config;
    my $perldoc = $Config{bin} . $PATH_DELIMITER . 'perldoc';
    if (-x $perldoc) {
       system( "perldoc $script" );
    }
    else {
       system( "perldoc $script" );
	   warn( "Warning: Help program $perldoc not properly installed: $!\n")  if ($?);
    }
}

##########################################################################


#
# Function to add hyperlink in the given vob.
#
sub addhlink
{
    my($tbranch, $fbranch, $vob, $hlink) = @_;
    my($subcommand);

    if(verifyHyperLink($tbranch, $fbranch, $vob, $hlink) ne "")
    {
	# hyperlink already exist, will just return.
	return 0;
    }

    $subcommand = "mkhlink -ttext $fbranch $hlink brtype:$tbranch\@vob:$vob";

    qx($CLEARTOOL $subcommand);
    if($? != 0)
    {
	return 1;
    }

    return 0;
}

#
# Function to add hyperlink with -ftext option ...
#
sub addhlinkwithftext
{
    my($tbranch, $fbranch, $vob, $hlink,$ftextstr) = @_; 
    my($subcommand); 

    $subcommand = "mkhlink -ttext $fbranch -ftext $ftextstr $hlink brtype:$tbranch\@vob:$vob"; 

    dprint("$subcommand \n");
    
    qx($CLEARTOOL $subcommand); 
    if($? != 0) 
    { 
        return 1; 
    } 
 
    return 0; 
} 

#
# Function to del hyperlink in the given vob.
#

sub delhlink
{
    my($tbranch, $fbranch, $vob, $hlink) = @_;
    my($fullhlink);  # the full hyperlink name ie .. Ok_to_merge@493@/usr/vob/sc/sbox
    my($subcommand);

    if(($fullhlink = verifyHyperLink($tbranch, $fbranch, $vob, $hlink)) eq "")
    {
	# trying to remove a hyperlink that does not exist, will just return.
	return 0 ;
    }

    $subcommand = "rmhlink $fullhlink";
    qx($CLEARTOOL $subcommand);
    if($? != 0)
    {
	return 1;
    }

    return 0;
}

#
# Function will verify if the given hyperlink exist in the build branch.
#
sub verifyHyperLink
{
    my($tbranch,$fbranch, $vob, $hlink) = @_;
    my(@output, $line,$linkname,$branch);

    @output =  qx($CLEARTOOL describe  -long -ahlink $hlink brtype:$tbranch\@vob:$vob);

    if($?)
    {
	display_msg("Error: The following cleartool subcommand failed:\n\tdescribe  -long -ahlink $hlink brtype:$tbranch\@vob:$vob\n");
	exit(2);
    }

    foreach $line (@output)
    {
	chop $line;

	# getting the hyperlink information from the output of the describe command. The following is an example of the output:
	#
	# csdbld01> cleartool describe  -l -ahlink Ok_to_merge brtype:sbox_pre1.0_int-1972@vob:/usr/vob/sc/sbox
	# sbox_pre1.0_int-1972
        # Hyperlinks:
	# Ok_to_merge@493@/usr/vob/sc/sbox ->  "dev-0000816"
	# Ok_to_merge@494@/usr/vob/sc/sbox ->  "dev-0000817"
	# 

	if($line =~ /^(.*)->(.*)$/)
	{
	    $linkname = $1;
	    $branch = $2; 

	    $branch =~ s/^\s*\"//;   # getting rid of all the space characters up to the first quotation mark;
	    $branch =~ s/\"$//;      # getting rid of the last quotation mark;

	    $linkname =~ s/\s*//;

	    if($branch eq $fbranch)
	    {
		return $linkname;
	    }
	}
    }
    return "";
}

#
# Function that will create a -ttext hlink on a given object_selector.
#
#      Parameters: hyperlinkname
#		   text
#                  objectselector
#
#      Returns: 
#                  0 - No errors.
#                  1 - Errors.
#
#

sub createtexthlink
{
    my ($hyperlink, $ttext, $objectsel) = @_;
    dprint(1,"SUB: createtexthlink\n");
    
    my $cmd = "$CLEARTOOL mkhlink -ttext $ttext $hyperlink $objectsel";

    qx($cmd);
    if($?)
    {
	return 1;
    }

    return 0;
}


#
# Function that will verify if lock hyperlink exists in given branch.
# Function will return:
#       0 - lock does not exist.
#       1 - lock exist.
#      -1 - error in function.
#

sub lockhlexist
{
    my ($fbranch,$vob) = @_;
    dprint(1,"SUB: lockhlexist\n");

    # will verify if the work_completed hyperlink exist so the merge can continue.
    my $cmd = "$CLEARTOOL describe -local -ahlink $LOCKHLINK brtype:$fbranch\@$vob";
    dprint(1,"cmd = $cmd\n");

    my @describeoutput = qx($cmd);
    if($?)
    {
	return -1;
    }

    foreach (@describeoutput)
    {
	if(/->/)
	{
	    return 1;
	}
    }

    return 0;
}

#
# Function that will obtain the owner of the given brtype. Will return the owner in a
# string format.
#

sub getBrOwner
{
    my($brtype,$vob) = @_;
    my @output;
    my $line;
    my $owner;

    @output = qx($CLEARTOOL describe brtype:$brtype\@vob:$vob);
    if($?)
    {
	die("Failed to execute the following command:\n\t$CLEARTOOL describe brtype:$brtype\@vob:$vob\n");
    }

    foreach $line (@output)
    {
	if($line =~ /owner:/)
	{
	    $owner = (split(/:/,$line))[1];
	    $owner =~ s/^\s*//;  # getting of padded white spaces.
	    $owner =~ s/\s*$//;

	    if( $NT ) {
		#some user gets the owner of the brtype as owner: NA1\QA1854
		#need to get rid of NA1
		if( $owner =~ /\\/ )
		{
			$owner = (split(/\\/, $owner) )[1];
		}
	    }

	    return $owner;
	}
    }


    return "";
}


#
# Function that will verify if the given branch is a build branch.
#
sub isBuildBranch
{
    my($branch, $vob) = @_;
    my @branchseg;
    my ($lastseg,$prefix, $intprefix);

    # getting the last segment of the branch name.
    @branchseg = split($NAME_SEGMENT_DELIMITER, $branch);

    $lastseg = $branchseg[$#branchseg];

    $prefix = (split($USAGE_TAG_DELIMITER, $lastseg))[0];

    foreach $intprefix (@INT_BRANCH_TAG_LST)
    {
	if($prefix eq $intprefix)
	{
	    return 1;
	}
    }

    return 0;
}

#
# Function that will verify if the given branch is a build branch.
#
sub isDevIntCRBranch
{
    my($branch) = @_;
    my @branchseg;
    my ($lastseg,$prefix);

    dprint("SUB: isDevIntCRBranch \n");

    # getting the last segment of the branch name.
    @branchseg = split($NAME_SEGMENT_DELIMITER, $branch);

    $lastseg = $branchseg[$#branchseg];

    $prefix = (split($USAGE_TAG_DELIMITER, $lastseg))[0];

    dprint ("prefix = $prefix for branch $branch \n");

    if($::DEVINT_USAGE_TAGS{$prefix} == 1)
    {
        return 1;
    }

    return 0;
}


# Function that will verify if the brtype is valid.
# Will return 0 if not valid ... 1 if valid.
sub verifyBranch
{
    my ($branch,$vob) = @_;
    my $rc;

    qx($CLEARTOOL describe brtype:$branch\@vob:$vob 2>$ERRNULL);
    return $?;
}


#
# Function that will obtain the valid release ids from the VOB. Will return the an associative array
# where the key is the release and the content of the hask will be the release mainline branch name.
#
# The function will return a reference to the associative array.
#

sub getReleaseIDs
{
    my $hltype = "releasehl";

    my $vob = $NT ? $::CC_NT_ADMINVOB : $::CC_UNIX_ADMINVOB;

    my $command = "$CLEARTOOL describe -ahlink $hltype vob:$vob 2>$ERRNULL";
    my @output = qx($command);
    if($?)
    {
	display_msg("The following command failed: $command");
	return ();
    }

    my %releaselist = ();
    foreach (@output)
    {
	chomp($_);
	
	if(/->/)
	{
	    my $content = (split(/->/))[1];

	    # getting rid of the whitespace and quotes.
	    $content =~ s/^\s*//;
	    $content =~ s/^\"//;
	    $content =~ s/\s*$//;
	    $content =~ s/\"$//;

	    my ($key,$value) = split(/:/,$content);
	    
	    $releaselist{$key} = $value;
	}
    }


    return \%releaselist;
}


#
# Function that will return 1 if true and 0 if false if the the given branch is locked for all users.
# Returns -1 for errors.
#

sub isBranchLockedForAllUsers
{
    my ($branch, $vob) = @_;

    dprint("SUB: isBranchLockedForAllUsers\n");
    my  $cmd = "$CLEARTOOL lslock brtype:$branch\@$vob 2>$ERRNULL";
    my @output = qx($cmd);
    dprint("$cmd\n");

    if($?)
    {
	dprint("lslock command failed \n");
	return -1;
    }

    foreach (@output)
    {
	if(m/Locked for all users/)
	{
	    return 1;
	}
    }

    # Checking to see if the lock hyperlink exist in case the branch is mastered at a replica site.
    $cmd = "$CLEARTOOL describe -ahlink $LOCKHLINK brtype:$branch\@$vob 2>$ERRNULL";
    @output = qx($cmd);
    dprint("$cmd\n");
    if($?)
    {
	return -1;
    }

    foreach (@output)
    {
	if(m/->/)
	{
	    return 1;
	}
    }
    
    return 0;
}

#
# Depending on the lock status this function will return:
# -1 = ct lslock error
# 0 = branch is open
# 1 = branch is partially locked and locked for user
# 2 = branch is partially locked but unlocked for user
# 3 = branch is completely locked Returns -1 for errors.
# This should be used only if the branch has local mastership

sub isBranchUnLockedForUser
{
    my ($user,$branch, $vob) = @_;

    dprint("SUB: isBranchUnLockedForUser\n");
    my  $cmd = "$CLEARTOOL lslock brtype:$branch\@$vob 2>$ERRNULL";
    dprint("$cmd\n");
 
    my @output = qx($cmd);
    if($?)
    {
	dprint("lslock command failed \n");
	return -1;
    }
  
    # Return 0 if branch is unlocked
    chomp(@output);
    return 0 if (!scalar(@output));

    foreach (@output)
    {
	if(m/Locked except for users:/)
	{
	    my $unlocked = (split(/:/))[1];
	    $unlocked =~ s/^\s*//;
	    $unlocked =~ s/\"$//;
            my @users = split(/\s+/,$unlocked);
            foreach (@users) {
              return 2 if ($_ eq $user);
	    }
	}
        elsif (m/Locked for all users/)
	{
	    return 3;
	}
    }
    return 1;
}

#
# Function that will obtain the branch from reading in the configspec.
#

sub getBranchFromCS
{
    my($devbr,$cs) = @_;
    my $line;

    $$devbr = "";

    # Finding out the user's development branch from the config spec.
    foreach $line (@$cs)
    {
        # getting rid all front padded white spaces.
        $line =~ s/^\s*//;
        if($line =~ /^\#/)
        {
            next;
        }

        if($line =~ m/mkbranch/)
        {
            $$devbr = (split(/mkbranch/,$line))[1];
            # getting rid of trailing spaces on the end of the line.
            $$devbr =~ s/\s*$//;

            # getting rid of any comments that might be on the end of the string.
            $$devbr =~ s/\s*\#.*$//;

            # getting rid of any white space in the front of the string. 
            $$devbr =~ s/^\s*//;
            last;
        }
    }
}

#
# Function that will require the VOB Family configuration file.
# Parameters:
#       - configdir: The location of the configuration directory. 
#       - vfamily: If this is given, it means that the calling function already knows the vobfamily string.
#                  If empty, function will obtain the vobfamily string via the vob. First precedence is the CLEARCASE_AVOBS. 
#                  If not set, will assume the caller is current working directory is in a vob, if not error.
#
#

sub requireProdVobCfg
{
    my ($configdir, $vobfamily) = @_;


    if($vobfamily eq "")
    {
	# VOB family not entered, will get vobfamily information from one of the VOB Family VOBs. Will use the VOB from CLEARCASE_AVOBS.
	my $ccavob = $ENV{CLEARCASE_AVOBS};
	if($ccavob ne "")
	{
	    $ccavob = (split(/[\:\s\;]/,$ccavob))[0];
	}
	else
	{
	    $ccavob = ".";
	}
	
	dprint("clearcase vob to do describe: $ccavob \n");
	$vobfamily = qx($CLEARTOOL describe -s -aattr ProductVOB vob:$ccavob);

	if($?)
	{
	    display_msg("Following cleartool subcommand failed:\n\tdescribe -s -aattr ProductVOB vob:$ccavob\n");
	    exit(1);
	}

	# getting rid of the quotation marks.
	chomp($vobfamily);
	$vobfamily =~ s/^\"//;
	$vobfamily =~ s/\"$//;
    }


    my $cfgfile = "$configdir/$vobfamily"."_trigger.cfg";
    dprint("configfile = $cfgfile \n");
    

    package main;
    eval {
	require "$cfgfile";
    };

    if ($@) {
	display_msg("$cfgfile does not exist. Error in CC scripts/trigger installation. Contact your CC admin:\n");
	exit(2);
    };

    return $vobfamily;	
}


sub getEmailLocation()
{
    my $mailloc = "";
    my $mailSGI = "/usr/sbin/Mail";
    my $mailSUN = "/usr/ucb/Mail";
    my $mailLINUX = "/usr/bin/Mail";
    my $maildefault = "/bin/mailx";

        if(-x $mailSGI)
        {
            $mailloc = $mailSGI;
        }
        elsif (-x $mailSUN)
        {
            $mailloc = $mailSUN;
        }
        elsif (-x $mailLINUX)
        {
            $mailloc = $mailLINUX;
        }
        else
	{
            $mailloc = $maildefault;
	}

        return (  $mailloc );
}

sub setAview() {
        # But first verify if the user is currently set to a view.
        my @pwvoutput = qx($CLEARTOOL pwv -short);
        if($?)
        {
                display_msg("Unable to obtain current view name \n");
                exit 1;
        }

        my $cview = $pwvoutput[0];
        chomp($cview);

        if($cview =~ /NONE/)
        {
                # need tofind a view that is already started in a client.
                my $viewextendedpath = $NT ? "$::CC_NT_DEF_VIEW_DRIVE\\" : "/view/";

                # if the default view in the configuration file is set, verify it has been started.
                my $defaultpath = $viewextendedpath . $::DEFAULTVIEW;
                if($::DEFAULTVIEW ne "" && -e $defaultpath)
                {
                        $viewextendedpath = $defaultpath;
                }
                else
                {
                        dprint "Default view is not being used. Find any started view now. \n";
                        if(!opendir(DIR, $viewextendedpath))
                        {
                                display_msg("Failed to open dir: $viewextendedpath ($!)\n");
                                exit 1;
                        }
			my $viewname = "";
                        my $foundviewtouse = 0;
                        foreach $viewname (readdir(DIR))
                        {

                                if($viewname =~ /^\./)
                                {
                                        next;
                                }

                                $viewextendedpath .= $viewname;
                                $foundviewtouse = 1;
                                last;
                        }

                        closedir(DIR);


                        if(!$foundviewtouse)
                        {
                                display_msg("There are currently no views started on your client machine. You need to have at least one view started to verify there are no file currently checked out.\n");
                                exit 1;

                        }
                }

                dprint("view extended path: $viewextendedpath \n");

                if(!chdir("$viewextendedpath"))
                {
                        display_msg("chdir()failed on file: $viewextendedpath");
                        exit 1;
		}

        }

}

sub setCCAVOBS() {

        # Setting up the CLEARCASE_AVOBS var... In case user's mess with the environment to get around process.
        my $envdelimiter = $NT ? ';' : ':';
        dprint "delimiter = $envdelimiter \n";

        my $avoblist;

        if($NT)
        {
                foreach (@::CC_NT_VOB_LST)
                {
                        $avoblist .= $_;
                        $avoblist .= $envdelimiter;
                }
        }
        else
        {
                foreach (@::CC_UNIX_VOB_LST)
                {
                        $avoblist .= $_;
                        $avoblist .= $envdelimiter;
                }
        }

        # getting rid of the last delimiter.
        $avoblist =~ s/$envdelimiter$//;
        dprint "avoblist = $avoblist\n";

        $ENV{CLEARCASE_AVOBS} = $avoblist;

}

#
# Function that will fill in a  passed in associative array  all the CR branches that are currently Marked (Ok_to_merge, Merged_done,
# Merged_ready_to_build, etc this will also be passed in by the called), where the key will be
# the branch name and assigned to a numeric one (1). This method is being used for quick lookup if a given CR is already marked with the given 
# hyperlink.  Function will also return 0 on SUCCESS and 1 on failure.
#

sub getMarkedCRBranch
{
    my ($branch, $vob, $hlink, $markedbranches) = @_;

    my $cmd = "$CLEARTOOL describe -short -ahlink $hlink  brtype:$branch\@$vob"; 
    dprint("$cmd\n"); 
     
    my @output = qx($cmd); 
 
    if($?) 
    { 
        display_msg("Failed to execute the following command:\n\t$cmd\n"); 
        exit 1; 
    } 
 
    foreach (@output) 
    { 
        my $brtype = (split(/\"/))[1]; 
        my $cr; 
 
        if(getCRNumFromBrtype($brtype,$vob,\$cr)) 
        { 
            display_msg("Failed to get the CR number for branch $brtype\n"); 
	    return 1;
        } 

	if($cr ne "" && $$markedbranches{$cr} != 1)
	{
	    $$markedbranches{$cr} = 1;
	}
    } 

    return 0;

}


#
# Function that will get the CR number from the brtype. Will assign the CR number to the address of the parameter the user 
# passes. 
#
# Will return 0 on Success
#             1 on Failure.
#


sub getCRNumFromBrtype
{
    my ($branch,$vob,$CRNum) = @_;
    
    $$CRNum = "";

    my $cmd = "$CLEARTOOL describe -short -aattr OriginatingCR brtype:$branch\@$vob 2>$ERRNULL";
    my $crid = qx($cmd);
    dprint("cmd = $cmd\n");
    if($?)
    {
        return 1;
    }

    chomp($crid);
    dprint("originatingCR = $crid\n");
    

    # getting rid of the '"' strings from the output;
    $crid =~ s/^\"//;
    $crid =~ s/\"$//;


    $$CRNum = $crid;
    return 0;
}

#
# Function that will pass in an array and a string. The function will then return the index position of the string in the array.
# The position number will be of base 0, in other words 0 index is the first index. If the string does not exist in the array,
# the function will return -1.
#

sub getIndexFromArray
{
    my ($arr, $str) = @_;


    my $index = 0;
    foreach(@$arr)
    {
	if($str eq $_)
	{
	    return $index;
	}

	++$index;
    }

    return -1;

}


#function that will return 1 if master replica; 0 if not
# return -1 if error.

sub isTypeMasterReplica {
	my ( $objectSelector, $vob, $errmsgref)=@_;
	
	dprint( 1, "SUB isTypeMasterReplica\n");

	my $cmd="$CLEARTOOL describe vob\:$vob 2>$ERRNULL";

	my @output = qx($cmd);
    	dprint("$cmd\n");

    	if($?)
    	{
        	$$errmsgref="Failed to check if the type($objectSelector)  is master replica.\n\tThe command line that failed is:\n\t$cmd\n";
        	return -1;
    	}

	my $replicaFlag=0;
    	foreach (@output)
    	{
        	if(m/replica name:/)
        	{
			$replicaFlag=1;
			my $replicaName = (split(/:/))[1];
			chomp( $replicaName) ;
			if ( $replicaName ) {
				# getting rid of the whitespace 
				$replicaName =~ s/^\s*//;
            			$replicaName =~ s/\s*$//;

				# check if branch type is master replica
				my $desBR_cmd="$CLEARTOOL describe -l $objectSelector\@$vob 2>$ERRNULL";
				my @desBR_output=qx($desBR_cmd);
				dprint(1, "$desBR_cmd\n");
				if($?)
        			{
					$$errmsgref="Failed to check if the type($objectSelector)  is master replica.\n\tThe command line that failed is:\n\t$desBR_cmd\n";
					return -1;
				}

				foreach (@desBR_output) {
					if(m/master replica\:/) {
						my $masterReplica = (split(/\:/))[1];
						chomp ( $masterReplica ) ;
						$masterReplica = (split(/\@/, $masterReplica))[0];	
						# getting rid of the whitespace 
                                		$masterReplica =~ s/^\s*//;
                                		$masterReplica =~ s/\s*$//;
						
						if ( $masterReplica eq $replicaName ) {
							# branch type have mastership
							return 1;
						}
						else
						{
						    $$errmsgref="Branch type is currently mastered in site: $masterReplica. Current replica name is: $replicaName \n";
						        
						    return 0;
						}
					}
				}
			}
		}
		
	}

	return 1 ;
}

#
# Function: getReplicaNameFromVob
# Paramaters: vob_tag
#
# Description: Function that will obtain the replica name for the given VOB tag.
#
# Returns:  replica name or NULL if error.
#

sub getReplicaNameFromVob
{
    my ($vob) = @_;

    dprint("IN FUNCTION:  getReplicaNameFromVob passing in vob:$vob \n");
    my $command = "$CLEARTOOL describe vob:$vob";
    dprint ("Will execute command $command \n");

    my @output = qx($command);
    if($?)
    {
	display_msg("Following command was executed with error:\n\n\t$command \n");
	return "";
    }

    my $replicaName = "";
    foreach (@output)
    {
	if(m/replica name:/) 
	{ 
	    $replicaName = (split(/:/))[1]; 
	    chomp( $replicaName) ; 
	    if ( $replicaName ) 
	    { 
		# getting rid of the whitespace  
		$replicaName =~ s/^\s*//; 
		$replicaName =~ s/\s*$//; 
	    }
	}
    }

    return $replicaName;

}

#
# Function: getFACList
#
# Description: get an array of login names for valid FAC's from the config file.
# 
#

sub getFACList
{
    my @MergeAdminList;
    my $MergeAdminFilePath; 
    foreach (@::FAC) 
    { 
	if( $_ =~ m/^path=/ ) 
	{ 
	    $MergeAdminFilePath = (split("="))[1]; 
	    dprint (1, "\$MergeAdminFilePath = $MergeAdminFilePath\n"); 
 
	    # open supplementary MergeAdmin file for reading  
	    # Don't care if file doesn't exists or not 
	    # because the path may Windows or Unix path 
	    if ( -r $MergeAdminFilePath ) 
	    { 
		open (FACFILE,$MergeAdminFilePath); 
		
		while (<FACFILE>) 
		{ 
		    chomp; 
		    push(@MergeAdminList, $_); 
		} 
		close (FACFILE); 
	    } 
	} 
       else 
       { 
	   push(@MergeAdminList, $_); 
       } 
    }
    
    return @MergeAdminList;
}

#
# Function: exeFindMergeWithScriptTillDone
#
# Description: Will execute findmerge -exec on a given script. Will then continue to execute findmerge until no merges are deemed necessary.
#
# 

sub exeFindMergeWithScriptTillDone
{
    my($branch,$script,$logfile,$elementOnlyMerge) = @_;

    dprint "insub: exeFindMergeWithScriptTillDone \n";
    dprint "branch = $branch .... script = $script \n";

    my $avobOrElement = $elementOnlyMerge ne "" ? $elementOnlyMerge : "-avobs";

    my @output;
    my $filesize = 1;
    my $count = 1;

    while($filesize > 0)
    {
	my $cmd = "$CLEARTOOL findmerge $avobOrElement  -nc -log $logfile -fversion .../$branch/LATEST -co -exec '$script'";
	system($cmd);

	$filesize = (stat($logfile))[7];
    
	my $newlogfile = $logfile . $count++;
	if($NT)
	{
	    copy( $logfile, $newlogfile ) 
	}
	else
	{
	    link($logfile,$newlogfile);
	}
	unlink($logfile);
	dprint ("DEBUG === $filesize \n");
    }
}

#
# Function: getVobsBrtypeTouched
#
# Description: Function that will get all the local VOBs in the within the VOB family that the passed in brtype was created.
#
# Returns: An array of vobs.
#

sub getVobsBrtypeTouched
{
    my ($brtype) = @_;
    my $adminvob = $NT ? $::CC_NT_ADMINVOB : $::CC_UNIX_ADMINVOB;
    my @listOfVobs;


    $listOfVobs[0] = $adminvob;

    my $cmd = "$CLEARTOOL describe brtype:$brtype\@$adminvob";
    my @output = qx($cmd);

    if($?)
    {
	display_msg("The following command failed:\n\t$cmd\n");
	return "";
    }

    foreach (@output)
    {
	chomp;

	if(/\s+GlobalDefinition/)
	{
	    # getting the local vobs.
	    # an example output would be:
	    #
	    # GlobalDefinition <- brtype:r16.3_dev-127024@/usr/vob/sc/arnie_cruz.dir
	    # will split in the '@' sign to obtain the vobpn.

	    my $vob = (split(/\@/))[1];

	    push @listOfVobs, $vob;
	}
    }


    return @listOfVobs;
}

#
# Function that will convert CQ's predicted release string and return CC release string.
# 

sub convertCQReleaseToCCRelease
{
    my ($cqrelease) = @_;

    my $rel = $cqrelease;
    if(!$::ALLOWRELEASEALPHANUMERIC)  
    {  
	dprint("NO ALPHA LETTERS IN RELEASE NAME\n");  
	if($rel =~ /(\d+(\.\d+)*)/) {  
	    $rel = "r".$1;  
	}  
    }  
    else  
    {  
	dprint("ALLOW ALPHA LETTERS IN RELEASE NAME\n");  
	if($rel =~ /^\D*(.*)/)  
	{  
	    $rel = "r".$1;  
	}  
    }

    return lc($rel);  
}

#
# Function that will return an array of Feature IDs from a given branch.
#
sub getFeatureIDFromBranch
{
    my ($branch, $vob,$num) = @_;

    dprint ("In SUB: getFeatureIDFromBranch");

    my @output; # an array of feature ids;
    my %fids;   # for quick lookups, will use an associative array and use the feature id as the key.
    my $cmd = "$CLEARTOOL describe -short -ahlink  FeatureID brtype:$branch\@$vob 2>$DEVNULL";

    @output = qx($cmd);
    if($?)
    {
	display_msg("Failed to obtain FeatureID list since the following command failed:\n\t$cmd\n");
	exit 1;
    }

    #
    # The output is similiar to this...
    #   ->  "1004L"
    #   ->  "670B"
    #
    #

    $$num = 0;
    foreach(@output)
    {
	chomp;
	
	# Need to strip out the uncessary " and -> chars.
	s/^->\s*\"//;
	s/\"$//;

	dprint "featureID for branch: $branch --> $_\n";
	$fids{lc($_)} = 1;
	++$$num;
    }

    return %fids;
}

1;
