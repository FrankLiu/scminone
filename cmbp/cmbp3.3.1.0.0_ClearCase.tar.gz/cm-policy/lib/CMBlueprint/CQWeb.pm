package CMBlueprint::CQWeb;

#######################################################################

=head1 NAME

CMBlueprint::CQWeb - Communicates with CQ via CQWeb

=head1 EXPORTS

  PopulateCQWebParams PerformQuery_CQWeb url_encode  PostCommand   MakeFilter
  LogCset_CQWeb       UnLogCset_CQWeb    GetCQWebUrl GetLogonParms

=head1 DESCRIPTION

B<CMBlueprint::CQWeb> communicates with ClearQuest via CQWeb. 
It provides functions to query and write change set to CQ via the
CQWeb Interface.                                                

=cut

###################################################################################

# use strict;
use vars qw(@ISA @EXPORT);
use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(PopulateCQWebParams PerformQuery_CQWeb  Query_CQWeb url_encode PostCommand MakeFilter
			LogCset_CQWeb UnLogCset_CQWeb GetCQWebUrl GetLogonParms @QUERIED_CRLIST);


use vars qw(%CQ_QUERY_FILTER @CQ_QUERY_FIELDS %CQ_WEB_PARAMS);

use CMBlueprint;
use CMBlueprint::UI;
use Socket;

#############################################################################################

=head1 NAME

PerformQuery_CQWeb -- Queries ClearQuest via the WEB server.  

=head1 SYNOPSIS

 PerformQuery_CQWeb()

=head1 DESCRIPTION

This function uses %CQ_QUERY_FILTER and %CQ_WEB_PARAMS.  The hashes should be populated 
by the calling program before calling this function.  It calls PostCommand to communicate 
and obtain the list of CRs from ClearQuest.

=head1 RETURN VALUES

 Returns ($rc, @bugdesc)           
   where $rc is CMBP_SUCCESS on success, CMBP_QUERY_FAIL or CMBP_LOGIN_FAIL on failure
         @bugdesc contains a list of CRs returned by the Query


=head1 B<NOTES>

This function was provided by Rational in the out-of-the-box CQCC integration script.

=cut

#################################################################

@QUERIED_CRLIST = ();   ## Used to cache results from earlier query

sub PerformQuery_CQWeb {
    (@QUERIED_CRLIST > 0)  and  return (CMBP_SUCCESS, @QUERIED_CRLIST);
	
    my (@QueryResult, @bugdesc);

    # my @fields= qw/id headline/;
	my @fields= @CQ_QUERY_FIELDS;
    my @filters;  
    foreach my $field (keys %CQ_QUERY_FILTER) {
       my ($operator, $value) = @{$CQ_QUERY_FILTER{$field}};
       
       push @filters, MakeFilter($field, $operator, $value);
    }

    #-------------------
    # SEND THE QUERY...
    #-------------------
    my $cmd = "CCIntQryFlds=" . url_encode(join('&',@fields)) . 
        "&CCIntQryFltrs=" . url_encode(url_encode(join('&',@filters))) .
        "&CCIntCmd=" . url_encode("QUERY");
    $cmd .= "&CCIntUID=" . url_encode($CQ_WEB_PARAMS{'cquser'}) .
        "&CCIntPWD=" . url_encode($CQ_WEB_PARAMS{'cqpwd'}) .
        "&CCIntDbName=" . url_encode($CQ_WEB_PARAMS{'cqdb'}) .
        "&CCIntDbgTrace=" . url_encode($CQ_WEB_PARAMS{'trace'}) .
        "&CCIntEntName=" . url_encode($CQ_WEB_PARAMS{'cq_rec_type'}) .
        "&CCIntKeepSession=" . url_encode($CQ_WEB_PARAMS{'keepsession'});
    dprint($cmd . "\n");

    my ($stat,$info,$warn,$error,$sessionStat,$queryStat, @tmp_queryresult) = PostCommand($cmd);
    if (($stat =~ /FAIL/) || $warn || $error) {
        if ($error =~ /batch_logon/){
           my $errormsg = "Query failed!  Possible reasons are:\n" .
                          "[1] You have an invalid CQ user id/password in $CQPARAM/.cqparams file.\n" .
                          "    Please remove the file and try again.\n" .
						  "[2] $CQPARAM/.cqparams file has a valid CQ user id/password but the user may not ".
						  "be subscribed to the $CQ_WEB_PARAMS{'cqdb'} database.\n".
                          "[3] Database name $CQ_WEB_PARAMS{'cqdb'} is invalid.\n" .
                          "    Please contact your ClearCase site administrator and " .
                          "ensure that the database name is in the list of databases\n"  .
                          "in the <prod>_trigger.cfg file\n";
           display_msg($errormsg);
           return(CQ_LOGIN_FAIL, @bugdesc);
        }
        else{
           display_msg("Query failed! $warn$error");
           return(CQ_QUERY_FAIL, @bugdesc);
        }
        return (CQ_QUERY_FAIL, @bugdesc);
    }

    push @QueryResult, @tmp_queryresult;

    #---------------------------------
    # FETCH MORE RESULTS IF NECESSARY
    #---------------------------------
    while ($queryStat =~ m/PARTIAL/ && $sessionStat =~ m/ACTIVE/) {
        dprint "queryStat: $queryStat, attempting FETCH\n";
        $cmd = "CCIntCmd=" . url_encode("FETCH") .
            "&CCIntDbgTrace=" . url_encode($CQ_WEB_PARAMS{'trace'}) .
            "&CCIntKeepSession=" . url_encode($CQ_WEB_PARAMS{'keepsession'});
        ($stat, $info, $warn, $error, $sessionStat, $queryStat, @tmp_queryresult) = PostCommand($cmd);

        if (($stat =~ /FAIL/) || $warn || $error) {
            display_msg("QUERY/FETCH request failed! $warn$error");
            return (CQ_QUERY_FAIL, @bugdesc);
        }
        push @QueryResult, @tmp_queryresult;
    }
    my $encodedbug;
    my $n;
    #---------------------------------------------------------------------------
    # QUERY RESULTS COME BACK IN A URL-ENCODED GLOBAL ARRAY. DECODE AND FORMAT.
    #---------------------------------------------------------------------------
    foreach $encodedbug (@QueryResult) {
        chop $encodedbug;  # get rid of NT-style cr/lf combo
        chop $encodedbug;
        my @fld = split('&',$encodedbug);
        my $i;
        for ($i = 0; $i < @fld; $i++) {
            $fld[$i] =~ tr/+/ /;
            $fld[$i] =~ s/%([\dA-Fa-f][\dA-Fa-f])/pack ("C", hex ($1))/eg;
        }
        $bugdesc[$n++] = sprintf("%s   %-100.100s",$fld[0],$fld[1]);
    }

    @QUERIED_CRLIST = sort @bugdesc;
    return (CMBP_SUCCESS, @QUERIED_CRLIST);
}


#### ARNIE CHANGES ############

sub Query_CQWeb {
    (@QUERIED_CRLIST > 0)  and  return (CMBP_SUCCESS, @QUERIED_CRLIST);

    my ($fieldList)  = @_;
    my (@QueryResult, @bugdesc);

    my @fields= @$fieldList;

    my @filters;  
    foreach my $field (keys %CQ_QUERY_FILTER) {
       my ($operator, $value) = @{$CQ_QUERY_FILTER{$field}};
       
       push @filters, MakeFilter($field, $operator, $value);
    }


    #-------------------
    # SEND THE QUERY...
    #-------------------
    my $cmd = "CCIntQryFlds=" . url_encode(join('&',@fields)) . 
        "&CCIntQryFltrs=" . url_encode(url_encode(join('&',@filters))) .
        "&CCIntCmd=" . url_encode("QUERY");
    $cmd .= "&CCIntUID=" . url_encode($CQ_WEB_PARAMS{'cquser'}) .
        "&CCIntPWD=" . url_encode($CQ_WEB_PARAMS{'cqpwd'}) .
        "&CCIntDbName=" . url_encode($CQ_WEB_PARAMS{'cqdb'}) .
        "&CCIntDbgTrace=" . url_encode($CQ_WEB_PARAMS{'trace'}) .
        "&CCIntEntName=" . url_encode($CQ_WEB_PARAMS{'cq_rec_type'}) .
        "&CCIntKeepSession=" . url_encode($CQ_WEB_PARAMS{'keepsession'});
    dprint($cmd . "\n");

    my ($stat,$info,$warn,$error,$sessionStat,$queryStat, @tmp_queryresult) = PostCommand($cmd);
    if (($stat =~ /FAIL/) || $warn || $error) {
        if ($error =~ /batch_logon/){
           my $errormsg = "Query failed!  Possible reasons are:\n" .
                          "[1] You have an invalid CQ user id/password in $CQPARAM/.cqparams file.\n" .
                          "    Please remove the file and try again.\n" .
						  "[2] $CQPARAM/.cqparams file has a valid CQ user id/password but the user may not ".
						  "be subscribed to the $CQ_WEB_PARAMS{'cqdb'} database.\n".
                          "[3] Database name $CQ_WEB_PARAMS{'cqdb'} is invalid.\n" .
                          "    Please contact your ClearCase site administrator and " .
                          "ensure that the database name is in the list of databases\n"  .
                          "in the <prod>_trigger.cfg file\n";
           display_msg($errormsg);
           return(CQ_LOGIN_FAIL, @bugdesc);
        }
        else{
           display_msg("Query failed! $warn$error");
           return(CQ_QUERY_FAIL, @bugdesc);
        }
        return (CQ_QUERY_FAIL, @bugdesc);
    }

    push @QueryResult, @tmp_queryresult;

    #---------------------------------
    # FETCH MORE RESULTS IF NECESSARY
    #---------------------------------
    while ($queryStat =~ m/PARTIAL/ && $sessionStat =~ m/ACTIVE/) {
        dprint "queryStat: $queryStat, attempting FETCH\n";
        $cmd = "CCIntCmd=" . url_encode("FETCH") .
            "&CCIntDbgTrace=" . url_encode($CQ_WEB_PARAMS{'trace'}) .
            "&CCIntKeepSession=" . url_encode($CQ_WEB_PARAMS{'keepsession'});
        ($stat, $info, $warn, $error, $sessionStat, $queryStat, @tmp_queryresult) = PostCommand($cmd);

        if (($stat =~ /FAIL/) || $warn || $error) {
            display_msg("QUERY/FETCH request failed! $warn$error");
            return (CQ_QUERY_FAIL, @bugdesc);
        }
        push @QueryResult, @tmp_queryresult;
    }
    my $encodedbug;
    my $n;
    #---------------------------------------------------------------------------
    # QUERY RESULTS COME BACK IN A URL-ENCODED GLOBAL ARRAY. DECODE AND FORMAT.
    #---------------------------------------------------------------------------
    foreach $encodedbug (@QueryResult) {
        chop $encodedbug;  # get rid of NT-style cr/lf combo
        chop $encodedbug;
        my @fld = split('&',$encodedbug);
        my $i;
	my $outputline;
        for ($i = 0; $i < @fld; $i++) {
            $fld[$i] =~ tr/+/ /;
            $fld[$i] =~ s/%([\dA-Fa-f][\dA-Fa-f])/pack ("C", hex ($1))/eg;
	    $outputline .= "$fld[$i] ";
        }
	chomp($outputline); # getting rid of the last semi-colon.
        $bugdesc[$n++] = $outputline;
    }

    @QUERIED_CRLIST = sort @bugdesc;
    return (CMBP_SUCCESS, @QUERIED_CRLIST);
}



###############################



#==============================================================================
# URL-ENCODE AND FORMAT THE ARGLIST (field,op,value) TO CREATE A CQ FILTER
#==============================================================================
#################################################################

=head1 NAME

MakeFilter -- Returns an url encoded string containing the ClearQuest filter command.

=head1 SYNOPSIS

 MakeFilter($CQfield, $CQop, @values)

 where

       $CQfield    - ClearQuest Field name 
       $CQop       - operand
       @values     - array of values


=head1 DESCRIPTION

Generates an url-encoded CQ filter string containing the field name, operand and list of values.

=head1 RETURN VALUES

 On SUCCESS, url-encoded string
 On FAILURE, an empty string


=head1 B<NOTES>

This function was provided by Rational in the out-of-the-box CQCC integration script.

=cut

#################################################################
sub MakeFilter {
    my $p1 = shift;
    my $op = shift;
    my @args = @_;
    #dprint "\n\n\nARGS:" . join("X",@args) . " number: $#args\n";
    my $filter = url_encode($p1) . "\001" . $op;
    my $i;
    for ($i = 0; $i <= $#args; $i++) {
        $filter .= ("\001" . url_encode($args[$i]));
    }
    return $filter;
}

#==============================================================================
# POST A COMMAND TO THE CLEARQUEST SERVER VIA THE WEB INTERFACE
#==============================================================================
#################################################################

=head1 NAME

PostCommand -- Submits a command to the ClearQuest WEB server, parses the output from the WEB server and returns results. 

=head1 SYNOPSIS

 PostCommand($cmdstring)

 where

       $cmdstring  - CQ/CC integration command to be 
                     submitted to the WEB server.


=head1 DESCRIPTION

The function connects to the ClearQuest WEB server using the URL.  It submits the command string 
and parses the output from the WEB server and populates the results.  If the WEB server returns 
results of a query, it populates @CQCC::QueryResult array.

=head1 RETURN VALUES

 Returns ($result, $info, $warn, $error, $sessionStatus, $queryStatus, @QueryResult)

 where

         $result - results from the WEB server
         $info   - Information from the WEB server
         $warn   - Any warnings from the WEB server
         $error  - Any errors from the WEB server
 $sessionStatus  - Status of the session with the WEB server
                   Can be ACTIVE, CLOSED
  $queryStatus   - Status of the results of query 
                   submitted on the WEB server
                   Can be COMPLETE, PARTIAL
  @QueryResult   - List of CRs and their corresponding headlines.


=head1 B<NOTES>

This function was provided by Rational in the out-of-the-box CQCC integration script.

=cut

#################################################################
sub PostCommand {
    my $cmdstring = shift @_;

    my @QueryResult;
    my $NumResultRows = 0;

    # Socket setup
    my $sockaddr = 'S n a4 x8';
    my ($name, $aliases, $proto) = getprotobyname('tcp');
    my ($type, $len, $thisaddr);
    my $localhost = $HOSTNAME;
    ($name, $aliases, $type, $len, $thisaddr) = gethostbyname($localhost);
    my $rthis = pack($sockaddr, AF_INET, 0, $thisaddr);

    my $contentlen = length($cmdstring);
    # String sent to http server
    my $toserver = "POST $CQ_WEB_PARAMS{'url'} HTTP/1.0\n" .
        "Content-Length: $contentlen\n" .
        "Content-Type: application/x-www-form-urlencoded\n";
    if ($CQ_WEB_PARAMS{'cookie'}) {
        $toserver .= "Cookie: $CQ_WEB_PARAMS{'cookie'}\n";
    }
    $toserver .= "\n$cmdstring";   # the \n is needed to separate the header!

    # Write to the server
    # Connect directly to server indicated by URL
    my $remotehost;
    if ($CQ_WEB_PARAMS{'url'} =~ m|^http://(.*)|) {
       $remotehost = $1;
    }
    my $remoteport = 80;	# default
    my $request = "/";	# default
    ($remotehost =~ s|^([^/]+)/(.*)$|$1|) && ($request = $2);
    ($remotehost =~ s/:(\d+)$//) && ($remoteport = $1);
    dprint "Host is $remotehost:$remoteport.\n";
    my $thataddr;
    ($name, $aliases, $type, $len, $thataddr) = gethostbyname($remotehost);
    my $there = pack($sockaddr, AF_INET, $remoteport, $thataddr);
    socket(RSVR, PF_INET, SOCK_STREAM, $proto) or 
        return("FAIL", '', '', "Can't create server socket: $!");

    connect(RSVR, $there) or return('FAIL', '', '',  "Can't connect to $remotehost: $!");
    select(RSVR); $| = 1; select(STDOUT); # changed stdout to STDOUT - Gopal.

    # Remove the hostname from the URL
    if (!($toserver =~ s|http://$remotehost:$remoteport||)) {
        $toserver =~ s|http://$remotehost||;
    }

    # Send the request
    dprint "SENDING TO SERVER:\n$toserver\n";
    print RSVR $toserver;

    # Get the content
    my $got_content_type = 0;
    my $length = 0;
    my $buffer;
    my $end_header = 0;
    my $output;
    my ($warn,$error,$info,$result,$sessionStatus, $querystatus);

    while(read(RSVR,$buffer,8*1024)) { 
        dprint "\n\n\n\n***********************************Read from server:\n\n";
        #if (!$end_header) {
            my @lines = split(/^/, $buffer);
            my $line;
            foreach $line (@lines) {
                #dprint "LINE:$line\n";
                if ($end_header && ($line =~ m/^CCInt/) ) {
                    my $value;
                    my $key;
                    ($key,$value) = split(/=/, $line);
                    if ($key eq 'CCIntQueryRow') {
                        # if we have a query result row, add it to the global result buffer
                        # untouched; don't know enough about what's going on down at this
                        # level to do anything with it, except format for debug printing.
                        $QueryResult[$NumResultRows++] = $value;

                        # this stuff is just for debug
                        my @flds = split('&',$value);
                        my $i;
                        for ($i = 0; $i < $#flds; $i++) {
                            $flds[$i] =~ tr/+/ /;
                            $flds[$i] =~ s/%([\dA-Fa-f][\dA-Fa-f])/pack ("C", hex ($1))/eg;
                        }
                        #$output .= join('!',@flds);
                        $output .= $key . '=' . $value;
                    } else {
                        $value =~ tr/+/ /;
                        $value =~ s/%([\dA-Fa-f][\dA-Fa-f])/pack ("C", hex ($1))/eg;
                        $output .= $key . '=' . $value;
                    }
                    # Check for status and messages to return to caller
                    if ($line =~ m/^CCIntInfoMsg/) {
                        $info = $value;
                    } elsif ($line =~ m/^CCIntResult/) {  # SUCCESS / FAIL
                        $result = $value;
                    } elsif ($line =~ m/^CCIntSessionStatus/) { # ACTIVE / CLOSED
                        $sessionStatus = $value;
                    } elsif ($line =~ m/^CCIntFetchStatus/) {  # COMPLETE / PARTIAL
                        $querystatus = $value;
                        #dprint "QUERY STATUS: $querystatus\n";
                    } elsif ($line =~ m/^CCIntErrorMsg/) {
                        $error = $value;
                    } elsif ($line =~ m/^CCIntWarnMsg/) {
                        $warn = $value;
                    }
                } elsif ($line =~ m/^Set-Cookie: (.*)$/) {
                    # save cookie, will throw away later if the session is gone
                    $CQ_WEB_PARAMS{'cookie'} = $1;
                    dprint "cookie set: $CQ_WEB_PARAMS{'cookie'}\n";
                } elsif ($line =~ m/^\s*$/) {
                    $end_header = 1;
                } else {
                    # header stuff other than cookie
                }
            }
        #} else {
        #    $output .= $buffer;
        #}
    } # end 'while(read(RSVR....

    # don't keep the cookie if we didn't keep the session
    $CQ_WEB_PARAMS{'cookie'} = '' if ($sessionStatus =~ m/CLOSED/);
    close RSVR;
    dprint "*****OUTPUT from Server:\n$output\n*****END of Server Output\n";
    dprint "session status: $sessionStatus queryStat: $querystatus Cookie: $CQ_WEB_PARAMS{'cookie'}\n";
    return ($result,$info,$warn,$error,$sessionStatus,$querystatus, @QueryResult);
}

#==============================================================================
# URL_ENCODE   Stolen from CGI.PM
#==============================================================================
#################################################################

=head1 NAME

url_encode -- URL encode a specified string

=head1 SYNOPSIS

 url_encode($toencode)

 where

    $toencode - string to be encoded


=head1 DESCRIPTION

URL encodes the specified string.

=head1 RETURN VALUES

 Returns the encoded string on success


=head1 B<NOTES>

This function was provided by Rational in the out-of-the-box CQCC integration script. 

=cut

#################################################################
sub url_encode 
{
    my($toencode) = @_;
    $toencode=~s/([^a-zA-Z0-9_\-.])/uc sprintf("%%%02x",ord($1))/eg;
    return $toencode;
}

#################################################################

=head1 NAME

LogCset_CQWeb -- Log change set in a CR in ClearQuest via the WEB server

=head1 SYNOPSIS

 LogCset_CQWeb($crid)

 where

    $crid - ClearQuest CR


=head1 DESCRIPTION

Uses %CQ_WEB_PARAMS to login and write the change set to the CQ WEB server.  Calls PostCommand to 'ASSOCIATE' the change set to the CR.

=head1 RETURN VALUES

 Returns 0 on success.                
 Returns 1 on failure.                


=head1 B<NOTES>

This function was provided by Rational in the out-of-the-box CQCC integration script. 

=cut

#################################################################
sub LogCset_CQWeb {
    my $crid = shift @_;

    my $rc = 0;
    my $basic_cmd ="&CCIntUID="         . url_encode($CQ_WEB_PARAMS{'cquser'}) .
                   "&CCIntPWD="         . url_encode($CQ_WEB_PARAMS{'cqpwd'}) .
                   "&CCIntDbName="      . url_encode($CQ_WEB_PARAMS{'cqdb'}) .
                   "&CCIntDbgTrace="    . url_encode($CQ_WEB_PARAMS{'trace'}) .
                   "&CCIntEntName="     . url_encode($CQ_WEB_PARAMS{'cq_rec_type'}) .
                   "&CCIntKeepSession=" . url_encode($CQ_WEB_PARAMS{'keepsession'});


    my $cmdstring = "CCIntCmd="     . url_encode("ASSOCIATE") .
                    "&CCIntBugIDs=" . url_encode($crid) .
                    "&CCIntVOList=" . url_encode($CQ_WEB_PARAMS{'volist'}) .
                    $basic_cmd;

    my ($stat, $info, $warn, $error, $s, $q, @queryresult) = PostCommand($cmdstring);

    dprint "\nASP stat: $stat\ni: $info w: $warn e: $error\n";
    chomp $stat;
    if ($stat =~ /FAIL/) {
        # association failed; we'll attempt to DISassociate the same list
        # in order to clean up as much as possible.
        $rc = 1;
        display_msg("Error: Associate ClearQuest CR failed: $warn$error\n",1);
        $cmdstring = "CCIntCmd="     . url_encode("DISASSOCIATE") . 
                     "&CCIntBugIDs=" . url_encode($crid) .
                     $basic_cmd;
        my ($stat, $info, $warn, $error, $s, $q, @queryresult) = PostCommand($cmdstring);
    }
    return $rc;
}

#################################################################

=head1 NAME

UnLogCset_CQWeb -- Removes a change set from a CR in ClearQuest via the WEB server

=head1 SYNOPSIS

 UnLogCset_CQWeb($crid)

 where

    $crid - ClearQuest CR


=head1 DESCRIPTION

Uses %CQ_WEB_PARAMS to login and remove the change set via the CQ WEB server.  Calls PostCommand to 'DISASSOCIATE' the change set from the CR.

=head1 RETURN VALUES

 Returns 0 on success.                
 Returns 1 on failure.                


=head1 B<NOTES>

This function was provided by Rational in the out-of-the-box CQCC integration script. 

=cut

#################################################################
sub UnLogCset_CQWeb {
    my $crid = shift @_;

    my $rc = 0;
    my $basic_cmd ="&CCIntUID="         . url_encode($CQ_WEB_PARAMS{'cquser'}) .
                   "&CCIntPWD="         . url_encode($CQ_WEB_PARAMS{'cqpwd'}) .
                   "&CCIntDbName="      . url_encode($CQ_WEB_PARAMS{'cqdb'}) .
                   "&CCIntDbgTrace="    . url_encode($CQ_WEB_PARAMS{'trace'}) .
                   "&CCIntEntName="     . url_encode($CQ_WEB_PARAMS{'cq_rec_type'}) .
                   "&CCIntKeepSession=" . url_encode($CQ_WEB_PARAMS{'keepsession'});


    my $cmdstring = "CCIntCmd="     . url_encode("DISASSOCIATE") .
                    "&CCIntBugIDs=" . url_encode($crid) .
                    "&CCIntVOList=" . url_encode($CQ_WEB_PARAMS{'volist'}) .
                    $basic_cmd;

    my ($stat, $info, $warn, $error, $s, $q, @queryresult) = PostCommand($cmdstring);

    dprint "\n\nASP stat: $stat\ni: $info w: $warn e: $error\n";
    chomp $stat;
    if ($stat =~ /FAIL/) {
        $rc = 1;
        display_msg("Error: Disassociate ClearQuest CR $crid failed: $warn$error\n",1);
    }

    return $rc;
}

#################################################################

=head1 NAME

PopulateCQWebParams  -- Populates %CQ_WEB_PARAMS.                            

=head1 SYNOPSIS

 PopulateCQWebParams()      

=head1 DESCRIPTION

Calls GetLogonParms() to get the ClearQuest userid and password from the .cqparams file.  
It calls GetCQWebUrl to get the url to the WEB server.  

=head1 RETURN VALUES

returns 0 if there are no errors
returns 1 otherwise.

=cut

#################################################################
sub PopulateCQWebParams {
  my ($cqcc_server, $cqcc_serverroot, $cq_rec_type) = @_;
  my ($rc, $cquser, $cqpwd) = GetLogonParms();
  return $rc if $rc;

  @CQ_WEB_PARAMS{'cquser', 'cqpwd'} = ($cquser, $cqpwd);

  my $url = GetCQWebUrl($cqcc_server, $cqcc_serverroot);
  return 1 if not length($url);

  $CQ_WEB_PARAMS{'url'} = $url;

  $CQ_WEB_PARAMS{'cq_rec_type'} = $cq_rec_type;
  $CQ_WEB_PARAMS{'keepsession'} = 'TRUE';
  if (exists $ENV{CQCC_DEBUG} and $ENV{CQCC_DEBUG} > 1){
     $CQ_WEB_PARAMS{'trace'} = 'TRUE';
  }

  $CQ_WEB_PARAMS{'cookie'} = '';
  
  return 0;
}

##########################################################################
#==============================================================================
# RETURNS THE ROOT DIRECTORY OF THE CC/CQ INTEGRATION WEB SERVER
#==============================================================================
#################################################################

=head1 NAME

GetCQWebUrl -- Generate the URL to the WEB server, given the WEB server name and the WEB server root.

=head1 SYNOPSIS

 GetCQWebUrl()


=head1 DESCRIPTION

The function gets the WEB server name and root from the calling program.  The url is generated by concatenating the WEB server name and the WEB server root. 

=head1 RETURN VALUES

 Returns the url on success
 Returns an empty string on failure


=head1 B<NOTES>

This function was provided by Rational in the out-of-the-box CQCC integration script. 

=cut

#################################################################
sub GetCQWebUrl {
    my ($server, $serverroot) = @_;

    if ($server && $serverroot) {
        my $serversystem = $server . "\/" . $serverroot;
        my $url = "http://$serversystem/ccintegration/default.asp";
        return $url;
    } else {
        return '';
    }
}

#################################################################

#==============================================================================
# Get ClearQuest Login Information from ".cqparams" file. If this file does
# not exist, then prompt for the information and save it in "~/.cqparams".
#==============================================================================
#################################################################

=head1 NAME

GetLogonParms -- Get the ClearQuest ID and password.

=head1 SYNOPSIS

 GetLogonParms()


=head1 DESCRIPTION

The function checks if .cqparams file exists in $ENV{HOME} on the UNIX client or in $ENV{USERPROFILE} 
on the Windows NT client.  If the file exists, it returns the ClearQuest id and password from the file.  
If the file does not exist,  it prompts the user to enter the ClearQuest id and password, separated by 
spaces.  It then saves the id and encrypted password in the .cqparams file in $ENV{HOME} on UNIX and 
$ENV{USERPROFILE} on Windows NT.

=head1 RETURN VALUES

 Returns ($rc, $user, $pass)

 where

           $rc - 0 on success, 1 on failure
         $user - ClearQuest user id              
         $pass - encrypted ClearQuest password


=head1 B<NOTES>

This function was provided by Rational in the out-of-the-box CQCC integration script.  
The path to .cqparams file was modified to work on Windows NT.

=cut

#################################################################
sub GetLogonParms {
    # look for a file '.cqparams' that will have logon info for the CQ database.

    my $parmfile = "$CQPARAM/.cqparams";
    my ($rc, $user, $pass, $user_pass);
    my $done = 0;
	my $saveEuid = $>;
	$> = $<;	##scMergeList

    if (-s $parmfile) {
        open(PARM, $parmfile);
        while (<PARM>) {
          ($user, $pass) = split(" ", $_, 2);
        }
        close PARM;
        if ($pass) {
           $pass =~ tr/M-Za-v0-5A-L6-9w-z/A-Za-z0-9/;
        }
        $rc = 0;
    }else{
        while (not $done) {
           ($rc, $user_pass) = get_text({'-name' => 'CQUSERPASS'},
               "Enter your ClearQuest username and password, separated by a space: ");
           if ($rc != 0){
              $done = 1;
           }
           elsif (length($user_pass)){
              ($user, $pass) = split(" ", $user_pass, 2);
              if (not length($pass)){
                 display_msg("You have not entered your ClearQuest password. \n" .
                        "Please re-enter\n", 0);
              }
              else {
                 my $encrpass = $pass;
                 $encrpass =~ tr/A-Za-z0-9/M-Za-v0-5A-L6-9w-z/;
                 open (PWC,">$parmfile") or die( "Error: can't open $parmfile");
                 chmod(0600,$parmfile) if not $NT;
                 print PWC "$user $encrpass";
                 close PWC;
                 $done = 1;
              }         
           }
        }
    }
	$> = $saveEuid;	
    return ($rc, $user,$pass);
}

1;
