## Need to predeclare these variables form the main:: package
use vars qw( %DEVPROJECT);


package CMBlueprint::DevProject;

########################################################################

=head1 NAME

CMBlueprint::DevProject - module to query "development project" information

=head1 DESCRIPTION

B<CMBlueprint::DevProject> is a module to query "development
project" information maintained by CC admins. ClearCase
"devproject" definition files may be created as document in
B<mkview.pl> or in the I<prod>_projects subdirectory of the
CMBlueprint ClearCase configuration directory.

B<CMBlueprint::DevProject> defines and exports a number of subroutines,
each of which are describes in the subsections which follow.

=cut

########################################################################

use CMBlueprint;
use strict;

use vars qw(@ISA @EXPORT);
use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(
    date_time
    dir_entries
    compute_cspec
    devprojects_dir
    get_devprojects
    read_devproject_file
    check_proj_file
);

BEGIN {
  use File::Basename;
  my $dirname = dirname($0);
  unshift(@INC, "$dirname/../../lib");
 };
use vars qw($DEVPROJ_SFX);
use vars qw(@EXPORT_OK);

$DEVPROJ_SFX = '.prj';

#####################################################################

=head2 date_time - Get current date+time in CC date.time format

          my $dt_tm = date_time();

This function gets the current time and converts it to CC date.time format of 
DD-MMM-YYYY.HH:MM:SS (e.g., 17-Jul-2000.15:42:22)

Returns the current time in CC date.time format

=cut

#####################################################################

sub date_time {
   local $_ = scalar(@_) ? localtime(shift) : localtime;
   my($wkday, $mon, $mday, $time, $yr) = split;
   return "$mday-$mon-$yr.$time";
}

#####################################################################

=head2 dir_entries - Get all the element names in the directory

        my @elems = dir_entries($dir);

where

        $dir - directory path

This function takes the directory path and returns all the elements
under that directory. 

Returns the list of all element names under a directory

=cut

###########################################################################

sub dir_entries {
   my $dir = shift;
   my(@elements);
   local($_);
   ## Open the directory for reading
   opendir(DIRECTORY, $dir) or return @elements;
   ## Read all the directory entries
   while (defined($_ = readdir(DIRECTORY))) {
      next if (/^\.*$/);  ## ignore . and .. (does this work for NT)
      push(@elements, "$_");
   }
   closedir(DIRECTORY);
   return @elements;
}

##########################################################################

=head2 compute_cspec - compute the view config-spec

    my $cspec = compute_cspec(\%devproj, $brtype, $vwusage, $time_based);

where

    %devproj - hash containing the devproject attributes such as the
               integration branch for the devproject and the base
               config spec rules
    $brtype - branch type
    $vwusage - usage or purpose of the view
    $time_based - time

Computes the view config spec to use based on
the devproject spec, the branch type, and the view-usage.
This function forms a string suitable for use as an
NT-compatible config-spec associated with a View Profile. The
view is configured based on the CC "development project"
attributes defined in a hash. The reference to this hash is
passed to this function, which holds information such as the
project name, the integration branch to be used for work on
this devproject, the base config-spec rules etc.

Returns a string suitable for use as an NT-compatible
config-spec associated with a View Profile.

=cut

##########################################################################

sub compute_cspec {
  my($projref, $brtype, $vwusage, $timeshot) = @_;
  my @dev_rules = ();
  my @base_rules = split("\n", $projref->{CSPEC_BASE}||"");
  if (@base_rules == 0) {
     push @base_rules, "element * /main/LATEST";
  }
  my $eol = "\n";
  for (@base_rules) {
     ## handle any \r characters before the \n
     s/\r$//g  and  $eol = "\r\n";
  }
  my $projname = $projref->{NAME};
  my $projfile = $projref->{FILE};
  my $projbranch = $projref->{PROJECT_BRANCH};
  my $qualifier = "";

  ## Get current time and convert it to CC date.time format
  ## of DD-MMM-YYYY.HH:MM:SS (e.g., 17-Jul-2000.15:42:22)
  my $cc_time   = ($timeshot) ? date_time() : "";
  my $time_rule = ($timeshot) ? "time $cc_time" : ""; 

  if ($vwusage =~ /^noc[ho]/) {
     $qualifier = ' -nocheckout';
  }
  else {
     push @dev_rules, "element * CHECKEDOUT";
  }

  if ( (! length $brtype)  and  $vwusage =~ /^(int|dev)$/ ) {
     ## development on the integration branch
     $brtype = $projbranch;
  }

  if ($brtype eq $projbranch) {
     ## Remove the first rule from the set of base rules
     ##  *IF* it explicitly selects the integration branch
     local $_ = $base_rules[0] . " ";
     m{/$brtype/(LATEST|[A-Z][-.\w]+)[^/]}  and  shift @base_rules;
  }

  if (length $brtype) {
     ## Add rule to select latest on this branch
     ##  and do a mkbranch for remaining rules
     my $dots = ($brtype eq 'main') ? '' : "...";
     push @dev_rules, "element * $dots/$brtype/LATEST";
     push @dev_rules, "mkbranch $brtype"  unless ($brtype eq 'main');
  }

  if ($timeshot) {
     push @dev_rules, $time_rule;
  }

  ## Add the qualifier to the remaining rules if specified
  @base_rules = map { $_ . $qualifier } @base_rules;

  ## Now return a string suitable for use as a config-spec
  my @head_rules = (
     "#----------------------------------------------------------------------#",
     "# CMBlueprint - ClearCase View Config Spec",
     "#   (Using DevProject '$projname' located at:",
     "#    $projfile)",
     "",
  );
  my @tail_rules = (
     "",
     "#----------------------------------------------------------------------#",
     "",
  );
  if (@dev_rules) {
     unshift @dev_rules,
             "",
             "# Development rules:",
             "#";
  }
  if (@base_rules) {
     unshift @base_rules,
             "",
             "# Base rules for DevProject '$projname':",
             "#";
  }

  return  join $eol, (@head_rules, @dev_rules, @base_rules, @tail_rules);
}


####################################################################

=head2 devprojects_dir - Get the directory holding the "devproject" definitions

    my $dirpath = devprojects_dir ($dir, $prodfamily);

where

    $dir - path to the product-family's ClearCase configuration file
    $prodfamily - Product family associated with the VOB.

Get the directory name (with path) holding the development
projects associated with the product family.  This function
returns the subdirectory (e.g. "Aspira_projects") holding the
project definition files for a product family. The directory
name is product family name followed by "_projects" and is
under the product-family's ClearCase configuration file

Returns the directory name (with path) of the directory holding the
devproject definition files associated with a product family.

=cut

###############################################################

sub devprojects_dir
{
   my ($config_dir, $product_family) = @_;
   return "$config_dir/$product_family"."_projects";
}

#############################################################

=head2 get_devprojects - Get all the devprojects in a directory

    my @devprojs = get_devprojects($projdir);

where 

    $projdir - development project directory name (with path), holding
               the devproject definition files for a product_family.

This function returns the development project definition files
(without file extension) associated with a product family.

Returns the list of development project files (without file extension)
associated with a product family.

=cut

##############################################################################

sub get_devprojects
{
   my $devprojects_dir = shift;
   return ()  unless (-d $devprojects_dir);

   my @devprojects = grep { (! -d $_) and (lc($_) =~ /\Q$DEVPROJ_SFX\E$/) }
                          dir_entries($devprojects_dir);

   return @devprojects;
}

############################################################################


=head2 read_devproject_file - read the devproject definition file

    my %projhash = read_devproject_file($dir, $devproj);

where 

    $dir - directory name with path
    $devproj - clearcase "development project" definition file

This function reads the clearcase "development project"
definition files, which is located based on the directory path
and the development project name that are passed as parameters.
The function returns the single data structure holding the
project attributes.

Returns the value (%projhash) where:

    %projhash is a hash containing the development project
    attributes and their values.

=cut

########################################################################

sub read_devproject_file
{
   my ($devprojects_dir, $devproject) = @_;

   my $project_file = "";
   ## Got a good one - now read it's definition
   $project_file = $devprojects_dir . '/' . ($devproject||"");
   my ($cmt, %devproj)= check_proj_file($project_file);
   if($cmt) {
        display_msg( "Error: $cmt");
        exit(2);
   }

#   return $project_file;
   ## We could also check to make sure the project-branch exists,
   ## but we wont do that.
   return %devproj;

}

#########################################################################

=head2 check_proj_file - checks the validity of the "devproject"

    my %devproj = check_proj_file($file);

where 

    $file - file name with the path of the clearcase development project

This function verifies the existence of the clearcase development
project file at the specified path.  It also ensures that the
neccesary devproject attributes of the data structure defined
inside the devproject files have appropriate values.

Returns (%devproj) where:

    %devproj is the copy of the hash defined in the clearcase
    development project file, having the devproject attributes
    and their values.

=cut

############################################################################

sub check_proj_file {
   my $proj_file = shift;
   my %devproj_copy =();
   my $cmt="";

   package main;
   eval  { require "$proj_file"; };
   package CMBlueprint::DevProject;

   if ($@) {
      $cmt= "Development Project File eval error in $proj_file.\n" .
            "The error is: $@\n\n" . 
            "Please notify your local CC administrator.\n";
            return ($cmt,%devproj_copy);
    };
   ## Make sure they defined the hash we need
   unless (defined %::DEVPROJECT) {     
     $cmt= "Development Project File definition error in $proj_file.\n" .
           "The '%DEVPROJECT' hash was not defined in the main package.\n" .
           "Please notify your local CC administrator.\n";
           return ($cmt,%devproj_copy);
   }
   ## Make sure we capture the filename
   $::DEVPROJECT{'FILE'} = $proj_file  unless (exists $::DEVPROJECT{'FILE'});

   ## Make sure they defined the hash values we need
   for (qw(NAME)) {
      unless ( exists $::DEVPROJECT{$_}
                 and  defined $::DEVPROJECT{$_}
                 and  length $::DEVPROJECT{$_} )
      {

         $cmt = "Development Project File definition error in $proj_file.\n" .
           "The value '\$DEVPROJECT{$_}' was not defined!\n" .
           "Please notify your local CC administrator.\n";
           return ($cmt,%devproj_copy);
      }
    }
    unless ($cmt) {
          %devproj_copy = %::DEVPROJECT;
    }
    return ($cmt, %devproj_copy);
}

#########################################################################


1; 
