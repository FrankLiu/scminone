package CMBlueprint::ClearQuest;

#######################################################################

=head1 NAME

CMBlueprint::ClearQuest - provides interface to ClearQuest                 

=head1 EXPORTS

  GenerateCrId ParseCrId FormatCrId GetCrId GetAssignedCR AuthorizedCR GetValidCRSet
  ShowValidCrSet IsValidCR LogCset UnLogCset CheckIsValidIntCR GetReleaseLoadlineforCR GetRelLLTTCRUforCR GetSPCFforCR GetCRFeature

=head1 DESCRIPTION

B<CMBlueprint::ClearQuest> provides an interface to ClearQuest. 
It provides functions to generate or parse a Change Record (CR)
ID using the format that ClearQuest uses.  It also has functions
to validate a CR, or log change set in the CR in ClearQuest.

=cut

###################################################################################
###############################################
# Use variables from site.cfg                 #
###############################################
use vars qw($CQ_REC_TYPE);

use CQCCIntegration::Session;
use CQCCIntegration::Session::Admin;

###############################################
# Use variables from $PROD_trigger.cfg        #
###############################################
use vars qw(@CQ_DB_LST $CQ_DEF_DB $SERVERCQWEB);



use strict;
use vars qw(@ISA @EXPORT);
use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(GenerateCrId ParseCrId FormatCrId GetCrId GetAssignedCR AuthorizedCR 
	GetValidCRSet ShowValidCrSet IsValidCR LogCset MVCsetLog UnLogCset CheckIsValidIntCR CheckIsCRAssigned CheckIsCRClosed CheckIsCRPerformed GetLinkedCRs comm_AuthorizedCR GetParentLinkedCRs
	     clearcaseTabAction getVobObjectNameFromCQ getBaseLineRecord getBranchTypeFromCR GetReleaseLoadlineforCR IsAltMainReleaseforCR GetRelLLTTCRUforCR GetSPCFforCR GetCRFeature
	     getCRComponent getCRInfo
	     get_verifyBrtypeFromCR
	     relinkCStoCR
	     IsCRClosedAndCRInformation
	     getDepFromHlink
	     getuuidfromCQ
	     checkCRassignedAndNoOtherActiveBrtype
	     getReleaseIDs);

use vars qw(%CQ_WEB_PARAMS); # use variable from CMBlueprint.pm
use vars qw(@QUERIED_CRLIST); # use variable from CMBlueprint.pm

use CMBlueprint;
use CMBlueprint::UI;
use CMBlueprint::CQWeb;
use CMBlueprint::Config;
use CMBlueprint::Vob;

=head1 NAME

GenerateCrId -- Formats ClearQuest CR ID.   

=head1 SYNOPSIS

 GenerateCrId($cqdb, $dbID, $cq_def_db, @cq_db_lst)

 where
     $cqdb      -  ClearQuest database name.  Can be blank.
     $dbID      -  ClearQuest CR number
     $cq_def_db -  Default ClearQuest database for the product.
     @cq_db_lst -  List of Valid ClearQuest databases for the product


=head1 DESCRIPTION

Given a ClearQuest database name and number, GenerateCrId generates a CR ID in the format as seen in ClearQuest.  If the ClearQuest database name is blank, it uses $cq_def_db as the database name.  If the ClearQuest database name is not blank, it checks if it exists in @cq_db_lst and matches the right character case for cqdb.  It $dbID is blank, it returns 1.  Otherwise, it 0-pads the dbID to 8-digits.

=head1 RETURN VALUES

 Returns 0 and the formatted $cqdb and $dbID on success.
 Returns 1 on failure.                


=cut

#################################################################
sub GenerateCrId {

   my ($cqdb, $dbID, $cq_def_db, @cq_db_lst) = @_;

   my $rc = 0;
   my $crid = 0;

   if (length $dbID) {
      ## 0-pad the dbid upto 8 digits
      $dbID = sprintf("%08d", $dbID);
   
      ## Match the right character-case for the cqdb
      $cqdb ||= $cq_def_db;
      my @matches = grep { (lc $_) eq (lc $cqdb) } @cq_db_lst;
      if (@matches == 1) {
         $cqdb = shift @matches;
      }
      else {
         $rc = 1;
      }
   }
   else{
      $rc = 1;
   }

   return ($rc, $cqdb, $dbID);
}

#################################################################

=head1 NAME

ParseCrId -- Gets the ClearQuest database name and number from a CR ID.

=head1 SYNOPSIS

 ParseCrId($crid)

 where
     $crid      -  ClearQuest CR ID.                        


=head1 DESCRIPTION

Gets the database name and number from a CR ID.

=head1 RETURN VALUES

 Returns 0 and the ClearQuest database name and number on success.
 Returns 1 on failure.                


=cut

#################################################################
sub ParseCrId {

   my $crid = shift @_;
   my $rc = 0;
   my ($cqdb, $crnum);

   if ( $crid =~ /^([A-Za-z]\w*[A-Za-z])?(\d+)$/){
      ($cqdb, $crnum) = ($1, $2);
   }
   else{
      $rc = 1;
   }

   return($rc, $cqdb, $crnum);
}


#########################################################################

=item B<FormatCrId>

Take a crid and output it in proper canonical format with
correct database name and character case and leading zeros.
Takes a $crid as its argument, and returns the list ($rc, $crid)
where $rc is 0 for success and non-zero otherwise.

=cut

sub FormatCrId ($) {
  my $crid = shift;
  my ($rc, $cqdb, $crnum) = ParseCrId($crid);

  # This part of the code is required to Create the CR ID in
  # correct format if user does not have it in correct format
  unless($rc){
    ($rc, $cqdb, $crnum) = GenerateCrId($cqdb,$crnum,$::CQ_DEF_DB, @::CQ_DB_LST);
    $crid = $cqdb.$crnum  unless($rc);
  }

  return ($rc, $crid);
}

#########################################################################

=head1 NAME

IsValidCR -- Validates a CR number

=head1 SYNOPSIS

 IsValidCR($cq_comm_mode, $crid, $cq_def_db, @cq_db_lst)

 where
     $cq_comm_mode -  Mode of communication with CQ (WEB or COM)
     $crid         -  ClearQuest CR ID.                        
     $cq_def_db    -  Default CQ database for the product
     @cq_db_lst    -  List of valid CQ databases for the product

=head1 DESCRIPTION

Gets the database name and number from a CR ID.  $cq_comm-mode is
currently assumed to be via the WEB.  It is reserved for future
use when communication could be via COM component or via the WEB.
It queries ClearQuest via the WEB server and gets a list of CRs that
are assigned to the user.  It then checks if the CR exists in the
list of CRs.  If so, it returns 1.

=head1 RETURN VALUES

 Returns ($rc, $crid)
 where 
     $rc is CQ_VALID_CR if the CR is valid
     $crid    contains the CR ID
   
=cut

#################################################################
sub IsValidCR {
   my ($cq_comm_mode, $crid, $cq_def_db, @cq_db_lst) = @_;
	dprint "INTO IsValidCR\n";
   
   my ($rc, $cqdb, $crnum) = ParseCrId($crid);
   if ($rc){
      display_msg("Error: Invalid CR ID format. ", 1);
      return(CQ_INVALID_CR, '');
   }

   my ($new_cqdb, $new_crnum);
   ($rc, $new_cqdb, $new_crnum) = GenerateCrId($cqdb, $crnum, $cq_def_db, @cq_db_lst);
   if ($rc){
      display_msg("Error: Crid $crid does not contain a valid CQ database name\n", 1);
      return(CQ_INVALID_CR, '');
   }
   my $new_crid = $new_cqdb . $new_crnum;
   
   my @crlist;
   $CQ_WEB_PARAMS{'cqdb'} = $new_cqdb;
   ($rc, @crlist) = PerformQuery_CQWeb();
   if ($rc != CMBP_SUCCESS){
      return($rc, '');
   }
   elsif (!(scalar(@crlist))) {
      display_msg("Warning: Query returned no CRs for user $CQ_WEB_PARAMS{'cquser'}.\n");
      return(CQ_INVALID_CR, '');
   }
	
   my @result = grep(/$new_crid/, @crlist);
   if ($#result < 0) {
      display_msg("\nError: CR $crid either not assigned to you '$CQ_WEB_PARAMS{'cquser'}' or not in Assigned state, or an invalid CR number!\n", 1);
      return(CQ_INVALID_CR, '');
   }

   return(CQ_VALID_CR, $new_crid);
}

####################################################################################3

=head1 NAME

GetCrId -- Prompt for the CR ID and check if the CR exists in the list of CRs obtained from querying ClearQuest with %CQ_QUERY_FILTER.

=head1 SYNOPSIS

 GetCrId($comm_mode, $prompt, $helpmsg,$cq_def_db, @cq_db_lst)

 where
    $comm_mode -  Mode of communication with ClearQuest.  
                  Is "WEB" for communication via the WEB server
    $prompt    -  Text used to prompt the user
    $helpmsg   -  Text when user asks for help
    $cq_def_db -  Default CQ database for the product
    @cq_db_lst -  List of CQ databases for the product.


=head1 DESCRIPTION

  A ClearQuest CR ID is of the form <CQDB><CRNUM> where
  <CQDB> is the ClearQuest Database Name and <CRNUM> is
  is a 8-digit number.

  This function prompts for the CR ID

  The user has the following options:

  1.  The user can enter "0" or click on 'Cancel'
      In this case, the function returns 1. 

  2.  The user can enter "?" 
      In this case, the help message is displayed.

  3.  The user can enter "*"
      In this case, ShowValidCrSet is called to display a list of
      CRs in $cq_def_db Database.

  4.  The user can enter "<CQDB*>",  where <CQDB> is the
      ClearQuest database name.
      In this case, the function checks if <CQDB> is defined 
      in the list of databases in @cq_db_lst.  If so, it calls
      ShowValidCrSet to display a list of CRs in <CQDB>.
      If <CQDB> is not defined in @cq_db_lst, the function
      will display an error message and re-prompt for the CR ID.

  5.  The user can choose to enter just <CRNUM>.  The user can
      enter the <CRNUM> by dropping off the leading zeros.
      The function will then generate the CRID by adding the 
      required leading zeros to <CRNUM> and prefixing it with 
      $cq_def_db.  The function will then call IsValidCR to check
      if the CR is valid. If the CR is not valid, it will re-prompt
      for the CR ID.

  6.  If the user enters a ClearQuest Database name and a number,
      the function will check if the Database name is defined in
      @cq_db_lst.  The function will call IsValidCR to check if
      the CR is valid.  If the CR is not valid, it will re-prompt 
      for the CR ID. 

  7.  For all other cases, it will display an error message and
      re-prompt the CR number.


=head1 RETURN VALUES

 Returns 0 and the CRID on success.
 Returns 1 on failure.


=cut

#################################################################
sub GetCrId {
    my ($comm_mode, $prompt, $help_msg, $cq_def_db, @cq_db_lst) = @_;
    my ($rc, $cr_list, $crnum, $crid, $db, $retcode);
    my $done = 0;
    my $text_msg;
    my @buglist;


    while (not $done){
      ($rc, $cr_list) = get_text({'-name' => 'CRID'}, $prompt);

      @buglist = split(" ", $cr_list);
      if ($rc != 0 ){
         $retcode = CMBP_FAIL;
         $done = 1;
      }
      elsif (not length($cr_list)){
         display_msg("You did not enter a valid CR Id\n");
      }
      elsif ( $buglist[0] eq "0"){
         $done = 1;
         $retcode = CMBP_FAIL;
      }
      elsif ( $buglist[0] eq "?"){
         display_msg($help_msg,3);
      }
      elsif (@buglist > 1){
         display_msg("You cannot enter more than one CR number\n");
      }
     elsif ($buglist[0] =~ m/\*/) {  
         if ($buglist[0] =~ m/^([A-Za-z]{1,5})\*/) { 
            $db = $1;
            my @result = grep(/$db/, @cq_db_lst);
            if ($#result < 0) {
               display_msg("Error: CQ database $db is not defined in " .
                      "the list of available databases for the product" .
                      "Please re-enter\n");
            }
            else{
               ($retcode, $crid) = ShowValidCrSet($comm_mode, $db);
               $done = 1;
            }
         } else { 
            $db = $cq_def_db;
            ($retcode, $crid) = ShowValidCrSet($comm_mode, $db);
            $done = 1;
         } 
     }
     elsif (($buglist[0] =~ m/([A-Za-z]{1,5})(\d{1,8})/)){
           $db    = $1;
           $crnum = $2;
           $crid = $db . $crnum;
           ($rc, $crid) = IsValidCR($comm_mode, $crid, $cq_def_db, @cq_db_lst);
           $done = 1 unless ($rc == CQ_INVALID_CR);
           if ($rc == CQ_VALID_CR){
              $retcode = CMBP_SUCCESS;
           }
           else{
              $retcode = CMBP_FAIL;
           }
     }
     elsif ($buglist[0] =~ m/^(\d{1,8})$/){
           $db = $cq_def_db;
           $crnum = $1;
           $crid = $db . $crnum;
           ($rc, $crid) = IsValidCR($comm_mode, $crid, $cq_def_db, @cq_db_lst);
           $done = 1 unless ($rc == CQ_INVALID_CR);
           if ($rc == CQ_VALID_CR){
              $retcode = CMBP_SUCCESS;
           }
           else{
              $retcode = CMBP_FAIL;
           }
     }
     else {
          display_msg("You have entered an invalid CR number. " .
                 "CR number should be of the form: \n");
          display_msg($help_msg,3);
      }
   }

   return ($retcode, $crid);
}

#################################################################

=head1 NAME

ShowValidCrSet -- Presents a list of all assigned CRs for a given ClearQuest user, password and database.

=head1 SYNOPSIS

 ShowValidCrSet($comm_mode, $db)

 where 

 $comm_mode - Mode of communication with ClearQuest.  
              Is "WEB" for WEB server communication.
 $db        - ClearQuest database


=head1 DESCRIPTION

Calls PerformQuery_CQWeb() to query $db database.  PerformQuery_CQWeb uses %CQ_QUERY_FILTER as filter to the CQ query.  It displays the list of CRs returned from PerformQuery_CQWeb and prompts the user to select from the list.

=head1 RETURN VALUES

 Returns CMBP_SUCCESS and the CRID on success.
 Returns CMBP_FAIL on failure.


=cut

#################################################################
sub ShowValidCrSet{
    my ($comm_mode, $db) = @_;
    my ($crid, @rest_of_sel);
    my $done = 0;

   $CQ_WEB_PARAMS{'cqdb'} = $db;
   my ($rc, @crlist) = PerformQuery_CQWeb();
   if ($rc != CMBP_SUCCESS){
      display_msg("Error: Query failed!!! \n", 1);
      return (CMBP_FAIL, '');
   }
   elsif (!(scalar(@crlist))) {
      display_msg("Warning: Query returned no CRs for user $CQ_WEB_PARAMS{'cquser'}.\n",2);
      return (CMBP_FAIL, '');
   }

    my $items = join ",", @crlist;
    my $selection;

    while (not $done){
      ($rc, $selection) = get_selection({'-name' => 'CRID_SELECTION'}, 
                                     "$items", "Select from list of CRs");
      if ( $rc ){
         return(CMBP_FAIL, $crid);
      }
      elsif (not length($selection)){
         display_msg("You have not selected a CR from the list\n");
      }
      else{
         ($crid, @rest_of_sel) = split (" ", $selection);
         $done = 1;
      }  
    }

    return ($rc, $crid);
}

####################################################################################

sub AuthorizedCR {
   my ($crid, $cq_rec_type,$cq_def_db, @cq_db_lst) =@_;
   my $cq_comm_mode = "WEB";
   my $i;
   my $fallout=0;

   if($::SERVERCQWEB)
   {
       for($i=0;$i<1;++$i)
       {
	   my( $cq ) = CQCCIntegration::Session->new();
	   if(!$cq)
	   {
	       $fallout = 1;
	       last;
	   }

	   my ($rc, $cquser, $cqpwd) = GetLogonParms();
	   my( $result ) = $cq->xquery( record      => 'Development_CR',
				       id          => $crid,
				       fields      => 'state,technical_authority' );
	   unless($result)
           {
               $fallout = 1;
               last;
           }


	   my( %stuff ) = $cq->getResults();
       
	   if($stuff{technical_authority} =~ m/$cquser~/)
	   {
	       return 0;
	   }
	   return 1;
       }
   }

   if(!$::SERVERCQWEB || $fallout == 1)
   {
       my $rc = CQ_QUERY_FAIL;
       $rc = PopulateCQWebParams($ENV{CQCC_SERVER}, $ENV{CQCC_SERVERROOT}, $cq_rec_type) if not length($CQ_WEB_PARAMS{'cquser'});
       dprint ("Returning rc= $rc from PopulateCQweb sub \n");
       return CQ_INVALID_CR if ($rc == CMBP_FAIL);

       ($rc, $crid) = IsValidCR($cq_comm_mode, $crid, $cq_def_db, @cq_db_lst);
       dprint ("Returning rc= $rc from AuthorizedCR sub \n");
       return $rc;
   }
}
##################################################################################

sub GetAssignedCR{
    my %opts = ();

    my ($cq_rec_type, $cq_def_db, @cq_db_lst);
    ## See if first arg was a hash ref
    if (ref($_[0]) eq 'HASH'){
       ## It is, record the options
       local $_ = shift @_;
       %opts = %$_;
    }

    ($cq_rec_type, $cq_def_db, @cq_db_lst) = @_;
  
    my $prompt = "Enter ClearQuest CR ID ('?'=help, '*'=my open CRs,";
    if ( ! defined $opts{'-abort'} or ! $opts{'-abort'} ){
       $prompt .= " 0 = Ignore): \n";
    }
    else {
       $prompt .= " 0 = Abort): \n";
    }

    my $helpmsg = "Enter the ID of the ClearQuest CR to associate with this ClearCase operation.\n" .
    "You may enter a full CR number or drop the leading zeros, like this: '<DBID>23'\n" .
    "If you do not specify <DBID>, it will default to $cq_def_db.\n" .
    "Entering '?' will produce this message.\n";

    $prompt .=
    "Entering '*' (asterisk) will query ClearQuest database $cq_def_db\n" .
    "for a list of CRs in the 'Assigned' state and for which you are\n" .
    "the TA.  You can specify a different ClearQuest database as: '<CQDB>*'.\n" ;
    $_ = $opts{'-helpmsg'};
    if (length and ! /^\d+$/){
       $helpmsg .= $_; 
    }
    
    my $cq_comm_mode = "WEB";

    my ($rc, $crid);

    $rc = PopulateCQWebParams($ENV{CQCC_SERVER}, $ENV{CQCC_SERVERROOT}, $cq_rec_type) if not length($CQ_WEB_PARAMS{'cquser'});
    return 1 if $rc;

    ($rc, $crid) = GetCrId($cq_comm_mode,$prompt,$helpmsg,$cq_def_db,@cq_db_lst);
    return($rc, $crid);
};

#################################################################

=head1 NAME

LogCset -- Log ClearCase Change set in ClearQuest

=head1 SYNOPSIS

 LogCset($cc_object, $crid)

 where

 $cc_object - $ENV{CLEARCASE_BRTYPE} for post-mkbrtype,
              $ENV{CLEARCASE_PN} for post-checkout,
              $ENV{CLEARCASE_XPN} for pre-checkin
 $crid -  ClearQuest CRID


=head1 DESCRIPTION

 1.  Call ParseCrId() to get the ClearQuest database name from $crid
 2.  Call GetUidOid() to get the VOB's oid and
     the cc_object's oid.
 3.  Since the communication with ClearQuest is via the WEB server, it
     populates %CQ_WEB_PARAMS by calling PopulateCQWebParams.
 4.  Call LogCset_CQWeb to write the change set to the CR in ClearQuest
     via the WEB.


=head1 RETURN VALUES

0 on success
1 on failure

=cut

#################################################################
sub LogCset {
    my ($cc_object, $crid,$cvalue) = @_;
    my @crlist;


    my ($rc, $cqdb, $crnum) = ParseCrId($crid);
    if ($rc){
      display_msg("Error: Invalid CR ID format.", 1);
      return 0;
    }

    my ($uuid, $oid);
    ($rc, $uuid, $oid) = GetUidOid($cc_object,$cvalue);
    return 1 if $rc;

    $rc = PopulateCQWebParams($ENV{CQCC_SERVER}, $ENV{CQCC_SERVERROOT}, $::CQ_REC_TYPE) if not length($CQ_WEB_PARAMS{'cquser'});
    return 1 if $rc;

    my $VOstr;
	if ( length($cvalue) ) {
		##if using oid, will have different oid if the brtype
		##is removed and re-created, then multiple entries 
		##will be created in CQ cc_change_set
		##remove the vob path if attached
		$cc_object =~ s/\@.*$//;
    	$VOstr = url_encode("$uuid\001$cc_object\001$cvalue");
    	#$VOstr = url_encode("$uuid\001$oid\001$cvalue");
	} else {
    	$VOstr = url_encode("$uuid\001$oid\001$cc_object");
	}

    $CQ_WEB_PARAMS{'cqdb'} = $cqdb;
    $CQ_WEB_PARAMS{'volist'} = $VOstr;

    return(LogCset_CQWeb($crid));
}

#################################################################

=head1 NAME

MVCsetLog -- Log ClearCase Change set in different vob setup

=head1 SYNOPSIS

 MVCsetLog($cc_object, $crid,$cvalue)

 where

 $cc_object - brtype name
 $crid -  ClearQuest CRID
 $cvaule - WORK_STARTED/WORK_COMPLETED/BRTYPE_DELETED


=head1 DESCRIPTION

 1.  get the vob location where the trigger was fired
 2.  get the admin vob location associated with the vob if any
 3.  determin what vob will be used for logging the cset


=head1 RETURN VALUES

0 on success
1 on failure

=cut

#################################################################
sub MVCsetLog {

    my ($brtype, $crid,$cvalue) = @_;

    my ($rc, $cqdb, $crnum) = ParseCrId($crid);
    if ($rc){
      display_msg("Error: Invalid CR ID format.", 1);
      return 0;
    }

	my $ivob;	##vob passed in with brtype

	if ( $brtype =~ s/\@(.*)\s*$// ) {
		$ivob = $1;
	}
	$brtype =~ s/^brtype://;

	my $cvob = $ENV{CLEARCASE_VOB_PN};	##the vob where the trigger was fired
	
	##use the paased-in vob
	$cvob = $ivob if ( ! $cvob && $ivob  );

	## the admin vob associated with the vob where the trigger was fired
	my $admVob = (qx{$CLEARTOOL describe -s -ahlink AdminVOB vob:$cvob})[0];
	## the vob whose uuid will be used for logcset
	my $pickedVob;	

	if ( $admVob =~ /^\s*->\s+(vob:.*)\s*$/ ) {#invoking vob is not a admvob
		$pickedVob = $1;
	} elsif ( $admVob =~ /^\s*<-\s+(vob:.*)\s*$/ ) {#itself a admvob
		$pickedVob = $cvob;
	} else { #no admin vob
		$pickedVob = $cvob;
	}

	$pickedVob =~ s/^vob://;

	#we don't care oid, error happened inside GetUidOid
	#GetUidOid use this variable
	$ENV{CLEARCASE_VOB_PN} = $pickedVob;

    my ($uuid, $oid);
    ($rc, $uuid, $oid) = GetUidOid($brtype,$cvalue);
    my $j;
    my $fallover=0;  # Flag to see if you should just fallover to the old way of querying....

    my $replicaname = getReplicaNameFromVob($pickedVob);
    if($replicaname eq "")
    {
	$replicaname = "original";
    }

    if($::SERVERCQWEB)
    {
	for($j=0; $j<1;++$j)
	{
	    # first checking if the uuid which is the key exist in the database.
	    my( $cq ) = CQCCIntegration::Session::Admin->new();
	    if(!$cq)
	    {
		$fallover=1;
		last;
	    }

	    my( $result ) = $cq->listquery( record      => 'cc_vob_object',
					   filters      => "vob_family_uuid|EQ|$uuid,object_oid|EQ|$brtype",
					   fields      =>  'object_oid,dbid' );

	    unless($result)
	    {
		$fallover=1;
		last;
	    }


	    my( %output ) = $cq->getResults();
	    if($ENV{CQCC_DEBUG})
	    {
		print "QUERY RESULT ->$output{object_oid}\n";
	    }

	    if($output{object_oid} ne "")
	    {
		# Object found in the db
		my( $_result ) = $cq->edit( record          => 'cc_vob_object',
					   name            => $cvalue,
					   replica_vob     => "$replicaname\@$pickedVob",
					   dbid            => $output{dbid} );
		unless( $_result )
		{
		    $fallover=1;
		    last;
		}

		$cq->getResults();

		#
		# Object exist ... but does it linked to the CR? If not will relink it...
		# 

		my( $result ) = $cq->xquery( record      => 'Development_CR',
					    id          => $crid,
					    fields      => 'cc_change_set.objects' );
		unless($result)
		{
		    $fallover = 1;
		    last;
		}

		my( %op ) = $cq->getResults();
		if($op{'cc_change_set.objects'} eq "")
		{
		    my $rc;
		    dprint "HOUSTON WE HAVE A PROBLEM ... CCCHANGESET EXIST BUT IT IS NOT LINKED .. WILL LINK NOW! \n";

		    relinkCStoCR($crid,$uuid,$brtype, \$rc);
		    if($rc != 0)
		    {
			## fail over and let it do it the old way.
			$fallover = 1;
			last;
		    }
		}
	    }
	    else
	    {
		# Object not found in the db

		my( $_result ) = $cq->create( record          => 'cc_vob_object',
					     name            => "$cvalue",
					     object_oid      => "$brtype",
					     replica_vob     => "$replicaname\@$pickedVob",
					     vob_family_uuid => "$uuid" );

		unless( $_result ){ 
		    $fallover=1;
		    last;
		}
		my( %createobj ) = $cq->getResults();
		my( $ccVobObj ) = $createobj{uid};

		unless( $ccVobObj )
                {
                    $fallover=1;
                    last;
                }

		# checking if the CR already has a cc_change_set_object
		my $ccChangeSet;

		$_result = $cq->xquery( record      => 'Development_CR',
				       id          => $crnum,
				       fields      => 'cc_change_set' );

		unless( $_result )
		{
		    $fallover=1;
		    last;
		}

		
		my( %cs ) = $cq->getResults();
		if($cs{cc_change_set} ne "")
		{
		    $ccChangeSet = $cs{cc_change_set};
		}
		else
		{
		    $_result = $cq->create( record          => 'cc_change_set' );
		    unless( $_result )
		    {
			$fallover=1;
			last;
		    }

		    %cs = $cq->getResults();
		    $ccChangeSet  = $cs{uid};
		    unless( $ccChangeSet )
		    {
			$fallover=1;
			last;
		    }
		}

		$_result  = $cq->edit( record          => 'CC_Change_Set',
				      dbid             => $ccChangeSet,
				      'objects'   => "$ccVobObj" );

		unless( $_result )
	        {
                    $fallover=1;
                    last;
                }

		my( %editoutput ) = $cq->getResults();
		$_result  = $cq->edit( record          => 'Development_CR',
				      id              => $crnum,
				      cc_change_set   => $ccChangeSet );

		unless( $_result )
                {
                    $fallover=1;
                    last;
                }

		#
		# Will verify the links went ok ...
		#
		dprint("Checking the links went ok .... \n");
		my( $result ) = $cq->xquery( record      => 'Development_CR',
					    id          => $crid,
					    fields      => 'cc_change_set.objects' );
		unless($result)
		{
		    $fallover = 1;
		    last;
		}
		
		
		
		my( %op ) = $cq->getResults();
		if($op{'cc_change_set.objects'} eq "")
		{
		    my $rc;
		    dprint "HOUSTON WE HAVE A PROBLEM ... CCCHANGESET EXIST BUT IT IS NOT LINKED .. WILL LINK NOW! \n";
		    
		    relinkCStoCR($crid,$uuid,$brtype,\$rc);

		    if($rc != 0)
		    {
			## fail over and let it do it the old way.
			$fallover = 1;
			last;
		    }
		}

	    } # end of else statment where object was not found.
	} # end of for loop
    }

    # Querying the old fashion way .... 
    if(!$::SERVERCQWEB || $fallover == 1)
    {
	if($ENV{CQCC_DEBUG})
	{
	    print "FALLOVER !!! \n";
	}

	$ENV{CLEARCASE_VOB_PN} = $cvob;
	return 1 if $rc;

	$rc = PopulateCQWebParams($ENV{CQCC_SERVER}, $ENV{CQCC_SERVERROOT}, $::CQ_REC_TYPE) if not length($CQ_WEB_PARAMS{'cquser'});
	return 1 if $rc;

	my $VOstr;
	if ( length($cvalue) ) {
	    ##if using oid, will have different oid if the brtype
	    ##is removed and re-created, then multiple entries 
	    ##will be created in CQ cc_change_set
	    ##remove the vob path if attached
	    $VOstr = url_encode("$uuid\001$brtype\001$cvalue");
	} else {
	    return 1;
	}

	$CQ_WEB_PARAMS{'cqdb'} = $cqdb;
	$CQ_WEB_PARAMS{'volist'} = $VOstr;

	return(LogCset_CQWeb($crid));
    }


    return 0;
}

#################################################################

=head1 NAME

UnLogCset -- UnLog ClearCase Change set in ClearQuest

=head1 SYNOPSIS

 UnLogCset($cc_object, $crid)

 where

 $cc_object - $ENV{CLEARCASE_BRTYPE} for post-mkbrtype,
              $ENV{CLEARCASE_PN} for post-checkout,
              $ENV{CLEARCASE_XPN} for pre-checkin
 $crid -  ClearQuest CRID


=head1 DESCRIPTION

 1.  Call ParseCrId() to get the ClearQuest database name from $crid
 2.  Call GetUidOid() to get the VOB's oid and
     the cc_object's oid.
 3.  Since the communication with ClearQuest is via the WEB server, it
     populates %CQ_WEB_PARAMS by calling PopulateCQWebParams.
 4.  Call UnLogCset_CQWeb to remove the change set from the CR in ClearQuest
     via the WEB.


=head1 RETURN VALUES

0 on success
1 on failure

=cut

#################################################################

sub UnLogCset {
    my ($cc_object, $crid) = @_;

    my ($rc, $cqdb, $crnum) = ParseCrId($crid);
    if ($rc){
      display_msg("Error: Invalid CR ID format. ", 1);
      return 0;
    }

    my ($uuid, $oid);
    ($rc, $uuid, $oid) = GetUidOid($cc_object);
    return 1 if $rc;


    $rc = PopulateCQWebParams($ENV{CQCC_SERVER}, $ENV{CQCC_SERVERROOT}, $::CQ_REC_TYPE) if not length($CQ_WEB_PARAMS{'cquser'});
    return 1 if $rc;
    $CQ_WEB_PARAMS{'cqdb'} = $cqdb;

    my $VOstr = url_encode("$uuid\001$oid\001$cc_object");
    $CQ_WEB_PARAMS{'volist'} = $VOstr;

    return(UnLogCset_CQWeb($crid));
}
##########################################################################
#Check if the IntCRID is valid
#Populate the hashes %CQ_QUERY_FILTER and %CQ_WEB_PARAMS
#IsValidCR($cq_comm_mode, $crid, $cq_def_db, @cq_db_lst);

sub CheckIsValidIntCR {

  my $rc = 0;
  my $int_cr = shift;
  my $valid_cr = $int_cr;

  read_configFile();
  PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
                      $::CQ_REC_TYPE);
  my $cq_comm_mode = "WEB";
  %CQ_QUERY_FILTER = ();
  %CQ_QUERY_FILTER = ( State  => ['eq', 'Assigned'] );

  ($rc, $valid_cr) = IsValidCR($cq_comm_mode, $int_cr,
                               $::CQ_DEF_DB, @::CQ_DB_LST);

  return ($rc, $valid_cr)}

# checks CQ if the given CR is in the assigned state;
sub CheckIsCRAssigned {

    my ($int_cr)  = @_;
    my $i;
    my $fallout=0;

    if($::SERVERCQWEB)
    {
	for($i=0;$i<1;++$i)
	{
	    my( $cq ) = CQCCIntegration::Session->new();
	    if(!$cq)
	    {
		$fallout = 1;
		last;
	    }


	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $int_cr,
					fields      => 'state' );

	    unless($result)
	    {
		$fallout = 1;
		last;
	    }


	    my( %output ) = $cq->getResults();
	
	    if($ENV{CQCC_DEBUG})
	    {
		print "STATE --> $output{'state'}\n";
	    }

	    if($output{'state'} =~ m/assigned/i)
	    {
		return 1;
	    }
    
	    return 0;
	}
    }
    
    if(!$::SERVERCQWEB || $fallout == 1)
    {
	my $rc = 0;
	read_configFile();
	PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
			    $::CQ_REC_TYPE);
	my $cq_comm_mode = "WEB";
	
	my $db = getCQDB($int_cr, \$rc);
	if($rc == CQ_INVALID_CR)
	{
	    return 0;
	}

	$CQ_WEB_PARAMS{cqdb} = $db;
	%CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = ( State  => ['eq', 'Assigned'] ,
			    id => ['eq', $int_cr]);
	
	@QUERIED_CRLIST = ();
	my @crlist = ();
	($rc, @crlist) = PerformQuery_CQWeb();
	
	if($rc != CQ_VALID_CR)
	{
	    return 0;
	}
	
	if($#crlist == -1)
	{
	    return 0;
	}

	return 1;
    }
}

# checks CQ if the given CR is in the performed state;
sub CheckIsCRPerformed {
    
    my ($int_cr, $rc)  = @_;
    my $i;
    my $fallout=0;
 

    if($::SERVERCQWEB)
    {
	for($i=0; $i<1;++$i)
	{
	    my( $cq ) = CQCCIntegration::Session->new();
	    if(!$cq)
	    {
		$fallout = 1;
		last;
	    }

	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $int_cr,
					fields      => 'state' );

	    unless($result)
	    {
		$fallout = 1;
		last;
	    }

	    my( %output ) = $cq->getResults();
	    
	    if($ENV{CQCC_DEBUG})
	    {
		print "STATE --> $output{'state'}\n";
	    }

	    if($output{'state'} =~ m/performed/i)
	    {
		return 1;
	    }
	    return 0;
	}
    }

    if(!$::SERVERCQWEB || $fallout == 1)
    {
	$$rc = 0;
	read_configFile();
	PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
			    $::CQ_REC_TYPE);
	my $cq_comm_mode = "WEB";

	my $db = getCQDB($int_cr, $rc);
	if($$rc == CQ_INVALID_CR)
	{
	    return 0;
	}

	$CQ_WEB_PARAMS{cqdb} = $db;
	%CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = ( State  => ['eq', 'Performed'] ,
			    id => ['eq', $int_cr]);

	@QUERIED_CRLIST = ();
	my @crlist = ();
	($$rc, @crlist) = PerformQuery_CQWeb();

	if($$rc != CQ_VALID_CR)
	{
	    return 0;
	}

	if($#crlist == -1)
	{
	    return 0;
	}

	return 1;
    }
}

# checks CQ if the given CR is in the closed state;
sub CheckIsCRClosed {
    
    my ($int_cr, $rc)  = @_;
    my $i;
    my $fallout=0;
 
    if($::SERVERCQWEB)
    {
	for($i=0; $i<1;++$i)
	{
	    my( $cq ) = CQCCIntegration::Session->new();
	    if(!$cq)
	    {
		$fallout = 1;
		last;
	    }

	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $int_cr,
					fields      => 'state' );

	    unless($result)
	    {
		$fallout = 1;
		last;
	    }

	    my( %output ) = $cq->getResults();
	    
	    if($ENV{CQCC_DEBUG})
	    {
		print "STATE --> $output{'state'}\n";
	    }

	    if($output{'state'} =~ m/Closed/i)
	    {
		return 1;
	    }
	    return 0;
	}
    }

    if(!$::SERVERCQWEB || $fallout == 1)
    {
	$$rc = 0;
	read_configFile();
	PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
			    $::CQ_REC_TYPE);
	my $cq_comm_mode = "WEB";

	my $db = getCQDB($int_cr, $rc);
	if($$rc == CQ_INVALID_CR)
	{
	    return 0;
	}

	$CQ_WEB_PARAMS{cqdb} = $db;
	%CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = ( State  => ['eq', 'Closed'] ,
			    id => ['eq', $int_cr]);

	@QUERIED_CRLIST = ();
	my @crlist = ();
	($$rc, @crlist) = PerformQuery_CQWeb();

	if($$rc != CQ_VALID_CR)
	{
	    return 0;
	}

	if($#crlist == -1)
	{
	    return 0;
	}

	return 1;
    }
}



# checks CQ if the given CR is in the performed state;
sub GetLinkedCRs {
    
    my ($int_cr, $rc)  = @_;
    my $i;
    my $fallout=0;

    $$rc = 0;

    if($::SERVERCQWEB)
    {
	for($i=0;$i<1;++$i)
	{
	    my( $cq ) = CQCCIntegration::Session->new();
	    if(!$cq)
	    {
		$fallout = 1;
		last;
	    }
	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $int_cr,
					fields      => 'Child_CRs' );
	    unless($result)
	    {
                $fallout = 1;
                last;
            }

	    my( %output ) = $cq->getResults();
	    if($ENV{CQCC_DEBUG})
	    {
		print "Parent=$int_cr;  ChildCRs --> $output{'Child_CRs'}\n";
	    }

	    my @crlist = split(",",$output{'Child_CRs'});			
	    return @crlist;
	}
    }

    if(!$::SERVERCQWEB || $fallout==1)
    {
	$$rc = 0;
	read_configFile();
	PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
			    $::CQ_REC_TYPE);
	my $cq_comm_mode = "WEB";

	my $db = getCQDB($int_cr, $rc);
	if($$rc == CQ_INVALID_CR)
	{
	    return ();
	}

	$CQ_WEB_PARAMS{cqdb} = $db;
	%CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = (Parent_CRs => ['eq', $int_cr]);

	@QUERIED_CRLIST = ();
	my @crlist;
	($$rc, @crlist) = PerformQuery_CQWeb();
	if($$rc != CQ_VALID_CR)
	{
	    return ();
	}

	my @crs;
	foreach(@crlist)
	{
	    push(@crs, (split(" ",$_))[0]);
	}

	return @crs;
    }
}

# gets all the parent CRs for the given CR number
sub GetParentLinkedCRs {
    
    my ($int_cr, $rc)  = @_;
    my $i;
    my $fallout=0;

    $$rc = 0;

    if($::SERVERCQWEB)
    {
	for($i=0;$i<1;++$i)
	{
	    my( $cq ) = CQCCIntegration::Session->new();
	    if(!$cq)
	    {
		$fallout = 1;
		last;
	    }
	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $int_cr,
					fields      => 'Parent_CRs' );
	    unless($result)
	    {
                $fallout = 1;
                last;
            }

	    my( %output ) = $cq->getResults();
	    dprint "ChildCRs=$int_cr;  ParentCRs --> $output{'Parent_CRs'}\n";

	    my @crlist = split(",",$output{'Parent_CRs'});			
	    return @crlist;
	}
    }

    if(!$::SERVERCQWEB || $fallout==1)
    {
	$$rc = 0;
	read_configFile();
	PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
			    $::CQ_REC_TYPE);
	my $cq_comm_mode = "WEB";

	my $db = getCQDB($int_cr, $rc);
	if($$rc == CQ_INVALID_CR)
	{
	    return ();
	}

	$CQ_WEB_PARAMS{cqdb} = $db;
	%CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = (Child_CRs => ['eq', $int_cr]);

	@QUERIED_CRLIST = ();
	my @crlist;
	($$rc, @crlist) = PerformQuery_CQWeb();
	if($$rc != CQ_VALID_CR)
	{
	    return ();
	}

	my @crs;
	foreach(@crlist)
	{
	    push(@crs, (split(" ",$_))[0]);
	}

	return @crs;
    }
}


#
# Function to otain the given CR's component ... the 'C' in SPCF...
#
sub getCRComponent
{
    my ($crnum,$rc) = @_;
    my $i;
    my $fallout=0;

    $$rc = 0;

    #
    # Padding the crid with 0's and placing the DB name if needed.
    #

    my $dbname;
    my $number;
    if($crnum =~ /^([a-zA-Z]+)(\d+)$/)
    {
        $dbname = $1;
        $number = $2;
	
        if($dbname !~ m/$::CQ_DEF_DB/i)
        {
            dprint("DBNAME $dbname is not default DB: $::CQ_DEF_DB\n");
	    $$rc = CQ_INVALID_CR;
            return ();
        }

        $crnum = sprintf("%s%08d",$::CQ_DEF_DB,$number);
    }
    elsif($crnum =~ /^(\d*)$/)
    {
        $number = $1;
        $crnum = sprintf("%s%08d",$::CQ_DEF_DB,$number);
    }
    else
    {
        $$rc = CQ_INVALID_CR;
        return ();  # Invalid CR given in the parameters.
    }

    dprint("crnumber = $crnum \n");

    my $comp;
    if($::SERVERCQWEB)
    {
	for($i=0;$i<1;++$i)
	{
	    # need to get the component of the CR...
	    my( $cqSession ) = CQCCIntegration::Session->new(); 
	    if(!$cqSession)
	    {
		$fallout=1;
		last;
	    }


	    my ( $result ) = $cqSession->xquery( record      => 'Development_CR',
						id          => $crnum,
						fields      => 'CI_Component' );

	    unless($result)
	    {
		$fallout=1;
		last;
	    }

	    my %output = $cqSession->getResults();
	    $comp = $output{CI_Component};
	}
    }

    if(!$::SERVERCQWEB || $fallout==1)
    {
	read_configFile();
	PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
			    $::CQ_REC_TYPE);
	my $cq_comm_mode = "WEB";
	
	$CQ_WEB_PARAMS{cqdb} = $::CQ_DEF_DB;
	%CQ_QUERY_FILTER = ();
	
	%CQ_QUERY_FILTER = (id => ['eq', $crnum]);
	@CQ_QUERY_FIELDS = qw(CI_Component);

	my @crlist=();
	($rc, @crlist) = PerformQuery_CQWeb();

	$comp = $crlist[0];
	$comp =~ s/^\s*//;
	$comp =~ s/\s*$//;
    }

    #
    # Getting rid of the namespace in the component name.
    #

    $comp =~ s/:.*$//;
    return $comp;
}


#
# Function to get the given CR's information:
#
# Assumes that two arguments are passed:
#
#  1) CRid (e.g. INDEV00066612)
#  2) Reference to a hash in which the CR query results will be returned
#         - the CR fields that will be queried in CQ will be the hash keys
#           that are currently set.
#         - the query results will be set in the values for each 
#           corresponding field name key
#
# Returns 0 upon success
#         1 upon failure
#
sub getCRInfo
{
        my $crid = shift;
	my ( $query_resultRef ) = shift ;

	my $fields = "";

	dprint ("In getCRInfo...  crid=$crid\n");
        if($::SERVERCQWEB)
        {
		my( $cq ) = CQCCIntegration::Session->new();
		if(!$cq)
		{
			return (1);
		}

		# Get query field list from list of valid keys in hash
		# This field list should be comma separated
		# Example: "CI_Component,State,Technical_Authority"
		my @field_keys = keys %$query_resultRef;
		if (! (scalar(@field_keys)) )
		{
			return (1);
		} 

		$fields = join (',',@field_keys);
		dprint ("Field list passed to CQ=$fields\n");

		my ($result) = $cq->xquery(record  => 'Development_CR',
					   id      => $crid,
					   fields  => "$fields" );

		unless($result)
		{
			return (1);
		}


		my( %output ) = $cq->getResults();

		foreach ( keys %output ) {
			dprint ( "key $_ = $output{$_}\n");
			$$query_resultRef{$_} = $output{$_};
		}
		return 0;
        }
	return (1);
}


# 
# Function to obtain the all the CR linked to a given baseline record.
#

sub getBaseLineRecord
{
    my ($baselinerecord, $rc)  = @_;
    my @crlist;
    my $i;
    my $fallout=0;

    if($::SERVERCQWEB)
    {
	for($i=0;$i<1;++$i)
	{
	    my( $cqSession ) = CQCCIntegration::Session->new();
	    if(!$cqSession)
	    {
		$fallout=1;
		last;
	    }
	
	    my( $result ) = $cqSession->listquery( record      => 'Development_CR',
						  filters     => "BL_Actual_Target.Name|EQ|$baselinerecord",
						  fields     => 'id' );
	    unless($result)
	    {
		$fallout=1;
		last;
	    }

	    my %op =  $cqSession->getResults();
	    @crlist	= split(/\,/, $op{id});
	}
    }

    if(!$::SERVERCQWEB || $fallout==1)
    {

	$$rc = 0;
	read_configFile();
	PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
			    $::CQ_REC_TYPE);
	my $cq_comm_mode = "WEB";
	
	$CQ_WEB_PARAMS{cqdb} = $::CQ_DEF_DB;
	%CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = (BL_Actual_Target => ['eq', $baselinerecord]);

	@QUERIED_CRLIST = ();
	my @fields = qw/id headline/;
	($$rc, @crlist) = Query_CQWeb(\@fields);
	if($$rc != CQ_VALID_CR)
	{
	    return ();
	}
    }

    return @crlist;
}


#
# Function to obtain the branch names for the given CR. The branch names is store in CQ.
#
sub getBranchTypeFromCR
{
    my($crid , $rc) = @_;
    $$rc = 0;
    my @crlist = ();
    my $deletedBranch = "BRTYPE_";
    my $i;
    my $falloff = 0;

    #
    # Padding the crid with 0's and placing the DB name if needed.
    #

    my $dbname;
    my $number;
    if($crid =~ /^([a-zA-Z]+)(\d+)$/)
    {
        $dbname = $1;
        $number = $2;

        if($dbname =~ m/"$::CQ_DEF_DB"/i)
        {
            dprint("DBNAME $dbname is not default DB: $::CQ_DEF_DB\n");
	    $$rc = CQ_INVALID_CR;
            return ();
        }

        $crid = sprintf("%s%08d",$::CQ_DEF_DB,$number);
    }
    elsif($crid =~ /^(\d*)$/)
    {
        $number = $1;
        $crid = sprintf("%s%08d",$::CQ_DEF_DB,$number);
    }
    else
    {
        $$rc = CQ_INVALID_CR;
        return ();  # Invalid CR given in the parameters.
    }

    dprint("CRID = $crid\n");


    if($::SERVERCQWEB)
    {
	for($i=0;$i<1; $i++)
	{
	    my( $cq ) = CQCCIntegration::Session->new();
	    if(!$cq)
	    {
		$falloff = 1;
		last;
	    }
	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $crid,
					fields      => 'cc_change_set.objects' );

	    unless($result)
	    {
		$falloff = 1;
		last;
	    }

	    my( %op ) = $cq->getResults();
	    my @cset = split(/\,/,$op{'cc_change_set.objects'});

	    my $j=0;
	    foreach(@cset)
	    {
		my $status;
		my $oid;
		my $branch;

		($oid,$status) = split(/\s/);
		
		$cq =  CQCCIntegration::Session->new();
		$result  = $cq->listquery( record      => 'cc_vob_object',
					  filters      => "dbid|EQ|$oid",
					  fields      =>  'object_oid' );

		%op = $cq->getResults();

		# ignoring brtype that have been deleted !! 
		if($status !~ m/$deletedBranch/)
		{
		    $crlist[$j++] = $op{'object_oid'};
		}
	    }
	}
    }

    if(!$::SERVERCQWEB || $falloff == 1) 
    {
	read_configFile();
	PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
			    $::CQ_REC_TYPE);
	my $cq_comm_mode = "WEB";

	my $db = getCQDB($crid, $rc);
	if($$rc == CQ_INVALID_CR)
	{
	    return ();
	}
	
	$CQ_WEB_PARAMS{cqdb} = $db;
	%CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = ( id => ['eq', $crid]);

	@QUERIED_CRLIST = ();
	my @fieldList = qw/cc_change_set.objects.object_oid cc_change_set.objects.name/;
	my @queryoutput;
	my $branchname;
	my $i=0;

	($$rc, @queryoutput) = Query_CQWeb(\@fieldList);
	if($$rc != CQ_VALID_CR)
	{
	    return ();
	}

	foreach (@queryoutput)
	{
	    if(!m/$deletedBranch/)
	    {
		($branchname) = (split(/\s/))[0];
		$crlist[$i++] = $branchname;
	    }
	}
    }

    if($#crlist == -1)
    {
	return ();
    }
    elsif($#crlist == 0 && $crlist[0] =~ /^\s*$/) # if only returns white space .... 
    {
	return ();
    }

    return @crlist;
}

sub IsAltMainReleaseforCR{
	my $crid = shift;
	my ($rel,$loadline) = ('','');
	my $rc;

	($rc, $rel,$loadline) = GetReleaseLoadlineforCR($crid);
	my $validRelease = getReleaseIDs();

	dprint ("Returned RC=$rc from GetReleaseloadline sub\n");
	if($rc == CQ_LOGIN_FAIL || $rc == CQ_QUERY_FAIL) {
		return ($rc, '','');
	}

	if(!$rel || ($rel and $$validRelease{$rel} eq 'main')) {
		$rc=0;
	}else{
		$rc=1;
	}
	return ($rc, $rel, $loadline);
}

sub GetReleaseLoadlineforCR {
    
    my $crid  = shift;
	read_configFile();
	return (0,'','')  unless ($::CQCC_INTEGRATION_ENABLED);
	my ($rc, $cqdb, $crnum) = ParseCrId($crid);
	unless($rc){
		my $cnt = $crnum =~ tr/0-9//;
		if($cnt < 8) {
			($rc, $cqdb, $crnum) = GenerateCrId($cqdb,$crnum,$::CQ_DEF_DB, @::CQ_DB_LST);
			$crid = $cqdb.$crnum unless($rc);
		}
	}
    

    #######
    #
    #  Getting the Predicted_Release and Loadline.
    # 
    #######
    my($rel);
    my($loadline);
    my $i;
    my $falloff=0;
    if($::SERVERCQWEB)
    {
	for($i=0;$i<1;$i++)
	{
	    use CQCCIntegration::Session;

	    my( $cqSession ) = CQCCIntegration::Session->new();
	    if(!$cqSession)
	    {
		$falloff = 1;
		last;
	    }

	    my( $result ) = $cqSession->xquery( record      => 'Development_CR',
					       id          => $crid,
					       fields      => 'Proj_Predicted_Release.Name,Loadline');

	    unless($result)
	    {
		$falloff = 1;
		last;    
	    }

	    my( %output ) = $cqSession->getResults();
	    if($result != 1)
	    {
		return(CQ_QUERY_FAIL,'','');
	    }

	    $rel = $output{'Proj_Predicted_Release.Name'};
	    $loadline = $output{'Loadline'};
	}
    }

    if(!$::SERVERCQWEB || $falloff == 1) 
    {
	$rc = PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
				  $::CQ_REC_TYPE);
	return ($rc, '', '') if($rc);

        my $cq_comm_mode = "WEB";

	$CQ_WEB_PARAMS{cqdb} = $cqdb;
        @CQ_QUERY_FIELDS=();
	%CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = (id => ['eq', $crid]);
        @CQ_QUERY_FIELDS = qw(Proj_Predicted_Release.Name Loadline);
	@QUERIED_CRLIST = ();
	my @crlist=();
	($rc, @crlist) = PerformQuery_CQWeb();

        # reseting the filters and fields back to original values
        @QUERIED_CRLIST = ();
        %CQ_QUERY_FILTER = ();
    %CQ_QUERY_FILTER = ( Technical_Authority  => ['like','[CURRENT_USER]~'],
			State             => ['eq','Assigned']);
        @CQ_QUERY_FIELDS = qw(id headline);

	dprint ("mkview", "output from loadline query .. oldway .. -> $crlist[0]\n");
	($rel, $loadline) = split(/\s+/,$crlist[0]);
	dprint ("mkview", "rel=$rel loadline=$loadline\n");
        if($rc != CQ_VALID_CR)
	{
	    return ($rc, '', '');
	}
        chomp($rel, $loadline);
    }

    if(!$::ALLOWRELEASEALPHANUMERIC)
    {
	dprint("NO ALPHA LETTERS IN RELEASE NAME\n");
	if($rel =~ /(\d+(\.\d+)*)/) {
	    $rel = "r".$1;
	}
    }
    else
    {
	dprint("ALLOW ALPHA LETTERS IN RELEASE NAME\n");
	if($rel =~ /^\D*(.*)/)
	{
	    $rel = "r".$1;
	}

	$rel = lc($rel);
    }
    
    dprint("Releaseid = $rel \n");
    $loadline = uc $loadline;
    return ($rc, $rel, $loadline);
}

#
# Function to get CR fields (Release, Loadline, Target_Type, CR Usage)
#
sub GetRelLLTTCRUforCR {

    dprint (1,"Into GetRelLLTTCRUforCR....\n");
    my $crid  = shift;
	read_configFile();
	return (0,'','','','')  unless ($::CQCC_INTEGRATION_ENABLED);
	my ($rc, $cqdb, $crnum) = ParseCrId($crid);
	unless($rc){
		my $cnt = $crnum =~ tr/0-9//;
		if($cnt < 8) {
			($rc, $cqdb, $crnum) = GenerateCrId($cqdb,$crnum,$::CQ_DEF_DB, @::CQ_DB_LST);
			$crid = $cqdb.$crnum unless($rc);
		}
	}

    #######
    #
    #  Getting the Predicted_Release, Loadline, Target_Type, CR_Usage
    # 
    #######
    my($rel);
    my($loadline);
    my($targettype);
    my($crusage);
    my $i;
    my $falloff=0;
    if($::SERVERCQWEB)
    {
	for($i=0;$i<1;$i++)
	{
	    use CQCCIntegration::Session;

	    my( $cqSession ) = CQCCIntegration::Session->new();
	    if(!$cqSession)
	    {
		$falloff = 1;
		last;
	    }

	    my( $result ) = $cqSession->xquery( record      => 'Development_CR',
					       id          => $crid,
					       fields      => 'Proj_Predicted_Release.Name,Loadline,Target_Type,CR_Usage');

	    unless($result)
	    {
		$falloff = 1;
		last;    
	    }

	    my( %output ) = $cqSession->getResults();
	    if($result != 1)
	    {
		return(CQ_QUERY_FAIL,'','','','');
	    }

	    $rel = $output{'Proj_Predicted_Release.Name'};
	    $loadline = $output{'Loadline'};
	    $targettype = $output{'Target_Type'};
	    $crusage = $output{'CR_Usage'};
	}
    }

    # Old way... Need to Query CQ TWICE because Loadline and Target Type are not Mandatory fields and may be empty
    if(!$::SERVERCQWEB || $falloff == 1) 
    {
	$rc = PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
				  $::CQ_REC_TYPE);
	return ($rc, '', '', '', '') if($rc);

        my $cq_comm_mode = "WEB";

	$CQ_WEB_PARAMS{cqdb} = $cqdb;
        @CQ_QUERY_FIELDS=();
	%CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = (id => ['eq', $crid]);
        @CQ_QUERY_FIELDS = qw(Proj_Predicted_Release.Name Loadline);
	@QUERIED_CRLIST = ();
	my @crlist=();
	($rc, @crlist) = PerformQuery_CQWeb();

	# 2nd Query to get CR_Usage and Target_Type
	%CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = (id => ['eq', $crid]);
        @CQ_QUERY_FIELDS = qw(CR_Usage Target_Type);
	@QUERIED_CRLIST = ();
	my @crlist2=();
	my $rc2="";
	($rc2, @crlist2) = PerformQuery_CQWeb();

        # reseting the filters and fields back to original values
        @QUERIED_CRLIST = ();
        %CQ_QUERY_FILTER = ();
    %CQ_QUERY_FILTER = ( Technical_Authority  => ['like','[CURRENT_USER]~'],
			State             => ['eq','Assigned']);
        @CQ_QUERY_FIELDS = qw(id headline);

	dprint (1, "output from loadline query .. oldway .. -> $crlist[0]\n");
	($rel, $loadline) = split(/\s+/,$crlist[0]);
	($crusage, $targettype) = split(/\s+/,$crlist2[0]);
	dprint (1, "rel=$rel loadline=$loadline\n");
	dprint (1, "crusage=$crusage targettype=$targettype\n");
        if($rc != CQ_VALID_CR)
	{
	    return ($rc, '', '', '', '');
	}
        if($rc2 != CQ_VALID_CR)
	{
	    return ($rc2, '', '', '', '');
	}
        chomp($rel, $loadline, $crusage, $targettype);
    }

    if(!$::ALLOWRELEASEALPHANUMERIC)
    {
	dprint("NO ALPHA LETTERS IN RELEASE NAME\n");
	if($rel =~ /(\d+(\.\d+)*)/) {
	    $rel = "r".$1;
	}
    }
    else
    {
	dprint("ALLOW ALPHA LETTERS IN RELEASE NAME\n");
	if($rel =~ /^\D*(.*)/)
	{
	    $rel = "r".$1;
	}

	$rel = lc($rel);
    }
    
    dprint("Releaseid = $rel \n");
    $loadline = uc $loadline;

    dprint (1, "rel=$rel loadline=$loadline\n");
    dprint (1, "crusage=$crusage targettype=$targettype\n");
    dprint (1,"Leaving GetRelLLTTCRUforCR....\n");
    return ($rc, $rel, $loadline, $targettype, $crusage);

}

#
# Function to get SPCF CR fields (System, Product, Component, Feature)
#
sub GetSPCFforCR {
	
    dprint (1,"Into GetSPCFforCR....\n");
    my $crid  = shift;
	read_configFile();
	return (0,'')  unless ($::CQCC_INTEGRATION_ENABLED);
	my ($rc, $cqdb, $crnum) = ParseCrId($crid);
	unless($rc){
		my $cnt = $crnum =~ tr/0-9//;
		if($cnt < 8) {
			($rc, $cqdb, $crnum) = GenerateCrId($cqdb,$crnum,$::CQ_DEF_DB, @::CQ_DB_LST);
			$crid = $cqdb.$crnum unless($rc);
		}
	}

    #######
    #
    #  Getting the System, Product, Component, Feature
    # 
    #######
    my ($system, $product, $component, $feature);    
    my $i;
    my $falloff=0;
    if($::SERVERCQWEB)
    {
	for($i=0;$i<1;$i++)
	{
	    use CQCCIntegration::Session;

	    my( $cqSession ) = CQCCIntegration::Session->new();
	    if(!$cqSession)
	    {
		$falloff = 1;
		last;
	    }

	    my( $result ) = $cqSession->xquery( record      => 'Development_CR',
					       id          => $crid,
					       fields      => 'CI_System.Name,CI_Product.Name,CI_Component.Name,CI_Feature_Area.Name');

	    unless($result)
	    {
		$falloff = 1;
		last;    
	    }

	    my( %output ) = $cqSession->getResults();
	    if($result != 1)
	    {
		return(CQ_QUERY_FAIL,'');
	    }
	
	    $system = $output{'CI_System.Name'};
	    $product = $output{'CI_Product.Name'};
	    $component = $output{'CI_Component.Name'};
	    $feature = $output{'CI_Feature_Area.Name'};	    
	}
    }
    
    # Old way... Need to Query CQ TWICE because fields are not Mandatory fields and may be empty
    if(!$::SERVERCQWEB || $falloff == 1) 
    {
	$rc = PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
				  $::CQ_REC_TYPE);
	return ($rc, '') if($rc);

    my $cq_comm_mode = "WEB";

    $CQ_WEB_PARAMS{cqdb} = $cqdb;
    @CQ_QUERY_FIELDS = ();
    
    #1rst query to get System
	%CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = (id => ['eq', $crid]);
    @CQ_QUERY_FIELDS = qw(CI_System.Name CI_Product.Name CI_Component.Name CI_Feature_Area.Name);
	@QUERIED_CRLIST = ();
	my @crspcf = ();
	my $rcspcf = "";
	($rcspcf, @crspcf) = PerformQuery_CQWeb();
    if($rcspcf != CQ_VALID_CR)
	{
	    return ($rcspcf, '');
	}
	
    # reseting the filters and fields back to original values
    @QUERIED_CRLIST  = ();
    %CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = ( Technical_Authority  => ['like','[CURRENT_USER]~'],
		State             => ['eq','Assigned']);
    @CQ_QUERY_FIELDS = qw(id headline);

	dprint (1, "output from query .. oldway .. -> $crspcf[0]\n");
	($system, $product, $component, $feature) = split(/\s+/,$crspcf[0]);
	dprint (1, "system=$system product=$product component=$component feature=$feature\n");

    chomp($system, $product, $component, $feature);
    }

	# Parsing values
	my $parsedSPCF = parseSPCFHook($system, $product, $component, $feature);	
    
	chomp ($parsedSPCF);
	
    dprint (1,"Leaving GetSPCFforCR....\n");
    return ($rc, $parsedSPCF);

}

#
# Function to get CR Feature_Id field
#
sub GetCRFeature {
    
    my $crid  = shift;
	read_configFile();
	return (0,'')  unless ($::CQCC_INTEGRATION_ENABLED);
	my ($rc, $cqdb, $crnum) = ParseCrId($crid);
	unless($rc){
		my $cnt = $crnum =~ tr/0-9//;
		if($cnt < 8) {
			($rc, $cqdb, $crnum) = GenerateCrId($cqdb,$crnum,$::CQ_DEF_DB, @::CQ_DB_LST);
			$crid = $cqdb.$crnum unless($rc);
		}
	}
    
    my($feature);
    my $i;
    my $falloff=0;
    if($::SERVERCQWEB)
    {
	for($i=0;$i<1;$i++)
	{
	    use CQCCIntegration::Session;

	    my( $cqSession ) = CQCCIntegration::Session->new();
	    if(!$cqSession)
	    {
		$falloff = 1;
		last;
	    }

	    my( $result ) = $cqSession->xquery( record      => 'Development_CR',
					       id          => $crid,
					       fields      => 'Feature_Identifier');

	    unless($result)
	    {
		$falloff = 1;
		last;    
	    }

	    my( %output ) = $cqSession->getResults();
	    if($result != 1)
	    {
		return(CQ_QUERY_FAIL,'');
	    }

	    $feature = $output{'Feature_Identifier'};
	}
    }

    if(!$::SERVERCQWEB || $falloff == 1) 
    {
	$rc = PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
				  $::CQ_REC_TYPE);
	return ($rc, '') if($rc);

        my $cq_comm_mode = "WEB";

	$CQ_WEB_PARAMS{cqdb} = $cqdb;
        @CQ_QUERY_FIELDS=();
	%CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = (id => ['eq', $crid]);
        @CQ_QUERY_FIELDS = qw(Feature_Identifier);
	@QUERIED_CRLIST = ();
	my @crlist=();
	($rc, @crlist) = PerformQuery_CQWeb();

        # reseting the filters and fields back to original values
        @QUERIED_CRLIST = ();
        %CQ_QUERY_FILTER = ();
    %CQ_QUERY_FILTER = ( Technical_Authority  => ['like','[CURRENT_USER]~'],
			State             => ['eq','Assigned']);
        @CQ_QUERY_FIELDS = qw(id headline);

	dprint (1, "output from featureid query .. oldway .. -> $crlist[0]\n");
	$feature = $crlist[0];
	dprint (1, "feature=$feature\n");
        if($rc != CQ_VALID_CR)
	{
	    return ($rc, '');
	}
        chomp($feature);
    }

    return ($rc, $feature);
}

#
# Function to get the CQ DB name from the CR number.
#

sub getCQDB
{
    my($crid , $rc) = @_;

    my ($cqdb, $crnum); 
    ($$rc, $cqdb, $crnum) = ParseCrId($crid);
    if ($$rc){
	$$rc = CQ_INVALID_CR;
	return "";
    }

    my ($new_cqdb, $new_crnum);
    ($$rc, $new_cqdb, $new_crnum) = GenerateCrId($cqdb, $crnum, $::CQ_DEF_DB, @::CQ_DB_LST);
    if ($$rc){
	$$rc = CQ_INVALID_CR;
	return "";
    }
    return $new_cqdb;
}


#
# Function that will obtain the VobObject.name string from CQ (ie. WORK_STARTED, WORK_COMPLETED etc.)
#   Returns: 	name string.
#		NULL -- if empty.
#
#

sub getVobObjectNameFromCQ
{
    my ($uid,$branch,$vob,$norelink) = @_;
    my $falloff = 0;
    my $i;

    dprint("sub:  getVobObjectNameFromCQ\n");

    #
    # Need to obtain the OriginatingCR from the branch.
    # 

    my $cmd = "$CLEARTOOL describe -short -aattr OriginatingCR brtype:$branch\@$vob 2>$ERRNULL";
    my $crid = qx($cmd);
    dprint("cmd = $cmd\n");
    if($?)
    {
	return 1,"", "";
    }

    chomp($crid);
    dprint("originatingCR = $crid\n");
    

    # getting rid of the '"' strings from the output;
    $crid =~ s/^\"//;
    $crid =~ s/\"$//;


    if($::SERVERCQWEB)
    {
	for($i=0;$i<1; $i++)
	{
	    my( $cq ) = CQCCIntegration::Session::Admin->new();
            if(!$cq)
            {
                $falloff = 1;
                last;
            }
            my( $result ) = $cq->xquery( record      => 'Development_CR',
                                        id          => $crid,
                                        fields      => 'cc_change_set.objects' );

            unless($result)
            {
                $falloff = 1;
                last;
            }

	    my( %op ) = $cq->getResults();
            my @cset = split(/\,/,$op{'cc_change_set.objects'});

	    if($#cset == -1 && !defined($norelink))
	    {
		my $rc;
		$cset[0] = relinkCStoCR($crid,$uid,$branch,\$rc);

		if($rc != 0)
		{
		    return 1,"", "";
		}
		    
	    }


            foreach(@cset)
            {
                my $status;
                my $oid;
                my $i = 0;

                ($oid,$status) = split(/\s/);
		$cq =  CQCCIntegration::Session->new();
                $result  = $cq->listquery( record      => 'cc_vob_object',
                                          filters      => "dbid|EQ|$oid",
                                          fields      =>  'object_oid,vob_family_uuid' );

                %op = $cq->getResults();
		if($uid eq $op{'vob_family_uuid'} && $op{'object_oid'} eq $branch)
		{
		    dprint("status of cr-> $crid = $status brtype = $op{'object_oid'} vob--> $op{'vob_family_uuid'}\n"); 
		    return 0,$status, $crid;
		}
	    }
	}
    }

    if(!$::SERVERCQWEB || $falloff == 1) 
    {
	my $rc;
	dprint("FAILOVER ! \n");
	read_configFile();
	PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
			    $::CQ_REC_TYPE);
	my $cq_comm_mode = "WEB";

	my $db = getCQDB($crid, $rc);
	if($rc == CQ_INVALID_CR)
	{
	    return 1,"","";
	}
	
	$CQ_WEB_PARAMS{cqdb} = $db;
	%CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = ( id => ['eq', $crid]);

	@QUERIED_CRLIST = ();
	my @fieldList = qw/cc_change_set.objects.object_oid cc_change_set.objects.name cc_change_set.objects.vob_family_uuid /;
	my @queryoutput;
	my $branchname;
	my $i=0;

	($rc, @queryoutput) = Query_CQWeb(\@fieldList);
	if($rc != CQ_VALID_CR)
	{
	    return 1, "","";
	}

	foreach (@queryoutput)
	{
	    my($cqbranchname,$cqstatus,$cquuid) = (split(/\s+/))[0,1,2];

	    if($uid eq $cquuid && $branch eq $cqbranchname)
	    {
		dprint("status of cr-> $crid = $cqstatus  brtype = $cqbranchname vob-->$cquuid");
		return 0, $cqstatus,$crid;
	    }
	}
    }

    return 0, "", "";
}


#
# Function to update the ClearCase Tab.
#
sub clearcaseTabAction
{
    my($status,$originatingCR, $branch, $commandtype, $vob, $tobranch, $intBranch, $uuid, $desStatus) = @_;

    if($::USEMERGESTATES == 0)
    {
	return 0;
    }

    my $workcompleted = "WORK_COMPLETED:";
    my $workstarted = "WORK_STARTED";
    my $workintegrated = "WORK_INTEGRATED";
    my $worktargeted = "WORK_TARGETED";
    my $workpartialintegrated = "WORK_PARTIAL_INTEGRATED";
    my $worklockedpartintegrated = "WORK_LOCKED_PART_INT";

    my $branchlock = isBranchLockedForAllUsers($branch,$vob);
    dprint("BranchLock = $branchlock\n");

    my ($currentstate,$vobccsetbranch) = (split(/:/,$status))[0,1];
    dprint("currentstate=$currentstate vobccsetbranch=$vobccsetbranch\n");


    if($commandtype == ADDTARGETED)
    {
	if($branchlock == 0)
	{
	    $status = "$worktargeted:$tobranch";
	}
	else
	{
	    $status = "$workcompleted" . "$tobranch";
	}
    }
    elsif($commandtype == ADDTARGETEDSTRICT)
    {
	if($currentstate eq $workintegrated)
	{
	    $$intBranch = $vobccsetbranch;
	    return 1;
	}

	if($branchlock == 0)
	{
	    $status = "$worktargeted:$tobranch";
	}
	else
	{
	    $status = "$workcompleted" . "$tobranch";
	}
    }
    elsif($commandtype == RMINTEGRATED)
    {
	if(($currentstate eq $workintegrated) && ($vobccsetbranch ne $tobranch))
	{
	    $$intBranch = $vobccsetbranch;
	    return 1;
	    
	}

	if($branchlock == 0)
	{
	    $status = "$worktargeted:" . $tobranch;
	}
	else
	{
	    if(isDevIntCRBranch($tobranch))
	    {
		$status = "WORK_LOCKED_PART_INT:" . $tobranch;
	    }
	    else
	    {
		$status = "WORK_COMPLETED:" . $tobranch;
	    }
	}
    }
    elsif($commandtype == RMTARGETED)
    {
	if(($currentstate eq $workintegrated) && ($vobccsetbranch ne $tobranch))
	{
	    $$intBranch = $vobccsetbranch;
	    return 1;
	}

	if($branchlock == 0)
	{
	    $status = $workstarted;
	}
	else
	{
	    $status = $workcompleted;
	}
    }
    elsif($commandtype == ADDINTEGRATED)
    {
        if($currentstate eq $workintegrated)
        {
	    if($vobccsetbranch ne $tobranch)
	    {
		$$intBranch = $vobccsetbranch;
		return 1;
	    }
	    else
	    {
		return 0; ### Do nothing ... since it already marked integrated.
	    }
	}

	$status = "WORK_INTEGRATED:$tobranch";	
    }
    elsif($commandtype == ADDPARTIALINTEGRATED)
    {
	dprint("updating the clearcase tab to WORK_PARTIAL_INTEGRATED");
        if($currentstate eq $workpartialintegrated) 
	{ 
	    # need to make sure it is not partially merged into another branch...
	    if($vobccsetbranch ne $tobranch) 
	    { 
		$$intBranch = $vobccsetbranch; 
		return 1; 
	    } 
	    else
	    {
		return 0; ### Do nothing ... since it already marked partially integrated.
	    }
	}

	$status = "$workpartialintegrated:$tobranch";	
    }
    elsif($commandtype == ADDLOCKEDPARTINTEGRATED)
    {
	dprint("updating the clearcase tab to WORK_LOCKED_PART_INT");
        if($currentstate eq $worklockedpartintegrated) 
	{ 
	    # need to make sure it is not partially merged into another branch...
	    if($vobccsetbranch ne $tobranch) 
	    { 
		$$intBranch = $vobccsetbranch; 
		return 1; 
	    } 
	    else
	    {
		return 0; ### Do nothing ... since it already marked partially integrated.
	    }
	}

	$status = "$worklockedpartintegrated:$tobranch";	
    }
    elsif($commandtype == VERIFY_NOT_INTEGRATED_OTHER_BRANCHES)
    {
	dprint("Checking If Not Integrated With Other Branches.! \n");
        if($currentstate eq $workintegrated)
        {
	    if($vobccsetbranch ne $tobranch)
	    {
		$$intBranch = $vobccsetbranch;
		return 1;
	    }
	}

	return 0; # need to only check if integrated and not update the clearcase tab. 
    }
    elsif($commandtype == VERIFY_NOT_INTEGRATED)
    {
	dprint("Checking If Not In Integrated State \n");
        if($currentstate eq $workintegrated)
        {
	    $$intBranch = $vobccsetbranch;
	    return 1;
	}

	return 0; # need to only check if integrated and not update the clearcase tab. 
    }
    elsif($commandtype == ADDINTEGRATEDNOCHECK)
    {
	dprint("Updating Clearcase Tab No Precondition Checking ! \n");
	$status = "$workintegrated:$tobranch";
	
    }
    elsif($commandtype == ADDWORKCOMPLETED)
    {
	dprint("updating the clearcase tab to work_completed ! \n");

	if($vobccsetbranch ne "")
	{
	    $status = "$workcompleted" . "$vobccsetbranch";	
	}
	else
	{
	    $status = $workcompleted;
	}
    }
    elsif($commandtype == ADDWORKSTARTED)
    {
	dprint("updating the clearcase tab to work_started ! \n");

	if($vobccsetbranch ne "")
	{
	    $status = "$worktargeted:$vobccsetbranch";	
	}
	else
	{
	    $status = $workstarted;
	}
    }

	
    dprint("statusstring = $status\n");
    dprint("originatingCR = $originatingCR \n");
    MVCsetLog($branch,$originatingCR,$status);

	dprint ("uuid passed to sub clearcaseTabAction: $uuid\n");
    # If $uuid was passed as a parameter then make sure the desired change set has taken place
	if ($uuid ne "") {
	    dprint ("Getting new status for: uuid: $uuid branch: $branch vob: $vob\n");
	    my ($rc1, $new_status, $originatingCR) = getVobObjectNameFromCQ($uuid,$branch,$vob);
    	if($rc1) {
	  		display_msg("Error: Failed to obtain the current mergestate for brtype:$branch\n");
	  		return 1;
    	}
    	dprint ("status desired: $status current status: $new_status\n");

    	if ($new_status ne $status) {
        	$$desStatus = $status;
			return 1;
		}
    }      
    return 0;
}






#
sub comm_AuthorizedCR {
        my $crid = shift;
	my $cquser = shift;
	my ( $query_resultRef ) = shift ;
        my $cq_comm_mode = "WEB";
        my $i;
        my $fallout=0;


        if($::SERVERCQWEB)
        {
                for($i=0;$i<1;++$i)
                {
                        my( $cq ) = CQCCIntegration::Session->new();
                        if(!$cq)
                        {
                                $fallout = 1;
                                last;
                        }

                        my( $result ) = $cq->xquery( record      => 'Development_CR',
                                                        id          => $crid,
                                                        fields      => 'State,Technical_Authority,cc_change_set.objects,Work_Product_ID' );
                        unless($result)
                        {
                                $fallout = 1;
                                last;
                        }


                        my( %stuff ) = $cq->getResults();

			foreach ( keys %stuff ) {
				dprint ( "key $_ = $stuff{$_}\n");
			}

			foreach ( keys %stuff ) {
				$$query_resultRef{$_} = $stuff{$_};
			}
           		return 0;

                }
        }
        if(!$::SERVERCQWEB || $fallout == 1)
        {
                my $rc = 0;
                read_configFile();
                PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'}, $::CQ_REC_TYPE);
                my $cq_comm_mode = "WEB";

                my $db = getCQDB($crid, \$rc);
                if($rc == CQ_INVALID_CR)
                {
                        return 1;
                }

                $CQ_WEB_PARAMS{cqdb} = $db;
                %CQ_QUERY_FILTER = ();
                %CQ_QUERY_FILTER = (
                            id => ['eq', $crid]);

                my @fieldList  = qw(Work_Product_ID State Technical_Authority);

                @QUERIED_CRLIST = ();
                my @crlist = ();
                ($rc, @crlist) = Query_CQWeb(\@fieldList);

		my @crFieldsValue= split(/\s+/, $crlist[0]);
                dprint( "HELEN, crlist=@crlist\ncrlist=$crFieldsValue[0] 1=$crFieldsValue[1] 2=$crFieldsValue[2]  3=$crFieldsValue[3] 4=$crFieldsValue[4]\n");
		

                if($rc != CQ_VALID_CR)
                {
                        display_msg("Error: Failed to query database for validating CR($crid).\n");
                        return 1;
                }

                if( ! (scalar(@crlist)) )
                {
                        display_msg("Error: There is no CR($crid) in the database. Please make sure you entered the correct CR number\n");
                        return 1;
                }

		#populate the result in the query_result
                $$query_resultRef{'Work_Product_ID'} = $crFieldsValue[0];
		$$query_resultRef{'State'}= $crFieldsValue[1];
                $$query_resultRef{'Technical_Authority'} = $crFieldsValue[2];

		
		@fieldList = qw(cc_change_set.objects);
                @QUERIED_CRLIST = ();
                @crlist = ();
                ($rc, @crlist) = Query_CQWeb(\@fieldList);
                dprint( "HELEN2, crlist=@crlist\n");

                if($rc != CQ_VALID_CR)
                {
                        display_msg("Error: Failed to query database for validating CR($crid).\n");
                        return 1;
                }

                if( ! (scalar(@crlist)) )
                {
                        display_msg("Error: There is no CR($crid) in the database. Please make sure you entered correct CR number\n");
                        return 1;
                }

                #populate the cc_change_set.objects in the query_result
                $$query_resultRef{'cc_change_set.objects'} = join ',' , @crlist;

                return 0;
        }
}

#
# Function that gets Branch Type for CR number and validates that:
#   1. Only one active (WORK_*) development branch type exists for CR
#   2. Branch type exists for given VOB
#
# Parameters:
#	$cr	cr number
#	$vob	vob
#	$btref	reference to CR branch
#	$geterrFlag	return $errmsg if $geterrFlag set to 1; $errmsg is empty if 0
# Returns:  0 if successfully obtains a single valid branch type from CR
#           1 if CR invalid or CR branch type found invalid
#
sub get_verifyBrtypeFromCR()
{
    my ($cr, $vob, $btref,$geterrFlag) = @_;
	if ( !defined ( $geterrFlag )) {
		$geterrFlag=0;
	}
    my $errmsg='';
    my $rc='';
    @$btref = &getBranchTypeFromCR($cr, \$rc);

    if ( $rc != CQ_VALID_CR || $#$btref < 0 ) {
	if( $geterrFlag ) {
		$errmsg="Error: Did not find brtype associated with CR ($cr)!\n".
			"Please validate that the CR ($cr) specified on the command line is a valid CR\n".
			"and that it has an associated branch type in the CQ ClearCase tab.\n";
		return(1, $errmsg); 
	}
	else {
        	display_msg ("Error: Did not find brtype associated with CR ($cr)!\n".
                	"Please validate that the CR ($cr) specified on the command line is a valid CR\n".
                	"and that it has an associated branch type in the CQ ClearCase tab.\n");
        	return(1, $errmsg);
	}
    }

    @$btref = map { s/^\s*//; s/\s*$//; s/\@.*$//; chomp; if ( ! m/^\s*$/ ) { $_ } } @$btref;
    dprint (1, "CR ($cr) BT (" . join(" ",@$btref) . ")\n");

    # Should only have one associated (WORK_*) brtype per CR
    if ( $#$btref > 0 ) {
	if ( $geterrFlag ) { 
		$errmsg="Error: Found more than one active brtype (" . join(",",@$btref) .
			")\n\tassociated with CR ($cr) in the CQ ClearCase tab!\n".
			"Please delete or obsolete the invalid branch type in the appropriate VOB\n".
			"\tprior to reattempting this command.\n";
		return(1,$errmsg);
	}
	else {
        	display_msg ("Error: Found more than one active brtype (" . join(",",@$btref) .
            	")\n\tassociated with CR ($cr) in the CQ ClearCase tab!\n".
                "Please delete or obsolete the invalid branch type in the appropriate VOB\n".
            	"\tprior to reattempting this command.\n");
        	return(1, $errmsg);
	}
    }

    #
    # Verify Branch type is valid for current VOB family
    #
    my $brtype = @$btref[0];   # Already validated that there's only one brtype

    if (verifyBranch($brtype, $vob) != 0) {
	if ( $geterrFlag ) {
		$errmsg="Error: Branch Type [$brtype] for CR [$cr] is not a valid branch type\n".
			"in the VOB [$vob]\n";
		return(1, $errmsg);
	}
	else {
        	display_msg ("Error: Branch Type [$brtype] for CR [$cr] is not a valid branch type\n".
        	"in the VOB [$vob]\n");
        	return(1,$errmsg);
	}
    }

   return (0, $errmsg);  # Return success
}

#
# Function that will try to relink the ccchangeset. There are times the vob object change set exist but is not linked to the 
# back to the CR. If that is the case, this function will link them back. 
# Return struct relinkinfo which contains str, and a return code.
#
# Returns the dbid and WORK_* string;
#     if error: Will return error string instead.
#     will pass in the $rc ... 
#               rc = 0 -> No errors.
#               rc = 1 -> Error
# 

sub relinkCStoCR
{
    my($crid,$uid,$branch,$rc) = @_;

    dprint("SUB: relinkCStoCR \n");

    my( $cq ) = CQCCIntegration::Session::Admin->new();

    # Nothing is listed in the ccchangeset, so will now verify if the cc_vob_object exist.
    my( $result ) = $cq->listquery( record      => 'cc_vob_object',
				   filters      => "vob_family_uuid|EQ|$uid,object_oid|EQ|$branch",
				   fields      =>  'object_oid,dbid,name' );

    my( %output ) = $cq->getResults();

    my $ccChangeSet;
    if($output{object_oid} ne "")
    {
	# need to check if the ccchangeset record exist also..
	$result = $cq->xquery( record      => 'Development_CR',
			      id          => $crid,
			      fields      => 'cc_change_set' );

	unless ($result)
	{
	    $$rc = 1;
	    return "query failed to obtain the cc_change_set for CR $crid","";
	}

	my( %cs ) = $cq->getResults();
	if($cs{cc_change_set} ne "")
	{
	    $ccChangeSet = $cs{cc_change_set};
	    dprint "NO CHANGESET $ccChangeSet\n";
	}
	else
	{
	    dprint "NEW CHANGESET \n";

	    $result = $cq->create( record          => 'cc_change_set' );

	    unless ($result)
	    {
		$$rc = 1;
		return "Failed to create the cc_change_set object \n", "";
	    }


	    %cs = $cq->getResults();
	    $ccChangeSet  = $cs{uid};
	}
	
	dprint "TTT vobobject = $output{dbid} cc_change_set=$ccChangeSet\n";
	$result  = $cq->edit( record          => 'CC_Change_Set',
			     dbid             => $ccChangeSet,
			     'objects'   => "$output{dbid} $output{name}" );

	unless ($result)
	{
	    $$rc = 1;
	    return "Edit failed on CC_Change_Set object cc_change_set object \n", "";
	}

	$result  = $cq->edit( record          => 'Development_CR',
			     id              => $crid,
			     cc_change_set   => $ccChangeSet );

	unless ($result)
	{
	    $$rc = 1;
	    return "Edit failed on CR: $crid \n", "";
	}
    }
    else
    {
	#
	# Getting the replica name for the admin vob.
	#
	my $adminvob = $NT ? $::CC_NT_ADMINVOB : $::CC_UNIX_ADMINVOB;
	my $replicaname = getReplicaNameFromVob($adminvob); 
	if($replicaname eq "") 
	{ 
	    $replicaname = "original"; 
	} 


	### Object does not exist ... Will now create the Object with WORK_STARTED....
	my( $_result ) = $cq->create( record          => 'cc_vob_object',
				     name            => "WORK_STARTED",
				     object_oid      => "$branch",
				     replica_vob     => "$replicaname\@$adminvob",
				     vob_family_uuid => "$uid" );

	unless( $_result )
	{ 
	    $$rc = 1;
	    return "Failed to create cc_vob_object \n", "";
	}

	my( %createobj ) = $cq->getResults();
	my( $ccVobObj ) = $createobj{uid};

	unless( $ccVobObj )
	{
	    $$rc = 1;
	    return "Failed to obtain cc_vob_object uid\n", "";

	}

	# checking if the CR already has a cc_change_set_object
	my $ccChangeSet;
	$_result = $cq->xquery( record      => 'Development_CR',
			       id          => $crid,
			       fields      => 'cc_change_set' );

	unless( $_result )
	{
	    $$rc = 1;
	    return "Failed to query cc_change_set object\n", "";

	}

	my( %cs ) = $cq->getResults();

	if($cs{cc_change_set} ne "")
	{
	    $ccChangeSet = $cs{cc_change_set};
	}
	else
	{
	    $_result = $cq->create( record          => 'cc_change_set' );
	    unless( $_result )
	    {
		$$rc = 1;
		return "Failed to create cc_change_set object\n", "";
	    }

	    %cs = $cq->getResults();
	    $ccChangeSet  = $cs{uid};
	    unless( $ccChangeSet )
	    {
		$$rc = 1;
		return "Failed to obtain cc_change_set uid\n", "";
	    }
	}

	$_result  = $cq->edit( record          => 'CC_Change_Set',
			      dbid             => $ccChangeSet,
			      'objects'   => "$ccVobObj" );

	unless( $_result )
	{
	    $$rc = 1;
	    return "Failed to edit the CC_Change_Set to ccVobObj.\n", "";
	}

	my( %editoutput ) = $cq->getResults();
	$_result  = $cq->edit( record          => 'Development_CR',
			      id              => $crid,
			      cc_change_set   => $ccChangeSet );

	unless( $_result )
	{
	    $$rc = 1;
	    return "Failed to edit the CC_Change_Set to CR.\n", "";
	}

	$$rc = 0;
	dprint "RETURNING FROM function relinkCStoCR --> \"$ccVobObj WORK_STARTED\"";
	return "$ccVobObj WORK_STARTED";
    }

    
    $$rc = 0;
    dprint "RETURNING FROM function relinkCStoCR --> \"$output{dbid} $output{name}\"";
    return "$output{dbid} $output{name}";
}

#
# Function that will obtain the vob family oid from the cc_change_set object that is linked in CQ for the given CR.
#
# Function that will 
#


sub getuuidfromCQ
{
    my ($crid,$rc) = @_;
    my $i;
    my $failover = 0;

    $$rc = 0;

    dprint("SUB: getuuidfromCQ crid=$crid\n");

    if($::SERVERCQWEB)
    {
	for($i=0;$i<1; $i++)
	{
	    my( $cq ) = CQCCIntegration::Session->new();
	    if(!$cq)
	    {
		$failover = 1;
		last;
	    }
	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $crid,
					fields      => 'cc_change_set.objects' );

	    unless($result)
	    {
		$failover = 1;
		last;
	    }

	    my( %op ) = $cq->getResults();
	    my @cset = split(/\,/,$op{'cc_change_set.objects'});
	    my $j=0;
	    foreach(@cset)
	    {
		my ($dbid,$string) = (split(/\s/))[0,1];
		if($string =~ /^WORK_/)
		{
		    ###
		    # CR has a ccchangeset associated with the CR. Will return the ccchangeset's vob uuid back to the caller.
		    ###
		    $result  = $cq->listquery( record      => 'cc_vob_object',
					      filters      => "dbid|EQ|$dbid",
					      fields      =>  'vob_family_uuid' );

		    %op = $cq->getResults();
		    return $op{vob_family_uuid};
		}
	    }
	}
    }
    
    if(!$::SERVERCQWEB || $failover == 1) 
    {
	read_configFile(); 
        PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'}, 
                            $::CQ_REC_TYPE); 
        my $cq_comm_mode = "WEB"; 
 
        my $db = getCQDB($crid, $rc); 
        if($$rc == CQ_INVALID_CR) 
        { 
	    $$rc = 1;
	    return "";
	}
	
	$CQ_WEB_PARAMS{cqdb} = $db; 
        %CQ_QUERY_FILTER = (); 
        %CQ_QUERY_FILTER = ( id => ['eq', $crid]); 
 
        @QUERIED_CRLIST = (); 
        my @fieldList = qw/cc_change_set.objects.object_oid cc_change_set.objects.name cc_change_set.objects.vob_family_uuid /; 
        my @queryoutput; 
 
        ($$rc, @queryoutput) = Query_CQWeb(\@fieldList); 
	if($$rc != CQ_VALID_CR) 
	{ 
	    return ""; 
	} 
 
        foreach (@queryoutput) 
        { 
	    my($cqstatus,$cquuid) = (split(/\s+/))[1,2]; 
 
	    if($cqstatus =~ /^WORK_/)
	    {
		$$rc = 0;
		return $cquuid;
	    }
        } 
    }


    ##
    # If it makes it this far, that means that there is no ccchangeset associated with the CR.
    ##
    
    dprint "NO ACTIVE CCCHANGESET FOR CR  $crid \n";
    return "";
}

# 
# Function that will obtain the dependency information from the CRdep hyperlinks that is attached to the given branchtype. 
# 
# Caller will pass the branchtype, vobadmin and associative arrays %alreadycheck and %crdep. 
# 
# Associative array alreadycheck is used as a flag to see if the   
# CR has been queried. The key will be the CR number and will be assigned a 1 if check 0 if not yet checked.  
#   i.e. $alreadycheck{MOTCM00000001} = 1  ; CR MOTCM00000001 has been checked.  
#        $alreadycheck{MOTCM00000002} = 0  ; CR MOTCM00000002 has not been checked.  
#  
# 
#  
# Associative array crdep will be used to show the dependencies of the given CRs.  
# The key will be the CR and will be assigned to a node which has 2 arrays, an array of dependent CR numbers and   
# an array of brtypes that is associated with the CR.  
#  
#        $crdp{MOTCM002}->{  
#                          CRnumber => (MOTCM001,MOTCM003),  
#                          Brtype =>   (r16.3_dev-001,r16.3_dev-003) 
#                          keybrtype => "r16.3_dev-002"; 
#                         }  
#  
#              MOTCM002->MOTCM001  
#              MOTCM002->MOTCM003  
 
#  Function will return 0 for success and 1 for failure. 


sub getDepFromHlink 
{ 
    my($brtype, $adminvob,$alreadycheck,$crdep) = @_; 
     
    my $cmd="$CLEARTOOL describe -long -ahlink $DEPHLINK brtype:$brtype\@$adminvob";   
    dprint("Executing $cmd \n");   
   
    my @output = qx($cmd);   
    if($?)   
    {   
        return 1; 
    }   
 
    #   
    # This describe command will have the following sample output:   
    #  arnie_r16.4.1_int-01
    #  Hyperlinks:
    #    CRdep@645@/usr/vob/sc/arnie ->  "MOTSB00060128->MOTSB00060127"
    #    CRdep@646@/usr/vob/sc/arnie ->  "MOTSB00060128->MOTSB00060129"
    #    CRdep@647@/usr/vob/sc/arnie ->  "MOTSB00060129->MOTSB00060910"
    #    
   
    my $line; 
    my $hlink;
    foreach $line (@output)   
    {   
        chomp($line);   
         
        # getting rid of the white space in the front of the string.   
        $line =~ s/^\s*//;   
   
   
        if($line =~ /^$DEPHLINK\@/)   
        {   
            # To obtain the text hyperlink by splitting on the \" character. Can assume  
            # this since the hyperlink will be created   
            # using -ttext option.   
                 
            ($hlink,$line) = (split(/\"/,$line))[0,1];   

	    # Getting the hlink by splitting  on string ->
	    $hlink = (split(/->/,$hlink))[0];
	    $hlink =~ s/\s*$//;
             
            # now getting the parent child CRs by splitting on the '->' character.    
   
            my ($pCR, $cCR) = (split(/->/,$line))[0,1];   # the parentCr and childCR.   
 
                 
            dprint("Hyperlink data pCR=$pCR cCr=$cCR\n");   
            push @{$$crdep{$pCR}->{CRnumber}} , $cCR;   
 
            # now getting the branch equiavalent. 
            my $rc; 
            my @branch = getBranchTypeFromCR($cCR, \$rc);  
            if($rc) 
            { 
                return 1; 
            } 
 
            push @{$$crdep{$pCR}->{Brtype}} , $branch[0];   

	    # Adding the hyperlink information
            push @{$$crdep{$pCR}->{hlink}} , $hlink;   

	    # now getting the brtype of the key.
            if($$alreadycheck{$pCR} != 1)
	    {
		$rc; 
		@branch = getBranchTypeFromCR($pCR, \$rc);  
		if($rc) 
		{ 
		    return 1; 
		} 
 
		$$crdep{$pCR}->{keybrtype} = $branch[0];


		$$alreadycheck{$pCR} = 1;   
	    }
        }   
    }   
 
    return 0; 
} 

# checks CQ if the given CR is in the closed state and also get's CR information;
sub IsCRClosedAndCRInformation {
    
    my ($int_cr, $rc, $fieldArray,$fieldoutput)  = @_;
    my $i;
    my $fallout=0;
 
    if($::SERVERCQWEB)
    {
	for($i=0; $i<1;++$i)
	{
	    my( $cq ) = CQCCIntegration::Session->new();
	    if(!$cq)
	    {
		$fallout = 1;
		last;
	    }

	    my $fieldtoQuery = join(',', @$fieldArray);
	    $fieldtoQuery .= ",state";

	    my( $result ) = $cq->xquery( record      => 'Development_CR',
					id          => $int_cr,
					fields      => $fieldtoQuery);

	    unless($result)
	    {
		if($ENV{CQCC_DEBUG})
		{
		    print 'ERROR: [', $cq->getError(), "]\n";
		    print "\n";
		}

		$fallout = 1;
		last;
	    }

	    my( %output ) = $cq->getResults();
	    
	    if($ENV{CQCC_DEBUG})
	    {
		foreach (keys %output)
		{
		    print "$_ --> $output{$_}\n";
		}
	    }

	    %$fieldoutput = %output;
	    if($output{'state'} =~ m/Closed/i)
	    {
		return 1;
	    }

	    return 0;
	}
    }

    if(!$::SERVERCQWEB || $fallout == 1)
    {
	$$rc = 0;
	read_configFile();
	PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'},
			    $::CQ_REC_TYPE);
	my $cq_comm_mode = "WEB";

	my $db = getCQDB($int_cr, $rc);
	if($$rc == CQ_INVALID_CR)
	{
	    return 0;
	}

	$CQ_WEB_PARAMS{cqdb} = $db;

	my @localfield = ("state"); 
	push (@localfield, @$fieldArray);
	%CQ_QUERY_FILTER = ();
	%CQ_QUERY_FILTER = ( id => ['eq', $int_cr]);

	@QUERIED_CRLIST = ();
	my @crlist = ();
	($$rc, @crlist) = Query_CQWeb(\@localfield);

	my $index=0;
	foreach(split(/\s+/,$crlist[0]))
	{
	    $$fieldoutput{$localfield[$index]} = $_;
	    ++$index;
	}

	if($$rc != CQ_VALID_CR)
	{
	    return 0;
	}

	if($$fieldoutput{state} !~ m/closed/i)
	{
	    return 0;
	}

	return 1;
    }
}

#
# Name: checkCRassignedAndNoOtherActiveBrtype
# Parameters: CR - Full CQ CR number.
#             Brtype - the brtype in CC.
#             uuid - The current vob uuid.
#
# Function that will verify that the CR is still in the assigned state and 
# no other active working branch is listed in the CC Tab.
#
# Returns: NULL - CR is in the right state and no other active brtype exist.
#          ErrorStr - Will give the error statement back to the caller stating either the CR is not in the Assigned state or other working branches are around.
#          
#

sub checkCRassignedAndNoOtherActiveBrtype
{
    my($cr, $brtype, $uuid, %retval_hash)  = @_;
    my $i;
    my $fallout;
    my $msg;

      
    if($ENV{SERVEROFF})
    {
	$::SERVERCQWEB = 0;
    }

    dprint("IN FUNCTION : checkCRassignedAndNoOtherActiveBrtype \n");
    if($::SERVERCQWEB)
    {
	for($i=0;$i<1;++$i)
	{
	    my( $cq ) = CQCCIntegration::Session->new();
	    if(!$cq)
	    {
		$fallout = 1;
		last;
	    }

	    my( $result ) = $cq->xquery( record      => 'Development_CR',
			id          => $cr,
			fields      => 'state,cc_change_set.objects,Target_Type,CR_Usage' );

	    unless($result)
	    {
		$fallout = 1;
		last;
	    }

	    my( %stuff ) = $cq->getResults();

	    my @ccchangeset = split(/,/, $stuff{'cc_change_set.objects'});

	    #
	    # Verify the CR is in the assigned state.
	    #
	    dprint("STATE -> $stuff{'state'} \n");

	    if($stuff{'state'} !~ m/assigned/i)
	    {
		$msg = "CR ($cr) is currently in the $stuff{'state'} state. CR must be in the assigned state to execute command \n";
		dprint($msg);
		return $msg;
	    }

	    # If the branch type when created had CR Usage Dev-Integration, check 
            # if developer changed the CR Usage to other than Dev-Integration
	    dprint ("CR_Usage: $stuff{'CR_Usage'}\n");

	    if($retval_hash{IS_DEVINT_USAGE}) {
	      if($stuff{'CR_Usage'} !~ m/Dev-Integration/i) {
		$msg = "CR ($cr) has Usage $stuff{'CR_Usage'} state. Since brtype: $brtype has devint usage tag CR Usage must be Dev-Integration.\n";
		dprint($msg);
		return $msg;
	      }
	    }
	    else {
	      # Also make sure for CR Usage of Dev-Integration the branchtype also has
	      # usage tag of Dev-Integration. This check is to make sure CRs of Usage other
	      # than Dev-Integration were not changed to Dev-Integration after obsoleting 
              # the brtype

	      if ($stuff{'CR_Usage'} =~ m/Dev-Integration/i) {
		$msg = "CR ($cr) has Usage Dev-Integration but branch does not have devint/devbld usage tag in $brtype.Usage of CR must be changed from Dev-Integration to unlock the branch\n";
		dprint($msg);
		return $msg;
	      }

	      # For Dev-CRs that does not have TT=Dev-Build, make sure they have release 
	      # in their brtype. Only time it can happen is if branch type was created 
              # with TT=Dev-Build, the branch type is obsoleted, the CR TT is changed to
              # something other than Dev-Build.
	      dprint ("Target_Type: $stuff{'Target_Type'} REL_ID:$retval_hash{REL_ID}\n");		
              if ($retval_hash{IS_DEV_USAGE}) {
		if (($stuff{'Target_Type'} !~ /Dev-Build/) && ($retval_hash{REL_ID} eq "")) {
		  $msg = "CR ($cr) does not have Target Type Dev-Build. Still it does not have release in the brtype. This CR must have TT Dev-Build to continue\n";
		  dprint($msg);
		  return $msg;
		}
	      }
		
	    }
		

	    #
	    # Go through each change set and verify there is no other active branch.
	    #
	    foreach (@ccchangeset)
	    {
		if(/WORK_/)
		{
		    #
		    # Found active branch .. Will verify it is not the same branch and vob the current trigger is trying to unlock. 
		    # If that is the case that is ok.... 
		    #

		    my $dbid = (split(/\s+/))[0];
		    dprint "dbid from $_ is  $dbid \n";
		    $cq->{_formatResults} = undef;
		    $result = $cq->listquery(record      => 'cc_vob_object',
					     filters	 => "dbid|EQ|$dbid",
					     fields      => "name,object_oid,vob_family_uuid,replica_vob");

		    my( %output ) = $cq->getResults();

		    dprint "$output{object_oid}\n";
		    dprint "$output{replica_vob}\n";

		    if($brtype ne $output{object_oid}  || $uuid ne $output{vob_family_uuid})
		    {
			# Ok .. Found out there is another active branch around ... Will formulate an error message and send back to the caller.
			if($output{replica_vob} ne "")
			{
			    dprint("Ok .. Found out there is another active branch around ... Will formulate an error message and send back to the caller. \n");
			    # if the replica_vob information is there, will use it as part of the message.
			    $msg = "There is currently an active branch ($output{object_oid}) for CR($cr) in vob replica:$output{replica_vob} \n";
			    dprint "$msg \n";

			    return $msg;
			}
			else
			{
			    $msg = "There is currently an active branch ($output{object_oid}) for CR($cr).\n";
			    dprint "$msg \n";
			    return $msg;

			}
		    }
		}
	    }
	} # end of  for($i=0;$i<1;++$i) 
    } # end of if($::SERVERCQWEB) 


    if((!$::SERVERCQWEB || $fallout == 1) &&  $::CQCC_INTEGRATION_ENABLED)
    {
	dprint("OLD CQWEB WAY .... SLOOOOOWWWW \n");
	read_configFile();

	PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'}, $::CQ_REC_TYPE);
	my $cq_comm_mode = "WEB";

	my ($rc, @output);
	my $db = getCQDB($cr, \$rc);
	$CQ_WEB_PARAMS{cqdb} = $db;
	%CQ_QUERY_FILTER = (
			    id => ['eq', $cr]);

	my @fieldList  = qw(State cc_change_set.objects CR_Usage Target_Type);
	dprint ("\@fieldList: @fieldList \n");

	@QUERIED_CRLIST = ();
	my @ouptut = ();
	($rc, @output) = Query_CQWeb(\@fieldList);
	dprint ("\@output: @output \n");

	foreach (@output)
	{
	    my($state,$dbid,$status,$cr_usage,$target_type) = split(/\s+/);

	    dprint ("CURRENT STATE ==> $state \n");
	    if($state !~ m/assigned/i) 
            { 
                $msg = "CR ($cr) is currently in the \'$state\' state. CR must be in the assigned state to execute command \n"; 
                dprint($msg); 
                return $msg; 
            } 
 
	    # If the  branch type when created had CR Usage Dev-Integration. check
            # if developer changed the CR Usage to other than Dev-Integration
	    dprint ("CR_Usage: $cr_usage\n");

	    if($retval_hash{IS_DEVINT_USAGE}) {
	      if($cr_usage !~ m/Dev-Integration/i) {
		$msg = "CR ($cr) has Usage $cr_usage. Since brtype: $brtype has devint usage tag CR Usage must be Dev-Integration.\n";
		dprint($msg);
		return $msg;
	      }
	    }
	    else {
	      # Also make sure for CR Usage of Dev-Integration the branchtype also has
	      # usage tag of Dev-Integration. This is check to make sure CRs of Usage other
	      # than Dev-Integration were not changed to Dev-Integration after obsoleting 
              # the brtype

	      if ($cr_usage =~ m/Dev-Integration/i) {
		$msg = "CR ($cr) has Usage Dev-Integration but branch does not have devint/devbld usage tag in $brtype.Usage of CR must be changed from Dev-Integration to unlock the branch\n";
		dprint($msg);
		return $msg;
	      }

	      # For Dev-CRs that does not have TT=Dev-Build, make sure they have release 
	      # in their brtype. Only time it can happen is if branch type was created 
              # with TT=Dev-Build, the branch type is obsoleted, the CR TT is changed to
              # something other than Dev-Build.
	      dprint ("Target_Type: $target_type REL_ID:$retval_hash{REL_ID}\n");	

              if ($retval_hash{IS_DEV_USAGE}) {
		if (($target_type !~ /Dev-Build/) && ($retval_hash{REL_ID} eq "")) {
		  $msg = "CR ($cr) does not have Target Type Dev-Build. Still it does not have release in the brtype. This CR must have TT Dev-Build to continue\n";
		  dprint($msg);
		  return $msg;
		}
	      }
		
	    }
		
	    if($status =~ /WORK_/)
	    {

		my $oldrectype = $::CQ_REC_TYPE;
		$::CQ_REC_TYPE = "cc_vob_object";

		PopulateCQWebParams($ENV{CQCC_SERVER}, $ENV{CQCC_SERVERROOT}, $::CQ_REC_TYPE);
		
		%CQ_QUERY_FILTER = ( dbid => ['eq', $dbid]); 
		my @fieldList  = qw(name object_oid vob_family_uuid replica_vob);

		@QUERIED_CRLIST = (); 
		my @ouptut = (); 
		($rc, @output) = Query_CQWeb(\@fieldList); 

		foreach (@output)
		{
		    my($name, $crbrtype, $vfuuid, $repvob) = split(/\s+/);
		    
		    if($brtype ne $crbrtype || $uuid ne $vfuuid)
		    {
			
			if($repvob ne "")
			{

			    dprint("Ok .. Found out there is another active branch around ... Will formulate an error message and send back to the caller. \n"); 
			    # if the replica_vob information is there, will use it as part of the message. 
			    $msg = "There is currently an active branch ($crbrtype) for CR($cr) in vob replica:$repvob \n"; 
			    dprint "$msg \n"; 
			    return $msg; 
			}
			else
			{
			    $msg = "There is currently an active branch ($crbrtype) for CR($cr).\n"; 
			    dprint "$msg \n"; 
			    return $msg; 
			}
		    }
		}

		$::CQ_REC_TYPE = $oldrectype ;
	    } # end if($status .... 
	}
    }


    return "";
} # end of function......


=head1 NAME

GetValidCRSet -- Presents a list of all assigned CRs for ClearQuest user.

=head1 SYNOPSIS

 GetValidCRSet($comm_mode, $db)

 where 

 $comm_mode - Mode of communication with ClearQuest.  
              Is "WEB" for WEB server communication.
 $db        - ClearQuest database


=head1 DESCRIPTION

Calls PerformQuery_CQWeb() to query $db database.  PerformQuery_CQWeb uses %CQ_QUERY_FILTER as filter to the CQ query.  It displays the list of CRs returned from PerformQuery_CQWeb.

=head1 RETURN VALUES

 Returns CMBP_SUCCESS and the CRs and their headlines on success.
 Returns CMBP_FAIL on failure.


=cut

#################################################################
sub GetValidCRSet{

   my ($db) = @_;

   my ($fallout, $i);
   my ($rc, @crlist);

   if($::SERVERCQWEB) {

     for($i=0;$i<1;++$i){
       my( $cq ) = CQCCIntegration::Session->new();
       if(!$cq) {
	 $fallout = 1;
	 last;
       }
    
       chomp (my $cq_user = $CQ_WEB_PARAMS{'cquser'});
       my ($result) = $cq->listquery(record   => 'Development_CR',
		     filters	 => "technical_authority|LIKE|$cq_user~,State|EQ|Assigned",
		     fields      => "id,Headline");

       unless($result) {
	 $fallout = 1;
	 last;
       }

       my (%output) = $cq->getResults();
       dprint ("id: $output{id} \n");
       dprint ("headline: $output{Headline}\n");

       my @new_crlist = split(/\,/, $output{id});
       my @headline_list = split(/\,/, $output{Headline});

       # If the two arrays size do not match we have a problem
       if ($#headline_list != $#new_crlist ) {
	 $fallout = 1;
	 last;
       }

       # If there are no CRs assigned then we can return to calling function

       if (!(scalar(@new_crlist))) {
	 display_msg("Warning: Query returned no CRs for user $CQ_WEB_PARAMS{'cquser'}.\n",2);
	 return (CMBP_FAIL, '');
       }

       my $error_message = "Following are CR(s) assigned to you:\n\n";

       my $num;
       for($num=0; $num <= $#headline_list; $num++) {
	 $error_message .= "$new_crlist[$num]" . "\t" . "$headline_list[$num]" . "\n";
       }

       dprint ("crlist from SERVERCQWEB: $error_message \n");
       return ("CMBP_SUCCESS", $error_message);
	
     }
   }

   if(!$::SERVERCQWEB || $fallout == 1) {

     read_configFile();
     PopulateCQWebParams($ENV{'CQCC_SERVER'}, $ENV{'CQCC_SERVERROOT'}, $::CQ_REC_TYPE);
     my $cq_comm_mode = "WEB";
     $CQ_WEB_PARAMS{cqdb} = $db;

     # Get CRs for the user:
     @CQ_QUERY_FIELDS = qw(id headline);
     %CQ_QUERY_FILTER=();
     %CQ_QUERY_FILTER = ( Technical_Authority  => ['like','[CURRENT_USER]~'], 
			 State                => ['eq','Assigned']);

     ($rc, @crlist) = PerformQuery_CQWeb();

     if ($rc != CMBP_SUCCESS){
       display_msg("Error: Query failed!!! \n", 1);
       return (CMBP_FAIL, '');
     }
     elsif (!(scalar(@crlist))) {
       display_msg("Warning: Query returned no CRs for user $CQ_WEB_PARAMS{'cquser'}.\n",2);
       return (CMBP_FAIL, '');
     }

     dprint("crlist from WEB: @crlist \n");
     my $error_message = "Following are CR(s) assigned to you:\n\n";
     foreach(@crlist) {
       $error_message .= "$_ \n";
     }
     return ($rc, $error_message);
   }
}


1;





