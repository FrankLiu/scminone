## Need to predeclare variables used from package main
use vars qw(
  $PROD_CONFIG
  $SITE_CONFIG
  $CC_CLIENT_PLATFORM
  %CC_UNIX_VOB2PROD
  %CC_NT_VOB2PROD
);


package CMBlueprint::Config;

#######################################################################

=head1 NAME

CMBlueprint::Config - reads the site-specific and product-specific configuration files.

=head1 EXPORTS

  read_configFile

=head1 DESCRIPTION

B<CMBlueprint::Config> reads the config files and populates global variables in
the main package.

=cut

###################################################################################
## Need the following variables from the main:: package
use vars qw($SITE_CONFIG @VOBFAMILY_LST $PROD_CONFIG $CC_CLIENT_PLATFORM);


use strict;
use vars qw(@ISA @EXPORT);
use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(read_configFile parseSPCFHook);

use CMBlueprint;

use File::Basename qw(dirname);

sub read_configFile {
  my $product_family = shift || "";
  my $dirname   = dirname($0);
  my $configdir = "$dirname/../config";

  $configdir = "$dirname/../../config" if ( ! -d $configdir );

  unless ($::SITE_CONFIG or @::VOBFAMILY_LST) {
     dprint "cfg", "# reading site-config in read_configFile!\n";
     my $site_cfg = "$configdir/site.cfg";

     package main;
     eval { require "$site_cfg"; };
     package CMBlueprint::Config;

     if ($@) {
        display_msg( "Error: Site Config File eval error in $site_cfg:\n  $@\n" .
            "Error in CC scripts/trigger installation.\n" .
            "Please contact your CC admin!\n" );
	exit(2);
     }
  }

  $product_family = $::VOBFAMILY_LST[0]  if (@::VOBFAMILY_LST == 1 and !$product_family);

  unless ($::PROD_CONFIG or $::CC_CLIENT_PLATFORM) {
     $product_family  or  $product_family  = getProductFamilyfromSiteCfg();
     my $prod_cfg = "$configdir/$product_family".'_trigger.cfg';
     dprint "cfg", "# reading '$product_family'-config in read_configFile!\n";

     package main;
     eval { require "$prod_cfg"; };
     package CMBlueprint::Config;

     if ($@) {
        display_msg( "Error: Prod-Config File eval error in $prod_cfg:\n  $@\n" .
            "Error in CC scripts/trigger installation.\n" .
            "Please contact your CC admin!\n" );
	exit(2);
     }
  }
}

############################################################################
sub getProductFamilyfromSiteCfg {

  my $vob = shift || $ENV{CLEARCASE_VOB_PN};
  my $product_family = "";


  if(!$vob)
  {
      # Being called during a trigger execution.
      my $ccavob = $ENV{CLEARCASE_AVOBS};
      if($ccavob eq "")
      {
	  display_msg("Error: CLEARCASE_AVOBS env var is not set. Please set CLEARCASE_AVOBS environment variable appriopriately.\n");
	  exit(2);
      }
      
      if($NT)
      {
	  $vob = (split(/;/,$ccavob))[0];
      }
      else
      {
	  $vob = (split(/:/,$ccavob))[0];
      }

      dprint(1,"CALLED OUTSIDE TRIGGER ... vob --> $vob\n");
  }

  $product_family = qx($CLEARTOOL describe -s -aattr ProductVOB vob:$vob);

  if($?)
  {
      display_msg("Error: Following cleartool subcommand failed:\n\tdescribe -s -aattr ProductVOB vob:$vob\n");
	exit(2);
  }
      
  # getting rid of the quotation marks.
  chomp($product_family);
  $product_family =~ s/^\"//;
  $product_family =~ s/\"$//;

  
  dprint(1,"PRODUCTFAMILY --> $product_family\n");
  return $product_family;

};

#################################################################
sub parseSPCFHook {
   my ($system, $product, $component, $feature) = @_;
   my $status=0;
   my %retval=();
   
   read_configFile();
   
   ## Look here for a config variable specifying
   ## some other code to invoke instead

   my $parseHookVal;
   my $parseHookKey = "parseCRSPCF";
   
   if ( $parseHookVal = $::PARSE_SPCF{$parseHookKey} ) {
      ## invoke custom-function instead
      ($status, %retval) = invokeParseHook($parseHookVal, $system, $product, $component, $feature);
      if($status !=0){
        display_msg( "Error: Hook for parsing $system $product $component $feature failed:$parseHookVal. \n");
      }
   }
	
   return $retval{'CRSPCF'};
}

#########################################################################

sub invokeParseHook {
    my ($parseHookVal, $system, $product, $component, $feature) = @_;
	
    my ($parseHook, @hookArgs) = ($parseHookVal);
	 
    my $hookRefType = (ref $parseHookVal) || "";
    ## Execute the hook
    my $hookStatus = 0;
    my $hookStatusMsg = "";
    my $retval;

    $hookRefType = (ref $parseHookVal) || "";
    if ($hookRefType eq 'ARRAY') {
        ($parseHook, @hookArgs) = @$parseHookVal;
        $hookRefType = (ref $parseHook) || "";
    }

	unshift (@hookArgs, $system, $product, $component, $feature);
    if ($hookRefType eq 'CODE') {
        ## Must be a ref to a function to invoke. Just invoke the function
        ## with the specified arguments. Use an eval just in case the given
        ## function is invalid or unknown/undefined.
        eval { ($hookStatus, $retval) = &{$parseHook}(@hookArgs) };
        if($@) {
            $hookStatus = 255; ## error invoking function
            $hookStatusMsg = "Perl Code for \"$parseHook\" specified".
                             " in configuration file Failed: $@";
        }else {
            unless(defined $retval) {
                $hookStatus = 255; ## error in return val of the function
                $hookStatusMsg = "Perl Code for key \"$parseHook\"".
                                 " specified configuration file".
                                 " return a reference to a hash. For this".
                                 " hash definition, please refer to the".
                                 " pods for the Config.pm package\n";
            }
        }
    }
    else {
      ## Unknown value-type
      $hookStatus = 255;
      $hookStatusMsg = "Specification error!! Please check the configuration file".
                       " for any errors in defining the value for \"$parseHook\". \n";
    }

    
   ## See if the hook succeeded or failed
   if ($hookStatus != 0) {
      ## parse-hook failed or aborted!!
      display_msg( "Error: $hookStatusMsg");
   }

   return ($hookStatus, %{$retval});

}




1;
