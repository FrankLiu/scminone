
package CMBlueprint::UI;

#######################################################################

=head1 NAME

CMBlueprint::UI - module to obtain information about user interaction with the CC GUI.
in the Vob

=head1 EXPORTS

get_text get_selection get_continue_choice
  
=head1 DESCRIPTION

B<CMBlueprint::UI> is a module is used for any CC GUI related information. It provides
subroutines to display information (e.g. a list of CRs) to the user 
and return his input (or selection).

=cut

#######################################################################

use strict;
use vars qw(@ISA @EXPORT);
use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(get_text get_selection get_continue_choice);

use vars qw($TMPDIR $CLEARPROMPT);

use CMBlueprint;

=head1 NAME

get_selection -- Display a list of items for selection.  Return the user's selection.

=head1 SYNOPSIS

 get_selection($list, $comment)

 where 

    $list is comma-separated list of items for selection
    $comment is the prompt


=head1 DESCRIPTION

Display the list of items for selection by using "clearprompt".  Return the user's selection.

=head1 RETURN VALUES

 Return ($rc, $selection) 

 where

        $rc - return value from clearprompt
 $selection - user's selection


=cut

##########################################################################

sub get_selection
{
    my %opts = (ref $_[0]) ? %{shift()} : ();
    my ($list, $comment) = @_;

    my $outfile = "$TMPDIR/response.$$";
    my $rc;

    if (DEBUGGING) {
       my @items = split /\s*,\s*/, $list;
       my $prompt = "$comment\nPlease choose one of the following:\n" .
                    join("\n",
                         (map {sprintf "%d. %s", $_+1, $items[$_]} 0..$#items)
                    )."\n";
       my $text = _get_debug_reply($prompt, $opts{'-name'}||"");
       if (length($text)) {
           my $selection = $items[$text - 1]||"";
           length($selection)  and  return (0, $selection);
       }
    }
    
    my $cmd = "$CLEARPROMPT list -outfile $outfile -items \"$list\" -prompt \"$comment\" -pre";

    $cmd = qq#"$cmd"# if $NT;

	if(!$NT) {
		delete $ENV{DISPLAY};
	} 
    `$cmd`;
    $rc  = $?;
    my $selection ="";
    unless($rc) {
        open (RESPONSE,"<$outfile");
        $selection = <RESPONSE>; # get the string from the file
        close (RESPONSE);
    }
    chomp($selection);
    unlink $outfile;
    return ($rc, $selection);
}

##########################################################################

=head1 NAME

get_text -- Prompt for text input from the user.  Return the user's input.

=head1 SYNOPSIS

 get_text($comment)

 where
    $comment is the prompt


=head1 DESCRIPTION

Prompt the user for text input. Return the user's input.

=head1 RETURN VALUES

 Return ($rc, $text) 

 where

        $rc - return value from clearprompt
      $text - user's input


=cut

##########################################################################
sub get_text
{
    my %opts = (ref $_[0]) ? %{shift()} : ();
    my $comment = shift;
    my $outfile = "$TMPDIR/response.$$";
    my $rc;

    if (DEBUGGING) {
       my $text = _get_debug_reply($comment, $opts{'-name'}||"");
       length($text)  and  return (0, $text);
    }
    
    my $cmd = "$CLEARPROMPT text -outfile $outfile -prompt \"$comment\" -pre";

	##whoever add the line below, I bet s/he did not test it!!
	##I just comment it out

    $cmd = qq#"$cmd"# if $NT;

	if(!$NT) {
		delete $ENV{DISPLAY};
	}
    `$cmd`;

    $rc = $?;
    open (RESPONSE,"<$outfile");
    my $text = <RESPONSE>; # get the string from the file
    close (RESPONSE);
    unlink $outfile;
    chomp($text) if defined $text;
	dprint ("Text being returned from get_text for the prompt :$text\n"); 
    return ($rc, $text);
}

##########################################################################

=head1 NAME

get_continue_choice -- Displays a message using clearprompt
and asks the user if the action should proceed or not.

=head1 SYNOPSIS

 get_continue_choice($msg)

 where

      $msg - message to be displayed

=head1 DESCRIPTION

Displays the message using clearprompt. The user can choose either
proceed or abort. The exit status of the clearprompt is returned back to
the user

=head1 RETURN VALUES

non-zero - if user chose abort
zero - if user chosl proceed.

=cut

#################################################################

sub get_continue_choice {

    my $retval = 0;
    my $msg = shift;

    my $ev = $ENV{CMBP_CONTINUE_CHOICE} || "";
    if (length $ev) {
       return (lc($ev) eq 'abort') ? 1 : 0;
    }

    $msg =~ s#\"#\\\"#g;
    my $cmd ="$CLEARPROMPT proceed -prompt \"$msg\" ";
	if(!$NT) {
		delete $ENV{DISPLAY};
	}
    prep_cmd(\$cmd);
    $retval = system($cmd);
    return $retval;
    
}

##########################################################################



