###############################################
# Use variables from site.cfg                 #
###############################################
use vars qw($CQ_REC_TYPE);

###############################################
# Use variables from $PROD_trigger.cfg        #
###############################################
use vars qw($DEVBRANCH_MERGELOCK_LOOKUP_ENABLED
            $INTBRANCH_MERGELOCK_LOOKUP_ENABLED);

package CMBlueprint::MetaData;

#######################################################################

=head1 NAME

CMBlueprint::MetaData - writes/retrieves ClearCase metadata to/from ClearCase objects.

=head1 EXPORTS

  MakeCrHlink     GetCrHlink     RemoveCrHlink   MakeOrigCrAttr AddFeatureidHlink AddDevintMergeListAttr GetCrAttr 
  FindCrBranches
  createmergelock querymergelock removemergelock GetBugHlinks GetCrFromCCEntName

=head1 DESCRIPTION

B<CMBlueprint::MetaData> writes ClearCase attributes, hyperlinks to ClearCase
branch types and file versions.  It also retrieves information from the attributes
and the hyperlinks.                                                 

=cut

###################################################################################

use strict;


use vars qw(@ISA @EXPORT @EXPORT_OK @order_of_vals @error_msg);
use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(MakeCrHlink GetCrHlink RemoveCrHlink MakeOrigCrAttr AddFeatureidHlink AddDevintMergeListAttr GetCrAttr 
             FindCrBranches AppendVobTagtoBranch
			createmergelock querymergelock removemergelock GetBugHlinks GetCrFromCCEntName);
@EXPORT_OK = qw(@order_of_vals @error_msg);

use vars qw($CLEARTOOL $TMPDIR $CQCC_HLTYPE $CQCC_ATTYPE $DEVINT_MERGELIST_ATTYPE);

use CMBlueprint;
use CMBlueprint::NamingPolicy;
use CMBlueprint::Vob;
use CMBlueprint::ClearQuest;
use CMBlueprint::ViewCache;

# Variables used in querymergelock
@order_of_vals = qw(hlinkid hlinkname arrow username timestamp intCR intModel from_br comment);
@error_msg = qw(invalid unlocked);

#################################################################

=head1 NAME

MakeCrHlink  -- Create an uni-directional text hyperlink instance of 'CrmRequest' hyperlink type.

=head1 SYNOPSIS

 MakeCrHlink($cc_object, $crid)

 where
 $cc_object  - $ENV{CLEARCASE_BRTYPE}@$ENV{CLEARCASE_VOB_PN}
               on post mkbrtype
             - $ENV{CLEARCASE_PN} on post checkout
             - $ENV{CLEARCASE_XPN} on pre-Checkin

 $crid       - ClearQuest CR ID


=head1 DESCRIPTION

Create an instance of I<CrmRequest> hyperlink from
$::CQ_REC_TYPE to $cc_object

=head1 RETURN VALUES

NONE

=cut

#################################################################

sub MakeCrHlink {
    my ($cc_object, $crid) = @_;

    my $cmd = qq#$CLEARTOOL mkhlink -unidir -ttext "$crid" -ftext "$::CQ_REC_TYPE" -nc $CQCC_HLTYPE \"$cc_object\"#;

    dprint($cmd . "\n");
    prep_cmd(\$cmd);
    `$cmd`;
}

#################################################################

=head1 NAME

MakeOrigCrAttr  -- Attach an attribute I<OrignatingCR> with value equal to ClearQuest CR Id.

=head1 SYNOPSIS

MakeOrigCrAttr($cc_object, $crid)

where
$cc_object  - $ENV{CLEARCASE_PN} on post checkout

$crid       - ClearQuest CR ID

=head1 DESCRIPTION

I<OriginatingCR> attribute signifes the ClearQuest CR which caused creation of the file element.  Attempt to attach an attribute I<OrignatingCR> with value equal ClearQuest CR Id.  If the attribute already exists on the element, it will fail.

=head1 RETURN VALUES

NONE

=cut

#################################################################
sub MakeOrigCrAttr {
    my ($cc_object, $crid) = @_;
    my $tmpfile = "$TMPDIR/orighlks$$.tmp";
    # object type involved in the operation that caused the trigger to fire: element type, branch type, etc..
    my $mtype = $ENV{CLEARCASE_MTYPE};
    my $cc_element = $cc_object;
    dprint("mtype is :$mtype: \n");
    $cc_element = $cc_object . $ENV{CLEARCASE_XN_SFX} unless ($mtype eq 'branch type');
    # This command will fail if attribute already exists, and that's fine...
    my $cmd = qq#$CLEARTOOL mkattr $CQCC_ATTYPE \\"$crid\\" $cc_element 2>$tmpfile#;
    dprint($cmd . "\n");
    prep_cmd(\$cmd);
    `$cmd`;
    unlink $tmpfile;
}

#################################################################

=head1 NAME

AddFeatureidHlink  -- Attach a hyperlink I<FeatureID> with ttext value equal to Feature ID number of the Dev-Int CR.

=head1 SYNOPSIS

AddFeatureidHlink($brtype, $crid)

where
$brtype  - Dev-Int CR branch type (fully qualified pathname)

$crid       - ClearQuest CR ID

=head1 DESCRIPTION

Attaches a hyperlink I<FeatureID> with ttext value equal to Feature ID number of the Dev-Int CR to the CR branch type.  If the CR FeatureID field is null or NFS (Non Feature Specific), NO FeatureID hyperlink shall be created so that no feature ID merge restrictions are immposed on the Dev-Int branch.

=head1 RETURN VALUES

Returns 0 on success
Returns 1 on failure

=cut

#################################################################
sub AddFeatureidHlink {
    my ($brtype, $crid) = @_;
    my ($rc, $feature) = ('','');
    my $featureid = '';
    my $featuretext = '';

    ($rc, $feature) = GetCRFeature($crid);
    return ($rc) if ($rc);

    # Split on tilde to get feature id number from description text
    ($featureid, $featuretext) = split('~', $feature);
    dprint (1, "featureid=$featureid  featuretext=$featuretext\n");

    # If feature ID is null or NFS, don't create FeatureID hyperlink
    if ($feature and ($feature !~ m/NFS/i) ) {
        my $cmd = qq#$CLEARTOOL mkhlink -ttext \"$featureid\" FeatureID  brtype:$brtype#;
        dprint(1, "$cmd" . "\n");
        prep_cmd(\$cmd);
        `$cmd`;
        return $?;
    } else {
        return 0;
    }
}

#################################################################

=head1 NAME

AddDevintMergeListAttr  -- Attaches an attribute I<devint-merge-list-required> with a numeric value equal to 0 or 1 on a Dev-Int branch type

=head1 SYNOPSIS

AddDevintMergeListAttr($brtype)

where
$brtype  - Dev-Int CR branch type (fully qualified pathname)

=head1 DESCRIPTION

Attaches an attribute I<devint-merge-list-required> with a numeric value equal to 0 or 1 on a Dev-Int branch type.  The attribute value shall be dependent on the current VOB family setting of the I<scm-merge-list-on> value.  If the I<devint-merge-list-required> attribute is set to 0 or does exist on a Dev-Int branch type, scMergeList shall not be required.  Otherwise, if the value is set to 1, scMergeList is required prior to any merge.

=head1 RETURN VALUES

Returns 0 on success
Returns 1 on failure

=cut

#################################################################
sub AddDevintMergeListAttr {
    my ($brtype) = @_;
    my $cmd = '';

    if ($ENV{MERGELIST_REQUIRED} and ($ENV{MERGELIST_REQUIRED} =~ m/^(0|1)$/) ) {
        $cmd = qq#$CLEARTOOL mkattr -nc -rep $DEVINT_MERGELIST_ATTYPE $ENV{MERGELIST_REQUIRED} brtype:$brtype#;
    }
    else {
        $cmd = qq#$CLEARTOOL mkattr -nc -rep -default $DEVINT_MERGELIST_ATTYPE brtype:$brtype#;
    }
        dprint(1, "$cmd" . "\n");
        prep_cmd(\$cmd);
        `$cmd`;
        return $?;
}

#################################################################

=head1 NAME

GetCrHlink -- Gets the CRID associated with the ClearCase object.

=head1 SYNOPSIS

 GetCrHlink($cc_object)

 where $cc_object = brtype:$ENV{CLEARCASE_BRTYPE}
 or    $cc_object = $ENV{CLEARCASE_PN}

=head1 DESCRIPTION

Calls GetBugHlinks() to get a list of CRs associated with
the ClearCase object.  A ClearCase object should have only
one instance of 'CrmRequest' hyperlink associated with it.
If it finds more than one or if it does not find any, then
it returns with fail status.  If there is just one hyperlink
instance, it returns the ClearQuest CR ID.

=head1 RETURN VALUES

 Returns 0 and CRID on success
 Returns 1 on failure.


=cut

#################################################################
sub GetCrHlink {
    my $cc_object = shift @_;
    my ($rc, $crid, $crid_origin, @crlist, %current, %retval);
    $crid = "";

    GetBugHlinks(\@crlist, \%current, $cc_object);
    dprint "GetBugIds(): hlinks: " . join(' ',@crlist) . "\n";

    if (not @crlist){
       ## See if it's on the branch-type
       my $brtype = "$ENV{CLEARCASE_BRTYPE}\@$ENV{CLEARCASE_VOB_PN}";
       dprint "perf", 
              "# couldnt find CrHlink on $cc_object - checking $brtype!\n";
       ($crid, $crid_origin, %retval) = GetCrFromCCEntName('BRTYPE', $brtype);
       $rc = $crid ? 0 : 1;
    }
    elsif (@crlist > 1){
       display_msg("More than one CR is associated with $cc_object");
       $rc = 1;
    }
    else {
       $crid = $crlist[0];
       $rc = 0;
    }

    return ($rc, $crid);
}

####################################################################################

=head1 NAME

RemoveCrHlink -- Removes 'CrmRequest' hyperlink instance on the ClearCase object.

=head1 SYNOPSIS

 RemoveCrHlink($cc_object, $crid)

 where $cc_object = $ENV{CLEARCASE_BRTYPE}
 or    $cc_object = $ENV{CLEARCASE_PN}
       $crid      = CRID


=head1 DESCRIPTION

Calls GetBugHlinks() to get all the hyperlinks that are attached to the specified ClearCase object.  
If the 'CrmRequest' hyperlink with the given CRID exists, then it removes it.

=head1 RETURN VALUES

NONE

=cut

#################################################################
sub RemoveCrHlink {
    my ($cc_object, $crid) = @_;
    my ($rc, @crlist, %current);

    GetBugHlinks(\@crlist, \%current, $cc_object);
    my $key = $::CQ_REC_TYPE . $crid;

    if ($current{$key}){
       my $cmd = qq#$CLEARTOOL rmhlink -nc $current{$key}#;
       dprint $cmd . "\n";
       prep_cmd(\$cmd);
       `$cmd`;
    }
}


#################################################################

=head1 NAME

GetCrAttr -- Gets the CRID associated with the ClearCase object.

=head1 SYNOPSIS

 GetCrAttr($cc_object)

 where $cc_object = brtype:$ENV{CLEARCASE_BRTYPE}
 or    $cc_object = $ENV{CLEARCASE_PN}

=head1 DESCRIPTION

A ClearCase object should have only one instance of 'OriginatingCR' attribute associated with it.  If it does not find any, then it returns with fail status.  If there is just one hyperlink instance, it returns the ClearQuest CR ID.

=head1 RETURN VALUES

 Returns 0 and CRID on success
 Returns 1 on failure.


=cut

#################################################################

sub GetCrAttr {
    my $cc_object = shift @_;
    my ($rc, $crid) = (1, "");

    my $tmpfile = "$TMPDIR/getcrattrs$$.tmp";
    my $cmd = "$CLEARTOOL desc -short -aattr $CQCC_ATTYPE $cc_object ";
    prep_cmd(\$cmd);
    $cmd .= " 2>$tmpfile |";

    dprint "GetAttr: $cmd\n";
    open(DUMP, $cmd);
    chomp($crid = <DUMP>);
    $crid =~ s/\"//g; #remove the quotes around the CRID string.
    dprint "GetAttr: CRID is :$crid: \n";
    close DUMP;
    unlink $tmpfile;

    $rc = 0 if ($crid);
    dprint "returning rc=$rc and crid=$crid \n";
    return ($rc, $crid);
}

#################################################################

=head1 NAME

FindCrBranches -- Find all branches in VOB associated with a CR

=head1 SYNOPSIS

 my @branches = FindCrBranches($crid, $vobtag)

 where $crid is a fully formatted CR-ID (with dbname and leading zeros)
 and   $vobtag is a vob pathname

=head1 DESCRIPTION

 For the given cr-id and vobtag, looks for all branch-types in
 the VOB that have the associated CR-ID attached as CQCC_ATTYPE
 metadata.

=head1 RETURN VALUES

 Returns a list of the names of all brtypes in the VOB that are 
 associated with the CR-ID using the CQCC_ATTYPE metadata.
 Returns empty list if there are no such branches or upon failure.


=cut

#################################################################

sub FindCrBranches($ ; $) {
   my $crid = shift;
   my $vobtag = shift || $ENV{CLEARCASE_VOB_PN} || "";
   my @brtypes = ();

   my $cmd = "$CLEARTOOL lstype -kind brtype -invob $vobtag".
                   " -fmt \"%n %[$CQCC_ATTYPE]SNa\\n |";

   open(LSBRTYPES, $cmd) or return @brtypes;

   while (<LSBRTYPES>) {
      chomp;
	  dprint ("\$_=>$_\n");
      my ($brtype, $attr) = split;
      next unless $attr;
      push @brtypes, $brtype  if ($attr eq "\"$crid\"");
   }
   close(LSBRTYPES);

   return @brtypes;
}

#################################################################

=head2 CREATEMERGELOCK

=item NAME

createmergelock -- creates a hyperlink of type "MergeLock" on
the specified branch-type so that only the user who created
the "MergeLock" can perform checkouts on instances of branches
corresponding to the branch-type.

=item SYNOPSIS

$result = createmergelock($int_brtype, \%opts);

=item ARGUMENTS

createmergelock($int_brtype, \%opts);

$int_brtype is the integration branch-type on which the
"MergeLock" hyperlink is to be created. The branch-type
specified will be checked for its naming convention - its
USAGE_PREFIX should match those allowed for integration
branches. See the B<CMBlueprint::NamingPolicy> module
for more details on the allowed branch-naming conventions.

\%opts is the hash-reference data-structure that contains the
information about the MergeLock details that will be used to
create the "MergeLock". The keys of the hash corresponding to
the hash reference that are used are:

    push, pull, help, intCR, c, from_br

One of push or pull keys must exist and help a true value,
but both cannot be specified at the same time. The push/pull
keys indicate the kind of integration model the developer
is using. The from_br key is used to specify the development
branch from which a developer/integrator is trying to merge
changes to the integration branch using a push/pull model
respectively. The -intCR key is used to specify the integration
CR associated with the integration branch. If this option is
used, then the integration CR specified will be checked for
its existence in the database. The 'c' key is used to store
any comments along with the "MergeLock" information.

The help key is used to call the function show_help that will
just print the man page for the calling script that uses this
perl module.

=item RETURN VALUES

  0 on success
  1 on failure

=cut

####################################################################

sub createmergelock {

my ($int_brtype, $opts)  = @_;

unless ($int_brtype) {
  display_msg("You must enter a name of the branch that ".
              "you want to obtain the mergelock for.\n\n");
  show_help();
  return 1;
}

# this just returns the name of the object, stripping it of the
# vob-portion of it.
my $int_brtype_name = describe_object("brtype:$int_brtype");

unless ($int_brtype_name) {
  display_msg("The branch type $int_brtype does not exist in the vob \n");
  return 1;

}

=begin _changed for efficiency

if ( exists($opts{push}) && exists($opts{pull}) ) {

  #print "The options push and pull are mutually exclusive... \n";
  display_msg("The options push and pull are mutually exclusive.\n\n");
  show_help();
  exit(1);

} elsif (! ( exists($opts{push}) && exists($opts{pull}) )) {

  display_msg("One of the options push/pull must be specified.\n\n");
  show_help();
  exit(1);

}

=end _changed for efficiency

=cut

unless ( $$opts{'push'} - $$opts{pull} ) {

  display_msg("Error in specifying arguments, this is either due to ".
              "specified both the push and pull options at same time ".
              "or else not specifying at at least one of them.\n\n");
  show_help();
  return 1;

}

my $username = $CURRENT_USER;
my $timestamp = get_timestamp();
# username time-stamp -intCR INT_CR_ID {-push|-pull} -from dev_branch_type
# " comment entered by the user using the -c option "

my $ttext .= "$username $timestamp -intCR:";

if (exists($$opts{'intCR'}) && $$opts{'intCR'} ) {
  my ($rc, $valid_cr) = CheckIsValidIntCR($$opts{'intCR'});
  if ($rc == CQ_VALID_CR) {
    #print "intcr is :$$opts{'intCR'}: and valid cr is :$valid_cr: \n";
    $ttext .= "$valid_cr" ;
  } else {
    return 1;
  }
}

$ttext .= " -push" if ( exists($$opts{'push'}) );
$ttext .= " -pull" if ( exists($$opts{'pull'}) );
my $from_br = $$opts{from_br};

if ( exists($$opts{from_br}) && $from_br ) {
  #print "from br type is :$from_br: \n";
  if ( describe_object("brtype:$from_br") )  {
    $ttext .= " -from_br:$from_br";
  } else {
    display_msg( "Warning: Branch type specified for from_br option '$from_br' is invalid \n",2);
    return 1;
  }
}

$$opts{c} =~ s/\"//g; # remove all quotes in the comment...

$$opts{c} =~ s/\\n/ /g; #remove all new lines..

$ttext .= " -comment:$$opts{c}" if (exists($$opts{c}) && $$opts{c} );
# or should we put this as part of the comment on the hyperlink.
#print "ttext is :$ttext: \n";

# first create an hyperlink called $MERGE_LOCK_HLTYPE on the specified int_brtype.

my $cmd = "$CLEARTOOL mkhlink -nc -ftext \"MergeLock\" -ttext \"$ttext\" $MERGE_LOCK_HLTYPE brtype:$int_brtype";
prep_cmd(\$cmd);
#print "CMD is :$cmd: \n";

system($cmd);

}
###########################################################################################

=head2 QUERYMERGELOCK

=over 6

=item NAME

querymergelock - queries for the presence of the MergeLock hyperlink on
specified branch-type.

=item SYNOPSIS

$result = querymergelock($int_branch_type, $hash_ref);

=item ARGUMENTS

The querymergelock is used as follows:

    $result = querymergelock($int_branch_type, $hash_ref);

The querymergelock function takes as arguments, the
integration_branch name and a hash reference. The presence
of the MergeLock hyperlink on the branch-type is determined
using the ClearCase "describe" command.

If the MergeLock exists on the specified integration branch,
then the hash corresponding to the hash reference is populated
with the details of the MergeLock hyperlink. The hash has the
following keys: username, timestamp, INT_CR_ID, push/pull,
dev_branch_type and comments. The keys are specified by the
array variable @order_of_vals. The values for the keys would
be values found on the hyperlink MergeLock on the specified
integration branch-type. The querymergelock returns 1 if
the MergeLock exists or if there was an error and 0 if the
MergeLock does not exist. The error could occur if the specified
branch-type does not exist.

=item RETURN VALUES

0 on success - the MergeLock exists on the specified branch-type
1 on failure - the MergeLock does not exists or if there was an error
(one error case could be - the specified branch-type does not exist).

=back

=cut

sub querymergelock {

  my ($int_brtype, $hashref) = @_;
  unless ($int_brtype && describe_object("brtype:$int_brtype")) {
    display_msg( "Error: invalid int_brtype specified... \n");
    $$hashref{'invalid'} = 1;
    return 0;
  }

  my $cmd = "$CLEARTOOL describe -l -ahlink $MERGE_LOCK_HLTYPE brtype:$int_brtype ";
  prep_cmd(\$cmd);
  #print "cmd is :$cmd: \n";
  open(CMD," $cmd | ");
  #ignore the first two lines, third line has the relevant attributes.
  my @lines = <CMD>;
  close (CMD);
  chomp(@lines);
  # parse the 3rd line.
  my $line = $lines[2];
  if ($line) {
    #print "line is :$line: \n";

    my @arr = split(' ',"$line");
    foreach (@arr) {
      s/\"//g;
    }
    #print "arr is @arr : \n";
    #%$hashref = map{$order_of_vals[$_] => $arr[$_] } (0..$#order_of_vals) ;
    # this line is replaced with the 3 lines below.
    %$hashref = map{$order_of_vals[$_] => shift @arr } (0..$#order_of_vals) ;
    # add remaining elements in array to the comments hash key.
    $$hashref{$order_of_vals[$#order_of_vals]} .= " @arr";
    #print "comment is $$hashref{comment} and array is @arr \n";

    return $$hashref{hlinkid} && ($$hashref{hlinkname} eq $MERGE_LOCK_HLTYPE) && $$hashref{username} ;
  }
    $$hashref{'unlocked'} = 1; # not used now, but might be required later ...
    return 0;

}

######################################################################################
=head2 REMOVEMERGELOCK

=over 6

=item NAME

removemergelock -- removes the "MergeLock" hyperlink on the specified
integration branch-type.

=item SYNOPSIS

removemergelock($int_br_type);

=item DESCRIPTION

removemergelock - removes the mergelock hyperlink of the specified
integration branch type. The presence of the "MergeLock" on the
specified br-type is first tested using the I<querymergelock>
function.

If the specified integration branch-type doesnot exist or the MergeLock
does not exist on the specifed br-type or if the current user does not
"own" the MergeLock, then the querymergelock function returns 1 and
hence the removemergelock functions also returns 1. If the current user
"owns" the MergeLock then the return value is the return status of the
"rmhlink" command used to remove the MergeLock on the specified
branch-type. This will be zero if if it successful.


=item RETURN VALUES

  0 - on success,
  non-zero - on failure.

=back

=cut

sub removemergelock {

my ($int_brtype) = shift;

my %mergelock;

my $logname = $CURRENT_USER;
if (querymergelock($int_brtype, \%mergelock) and
    lc($mergelock{username}) eq lc($logname))
{
    my $cmd = "$CLEARTOOL rmhlink $mergelock{hlinkid} ";
    prep_cmd(\$cmd);
    #print "CMD is :$cmd: \n";
    system($cmd);

} else {
    display_msg("No mergelock exists on the integration branchtype :$int_brtype: or it is not locked by $logname\n");
    return 1;
}

}

################################################################################
#==============================================================================
# RETURNS A LIST OF CRs THAT ARE ASSOCIATED WITH THE GIVEN VOB OBJECT
#==============================================================================
#################################################################

=head1 NAME

GetBugHlinks -- Returns a List of CRs that are associated with the given ClearCase object.

=head1 SYNOPSIS

 GetBugHlinks(\@buglinks, \%currentlinks, $cc_object)

 where

       \@buglinks     - Reference to an array
                        The function will return the ClearQuest
                        CR IDs in this array.

       \%currentlinks - Reference to a hash
                        The function will return all instances
                        of hyperlink type, "CrmRequest" in this
                        hash.

        $cc_object    - ClearCase object


=head1 DESCRIPTION

Gets instances of hyperlink type, "CrmRequest", that are attached to the ClearCase object.  The hash is populated with the hyperlink instance id (See example below).  The array is populated with ClearQuest CR IDs.


=head1 RETURN VALUES

 On SUCCESS, the input hash contains instances of type "CrmRequest"
             and the input array contains the ClearQuest CR IDs.


=head1 EXAMPLES

 <cmd-context> desc -long -ahlink CrmRequest brtype:dev-108@/usr/vob/expdoc

 dev-108
   Hyperlinks:
     CrmRequest@2342@/usr/vob/expdoc "Development_CR" -> "Proto00000108"


 In the above example, the hash would be populated as,

 "Development_CRProto00000108" => CrmRequest@2342@/usr/vob/expdoc



=head1 B<NOTES>

This function was provided by Rational in the out-of-the-box CQCC integration script.

=cut

#################################################################
sub GetBugHlinks {
    # return a list of bugIDs that have associations, and also a
    # hash (key: entdef concatted to bugID) for lookup of hlink ID later.
    # We're passing in an array and a hash as parameters BY REFERENCE.
    my ($buglinks, $currentlinks, $cc_object) = @_;

    my $i;

    my $tmpfile = "$TMPDIR/ghlks$$.tmp";
    my $cmd = "$CLEARTOOL desc -long -ahlink $CQCC_HLTYPE $cc_object";
    prep_cmd(\$cmd);
    $cmd .= " 2>$tmpfile |";

    dprint "GetBugHlinks(): $cmd\n";
    open(DUMP, $cmd);
    while (<DUMP>) {
        if (/^\s+(\S+)\s+"(\S+)"\s+->\s+"(\S*)"/) {
            $$buglinks[$i++] .= $3;
            my $key = $2 . $3;
            $$currentlinks{$key} = $1;  # concat entitydef & bugID, save the hlink's ID
            dprint "hlink found: $1 $2 -> $3\n";
        }
    }
    close DUMP;
    unlink $tmpfile;
    return;
}

############################################################################

=item B<GetCrFromCCEntName>

Attempt to obtain a CR ID from branch-type, label-type names and view tag. 
Returns the list ($crid, $crid_origin). Upon success, $crid is a CR ID and
$crid_origin is one of ("mergelock", "brtype", "viewtag","lbname") to indicate 
if the CR-ID was associated with the branch-itself, or with a
mergelock upon the branch or with the view tag or label type. An optional 
hash-ref may be supplied as the first argument to "fine-tune" the lookup process. [Right now,
only C<-mergelock_lookup> and C<-opcache_lookup> are supported].

If $crid is empty, then $crid_origin will be "sandbox" if
the branch name indicates it is for sandbox development,
otherwise $crid_origin will also be empty.

USAGE:
GetCrFromCCEntName( {'-mergelock_lookup' => 1, '-opcache_lookup' => 1},'BRTYPE', $brtype );
GetCrFromCCEntName('VWTAG', $vwtag );

=cut

sub GetCrFromCCEntName {
  my %opts = (ref $_[0]) ? %{shift()} : ();
  my $CCEntType = shift;
  my $CCEntName = shift;
  my $getCRRel = shift;
  # Before this, the mergelock takes the precedence....
  # so try to get the cr from the merge lock first...


  my ($rc, %mergelock, $crid, $crid_origin);
  my %retval =();
  if ($CCEntType eq 'BRTYPE') {
	%retval = ParseBrtypeName($CCEntName, $getCRRel);
  }elsif ($CCEntType eq 'VWTAG'){
	%retval = ParseViewTag($CCEntName, $getCRRel);
  }elsif ($CCEntType eq 'LBTYPE'){
	%retval = ParseLbtypeName($CCEntName);
  }
  if ($CCEntType eq 'BRTYPE'){
    if  ( (defined $opts{'-mergelock_lookup'} && $opts{'-mergelock_lookup'})
        and ( ($retval{IS_DEV_USAGE} && $::DEVBRANCH_MERGELOCK_LOOKUP_ENABLED)
            or
             ($retval{IS_INT_USAGE} && $::INTBRANCH_MERGELOCK_LOOKUP_ENABLED)
           )
        )
    {
       if (querymergelock($CCEntName, \%mergelock)) {
         # since the mergelock exists, the current user owns the mergelock -
         # otherwise the pre-checkout trigger would have caught the conflict.
         # so we do not need to check if the current user owns the mergelock,
         # just use the intCR id associated with the mergelock.
         $crid = (split(":","$mergelock{intCR}"))[1];
         $crid_origin = $crid ? "mergelock" : "";
         dprint("Integration CRID associated with the merge lock is:$crid: \n");
         dprint("Username associated with the merge lock is:$mergelock{username}: \n");
         return ($crid, $crid_origin);
       }
    }
    else {
         dprint ("perf", "# bypassed mergelock-lookup for brtype:$CCEntName\n");
    }
  }	
  ## If its not on the mergelock, see if its in the branch-name,
  if ($retval{IS_SANDBOX_USAGE}) {
    ($crid, $crid_origin) = ("", "sandbox");
  }
  elsif ($retval{ORIG_DBID}) {
    ($rc, $crid) = FormatCrId($retval{ORIG_DBID});
	unless ($rc) {
	   if ($CCEntType eq 'BRTYPE') {
	       $crid_origin = "brname";
		   dprint ("perf", "# bypassed CrAttr-lookup for brtype:$CCEntName\n"); 
       }
	   elsif ($CCEntType eq 'VWTAG'){
	       $crid_origin = "viewtag";
       }
	   elsif ($CCEntType eq 'LBTYPE'){
	       $crid_origin = "lbname";
       }		
	}

  }
  elsif ( (defined $opts{'-opcache_lookup'} and $opts{'-opcache_lookup'}) ) {
       my $OpCache_ref;
      ## Else try the opcache before looking at the CrAttr
      $OpCache_ref  = fetch_opcache();
		
      ($crid, $crid_origin) = @$OpCache_ref{'CRID','CRID_ORIGIN'};
      if ($crid and $crid_origin eq 'brtype') {
         dprint ("perf", "# Got brtype:$CCEntName cr-id $crid from opcache\n");
      }
      else { 
         ($rc, $crid) = GetCrAttr("brtype:$CCEntName");
         dprint ("# After getting CR id from GetCrAttr crid is :$crid: rc is :$rc:\n");
         $crid_origin = $crid ? "brtype" : "";
      }
  }

  return ($crid, $crid_origin, %retval);
}

#########################################################################

=head1 NAME

AppendVobTagtoBranch -- Append vob pathname to the branch name

=head1 SYNOPSIS

 my $brName = AppendVobTagtoBranch($brName, $vobtag)

 where $brName is the branch name which can have the vob pathname
 and   $vobtag is a vob pathname to be appended to or replace the vob 
 pathname in $brName

=head1 DESCRIPTION

 If the branch name does not have the vob pathname, then appends the
 vob pathname of the specified vob to it, else replaces the vob pathname 
 in the branch with the vob pathname of the specified vob. This sub 
 also ensures that the vobtag specified is a valid one.
 
 This sub is used by the mk_mergelock and rm_mergelock scripts.

=head1 RETURN VALUES

 Returns the branch name with the appended vob pathname. 
 
=cut


sub AppendVobTagtoBranch {
	
	my ($brName, $vobtag) = @_;
	my $brvob = ($brName =~ /@(\S+)$/) ? $1 : "";

	$vobtag = length $brvob ? $brvob : '.' unless ($vobtag);

	$vobtag = ct_subcmd( { -saveout => 1,
                          -abort => "Cannot determine VOB to use: Please specify a valid vobtag or else make sure your". 
						  " current working directory is within a VOB" },
                         "describe -short vob:$vobtag" );
	chomp($vobtag);

	if(length $vobtag and ($brvob ne $vobtag)) {
		if(length $brvob) {
			dprint "Replacing the vobtag:$1 in brtype:$brName with $vobtag\n";
			$brName =~ s/\Q$1\E$/$vobtag/;
		}
		else {
			$brName .= '@'.$vobtag;
		}	
	}
	return $brName;
}


1;


