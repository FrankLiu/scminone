package CQCCIntegration;


=head1 NAME

CQCCIntegration.pm -- Base class for CQ/CC integration.  Creates a socket connected to a CQCC Integration server.

=head1 SYNOPSIS

use CQCCIntegration;

# Can be constructed with no explicit values.  The values for the $CQCC_SERVER and $CQCC_SERVERPORT environment variables will be used (provided as part of CMBP). 

$cq = CQCCIntegration->new();

$cq = CQCCIntegration::->new( serverName => 'il27app17.cig.mot.com',
                                     serverPort => '10002' );

=head1 DESCRIPTION

The CQCCIntegration.pm module provides a socket connection to a CQCC Integration server to be used by child modules.

=head1 PROGRAMMING STYLE

CQCCIntegration.pm provides an object-oriented interface.  Multiple Session objects can be created to use with multiple CQ databases.  Creating multiple objects for the same database is not prohibited, but serves no value.  Interface methods are provided to post queries and retrive results and error messages.

=cut

=head2 CREATING A CCCQIntegation OBJECT

=over 3

A CCCQIntegation object requires 2 parameters:

=item 1. Name of the ClearCase/ClearQuest Integration server.

This can also be the IP address.  Both 'il27app17.cig.mot.com' and '136.182.21.158' will work.  If this value is not explicitly provided to new(), the constructor will assign the value stored in the $CQCC_SERVER environment variable.

=item 2. Port number on the ClearCase/ClearQuest Integration server.

If this value is not explicitly provided to new(), the constructor will assign the value stored in the $CQCC_SERVERPORT environment variable.


=item 3. Use diagnostic error messages to STDERR (Optional).

If a non-zero value is set for stderrMsg, the Perl Carp module is used to die with an error message to STDERR.  Since this tends to alarm end users, the default is "off" (0).  If you intend to use the default setting, be sure to check the value returned by new() and handle any failures appropriately.

=cut

=head1 REVISION HISTORY

=item 1. INDEV00007448 (IJONES1)

Initial.  Prototyped in DCML/CQ integration.  Converted existing DCML logic into modules.

=cut


use strict;
use Carp;

# Block hides default values
{

    # Default values for attributes
    my(%_attrData) = (  _serverName => undef,
                        _serverPort => undef,
                        _stderrMsg  => undef ); 

    sub _defaultKeys{ keys(%_attrData); }

    sub _setDefault{  $_attrData{$_[1]}; }
}


sub new{

    my($caller) = shift;
    my( %arg ) = @_;

    my($class) = ref(  $caller ) || $caller;
    my($self) = bless( {}, $class );

    my($attrib);

    foreach $attrib (_defaultKeys()) {
        my($argname) = ($attrib =~ /^_(.*)/);

        if   (exists($arg{$argname})) { $self->{$attrib} = $arg{$argname}; }
        elsif(ref($caller))           { $self->{$attrib} = $caller->{$argname}; }
        else                          { $self->{$attrib} = _setDefault($argname); }
    }

    $self->_initialize();

    return($self);
}

################################################################################
#
# _setup
#
# make sure the required values have been defined 
#
################################################################################
sub _initialize{

    my( $self ) = shift;

    unless( $self->{_serverName} ){
        unless( $self->{_serverName} = $ENV{'CQCC_SERVER'} ){
            $self->{_stderrMsg} ? croak( "No value for serverName. Must explicitly set value, or set \$CQCC_SERVER." )
                                : return();
        }
    }
    unless( $self->{_serverPort} ){
        unless( $self->{_serverPort} = $ENV{'CQCC_SERVERPORT'} ){
            $self->{_stderrMsg} ? croak( "No value for serverPort. Must explicitly set value, or set \$CQCC_SERVERPORT." )
                                : return();
        }
    }
}

1;
