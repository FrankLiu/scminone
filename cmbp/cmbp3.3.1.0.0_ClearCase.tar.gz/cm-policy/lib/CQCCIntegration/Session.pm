package CQCCIntegration::Session;


use base qw(CQCCIntegration);
use CQCCIntegration;

=head1 NAME

Session.pm -- ClearQuest user session class for CQ/CC integration.  Allows simple query and extended query (xquery) of CQ records.

=head1 SYNOPSIS

use CQCCIntegration::Session;

# Can be constructed with no explicit values.  The values for the $CQCC_SERVER and $CQCC_SERVERPORT environment variables will be used (provided as part of CMBP). 

$cq = CQCCIntegration::Session->new();

$cq = CQCCIntegration::Session->new( serverName => 'il27app17.cig.mot.com',
                                     serverPort => '10002' );

# query() tests if matching values exist for given fields in a record. Returns 0 or 1.

$cq->query( record => 'Development_CR',
            id     => 'MOTSB00001234',
            state  => 'Assigned' );

# xquery() returns values for given fields for a record. Returns 0 or 1.

$cq->xquery( record => 'Development_CR',
             id     => 'MOTSB00001234',
             fields => 'state,technical_authority' );

# list query() returns values for given fields for a given record type. Returns 0 or 1.

$cq->listquery( record      => 'Development_CR',
                filters     => 'state|EQ|Closed',
                fields      => 'id' );

# If a failure occured, the error is accessible through getError().

print $cq->getError(), "\n";

# xquery results are accessible through getResults().

%results = $cq->getResults();

=head1 DESCRIPTION

The Session.pm module provides a simple and fast interface to CQ, through which 2 types of queries can be posted.  A query() will determine if "field 'a' has value 'x' for record 'z'" (i.e. "is the state of CR MOTSB00001234 Assigned?").  An xquery will return the values for specified fields for the given record (i.e. "What are the values for the 'state' and 'technical_authority' fields for CR MOTSB00001234?").

=head1 PROGRAMMING STYLE

Session.pm provides an object-oriented interface.  Multiple Session objects can be created to use with multiple CQ databases.  Creating multiple objects for the same database is not prohibited, but serves no value.  Interface methods are provided to post queries and retrive results and error messages.

=cut

=head2 CREATING A SESSION OBJECT

=over 3

A Session object requires 2 parameters:

=item 1. Name of the ClearCase/ClearQuest Integration server.

This can also be the IP address.  Both 'il27app17.cig.mot.com' and '136.182.21.158' will work.  If this value is not explicitly provided to new(), the constructor will assign the value stored in the $CQCC_SERVER environment variable.

=item 2. Port number on the ClearCase/ClearQuest Integration server.

If this value is not explicitly provided to new(), the constructor will assign the value stored in the $CQCC_SERVERPORT environment variable.

=item 3. Use diagnostic error messages to STDERR (Optional).

If a non-zero value is set for stderrMsg, the Perl Carp module is used to die with an error message to STDERR.  Since this tends to alarm end users, the default is "off" (0).  If you intend to use the default setting, be sure to check the value returned by new() and handle any failures appropriately.

=cut

=head2 POSTING A QUERY

The query method can be used to determine if the field values for a given record match those provided.  query returns a '1' if the values match, '0' if they do not, or there was an error.

$cq->query( record => 'Development_CR',
            id     => 'MOTSB00001234',
            state  => 'Assigned' );

All query parameters are entered as <field_name> => '<field_value>'.  Each combination is comma seperated.

REQUIRED PARAMETERS:

=item 1. record 

Currently, only the 'Development_CR' and 'Work_Product' record types are supported.

=item 2. id or identifier

The unique id for the record type.  This is 'id' for Development_CR's and 'identifier' for Work_Product's.

OPTIONAL PARAMETERS:

=item 1. additional field

Any additional field.

=back

=cut

=head2 POSTING AN EXTENDED QUERY (xquery)

The xquery method can be used to return field values for a given record.  xquery returns a '1' if the query succeeds, '0' if there was an error.

$cq->xquery( record => 'Development_CR',
             id     => 'MOTSB00001234',
             fields => 'state,technical_authority' );

All query parameters are entered as <field_name> => '<field_value>'.  Each combination is comma seperated.

REQUIRED PARAMETERS:

=item 1. record 

Currently, only the 'Development_CR' and 'Work_Product' record types are supported.

=item 2. id or identifier

The unique id for the record type.  This is 'id' for Development_CR's and 'identifier' for Work_Product's.

=item 3. fields

A comma seperated list of fields whose values should be retrieved

abstract => 'Some new abstract information'

=head2 POSTING A LIST QUERY (listquery)

The list method can be used to return field values for a given record type.  listquery returns a '1' if the query succeeds, '0' if there was an error.

$cq->listquery( record      => 'Development_CR',
                filters     => 'state|EQ|Closed',
                fields      => 'id' );

This example is requesting 'All ids for Development_CR records where state is equal to Closed'

REQUIRED PARAMETERS:

=item 1. record 

Currently, only the 'Development_CR' and 'Work_Product' record types are supported.

=item 2. filters

Each filter consists of 3 parts, pipe ('|') seperated.  The first part is the field identifier, the second part is a boolean operator (EQ, NEQ, LIKE, etc.), and the third part is the value.  For example, a filter to identify records assigned to 'cquser1' would be 'technical_authority|LIKE|cquser1'.  In order to be useful, the record parameter would be set to 'Development_CR'.

=item 3. fields

Like xquery, the fields parameter is a comma seperated list of field values to return for records that match the filter parameter.

=head2 RETRIEVING EXTENDED QUERY AND LISTQUERY RESULTS:

The getResults method will return a hash containing the results from the last call to xquery() or listquery().  The hash is keyed on the field names provided fields parameter.

my( %results ) = getResults();

foreach( keys( %results ) ){
    print( "$_=$results{_};    
}

NOTE: For fields that contain multiple values, all values will be captured in a comma separated string.

i.e. Targetted_CRs => 'MOTSB00001234,MOTSB00009876'

=head2 RETRIEVING ERRORS

The error generated from the last call to query() or xquery() can be retrieved by getError().

print( "Something bad happened! ", getError(), "\n" );

=cut

=head1 REVISION HISTORY

=item 1. INDEV00007448 (IJONES1)

Initial.  Prototyped in DCML/CQ integration.  Converted existing DCML logic into modules.

=cut


use strict;
use Carp;
use Socket;

$| = 1;

{
	# Default values for attributes
	my(%_attrData) = ( _socket	      => undef,
                       _querystring   => undef,
                       _exitValue     => undef,
                       _errorMessage  => undef,
                       _rawResults    => undef,
                       _formatResults => {} );

	sub _defaultKeys { keys(%_attrData); }

	sub _setDefault { $_attrData{$_[1]}; }
}


sub new{

	my($caller, %arg) = @_;
	my($self) = shift()->SUPER::new(@_);
	my($attrib) = 0;
  
        # User may want 'silent' failures (_stderrMsg is NULL).
        #  Check if paernt constructor returned NULL
        unless( $self ){ return( 0 ); }

	foreach $attrib (_defaultKeys()) {
		my($argname) = ($attrib =~ /^_(.*)/);
        
		if (exists($arg{$argname}))	{ $self->{$attrib} = $arg{$argname}; }
		elsif (ref($caller))		{ $self->{$attrib} = $caller->{$argname}; }
		else				        { $self->{$attrib} = _setDefault($argname); }
	}
    
        $self->_setup();

        # _errorMessage just signals a problem.  It serves no use to the user, since
        #  the returned value (a ref to our object) will be undef.  Set stderrMsg to
        #  non-zero (!=0) for error messages (from Carp) to stderr.
        $self->{_errorMessage} ? return( )
                               : return( $self );
}


sub _setup{

    my( $self ) = shift;
    
    # Socket setup
    my( $sockaddr ) = 'S n a4 x8';
    my( $name, $aliases, $proto) = getprotobyname('tcp');
    my( $localhost ) = $ENV{COMPUTERNAME} || `hostname`;
 
    my( $thisaddr ) = (gethostbyname( $localhost ))[4];
    my( $rthis ) = pack( $sockaddr, AF_INET, 0, $thisaddr );
    
    my $thataddr;
    
    my( $thataddr ) = (gethostbyname( $self->{_serverName} ))[4];
    my( $there ) = pack( $sockaddr, AF_INET, $self->{_serverPort}, $thataddr );
    
    unless( socket( RSVR, PF_INET, SOCK_STREAM, $proto ) ){
        if( $self->{_stderrMsg} ){ croak( "Can't create server socket: $!" ); }
        $self->{_errorMessage} = "Can't create server socket: $!";
        return();
    }

    unless( connect( RSVR, $there ) ){
        if( $self->{_stderrMsg} ){ croak( "Can't connect to CQ server [$self->{_serverName}]: '$!'" ); }
        $self->{_errorMessage} = "Can't connect to CQ server [$self->{_serverName}]: '$!'";
        return();
    }

    select( RSVR ); $| = 1; select( STDOUT );
    
    $self->{_socket} = *RSVR;
}


sub _setQuery{

    my( $self )    = shift;
    my( $hashRef ) = shift;

    # Protocol requires action and rectype to be the first 2 parameters
    $self->{_queryString} = 'action=' . $$hashRef{action} . ';';
    delete( $$hashRef{action} );
    $self->{_queryString} .= 'rectype=' . $$hashRef{record} . ';';
    delete( $$hashRef{record} );
             
    foreach( keys( %$hashRef ) ){
     
      # Swap reserved chars
      $$hashRef{$_} =~ s/"/__CQCC_INT_DBLQUOT__/g;
      $$hashRef{$_} =~ s/;/__CQCC_INT_SEMICOL__/g;
      $$hashRef{$_} =~ s/\n/__CQCC_INT_NEWLINE__/g;
      
      $self->{_queryString} .= $_ . '=' . $$hashRef{$_} . ';'; 
    }
    $self->{_queryString} .= "\n";
}

sub _processRequest{

    my( $self ) = shift;

    # Flush to prepare for new request results
    undef( $self->{_errorMessage} );
    undef( $self->{_exitValue} );
    undef( $self->{_rawResults} ); 

    # Reset the socket.  Do it this way until the blocking issue is resolved. . .
    $self->_setup();

    if( $self->{_errorMessage} ){
        # If setup fails, _errorMessage will be set.  Set exit value, so the calling method can
        #  throw an appropriate error.
        $self->{_rawResults} = $self->{_errorMessage};
        $self->{_exitValue} = '999';
        return();
    }

    my( $socketRef ) = $self->{_socket};

    print $socketRef $self->{_queryString};

    my( $buffer );
    undef( $buffer );

    while( defined( $buffer = <$socketRef> ) ){

        chomp $buffer; 

	unless( defined( $self->{_exitValue} ) ){ 
        	# If the request gets mangled or there's a fatal error, the server will return a single '0'
        	$buffer =~ s/^(\d)://;
        	$self->{_exitValue} = $1;
	}

        # In case there's multi-line output
        $self->{_rawResults} .= $buffer;
    }
    $self->{_rawResults} =~ s#\\0#\n#g;
    unless( defined( $self->{_exitValue} ) ){ $self->{_exitValue} = '999'; }
}


sub query{

    my( $self ) = shift;
    my( %argHash ) = @_;
    
    $argHash{action} = 'query';
    
    $self->_setQuery( \%argHash );    
    $self->_processRequest();

    # If the request gets mangled, the server will return a single '0'
    # For query - returns a single '0' (fatal error), '1' (query success), or '2' (query fail)
    # For all others - '0' (fatal error), or '1:<field1>=<value1>;<fieled2>=<value2>...' 
    if(    $self->{_exitValue} eq '0' ){ $self->{_errorMessage} = 'Error: Cannot complete requested action ' . $self->{_rawResults}; return( 0 ); }
    elsif( $self->{_exitValue} eq '1' ){ $self->{_errorMessage} = ''; return( 1 ); }
    elsif( $self->{_exitValue} eq '2' ){ $self->{_errorMessage} = 'Error: No records found to match query parameters ' . $self->{_rawResults}; return( 0 ); }
    else                               { $self->{_errorMessage} = 'Error: Cannot complete requested action, ClearQuest returned an unknown value ' . $self->{_rawResults}; return( 0 ); }    
}

sub xquery{

    my( $self ) = shift;
    my( %argHash ) = @_;

    $argHash{action} = 'xquery';

    $self->_setQuery( \%argHash );

    $self->_processRequest();    

    foreach( split( /;/, $self->{_rawResults} ) ){
        my( $field, $value ) = split( /=/, $_ );
        
        $value =~ s/\\2/"/g;
        $value =~ s/\\1/;/g;
        $value =~ s/\\0/\n/g;
      
        # If a field contained multiple values, they will have the same key.  Create
        #  a comma seperated string to hold all the values.        
        if( $self->{_formatResults}{$field} ){
              $self->{_formatResults}{$field} .= ',' . $value;
        }
        else{ $self->{_formatResults}{$field}  = $value; }
    }
        
    # The return codes from CQ mean slightly different things
    # Do we need to define the list of possible actions in site.cfg??
    if(    $self->{_exitValue} eq '0' ){ $self->{_errorMessage} = 'Cannot complete requested action [' .  $self->{_rawResults} . ']'; return( 0 ); }
    elsif( $self->{_exitValue} eq '1' ){ $self->{_errorMessage} = ''; return( 1 ); }
    else                               { $self->{_errorMessage} = 'Cannot complete requested action, ClearQuest returned an unknown value [' .  $self->{_rawResults} . ']'; return( 0 ); }
}


sub listquery{

    my( $self ) = shift;
    my( %argHash ) = @_;

    $argHash{action} = 'listquery';

    $self->_setQuery( \%argHash );

    $self->_processRequest();    

    foreach( split( /;/, $self->{_rawResults} ) ){
        my( $field, $value ) = split( /=/, $_ );
        
        $value =~ s/\\2/"/g;
        $value =~ s/\\1/;/g;
        $value =~ s/\\0/\n/g;
      
        # If a field contained multiple values, they will have the same key.  Create
        #  a comma seperated string to hold all the values.        
        if( $self->{_formatResults}{$field} ){
              $self->{_formatResults}{$field} .= ',' . $value;
        }
        else{ $self->{_formatResults}{$field}  = $value; }
    }
        
    # The return codes from CQ mean slightly different things
    # Do we need to define the list of possible actions in site.cfg??
    if(    $self->{_exitValue} eq '0' ){ $self->{_errorMessage} = 'Cannot complete requested action [' .  $self->{_rawResults} . ']'; return( 0 ); }
    elsif( $self->{_exitValue} eq '1' ){ $self->{_errorMessage} = ''; return( 1 ); }
    else                               { $self->{_errorMessage} = 'Cannot complete requested action, ClearQuest returned an unknown value [' .  $self->{_rawResults} . ']'; return( 0 ); }
}
# UNSUPPORTED!
sub sqlquery {

    my $self = shift;
    my (%argHash) = @_;

    $argHash{'action'} = 'sqlquery';
    $self->_setQuery( \%argHash );
    $self->_processRequest();    
}

sub getError{

    my( $self ) = shift;
    
    return( $self->{_errorMessage} );
}

sub getResults{

    my( $self ) = shift;
    
    if( ref( $self->{_formatResults} ) ){ return( %{$self->{_formatResults}} ); }
    else{                                 return( my( %empty ) ); }
}

1;
