package CQCCIntegration::Session::Admin;


use base qw(CQCCIntegration::Session);
use CQCCIntegration::Session;


=head1 NAME

Admin.pm -- ClearQuest Administrator session module for CQ/CC integration.  Extends Session.pm to allows creation of Work_Product records, and the edit of Work_Product and Development_CR records.

=head1 SYNOPSIS

use CQCCIntegration::Session::Admin;

# Can be constructed with no explicit values.  The values for the $CQCC_SERVER and $CQCC_SERVERPORT environment variables will be used (provided as part of CMBP). 

$cq = CQCCIntegration::Session::Admin->new();

$cq = CQCCIntegration::Session::Admin->new( serverName => 'il27app17.cig.mot.com',
                                     serverPort => '10002' );

# edit() cahnges the values for given fields in a record. Returns 0 or 1.

$cq->edit( record   => 'Development_CR',
           id       => 'MOTSB00001234',
           abstract => 'Some new abstract information' );

# create() creates a new instance of the given record type. Returns 0 or 1.

$cq->create( record             => 'Work_Product',
             identifier         => 'Some_WP_ID',
             configuration_item => 'DCML:WSG_SCM_DE',
             product_family     => 'WSG_Metrics_Dev',
             description        => 'A descriptive description',
             title              => 'The Really Big Title' );

# If a failure occured, the error is accessible through getError().

print $cq->getError(), "\n";

=head1 DESCRIPTION

The Session.pm module provides a simple and fast interface to CQ, through which 2 types of queries can be posted.  A query() will determine if "field 'a' has value 'x' for record 'z'" (i.e. "is the state of CR MOTSB00001234 Assigned?").  An xquery will return the values for specified fields for the given record (i.e. "What are the values for the 'state' and 'technical_authority' fields for CR MOTSB00001234?").  Additionally, the query methods from CQCCIntegration::Session are inherated (See POD for Session.pm for more details)..

=head1 PROGRAMMING STYLE

Admin.pm provides an object-oriented interface.  Multiple Session objects can be created to use with multiple CQ databases.  Creating multiple objects for the same database is not prohibited, but serves little value.  Interface methods are provided to create and edit records, and retrive results and error messages.

=cut

=head2 CREATING AN ADMIN OBJECT

=over 3

An Admin object requires 2 parameters:

=item 1. Name of the ClearCase/ClearQuest Integration server.

This can also be the IP address.  Both 'il27app17.cig.mot.com' and '136.182.21.158' will work.  If this value is not explicitly provided to new(), the constructor will assign the value stored in the $CQCC_SERVER environment variable.

=item 2. Port number on the ClearCase/ClearQuest Integration server.

If this value is not explicitly provided to new(), the constructor will assign the value stored in the $CQCC_SERVERPORT environment variable.

=cut

=head2 CREATING A RECORD

The create method can be used to create a new Work_Product record.  create() returns a '1' if the record is created, '0' if it is not, or there was an error.

$cq->create( record             => 'Work_Product',
             identifier         => 'Some_WP_ID',
             configuration_item => 'DCML:WSG_SCM_DE',
             product_family     => 'WSG_Metrics_Dev',
             description        => 'A descriptive description',
             title              => 'The Really Big Title' );

All create() parameters are entered as <field_name> => '<field_value>'.  Each combination is comma seperated.

REQUIRED PARAMETERS:

=item 1. record 

Currently, only the 'Development_CR' and 'Work_Product' record types are supported.

=item 2. identifier

The unique identifier for the new Work_Product.

=item 3. configuration_item

The configuration_item to associate with the new Work_Product record.

=item 4. product_family

The product_family to associate with the new Work_Product record.

=item 5. description

A description of the new Work_Product record.

=item 6.

The title of the new Work_Product record.

=back

=cut

=head2 EDITING A RECORD

The edit method can be used to edit field values for a given record.  edit() returns a '1' if the edit succeeds, '0' if there was an error. NOTE: At this time, only Developemnt_CR and Work_Product record types can be edited.

$cq->edit( record   => 'Development_CR',
           id       => 'MOTSB00001234',
           abstract => 'Some new abstract information' );

All edit() parameters are entered as <field_name> => '<field_value>'.  Each combination is comma seperated.

REQUIRED PARAMETERS:

=item 1. record 

Currently, only the 'Development_CR' and 'Work_Product' record types are supported.

=item 2. id or identifier

The unique id for the record type.  This is 'id' for Development_CR's and 'identifier' for Work_Product's.

=item 3. <field_name>

The new value for the given field

=cut

=head2 EDITING A RECORD

RETRIEVING ERRORS

The getError method returns the error (if any) that was generated by the last call to edit(), or create().

my( $errorMsg ) = $cq->getError();

=cut

=head1 REVISION HISTORY

=item 1. INDEV00007448 (IJONES1)

Initial.  Prototyped in DCML/CQ integration.  Converted existing DCML logic into modules.

=cut

  
use strict;


sub new{

	my($caller, %arg) = @_;
	my($self) = shift()->SUPER::new(@_);
    
	return($self);
}


sub edit{

    my( $self ) = shift;
    my( %argHash ) = @_;
    
    $argHash{action} = 'edit';
    
    $self->_setQuery( \%argHash );    
    $self->_processRequest();

    # If the request gets mangled, the server will return a single '0'
    # For query - returns a single '0' (fatal error), '1' (query success), or '2' (query fail)
    # For all others - '0' (fatal error), or '1:<field1>=<value1>;<field2>=<value2>...' 
    if(    $self->{_exitValue} eq '0' ){ $self->{_errorMessage} = 'Cannot complete requested action [' . $self->{_rawResults} . ']'; return( 0 ); }
    elsif( $self->{_exitValue} eq '1' ){ $self->{_errorMessage} = ''; return( 1 ); }
    else                               { $self->{_errorMessage} = 'Cannot complete requested action, ClearQuest returned an unknown value [' . $self->{_rawResults} . ']'; return( 0 ); }
}

sub create{

    my( $self ) = shift;
    my( %argHash );
    undef( %argHash );

    %argHash = @_;

    $argHash{action} = 'create';
        
    $self->_setQuery( \%argHash );
    $self->_processRequest();    
        
    if($self->{_exitValue} eq '0' ){ 
      $self->{_errorMessage} = 'Cannot complete requested action [' . $self->{_rawResults} . ']'; 
      return( 0 );   
    }
    elsif( $self->{_exitValue} eq '1' ){ 
      $self->{_errorMessage} = ''; 
      foreach( split( /;/, $self->{_rawResults} ) ){
        my( $field, $value ) = split( /=/, $_ );
        $self->{_formatResults}{$field}  = $value;
      }
      return( 1 );
    }
    else { 
      $self->{_errorMessage} = 'Cannot complete requested action, ClearQuest returned an unknown value [' . $self->{_rawResults} . ']'; 
      return( 0 ); 
    }
}


1;
