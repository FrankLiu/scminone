#VERSION CMBP 2.2
#
###############################################################################
##
## Program: pre/post trigger for lock and unlock
##
###############################################################################

package LockBrtype;
use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(preLock postLockCqCcInt preUnlockCqCcInt postUnlockCqCcInt);

BEGIN {
	use File::Basename;
	my $SCRIPT_ROOT = dirname $0;
	push(@INC, "$SCRIPT_ROOT/../lib");
}

use CMBlueprint;
use CMBlueprint::NamingPolicy;
use CMBlueprint::MetaData;
use CMBlueprint::UI;
use CMBlueprint::ViewCache;
use CMBlueprint::ClearQuest;
use CMBlueprint::Vob;

use vars qw($CLEARTOOL $TMPDIR);
use vars qw(@CC_VOBADM_LST);
use vars qw($CLEARTOOL);
use vars qw($OpCache_ref);
use vars qw(%CQ_WEB_PARAMS); # use variable from CMBlueprint.pm

################## SCM TRIGGER ###########################################

=head1 NAME

preLock -- function called on pre-op of 'cleartool lock' command. 

=head1 SYNOPSIS

preLock()

=head1 INSTALLATION COMMAND

Create this trigger type using the following command:

cleartool mktrtype -type -preop lock -brtype -all 
-execunix "$UNIX_PERL $UNIX_INSTALL_DIR/triggers/triggerMain.pl -t preLock" 
-execwin  "$NT_PERL   $NT_INSTALL_DIR\triggers\triggerMain.pl preLock" 
preLock


=head1 DESCRIPTION

=over 4

=item *

If lock command contains -nusers user, it will return true immediately
so lock brtype after mkbrtype can pass through successfully

=item *

Display error if there is an associated CR and it is not in assigned state

=item *

Verify there is no file checkedout from the branch type branch

=item *

VOB admin should exempt from this check

=back

=head1 RETURN VALUES

 0 on success
 1 on failure

=cut

##########################################################################

sub preLock {

	##put the check in the order of ascending time consumption
	my $user 	= $ENV{"CLEARCASE_USER"};

	##if current user is in the vob admin list, always return true
	foreach (@::CC_VOBADM_LST) {
		return 0 if ( lc($user) eq lc($_) );
	}

	return 0 if ( ! $::CQCC_INTEGRATION_ENABLED );
	
	##if lock command cotains (-nusers current_user), 
	##it probably comes after mkbrtype, return true,
	##in case of integration branch (int/bld/rel etc)
	##it also means, the brtype owner (excluded from -nuser)
	##can always pass through if he wants to lock the branch

	my $cmdline = $ENV{"CLEARCASE_CMDLINE"};

	##get the type of the brtype
	my $brtype = $ENV{"CLEARCASE_BRTYPE"};
	my %retval = ParseBrtypeName($brtype);
	
	if ( $cmdline =~ m/-nus(e|er|ers)?\s+(\S+)/ ) {
	  # If DEV/DEVINT branches have been completely locked/obsoleted 
	  # then ask the user to unlock the branch first 
	  if ($retval{IS_DEV_USAGE} or $retval{IS_DEVINT_USAGE}) {
	    if (isBranchLockedForAllUsers($brtype, $ENV{CLEARCASE_VOB_PN}) == 1) {
	      display_msg ("brtype: $brtype is locked for all users or has been obsoleted!.You must first unlock the branch type using cleartool unlock command before unlocking for selected users.\n\n");
	      return 1;
	    }
	  }
          # If -nuser option then branch is still unlocked so nothing to do
	  return 0;
	}



	##verify no files checkedout from the brtype branch (time-consuming???)
	##(20 seconds in bts1x vob)

	&setAview();
	&setCCAVOBS();

	my @coFiles = qx{$CLEARTOOL lsco -avobs -short -brtype brtype:$brtype};

	if ( $#coFiles >= 0 ) {
		display_msg("There are still elements checkedout from $brtype!\nCan't lock the brtype $brtype!\nIf you want to see the list of checkedout elements, please type the following command:\n\tcleartool lsco -avobs -short -brtype brtype:$brtype");
		return 1;
	}

	### will now verify if the branch type is mastered in the current site.
	#
	#
	my $errmsg;
	my $object = "brtype:$brtype";
	if(!isTypeMasterReplica($object, $ENV{CLEARCASE_VOB_PN}, \$errmsg))
	{
	    display_msg("$errmsg\n");
	    return 1;
	}

        # Check the lock status of the brtype 
        # -1 = ct lslock error
        # 0 = branch is open
        # 1 = branch is partially locked and locked for user
        # 2 = branch is partially locked but unlocked for user
        # 3 = branch is completely locked

	my $lock_type = isBranchUnLockedForUser($user, $brtype, $ENV{CLEARCASE_VOB_PN});
	dprint ("lock_type: $lock_type\n");

        if ($lock_type == 3 || $lock_type == 2) {
	  if ($cmdline !~ m/-rep(l|la|lac|lace)?/) {
	    display_msg ("brtype:$brtype is locked! Must use -replace with lock command.\n\n");
	    return 1;
	  }
	}
        elsif ($lock_type == 1) {
	  display_msg ("brtype:$brtype is locked for $user!You must unlock the branch for $user before locking the branch.\n\n");
	  return 1;
	}
        elsif ($lock_type == -1) {
	  return 1;
	}

	##return 0 for ALL except dev branch (int/sandbox/rel pass through)
	if ( $retval{ERROR} == 0 && ! ($retval{IS_DEV_USAGE} or $retval{IS_DEVINT_USAGE}) ) 
	{
	    if(addworkcompletedhlink($brtype))
	    {
		return 1;
	    }
	    return 0 ;
	}

	# See if trying to obsolete a branch.
	my $lbrname = qq(brtype:$brtype\@vob:$ENV{CLEARCASE_VOB_PN});
	my $crid  = (qx{$CLEARTOOL desc -s -aattr OriginatingCR $lbrname})[0];
	$crid =~ s/["']//g; chomp($crid);

	return 0 if ( $crid eq '' || $crid !~ m/\d{6,}$/ );

	dprint("lbrname ($lbrname) crid ($crid) cmdline($cmdline)");
	my $obsoleteoption = 0;
	if ( $NT ) { ##NT gui interface doesn't set the $cmdline
		my $obo = (grep(/\(obsolete\)/,qx{$CLEARTOOL desc -l $lbrname}))[0];
		if ( $obo ) {
			$obsoleteoption = 1;
		}
	}
	else
	{
		if ( $cmdline =~ m/-obs(o|ol|ole|olet|olete)?/ ) {
			
			$obsoleteoption = 1;
		}
	}


	if($obsoleteoption == 1 && $::USEMERGESTATES)
	{
		my ($rc, $uuid, $oid) = GetUidOid($brtype,$ENV{CLEARCASE_VOB_PN});
		if($rc)
		{
			display_msg("Failed to obtain the vob_family uid from branch $brtype.\n");
			return 1;
		}

		my ($rc,$status,$originatingCR) = getVobObjectNameFromCQ($uuid,$brtype,$ENV{CLEARCASE_VOB_PN});
		if($rc)
		{
			display_msg("Failed to obtain the current mergestate from brtype:$brtype\n");
			return 1;
		}

	

		if($status =~ /:/)
		{
			my($integrated_branch) = (split(/:/,$status))[1];

			if($integrated_branch ne "")
			{
				display_msg("Can not obsolete a branch. Branch has been already targeted or integrated with $integrated_branch.");
				return 1;
			}
		}

		##
                my %query_results;
                $query_results{BL_Actual_Target} = "";
                my $rc = getCRInfo($crid,\%query_results);
		if ($rc) {
		  display_msg("Could not get CQ information for cr: $crid", 1);
		  return 1;
		}

                if ($query_results{BL_Actual_Target} ne "") {
		  display_msg("Can not obsolete a branch. The CR has a predicted Release: $query_results{BL_Actual_Target}\n");
		  return 1;
		}

	}
  

	##check the CQ CR state, return 1 if not in assigned state
	if(!CheckIsCRAssigned($crid))
	{
		display_msg("CQ CR $crid must be in assigned state to lock the brtype:$brtype");
		return 1;
	}


	# Check for CR usage and Target type

	my ($msg);
	my ($rc, $cr_rel, $cr_loadline, $target_type, $cr_usage) = GetRelLLTTCRUforCR ($crid);
	dprint ("rc:$rc cr_rel:$cr_rel cr_loadline:$cr_loadline target_type:target_type cr_usage:$cr_usage \n");
	if ($rc) {
	  display_msg("Could not get CQ information for cr: $crid", 1);
	  return 1;
	}

	# If the branch type when created had CR Usage Dev-Integration, check if developer
        # changed the CR Usage to other than Dev-Integration 

	if($retval{IS_DEVINT_USAGE}) {
	  if($cr_usage !~ m/Dev-Integration/i) {
	    $msg = "CR ($crid) has Usage $cr_usage. Since brtype: $brtype has devint usage tag CR Usage must be Dev-Integration.\n";
	    display_msg("$msg", 1);
	    return 1;
	  }
	}
	else {
	  # Also make sure for CR Usage of Dev-Integration the branchtype also has
	  # usage tag of Dev-Integration. This is check to make sure CRs of Usage other
	  # than Dev-Integration were not changed to Dev-Integration after obsoleting 
          # the brtype

	  if ($cr_usage =~ m/Dev-Integration/i) {
	    $msg = "CR ($crid) has Usage Dev-Integration but branch does not have devint/devbld usage tag in $brtype.Usage of CR must be changed from Dev-Integration to unlock the branch\n";
	    display_msg("$msg", 1);
	    return 1;
	  }

	  # For Dev-CRs that does not have TT=Dev-Build, make sure they have release 
	  # in their brtype. Only time it can happen is if branch type was created 
	  # with TT=Dev-Build, the branch type is obsoleted, the CR TT is changed to
	  # something other than Dev-Build. 

	  dprint ("Target_Type: $target_type REL_ID:$retval{REL_ID}\n");	

	  if ($retval{IS_DEV_USAGE}) {
	    if (($target_type !~ /Dev-Build/) && ($retval{REL_ID} eq "")) {
	      $msg = "CR ($crid) does not have Target Type Dev-Build. Still it does not have release in the brtype. This CR must have TT Dev-Build to continue\n";
	      display_msg("$msg");
	      return 1;
	    }
	  }
		
	}
  
        # verifying the ClearCaseTab Changed Set does not have the state of INTEGRATED for this particular branch.
        my $errIntBranch;

	if($::USEMERGESTATES)
	{
		my ($rc, $uuid, $oid) = GetUidOid($brtype,$ENV{CLEARCASE_VOB_PN});
		if($rc)
		{
			display_msg("Failed to obtain the vob_family uid from branch $brtype.\n");
			return 1;
		}

		my ($rc, $status,$originatingCR) = getVobObjectNameFromCQ($uuid,$brtype,$ENV{CLEARCASE_VOB_PN});
		if($rc)
		{
			display_msg("Failed to obtain the current mergestate from brtype:$brtype\n");
			return 1;
		}
	
	        if(clearcaseTabAction($status,$originatingCR, $brtype, VERIFY_NOT_INTEGRATED, $ENV{CLEARCASE_VOB_PN}, "" , \$errIntBranch))
		{
			display_msg("Error: Branch type: $brtype has been integrated to branch:$errIntBranch\n");
			return 1;
		}
	}

	# Adding the lock hyperlink to the branch.
	if(addworkcompletedhlink($brtype))
        {
		return 1;
	}

   	return 0;
}

############

sub addworkcompletedhlink
{
    my ($brtype) = @_;


    my @listofvobs = getVobsBrtypeTouched($brtype);

    # 
    # Verify if the user is the owner of the branch type. If not will not execute the hlink on the brtype.
    #
    my $brtypeowner = getBrOwner($brtype,$ENV{CLEARCASE_VOB_PN});
    if($brtypeowner eq "")
    {
	die("Failed to obtain the owner for the following branch: $brtype in vob: $ENV{CLEARCASE_VOB_PN}");
    }

    if($brtypeowner !~ m/$CURRENT_USER/i)
    {
	warn("Current user: $CURRENT_USER does not own brtype:$brtype. It is own by user: $brtypeowner. work_completed hlink is not set. \n");

	return 0;
    }
    

    foreach (@listofvobs)
    {
	if(!lockhlexist($brtype, $_))
	{
	    if(createtexthlink($::LOCKHLINK,"1","brtype:$brtype\@vob:$_"))
	    {
		display_msg("Failed to create hlink $::LOCKHLINK on object type brtype:$brtype\@vob:$_\n");
		return 1;
	    }
	}
    }

    return 0;
}

############

################## SCM TRIGGER ###########################################

=head1 NAME

postLockCqCcInt -- function called on post-op of 'cleartool lock' command. 

=head1 SYNOPSIS

postLockCqCcInt()

=head1 INSTALLATION COMMAND

Create this trigger type using the following command:

cleartool mktrtype -type -postop lock -brtype -all 
-execunix "$UNIX_PERL $UNIX_INSTALL_DIR/triggers/triggerMain.pl -t postLockCqCcInt" 
-execwin  "$NT_PERL   $NT_INSTALL_DIR\triggers\triggerMain.pl postLockCqCcInt" 
postLockCqCcInt


=head1 DESCRIPTION

=over 4

=item *

If lock command contains -nusers user, it will return true immediately

=item *

Display error if branch is a CR branch and the CR is not in assigned state

=item *

if brtype is a CR branch, write "WORK_COMPLETED" to CQ cc_chage_set

=item *

VOB admin should exempt from this check

=back

=head1 RETURN VALUES

 0 on success
 1 on failure

=cut

##########################################################################


sub postLockCqCcInt {

	my $user 	= $ENV{"CLEARCASE_USER"};
	my $cvalue	= 'WORK_COMPLETED';

	##if current user is in the vob admin list, always return true
	#foreach (@::CC_VOBADM_LST) {
	#	return 0 if ( lc($user) eq lc($_) );
	#}
	#disabled per the code inspection
	
	return 0 if ( ! $::CQCC_INTEGRATION_ENABLED );

	##if lock command contains (-nusers current_user), 
	##it probably comes after mkbrtype, return true,
	##in case of integration branch (int/bld/rel etc)
	##it also means, the brtype owner (excluded from -nuser)
	##can always pass through if he wants to lock the branch
       
	my $cmdline = $ENV{"CLEARCASE_CMDLINE"};

	if ( $cmdline =~ m/-nus(e|er|ers)?\s+(\S+)/ ) {
	  return 0;
	}

	##get the type of the brtype
	my $brtype = $ENV{"CLEARCASE_BRTYPE"};
	my %retval = ParseBrtypeName($brtype);

	##all return 0 except dev branch (int/sandbox/rel pass through)
	return 0 if ( $retval{ERROR} == 0 && ! ($retval{IS_DEV_USAGE} or $retval{IS_DEVINT_USAGE}) );

	#my $crid   = $retval{REC_ID};
	my $lbrname = qq(brtype:$brtype\@vob:$ENV{CLEARCASE_VOB_PN});
	my $crid  = (qx{$CLEARTOOL desc -s -aattr OriginatingCR $lbrname})[0];
	$crid =~ s/["']//g; chomp($crid);

	return 0 if ( $crid eq '' || $crid !~ m/\d{6,}$/ );

	dprint("lbrname ($lbrname) crid ($crid) cmdline($cmdline)");
	if ( $NT ) { ##NT gui interface doesn't set the $cmdline
		my $obo = (grep(/\(obsolete\)/,qx{$CLEARTOOL desc -l $lbrname}))[0];
		if ( $obo ) {
			MVCsetLog($brtype,$crid,'BRTYPE_OBSOLETED');
		} 
		else {
			my ($errIntBranch, $errMergeState);
            if($::USEMERGESTATES) 
 			{
				my ($rc, $uuid, $oid) = GetUidOid($brtype,$ENV{CLEARCASE_VOB_PN});
				if($rc)
				{
					display_msg("Failed to obtain the vob_family uid from branch $brtype.\n");
					return 1;
				}
				my ($rc,$status,$originatingCR) = getVobObjectNameFromCQ($uuid,$brtype,$ENV{CLEARCASE_VOB_PN});
				if($rc)
				{
					display_msg("Failed to obtain the current mergestate from brtype:$brtype\n");
					return 1;
				}


                # For Agile, need to get the Target-Type of the CR. 
                my @fieldtoQuery = qw(Target_Type); 
                my %fieldoutput = ();    
                my $r; 
                                
                IsCRClosedAndCRInformation($originatingCR,\$r,\@fieldtoQuery,\%fieldoutput); 
                dprint ("TT--> $fieldoutput{Target_Type} \n"); 
                if(lc($fieldoutput{Target_Type})  eq "dev-build") 
                { 
                	my $targetedbranch = (split(/:/,$status))[1]; 
                                         
                    if($status =~ /^WORK_PARTIAL_INTEGRATED:/) { 
                    	dprint "GOING TO CHANGE IT FROM WORK_PARTIAL_INTEGRATED TO WORK_LOCK_PART_INT\n"; 
                        if(clearcaseTabAction($status,$originatingCR, $brtype, ADDLOCKEDPARTINTEGRATED, $ENV{CLEARCASE_VOB_PN}, $targetedbranch,\$errIntBranch, $uuid, \$errMergeState)){ 
	                        if ($errIntBranch) {
		                    	display_msg("Error: Branch has already been integrated with branch: $errIntBranch\n");
	                    	}
	                    	else {
	                    		my $errMsg;
                    			if ($errMergeState) {
		                			$errMsg = "Error: Could not change cc_change_set.objects in CQ to $errMergeState\n";
	                			}
		                		else {
		                   			$errMsg = "Error: Failed to change/validate cc_change_set.objects in CQ\n";
	                			}	
		                    	$errMsg .= "Though the branch has been locked, CQ has not been updated\n";
		                		$errMsg .= "Re-run the lock command or Contact CC support team if problem persists\n";
		                		display_msg("$errMsg\n");
							}
                            return 1; 
                    	}
               		}
                   	else {
                    	if(clearcaseTabAction($status,$originatingCR, $brtype, ADDWORKCOMPLETED, $ENV{CLEARCASE_VOB_PN}, "" , \$errIntBranch, $uuid, \$errMergeState))  
                        {  
                 			my $errMsg;
                    		if ($errMergeState) {
		                		$errMsg = "Error: Could not change cc_change_set.objects in CQ to $errMergeState\n";
	                		}
		                	else {
		                   		$errMsg = "Error: Failed to change/validate cc_change_set.objects in CQ\n";
	                		}	
		                    $errMsg .= "Though the branch has been locked, CQ has not been updated\n";
		                	$errMsg .= "Re-run the lock command or Contact CC support team if problem persists\n";
		                	display_msg("$errMsg\n");
                            return 1;      
                    	}        
                    }
                } 
                else 
                { 		
                    if(clearcaseTabAction($status,$originatingCR, $brtype, ADDWORKCOMPLETED, $ENV{CLEARCASE_VOB_PN}, "" , \$errIntBranch, $uuid, \$errMergeState)) 
                    { 
                 		my $errMsg;
               			if ($errMergeState) {
                			$errMsg = "Error: Could not change cc_change_set.objects in CQ to $errMergeState\n";
               			}
                		else {
                   			$errMsg = "Error: Failed to change/validate cc_change_set.objects in CQ\n";
               			}	
                    	$errMsg .= "Though the branch has been locked, CQ has not been updated\n";
                		$errMsg .= "Re-run the lock command or Contact CC support team if problem persists\n";
                		display_msg("$errMsg\n");
						return 1;  
                    }        
                } 
			}
			else
			{
				MVCsetLog($brtype,$crid,$cvalue);
			}
		}
	} else {
		if ( $cmdline =~ m/-obs(o|ol|ole|olet|olete)?/ ) {
			MVCsetLog($brtype,$crid,'BRTYPE_OBSOLETED');
		} 
		else {
	        my ($errIntBranch, $errMergeState);
			
			if($::USEMERGESTATES)
			{
				my ($rc, $uuid, $oid) = GetUidOid($brtype,$ENV{CLEARCASE_VOB_PN});
				if($rc)
				{
					display_msg("Failed to obtain the vob_family uid from branch $brtype.\n");
					return 1;
				}
				my ($rc, $status,$originatingCR) = getVobObjectNameFromCQ($uuid,$brtype,$ENV{CLEARCASE_VOB_PN});
				if($rc)
				{	
					display_msg("Failed to obtain the current mergestate from brtype:$brtype\n");
					return 1;
				}
				
				# For Agile, need to get the Target-Type of the CR.
				my @fieldtoQuery = qw(Target_Type);
				my %fieldoutput = ();   
				my $r;
				
				IsCRClosedAndCRInformation($originatingCR,\$r,\@fieldtoQuery,\%fieldoutput);
				dprint ("TT--> $fieldoutput{Target_Type} \n");
				if(lc($fieldoutput{Target_Type})  eq "dev-build")
				{
					my $targetedbranch = (split(/:/,$status))[1];
					
					if($status =~ /^WORK_PARTIAL_INTEGRATED:/) {
						dprint "GOING TO CHANGE IT FROM WORK_PARTIAL_INTEGRATED TO WORK_LOCK_PART_INT\n";
						if(clearcaseTabAction($status,$originatingCR, $brtype, ADDLOCKEDPARTINTEGRATED, $ENV{CLEARCASE_VOB_PN}, $targetedbranch,\$errIntBranch, $uuid, \$errMergeState)){
							my $errMsg;
			                if ($errIntBranch) {
		                    	display_msg("Error: Branch has already been integrated with branch: $errIntBranch\n");
	                    	}				
                   			else {
	                   			my $errMsg;
               					if ($errMergeState) {
                					$errMsg = "Error: Could not change cc_change_set.objects in CQ to $errMergeState\n";
               					}
                				else {
                   					$errMsg = "Error: Failed to change/validate cc_change_set.objects in CQ\n";
               					}	
                    			$errMsg .= "Though the branch has been locked, CQ has not been updated\n";
                				$errMsg .= "Re-run the lock command or Contact CC support team if problem persists\n";
                				display_msg("$errMsg\n");
            				}
							return 1;  
     					}
					}# End Lock on Dev-Build CR brach WORK_PARTIAL_INTEGRATED
					else
					{
					 	if(clearcaseTabAction($status,$originatingCR, $brtype, ADDWORKCOMPLETED, $ENV{CLEARCASE_VOB_PN}, "" , \$errIntBranch, $uuid, \$errMergeState)) 
		                { 
                 			my $errMsg;
               				if ($errMergeState) {
                				$errMsg = "Error: Could not change cc_change_set.objects in CQ to $errMergeState\n";
               				}
                			else {
                   				$errMsg = "Error: Failed to change/validate cc_change_set.objects in CQ\n";
               				}	
                    		$errMsg .= "Though the branch has been locked, CQ has not been updated\n";
                			$errMsg .= "Re-run the lock command or Contact CC support team if problem persists\n";
                			display_msg("$errMsg\n");
							return 1;  
     					} 
					}       
				}# Endif Dev-Build CR branch
				else
				{
		        	if(clearcaseTabAction($status,$originatingCR, $brtype, ADDWORKCOMPLETED, $ENV{CLEARCASE_VOB_PN}, "" , \$errIntBranch, $uuid, \$errMergeState))
					{
                 		my $errMsg;
               			if ($errMergeState) {
                			$errMsg = "Error: Could not change cc_change_set.objects in CQ to $errMergeState\n";
               			}
                		else {
                   			$errMsg = "Error: Failed to change/validate cc_change_set.objects in CQ\n";
               			}	
                    	$errMsg .= "Though the branch has been locked, CQ has not been updated\n";
                		$errMsg .= "Re-run the lock command or Contact CC support team if problem persists\n";
                		display_msg("$errMsg\n");
						return 1;  
					}	
				}#End CR-branches other than Dev-Build 
			}
			else # MERGESTATES is not used
			{
				##chage the cc_change_set to 'WORK_COMPLETED'
				MVCsetLog($brtype,$crid,$cvalue);
			}
		}
	}

	return 0;

}

################## SCM TRIGGER ###########################################

=head1 NAME

preUnlockCqCcInt -- function called on pre-op of 'cleartool unlock' command. 

=head1 SYNOPSIS

preUnlockCqCcInt()

=head1 INSTALLATION COMMAND

Create this trigger type using the following command:

cleartool mktrtype -type -preop unlock -brtype -all 
-execunix "$UNIX_PERL $UNIX_INSTALL_DIR/triggers/triggerMain.pl -t preUnlockCqCcInt" 
-execwin  "$NT_PERL   $NT_INSTALL_DIR\triggers\triggerMain.pl preUnlockCqCcInt" 
preUnlockCqCcInt


=head1 DESCRIPTION

=over 4

=item *

For CR brtypes, verify CR is in the assigned state

=item *

Display error if CR is not in assigned state

=item *

VOB admin should exempt from this check

=back

=head1 RETURN VALUES

 0 on success
 1 on failure

=cut

##########################################################################


sub preUnlockCqCcInt {

	my $user 	= $ENV{"CLEARCASE_USER"};

	##if current user is in the vob admin list, always return true
	foreach (@::CC_VOBADM_LST) {
		return 0 if ( lc($user) eq lc($_) );
	}
	return 0 if ( ! $::CQCC_INTEGRATION_ENABLED );
	
	##get the type of the brtype
	my $brtype = $ENV{"CLEARCASE_BRTYPE"};
	my %retval = ParseBrtypeName($brtype);

	##all return 0 except dev branch (int/sandbox/rel pass through)
	return 0 if ( $retval{ERROR} == 0 && ! ($retval{IS_DEV_USAGE} or $retval{IS_DEVINT_USAGE}) );

	#my $crid   = $retval{REC_ID};
	my $crid  = (qx{$CLEARTOOL desc -s -aattr OriginatingCR brtype:$brtype\@vob:$ENV{CLEARCASE_VOB_PN}})[0];
	$crid =~ s/["']//g; chomp($crid);

	if ( $crid eq '' || $crid !~ m/\d{6,}$/ ) {
		display_msg("Can't get CQ CR number for brtype $brtype!");
		return 1;
	}

	my ($rc, $uuid, $oid) = GetUidOid($brtype,$ENV{CLEARCASE_VOB_PN});
	if($rc)
	{
		display_msg("Failed to obtain the vob_family uid from branch $brtype.\n");
		return 1;
	}

	# Make sure 
	# 1) CR is assigned,  and 
        # 2) Does not have other active brtypes
	# 3) CR_Usage for Dev-Integration has not been changed after brtype has been created
        # 4) brtype has release if TT != Dev-Build
	####
	my $msg;
	if(($msg = checkCRassignedAndNoOtherActiveBrtype($crid, $brtype, $uuid, %retval)) ne "")
	{
		display_msg("$msg");
		exit (1);
	}
	####


	##checkif the CQ CR Merge State is not Integrated.
        my $errIntBranch;


	if($::USEMERGESTATES)
	{
		my ($rc,$status,$originatingCR) = getVobObjectNameFromCQ($uuid,$brtype,$ENV{CLEARCASE_VOB_PN});
		if($rc)
		{
			display_msg("Failed to obtain the current mergestate from brtype:$brtype\n");	
			return 1;
		}
		
		# If the branch is already integrated can not be unlocked (Verify)
	    if(clearcaseTabAction($status,$originatingCR, $brtype, VERIFY_NOT_INTEGRATED, $ENV{CLEARCASE_VOB_PN}, "" , \$errIntBranch))
		{
			display_msg("Error: Branch already integrated with branch: $errIntBranch\n");
			return 1;
		}
	}

	return 0;

}

################## SCM TRIGGER ###########################################

=head1 NAME

postUnlockCqCcInt -- function called on post-op of 'cleartool unlock' command. 

=head1 SYNOPSIS

postUnlockCqCcInt()

=head1 INSTALLATION COMMAND

Create this trigger type using the following command:

cleartool mktrtype -type -postop unlock -brtype -all 
-execunix "$UNIX_PERL $UNIX_INSTALL_DIR/triggers/triggerMain.pl -t postUnlockCqCcInt" 
-execwin  "$NT_PERL   $NT_INSTALL_DIR\triggers\triggerMain.pl postUnlockCqCcInt" 
postUnlockCqCcInt


=head1 DESCRIPTION

=over 4

=item *

For CR brtypes, writes to CQ cc_change_set "WORK_STARTED"

=back

=head1 RETURN VALUES

 0 on success
 1 on failure

=cut

##########################################################################

sub postUnlockCqCcInt {

	my $cvalue	= 'WORK_STARTED';

	return 0 if ( ! $::CQCC_INTEGRATION_ENABLED );

	##get the type of the brtype
	my $brtype = $ENV{"CLEARCASE_BRTYPE"};
	my %retval = ParseBrtypeName($brtype);

	# need to remove any work_started hlinks from the brtype.
	#
	# Need to get the list of VOBs ....
	#
	my @listOfVobs = getVobsBrtypeTouched($brtype);

	foreach (@listOfVobs)
	{
	    my $cmd = "$CLEARTOOL describe -long -local -ahlink $::LOCKHLINK brtype:$brtype\@vob:$_ 2>$ERRNULL";
	    my @output = qx($cmd);
	    if($?)
	    {
		return 0;
	    }        

	    foreach (@output)
	    {
		if(/->/)
		{
			my $hlinfo = (split(/->/))[0];
			
			# getting rid of the white spaces.
			$hlinfo =~ s/^\s*//;
			$hlinfo =~ s/\s*$//;

			$cmd = "$CLEARTOOL rmhlink $hlinfo 2>$ERRNULL";
			qx($cmd);
			if($?)
			{
				display_msg("The following command failed:\n$cmd\n");
				return 1;
			 }
		}
	    }
	}

	##all return 0 except dev branch (int/sandbox/rel pass through)
	return 0 if ( ! ($retval{IS_DEV_USAGE} or $retval{IS_DEVINT_USAGE}) );

	#my $crid   = $retval{REC_ID};
	my $crid  = (qx{$CLEARTOOL desc -s -aattr OriginatingCR brtype:$brtype\@vob:$ENV{CLEARCASE_VOB_PN}})[0];
	$crid =~ s/["']//g; chomp($crid);

	return 0 if ( $crid eq '' || $crid !~ m/\d{6,}$/ );

	##chage the cc_change_set to 'WORK_STARTED'


	my ($errIntBranch,$errMergeState);	
	
	if($::USEMERGESTATES)
	{

                my ($rc, $uuid, $oid) = GetUidOid($brtype,$ENV{CLEARCASE_VOB_PN});
                if($rc)
                {
                        display_msg("Failed to obtain the vob_family uid from branch $brtype.\n");
                        return 1;
                }
                my ($rc,$status,$originatingCR) = getVobObjectNameFromCQ($uuid,$brtype,$ENV{CLEARCASE_VOB_PN});
                if($rc)
                {
                        display_msg("Failed to obtain the current mergestate from brtype:$brtype\n");
                        return 1;
                }

				####
				# For Agile, need to get the Target-Type of the CR. 
				my @fieldtoQuery = qw(Target_Type); 
                my %fieldoutput = ();    
                my $r; 
                                
               	IsCRClosedAndCRInformation($originatingCR,\$r,\@fieldtoQuery,\%fieldoutput); 
				dprint ("TT--> $fieldoutput{Target_Type} \n"); 
				

				
				if(lc($fieldoutput{Target_Type})  eq "dev-build") 
                { 
                	my $targetedbranch = (split(/:/,$status))[1];             
					dprint "TTTTT--> $status \n";
					if($status =~ /^WORK_LOCKED_PART_INT:/) { 
                    	dprint "GOING TO CHANGE IT FROM WORK_LOCK_PART_INT TO WORK_PARTIAL_INT\n"; 
                        if(clearcaseTabAction($status,$originatingCR, $brtype, ADDPARTIALINTEGRATED, $ENV{CLEARCASE_VOB_PN}, $targetedbranch,\$errIntBranch, $uuid, \$errMergeState)){ 
	                        if ($errIntBranch) {
		                    	display_msg("Error: Branch has already been integrated with branch: $errIntBranch\n");
	                    	}				
                   			else {
	                    		my $errMsg;
                    			if ($errMergeState) {
		                			$errMsg = "Error: Could not change cc_change_set.objects in CQ to $errMergeState\n";
	                			}
		                		else {
		                   			$errMsg = "Error: Failed to change/validate cc_change_set.objects in CQ\n";
	                			}	
	                			$errMsg .= "Though the branch has been unlocked, CQ has not been updated\n";
		                		$errMsg .= "You need to run the lock and unlock commands or Contact CC support team if problem persists\n";
		                		display_msg("$errMsg\n");
	                		}
	                		return 1;
                        } 
					} 
                    else { 
						if(clearcaseTabAction($status,$originatingCR, $brtype, ADDWORKSTARTED, $ENV{CLEARCASE_VOB_PN}, "" , \$errIntBranch, $uuid, \$errMergeState))  
                        {  
	                    	my $errMsg;
                    		if ($errMergeState) {
		                		$errMsg = "Error: Could not change cc_change_set.objects in CQ to $errMergeState\n";
	                		}
		                	else {
		                   		$errMsg = "Error: Failed to change/validate cc_change_set.objects in CQ\n";
	                		}	
	                		$errMsg .= "Though the branch has been unlocked, CQ has not been updated\n";
		                	$errMsg .= "You need to run the lock and unlock commands or Contact CC support team if problem persists\n";
		                	display_msg("$errMsg\n");
							return 1;  
						}  
					}
				} #Endif Dev-Build CR branch for PostUnlock       
				else 
                {

                	if(clearcaseTabAction($status,$originatingCR, $brtype, ADDWORKSTARTED, $ENV{CLEARCASE_VOB_PN}, "" , \$errIntBranch,$uuid, \$errMergeState)) 
                    { 
	                    my $errMsg;
                    	if ($errMergeState) {
		                	$errMsg = "Error: Could not change cc_change_set.objects in CQ to $errMergeState\n";
	                	}
		                else {
		                   	$errMsg = "Error: Failed to change/validate cc_change_set.objects in CQ\n";
	                	}	
	                	$errMsg .= "Though the branch has been unlocked, CQ has not been updated\n";
		                $errMsg .= "You need to run the lock and unlock commands or Contact CC support team if problem persists\n";
		                display_msg("$errMsg\n");
						return 1;  
                     }        
                } 

####
	}
	else
	{
		MVCsetLog($brtype,$crid,$cvalue);
	}

	return 0;
}


1;
