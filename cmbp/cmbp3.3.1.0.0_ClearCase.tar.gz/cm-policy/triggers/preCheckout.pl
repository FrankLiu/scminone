#VERSION CMBP 2.2
#
###############################################################################
##
## Program: preCheckout
##
## Summary: trigger fired before checkout operation
##
## Description:
##
##       Do not allow unreserved checkouts.                          
##
###############################################################################

## Need these variables from the main:: package
use vars qw(
  $DEVBRANCH_MERGELOCK_LOOKUP_ENABLED
  $INTBRANCH_MERGELOCK_LOOKUP_ENABLED
  $PARALLEL_DEV_WARN_ENABLED
);


package PreCheckout;
use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(precheckout);

BEGIN {
	use File::Basename;
	my $SCRIPT_ROOT = dirname $0;
	push(@INC, "$SCRIPT_ROOT/../lib");
}

use vars qw($CLEARTOOL $TMPDIR);

use CMBlueprint;
use CMBlueprint::NamingPolicy;
use CMBlueprint::MetaData;
use CMBlueprint::UI;
use CMBlueprint::PI;
use CMBlueprint::Config;

use vars qw(@CC_INTRELMAIN_CO_LST);

my $BUILDCO_ATTRIBUTENAME = "build_co_permitted";

################## ACE TRIGGER ###########################################

=head1 NAME

preCheckout -- function called on pre-op of 'cleartool checkout' command.  Does not allow 
unreserved checkouts.

=head1 SYNOPSIS

  preCheckout.pl


=head1 INSTALLATION COMMAND

 Create trigger type using the following command:

 cleartool mktrtype -elem -all -preop checkout  \
   -execunix $UNIX_PERL "$UNIX_INSTALL_DIR/triggers/triggerMain.pl -t preCheckout" \
   -execwin  $NT_PERL   "$NT_INSTALL_DIR\triggers\triggerMain.pl preCheckout" \
 preCheckout


=head1 DESCRIPTION

=over 4

=item *

$ENV{'CLEARCASE_RESERVED'} is set to 1 if it is a reserved checkout.  It is
set to 0 otherwise.  If $ENV{'CLEARCASE_RESERVED'} is not set, then do not
allow the checkout.

=item *

If there is a "MergeLock" hyperlink on the pertaining branch type, check if the "MergeLock" 
is owned by the user.  If the "MergeLock" is not owned by the user, then refuse the checkout.

=item *

Call CheckParallelDev() to check if the file has been checked out on any other branch.  If so, 
provide a warning saying that the user may experience merge conflicts while merging this file.

=back

=head1 RETURN VALUES

 0 on success
 1 on failure

=head1 AUTHOR

ACE Common CM Dev Team E<lt>ise-list@relay1.cig.mot.comE<gt>

=cut

##########################################################################

sub precheckout{
	
	my $user 	= $ENV{"CLEARCASE_USER"};

	#if user is in a predefined user list, let it pass through
	foreach (@::CC_INTRELMAIN_CO_LST) {
		return 0 if ( lc($user) eq lc($_) );
	}
	
	##if the checkout is a result of findmerge operation,
	##let it pass through
	my $cmd = $ENV{'CLEARCASE_CMDLINE'};

	my $reserved  = $ENV{'CLEARCASE_RESERVED'};
	my $brtype 	= $ENV{CLEARCASE_BRTYPE};
	my %brinfo	= ParseBrtypeName($brtype);
	my $coBuildBranch = 0;

	##allow unreserved checkouts from branches other than g-main as a result of findmerge
	if ( $cmd =~ m/^findm(e|er|erg|erge)?\s+/ ) {
		if (  $brtype !~ m/[_-]?main$/ && not $reserved ) {
			return 0;
		}
		elsif ( $brtype =~ m/[_-]?main$/ ) {
			display_msg("Only authorized persons are permitted to merge to main branch [$brtype]");
			return 1;
		}
		
	} else { ##normal checkout
		if (  ($brinfo{IS_INT_USAGE} || $brtype =~ m/[_-]?main$/) ) {

			##if the co is the result of clearmrgman, let them do it
			if (  $brtype !~ m/[_-]?main$/  && isFromMergeManager() == 1 ) {
				return 0;
			}
			elsif ( $brtype =~ m/[_-]?main$/ ) {
				display_msg("Only authorized persons are permitted to merge to main branch [$brtype]");
				return 1;
			}
			
			# checking to see if the file checking out has the build_co_permitted attribute.
			my $fname = $ENV{"CLEARCASE_PN"};
			my $ctcmd = "$CLEARTOOL describe -s -aattr $BUILDCO_ATTRIBUTENAME $fname@@";
			my $listofusers = qx($ctcmd);
			if($?)
			{
			    display_msg("The following command failed:\n$ctcmd\n");
			    exit 1;
			}
			
			chomp($listofusers);

			my $allowedtocheckout = 0;

			# see if the attribute was placed on the file.
			if($listofusers ne "")
			{
			    $listofusers =~ s/\"//g;

			    # getting the current user login.
			    my $username;

			    if($NT)
			    {
				$username = $ENV{"USERNAME"};
			    }
			    else
			    {
				$username = getpwuid($<);
			    }

			    # see of the user is listed in the attribute string.
			    my @arrUsers = split(/:/, $listofusers);
			    foreach (@arrUsers)
			    {
				if($_ =~ m/$username/i)
				{
				    $allowedtocheckout = 1;
				    $coBuildBranch = 1;
				    last;
				}
			    }
			}
	
			if($allowedtocheckout == 0 && not $reserved)
			{
			    if ($brinfo{IS_INT_USAGE})
			    {
				display_msg("You can't do checkouts from integration branch of $brtype");
				return 1;
			    }
			    else # Must be main branch e.g. main, XXX-main
			    {
				display_msg("Checkouts from main release branch [$brtype] are not permitted");
				return 1;
			    }
			}
			
			if($reserved)
			{
			    display_msg("You must use the -unreserve option when checking a file out in a build branch.");
			    exit 1;
			}
		}
	}
	
	##not int/rel/main branch
	if ((not $reserved) && !$coBuildBranch) {
		display_msg("Unreserved checkouts are not allowed from $brtype\n");
		return 1;
	}

  my $pn = $ENV{CLEARCASE_PN};
  my $brtype = $ENV{CLEARCASE_BRTYPE} ."@". $ENV{CLEARCASE_VOB_PN};
       ## branch type of ClearCase object

  my %mergelock;

  if ( ($brinfo{IS_DEV_USAGE} and ! $::DEVBRANCH_MERGELOCK_LOOKUP_ENABLED)
          or
       ($brinfo{IS_INT_USAGE} and ! $::INTBRANCH_MERGELOCK_LOOKUP_ENABLED) )
  {
    dprint "perf",
           "# bypassed preCheckout mergelock-lookup for brtype '$brtype'\n";
  }
  else {
    if (querymergelock($brtype, \%mergelock)) {
      # the branch has a merge-lock.
      my $logname = $CURRENT_USER;
      unless ( lc($mergelock{username}) eq lc($logname) ) {
        # current user doesn't have access to merge-lock, so deny access...
        print "$logname does not have the mergelock, it is owned by $mergelock{username} \n";
        return 1;
      }  
    }
  }

  my ($rc, $element_list) = CheckParallelDev($pn); 
  if ($rc) {
    my $rc = get_continue_choice("There are checkouts of the element $pn by :$element_list: You may encounter merging conflicts later on. Abort or Proceed with current checkout?");
    if ($rc) { return 1; };      
  }
}


##########################################################################

=head1 NAME

CheckParallelDev -- function to check if concurrent development is being done   on a file.                          

=head1 SYNOPSIS

  CheckParallelDev($pn)

     where $pn - name of the file


=head1 DESCRIPTION

Check if the file has been checked out on any other branch.
If so, return a non-zero value.

=head1 RETURN VALUES

 0 if the file is not checked out on any other branch
 non-zero if the file is checked out on another branch.

=head1 AUTHOR

ACE Common CM Dev Team 

=cut

##########################################################################
sub CheckParallelDev {

  unless ($::PARALLEL_DEV_WARN_ENABLED) {
     dprint "perf", "# bypassed parallel-dev check!\n";
     return 0;
  }

  my $tmpfile = "$TMPDIR/getcrattrs$$.tmp";
  my $cc_element = shift @_ ;
  
  my $cmd = "$CLEARTOOL lsco -d -fmt \"%u (%Rf checkout) from (%PVn) in view %Tf since %d and by \" $cc_element";
  prep_cmd(\$cmd);
  $cmd .= " 2>$tmpfile |";
  my $rc = 1;
  my $str;

  dprint("cmd is :$cmd: \n");
  open(DUMP, $cmd);
  my @str = <DUMP>;
  $str = "@str";
  $str = substr($str,0,-8); # 8 because length(" and by ") gives 8;
  close DUMP;
  unlink $tmpfile;
  dprint("str is :$str: \n");
  $rc = 0 unless ($str);
  return ($rc, $str);

}

1;
