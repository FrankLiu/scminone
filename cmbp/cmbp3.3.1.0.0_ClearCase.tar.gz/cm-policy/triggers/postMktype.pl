#VERSION CMBP 2.2
#
###############################################################################
##
## Program: postMktype 
##
## Summary: trigger fired after mktype operation
##
## Description:
##
##       Change the ownership of the newly created type object to be
##       the VOB owner
##
###############################################################################

package PostMktype;

use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(postmktype);

BEGIN {
	use File::Basename;
	my $SCRIPT_ROOT = dirname $0;
	push(@INC, "$SCRIPT_ROOT/../lib");
}

use CMBlueprint;
use CMBlueprint::Vob;

use vars qw($CLEARTOOL);

################## ACE TRIGGER ###########################################

=head1 NAME

postMktype -- function to change the owner and group of the type to that of the VOB owner.  
Attached on post-op of 'cleartool mktype' command

=head1 SYNOPSIS

 postMktype

=head1 INSTALLATION COMMAND

 The trigger type can be created using the following command:

  cleartool mktrtype -type -postop mktype -eltype -all \
                                          -attype -all \
                                          -hltype -all \
                                          -lbtype -all \
                                          -trtype -all \
   -execunix $UNIX_PERL $UNIX_INSTALL_DIR/triggers/triggerMain.pl -t postMktype \
   -execwin  $NT_PERL   $NT_INSTALL_DIR\triggers\triggerMain.pl -t postMktype \
  postMktype


=head1 DESCRIPTION

When an element type, or an attribute type, or a branch type or a hyperlink
type or a label type is created, its owner and group are changed to that of the VOB owner.

  1.  Get the owner and group of the VOB.
  2.  $ENV{CLEARCASE_MTYPE} contains the type of object 
      that invoked the trigger.
  3.  The script maintains two hashes:
      a.  %type_kinds containing object types as the keys and
          their corresponding environment variable names as their
          values.
      b.  %obj_sels containing object types as the keys and their
          corresponding object selector names as their values.
  4.  Using the %type_kinds hash, get the env. variable associated 
      with the object type. Get the name of the ClearCase object
      from this env. variable.  
  5.  Using the %obj_sels hash, get the name of the object selector
      for the ClearCase object.
  6.  Change the owner and group of the type to that of the VOB 
      using "cleartool protect" command.


=head1 RETURN VALUES

  0 on success
  1 on failure


=cut

##########################################################################
sub postmktype{

   my %type_kinds = (
       "attribute type" => "CLEARCASE_ATTYPE",
       "branch type"    => "CLEARCASE_BRTYPE",
       "element type"   => "CLEARCASE_ELTYPE",
       "hyperlink type" => "CLEARCASE_HLTYPE",
       "label type"     => "CLEARCASE_LBTYPE",
       "trigger type"   => "CLEARCASE_TRTYPE",
   );

   my %obj_sels = (
       "attribute type" => "attype",
       "branch type"    => "brtype",
       "element type"   => "eltype",
       "hyperlink type" => "hltype",
       "label type"     => "lbtype",
       "trigger type"   => "trtype",
   );

   my $object_type = $ENV{'CLEARCASE_MTYPE'};
   my $object_name = "$ENV{$type_kinds{$object_type}}";
   my $object_sel = "$obj_sels{$object_type}";
   my $vob_path = $ENV{'CLEARCASE_VOB_PN'};

   my ($owner, $group) = &get_vob_owner_group;

   if($object_type eq "label type")
   {
       my $cmd = "$CLEARTOOL protect -chgrp \"$group\" $object_sel:$object_name\@$vob_path";
       prep_cmd(\$cmd);
       `$cmd`;
       if ($? != 0){
	   display_msg("Cannot change group owner of $object_type:$object_name to $owner\n");
	   return 1;
       }
   }
   else
   {
       my $cmd = "$CLEARTOOL protect -chown $owner -chgrp \"$group\" $object_sel:$object_name\@$vob_path";
       prep_cmd(\$cmd);
       `$cmd`;
       if ($? != 0){
	   display_msg("Cannot change owner of $object_type:$object_name to $owner\n");
	   return 1;
       }
   }

   return 0;
}

1;
