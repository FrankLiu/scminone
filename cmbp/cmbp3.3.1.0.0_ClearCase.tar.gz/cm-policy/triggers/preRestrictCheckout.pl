#VERSION CMBP 2.2
#
###########################################################################
##
## Program: preRestrictCheckout
##
## Summary: This is an individual element (not "all element" type) trigger 
##       that is fired before checkout operation. Trigger must be applied  
##       individually to each element with "cleartool mktrigger" command.
##       eg. 
##       % cleartool mktrigger -nc preRestrictCheckout /usr/vob/sc/scmtest/dir1
##       % cleartool mktrigger -nc -recurse preRestrictCheckout /usr/vob/sc/scmtest/dir1
##
## Description:
##
##       If an element has this trigger attached, make sure the user            
##       has permission to checkout
###############################################################################

package PreRestrictCheckout;
use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(preRestrictcheckout);

BEGIN {
	use File::Basename;
	my $SCRIPT_ROOT = dirname $0;
	push(@INC, "$SCRIPT_ROOT/../lib");
}

use vars qw($CLEARTOOL $TMPDIR);

use CMBlueprint;
use CMBlueprint::Config;

use vars qw(@CC_INTRELMAIN_CO_LST @CC_RESTRICT_CO_LST);

my $ELEMENTCO_HYPERLINK = "element_co_permitted";

################## ACE TRIGGER ###########################################

=head1 NAME

preRestrictCheckout -- function called on pre-op of 'cleartool checkout' command.  
Restrict the checkout to certain users.

=head1 SYNOPSIS

  preRestrictCheckout.pl


=head1 INSTALLATION COMMAND

 Create trigger type using the following command:

 cleartool mktrtype -elem -preop checkout  \
   -execunix $UNIX_PERL "$UNIX_INSTALL_DIR/triggers/triggerMain.pl -t preRestrictCheckout" \
   -execwin  $NT_PERL   "$NT_INSTALL_DIR\triggers\triggerMain.pl preRestrictCheckout" \
 preRestrictCheckout

=head1 RETURN VALUES

 0 on success
 1 on failure

=head1 AUTHOR

ACE Common CM Dev Team E<lt>ise-list@relay1.cig.mot.comE<gt>

=cut

##########################################################################

sub preRestrictcheckout{
	
	my $user = $ENV{"CLEARCASE_USER"};

	#if user is in a predefined user list, let it pass through
	foreach (@::CC_INTRELMAIN_CO_LST) {
		return 0 if ( lc($user) eq lc($_) );
	}
	
        #if the user is in predefined Restrict checkout list, let it pass through
	foreach (@::CC_RESTRICT_CO_LST) {
		return 0 if ( lc($user) eq lc($_) );
	}

        my $user_label_prefix = "USER_OBJ_";
	my $allowedtocheckout = 0;

        # 
        # Only if the element has the $ELEMENTCO_HYPERLINK hyperlink from the
        # users predefined lbtype (eg. USER_OBJ_<USER> the element can be checked out
	# by the user. 
	# 

	my $fname = $ENV{"CLEARCASE_PN"};

	my $gethlinkcmd = "$CLEARTOOL describe -s -ahlink $ELEMENTCO_HYPERLINK $fname@@";

        dprint("gethlinkcmd: $gethlinkcmd\n");

	my @allowedusers = qx($gethlinkcmd);
	if($?)
	{
	  display_msg("The following command failed:\n$gethlinkcmd\n");
	  exit 1;
	}

        my $user_uc = uc ($user);
        my $userlabel = "$user_label_prefix" . "$user_uc";
        dprint ("userlabel to look for: $userlabel\n");
        dprint ("label types with $ELEMENTCO_HYPERLINK hyperlink : \n @allowedusers");

	foreach (@allowedusers)
	{
	    dprint ("Hyperlink output: $_\n");
	    next unless (/^<-/);
	    if (/lbtype:$userlabel/) {
	      my $temp = (split(/:/))[-1];
	      my $label = (split(/\@/, $temp))[0];
              chomp ($label);
	      if ($userlabel eq $label)
	      {
	        $allowedtocheckout = 1;
	        last;
	      }
	    }
	}

	if($allowedtocheckout == 0 )
	{
	  display_msg("You do not have permission to checkout this file");
	  return 1;
	}
}


##########################################################################

1;
