#VERSION CMBP 2.2
#
###############################################################################
##
## Program: preMkelem  
##
## Summary: trigger fired before mkelem/mv operation
##
## Description:
##
##       Search all other branches and versions of the parent directory
##       to determine if an element with the same name has already been
##       created.  If so,
##       create a hard link if the parent operation is mkelem
##       error out if the parent operation is rmname (ct move)
##
###############################################################################

## Need these variables from the main:: package
use vars qw($FORBID_TWIN_ELEMS_ENABLED);


package PreMkelem;

use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(premkelem);

BEGIN {
	use File::Basename;
	my $SCRIPT_ROOT = dirname $0;
	push(@INC, "$SCRIPT_ROOT/../lib");
}

use CMBlueprint;


use vars qw($CLEARTOOL);

################## ACE TRIGGER ###########################################

=head1 NAME

preMkelem  -- function called on pre-op of 'cleartool mkelem/mv' command.  Disallows 
creation of an element if the element already exists in other versions of the parent 
directory.

=head1 SYNOPSIS

 premkelem()

=head1 INSTALLATION COMMAND

 Install trigger using the following command:

 cleartool mktrtype -elem -all -preop lnname  \
   -execunix $UNIX_PERL "$UNIX_INSTALL_DIR/triggers/triggerMain.pl -t preMkelem"\
   -execwin  $NT_PERL   "$NT_INSTALL_DIR\triggers\triggerMain.pl -t preMkelem" \
 preMkelem

=head1 DESCRIPTION

=over 3


=item 1.

Get the parent the parent operation, ENV{CLEARCASE_POP_KIND}.
Exit unless parent operation is mkelem or rmname

=item 2.

Get the name of the parent directory from $ENV{CLEARCASE_XPN}.             

=item 3.

Get the base name of the element from $ENV{CLEARCASE_XPN}.           

=item 4.

Get a recursive listing of the parent directory element.

=item 5.

Check the elementinvob hyperlink and see if the element already exit in the vob.


=head1 RETURN_VALUES

 Returns 0 if the element does not exist in the VOB
 Returns 1 if the element already exists in the VOB


=cut

##########################################################################

sub premkelem{

   unless ($::FORBID_TWIN_ELEMS_ENABLED) {
      dprint "perf", "# bypassed 'evil-twin' check!\n";
      return 0;
   }

   my $pop_kind = $ENV{'CLEARCASE_POP_KIND'};
   chomp ($pop_kind);

   dprint("pop_kind: $pop_kind");

   # We only need the trigger for ct mkelem and ct mv command
   unless (($pop_kind =~ /rmname/) || ($pop_kind =~ /mkelem/)) {
     return 0;
   }

   ###################################################
   # Get name of parent directory and the element    #
   ###################################################
   my $parent_dir = dirname $ENV{'CLEARCASE_XPN'};
   my $element = basename $ENV{'CLEARCASE_XPN'};
   chomp($element);

   dprint("parent_dir:$parent_dir element:$element\n");

   my $hyperlink = "elementinvob";
   my $foundit = 0;
   my $populatedir = 1;
   my @hloutput = qx($CLEARTOOL describe -ahlink $hyperlink \"$parent_dir\@\@\");
   my $elementInVob;    
   my $FullXPNelementName;   

   foreach (@hloutput)
   {
       chomp;

       if(/Hyperlinks:/)
       {
	   $foundit = 1;
	   next;
       }
       
       if($foundit == 1)
       {
	   if(/<-/)
	   {
	       next;
	   }
	   else
	   {
	       $populatedir = 0;
	   }

	   $FullXPNelementName = (split(/->/))[1];
	   $elementInVob = basename $FullXPNelementName;
	   
	   $elementInVob =~ s/\@\@$//;
	   if($elementInVob eq $element)
	   {

	     # If the $op_kind is rmname then user is trying to do a move
	     # and element already exists in a version of the parent directory.
	     # So exit with error message

	     my $FullPathElement = "$parent_dir/$element";
	     my $lncmd = "$CLEARTOOL ln $FullXPNelementName $FullPathElement";

	     if ($pop_kind =~ /rmname/)
	     {
	       display_msg("Element $element already exists in:\n$FullXPNelementName
                 \nTo create $element execute:\n$lncmd", 1);
	       return 1;
	     }
	     elsif ($pop_kind =~ /mkelem/) 
	     {
	       display_msg("Element $FullPathElement already exists in:\n$FullXPNelementName\n
                  \nTrigger will automatically create a link so that it is visible in view", 2);

	       my @lnoutput;
 
	       @lnoutput = qx($lncmd);
	       if($?) 
	       {
		 display_msg("Error in executing the following command:\n\t$lncmd\n", 1);
		 return 1;
	       }
               
	       display_msg ("\nSuccessfully created the link. 
                  \rIf you did not intend to create the link execute:
                  \rcleartool rmname $FullPathElement to remove the element.\n",3);

	       display_msg ("Trigger will now exit with failure and warning messages. 
                   \rPlease ignore these failure and warning messages.\n\n", 2);

	       return 1;
	     }# endif $pop_kind

	   } # endif $elementInVob

	 }# endif $foundit

   }#end of @hloutput

   # There is no 'elementInVob' hyperlink attached to the directory. Will populate 
   # hyperlink by attaching all elements in the current directory 
   # to hyperlink 'elementInVob';

   if($populatedir == 1)
   {
       # getting all the elements in the current directory in the vob.
       my $lscmd = "$CLEARTOOL ls -recurse \"$parent_dir/\.\@\@\"";
       my @lsoutput;
       my %fileList;
       my $fileName;

       @lsoutput = qx($lscmd);
       if($?)
       {
	   display_msg("Error in executing the following command:\n\t$lscmd\n");
	   return 1;
       }
       

       # the output of the cleartool ls command is as followings:
       #
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/0/bar.c@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/0/foo.c@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/0/lost+found@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/1/dir6@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/1/foo.c@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/1/lost+found@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/2/dir6@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/2/hhh.h@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/2/lost+found@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/3/ccc.h@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/3/dir6@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/3/hhh.h@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/3/lost+found@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/LATEST/ccc.h@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/LATEST/dir6@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/LATEST/hhh.h@@
       #     /usr/vob/sc/arnie_cruz.dir/.@@/main/dev-20113/LATEST/lost+found@@
       #
       #
       #
       # To obtain an exclusive list of files, will use an associative array using the filename as the key.
       #
       
       foreach (@lsoutput)
       {
	   chomp;
	   if(/\@\@$/)
	   {
	       $fileName = basename $_;
	       $fileName =~ s/\@\@$//;

	       if(!exists($fileList{$fileName}))
	       {
		   $fileList{$fileName} = $_;
	       }
	   }
       }


       my $key;
       my $mkhlinkcmd;
       my $isdup=0;
       my $duplocation;

       foreach $key (keys %fileList)
       {
	   $mkhlinkcmd = "$CLEARTOOL mkhlink $hyperlink \"$parent_dir\@\@\" \"$fileList{$key}\"";
	   qx($mkhlinkcmd);
	   
	   if($key eq $element)
	   {
	       $isdup = 1;
	   }
       }

       # ok .. now that the directory hyperlinks are now populated will check if the new file is already an element.
       if($isdup == 1)
       {
	   display_msg("Error:  Element already exists in $fileList{$element}\n", 1);
	   return 1;
       }
   }

   return 0;
}

1;


