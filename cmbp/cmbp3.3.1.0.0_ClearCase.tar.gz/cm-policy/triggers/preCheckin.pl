#VERSION CMBP 2.2
#
######################################################################
#
# SCRIPT NAME: preCheckin.pl
#
# DESCRIPTION: This is the pre checkin trigger script that is run
#              prior to checking in any element.
#
######################################################################
package PreCheckin;

use strict;
# use diagnostics;
use Env;
use FileHandle;
use File::Basename;
use File::Copy;
use CMBlueprint;

use vars qw($CLEARCASE_ELTYPE $CLEARCASE_PN $NT);

sub precheckin {
	
	my $ret_val=0;                         # Return value for script
	
	if ( $NT ) {

	# Check if the file needs to be checked for CR's, ^M, & EOF, ^Z

	if ($CLEARCASE_ELTYPE =~ /^text_file | ^perl_file/x) {
		if ( ! -w $CLEARCASE_PN ) {
			$ret_val = chmod 0755, "$CLEARCASE_PN"; 
			if ( $ret_val != 1 ) {
				display_msg("Failed to chmod for the element ($CLEARCASE_PN).\nPlease make the element writable before checking in the element again.\n", 1);
				exit ( not $ret_val);
			}
		}
		$ret_val = &strip_cr($CLEARCASE_PN);
	}
	else {
		$ret_val = 0;
	}

	} #if( NT) end

	exit $ret_val;
}

######################################################################
# SUBROUTINE: strip_cr
#
# DESCRIPTION: Open a file, read it, strip all <CR>'s and
#              write it back out in binary mode.
#
# CLEARCASE CMDS: N/A
#
# PARAMETER LIST: 1) String containing file name to process
#
# USAGE: strip_cr($filename);
#
# RETURN VALUE: 0 - SUCCESSFUL
#               1 - NOT SUCCESSFUL
#
######################################################################
sub strip_cr {
    my $fn = shift;
    my $fh;
    my @file_array;
    my $curDir= dirname $fn;
    my $tmpfile = "$curDir/precheckin$$.tmp";
    my $tmpfile1 = "$curDir/precheckin1$$.tmp";
    my $tmpfh;

	dprint "tmpfile=$tmpfile NT=$NT\n";

    $fh = new FileHandle $fn, "r+";
    return (1) unless defined $fh;

    $tmpfh = new FileHandle $tmpfile, "w+" ;
    return (1) unless defined $tmpfh;

    binmode($fh);
    binmode($tmpfh);

    @file_array = $fh->getlines;
    seek($tmpfh, 0,0);

# Search and destroy <CR> aka ^M and \r

    foreach (@file_array) {
        s,\r,,g;
       if ( ! print( $tmpfh $_ )) {
		display_msg("Failed to strip \"\^M\". and Failed to copy to tmp file. \n",2);
		cleanup ( $tmpfile, $tmpfile1 );	
		return 0;
	}
    }

    if ( ! $fh->close ) {
	display_msg("Failed to strip \"\^M\". Failed to close original file handle.\n",2);
	cleanup ( $tmpfile, $tmpfile1 );
	return 0;
    }
    if ( ! $tmpfh->close ) {
	display_msg("Failed to strip \"\^M\". Failed to close tmp file handle. \n",2);
	cleanup ( $tmpfile, $tmpfile1 );
	return 0;
    }

    if ( ! copy( $fn, $tmpfile1 ) ) {
	display_msg("Failed to strip \"\^M\". Failed to link original to tmp file.\n",2);
	cleanup ( $tmpfile, $tmpfile1 );
	return 0;
    }	
	
    if ( ! unlink($fn )) {
	display_msg("Failed to strip \"\^M\". Failed to unlink original file.\n",2); 
	cleanup ( $tmpfile, $tmpfile1 );
	return 0;
    }

    if ( ! copy( $tmpfile, $fn ) ) {
	copy ( $tmpfile1, $fn ) ;
	display_msg("Failed to strip \"\^M\". Failed to link tmp file to original file.\n",2); 
	cleanup ( $tmpfile, $tmpfile1 );
	return 0;
    }

    cleanup ( $tmpfile, $tmpfile1 );

    return (0);
}

sub cleanup {
	my ( $tmpf, $tmpf1 ) = @_;
	
	if ( -e $tmpf ) {
         	unlink $tmpf ;
   	}
   	if ( -e $tmpf1 ) {
        	unlink $tmpf1 ;
   	}
}

	
################## ACE TRIGGER ###########################################

=head1 NAME

preCheckin -- pre-op trigger of 'cleartool checkin' command.  Strips line feed characters ascii text files for NT.

=head1 SYNOPSIS

  preCheckin.pl


=head1 INSTALLATION COMMAND

 Create trigger type using the following command:

 cleartool mktrtype -elem -all -preop checkin  \
   -execwin  $NT_PERL   "$NT_INSTALL_DIR\triggers\preCheckin.pl " \
 preCheckin


=head1 DESCRIPTION

Strips line feed characters from all ascii text files for checkins from an NT client.

=back

 0 on success
 1 on failure

=head1 AUTHOR

ACE Common CM Dev Team E<lt>ise-list@relay1.cig.mot.comE<gt>

=cut

##########################################################################

1;

