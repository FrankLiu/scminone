#VERSION CMBP 2.2
#
###############################################################################
##
## Program: postMkelem  
##
## Summary: trigger fired after mkelem operation
##
## Description:
##
##       After an element is created, then do the following -
##        - Change the owner of the element to that of the VOB.            
##        - Change the group of the element to the primary group of the VOB
##        - Change the permissions of the element to 775.                   
##
###############################################################################
package PostMkelem;

use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(postmkelem);

BEGIN {
	use File::Basename;
	my $SCRIPT_ROOT = dirname $0;
	push(@INC, "$SCRIPT_ROOT/../lib");
}

use CMBlueprint;
use CMBlueprint::Vob;

use vars qw($CLEARTOOL);

################## ACE TRIGGER ###########################################

=head1 NAME

postmkelem -- function to change the owner and group of the element to that of the VOB.  
It changes the permissions on the element to 775.

=head1 SYNOPSIS

 postmkelem

=head1 INSTALLATION COMMAND

 The trigger type can be created using the following command:

  cleartool mktrtype -elem -all -postop mkelem  \
    -execunix $UNIX_PERL $UNIX_INSTALL_DIR/triggers/triggerMain.pl -t postMkelem\
    -execwin  $NT_PERL   $NT_INSTALL_DIR\triggers\triggerMain.pl -t postMkelem\
  postMkelem


=head1 DESCRIPTION

=over 3

=item *

Get the owner and primary group of the VOB

=item *

Change the owner, group and permissions of the element with 
I<cleartool protect -chown vob_owner -chgrp vob_primary group -chmod 775 ....> 
command.

=back

=head1 RETURN VALUES

 0 on success
 1 on failure

=cut

##########################################################################

sub postmkelem {
   ##################################################
   # Get the vob owner and group                    #
   ##################################################
   my ($vob_owner, $vob_group) = &get_vob_owner_group;

   ##################################################
   # Change the owner, group and permissions on     #
   # the element.                                   #
   ##################################################
   my $cmd = "$CLEARTOOL protect -chown $vob_owner -chgrp \"$vob_group\" -chmod 775 \"$ENV{'CLEARCASE_PN'}\"";
   prep_cmd(\$cmd);
   `$cmd`;
   if ($? != 0){
      display_msg("Warning:  Could not change ownership/group/permissions of $ENV{'CLEARCASE_PN'}\n",2);
      return 1;
   }


   ###### Adding the newly created file name to the evil twin hllink.
   my $hlink="elementinvob";
   my $fullfilepath = $ENV{'CLEARCASE_PN'};
   my $file;
   my $dir;
   
   ## getting the basename and dirname from $fullfilepath
   $file=$fullfilepath;
   $dir=dirname  $fullfilepath;

   if($ENV{"CQCC_DEBUG"})
   {
       print "FILE=$file DIR=$dir\n";
   }

   $cmd = "$CLEARTOOL mkhlink $hlink \"$dir\@\@\" \"$file\@\@\"";
   qx($cmd);
   if($? != 0)
   {
       display_msg("Warning: Could not apply hlink to directory $dir\n",2);
       return 1;
   }
}

1;


