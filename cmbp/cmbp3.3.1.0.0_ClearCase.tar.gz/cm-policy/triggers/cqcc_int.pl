#!c:\perl\bin\perl
#
#VERSION CMBP 2.2
#
#---------------------------------------------------------------------------+
# | Copyright 1998, Rational Software Corporation.  All Rights Reserved.
# | This software contains proprietary and confidential information of
# | Rational and its suppliers.  Use, disclosure or reproduction is
# | prohibited without the prior express written consent of Rational.
#---------------------------------------------------------------------------+
# modified by Jim Tykal, Rational Software Corporation
#  990524 - add functionality to associate branch type with CR, and
#           automatically associate any checkouts on that branch type
#           with the same CR.
#  991205 - Allow only a single CR to be associated with a ClearCase event.
#           Do not allow the CR associated on checkout to be changed on
#            checkin.
#           Create a "originatingCR" attribute on an element upon checkout
#            if that attribute does not already exist.
#  000131 - Revamped the script to use functions, site.cfg, prod_triggers.cfg
#
# Perl script to associate/disassociate ClearQuest bugs via a web server.
# Intended to be called as a ClearCase trigger script for co/ci/unco.
#
# Trigger is called POST-checkout, so it will attempt to uncheckout the
# file if the trigger fails. Since it is called PRE-checkin or uncheckout,
# simply returning a failed status will abort the ClearCase operation.
#
# Usage: scriptname -d <cm_policy_dir> -p <prod>
#-----------------------------------------
# INSTRUCTIONS FOR ATTACHING THIS TRIGGER
#-----------------------------------------
# cleartool mktrtype -element -all -postop checkout \
#    -exec "perl <pathname>/cqcc_int.pl \
#              -d <cm_policy_dir> -p <prod>" \
#    postCheckout
#
# cleartool mktrtype -element -all -prepop checkin,uncheckout \
#    -exec "perl <pathname>/cqcc_int.pl \
#            -d <cm_policy_dir> -p <prod>" \
#    preCheckin_Uncheckout
#
# cleartool mktrtype -type -postop mktype -brtype -all \
#    -exec "perl <pathname>/cqcc_int.pl \
#            -d <cm_policy_dir> -p <prod>" \
#    postMkbrtype
#-----------------------------------------

## Need the following variables from the main:: package
###############################################
# Use variables from site.cfg                 #
###############################################
use vars qw($CQ_REC_TYPE @CC_VOBADM_LST $CC_NT_ADMINVOB $CC_UNIX_ADMINVOB $CC_NT_PSEUDO_ADMINVOB $CC_UNIX_PSEUDO_ADMINVOB $NT);

###############################################
# Use variables from $PROD_trigger.cfg        #
###############################################
use vars qw(@CQ_DB_LST $CQ_DEF_DB $OPCACHE_TIMEOUT $UNIX_VIEWSTORE
            $PROMPT_ON_CR_MISMATCH
            $PER_CO_AUTH_REQD
            $CQCC_INTEGRATION_ENABLED
            $CQCC_CSET_LOGGING_ENABLED);


package CqCcInt;

use strict;

use Socket;
use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(cqcc_int);

###############################################
# Use variables from CMBlueprint.pm             #
###############################################
use vars qw(%CQ_QUERY_FILTER $CLEARTOOL
            %CQ_WEB_PARAMS   $CQCC_HLTYPE
            $TMPDIR          $CQCC_ATTYPE);



BEGIN {
  use File::Basename;
  my $dirname = dirname($0);
  unshift(@INC, "$dirname/../lib");
  unshift(@INC, "$dirname/../config");
};


use CMBlueprint;
use CMBlueprint::ClearQuest;
use CMBlueprint::ViewCache;
use CMBlueprint::Branch;
use CMBlueprint::MetaData;
use CMBlueprint::NamingPolicy;
use CMBlueprint::CQWeb;
use CMBlueprint::UI;
use CMBlueprint::Vob;

%CQ_QUERY_FILTER = ( Technical_Authority  => ['like','[CURRENT_USER]~'],
                     State                => ['eq','Assigned']);
use vars qw($OpCache_ref);

##########################################################################

#
# Function that will verify if the given brtype exist in the adminvob.
# If true will return 1 otherwise return 0;
#
#
sub isBrtypeInAdminVob($)
{
    my $bt = shift @_;
    $bt=~s/\@.*$//;
    my $brtypecmd = "$CLEARTOOL describe brtype:$bt\@";
    if($NT)
    {
	$brtypecmd .= "$::CC_NT_ADMINVOB 2>$ERRNULL";
    }
    else
    {
	$brtypecmd .= "$::CC_UNIX_ADMINVOB 2>$ERRNULL";
    }

    if($ENV{CQCC_DEBUG})
    {
	print "command = $brtypecmd\n";
    }

    my @broutput = qx($brtypecmd);
    if($? == 0)
    {
	if($ENV{CQCC_DEBUG})
	{
	    print "found brtype in adminvob";
	}

	return 1;
    }

    if($ENV{CQCC_DEBUG})
    {
	print "No brtype in adminvob .. will continue";
    }

    return 0;
}





## Need some "wrapper" functions for validating/prompting for CR-IDs
## based on whether or not the CQ/CC integration is enabled

sub cqccint_AuthorizedCR ($) {
    my $crid = shift;
    if ($::CQCC_INTEGRATION_ENABLED) {
       return AuthorizedCR($crid, $::CQ_REC_TYPE, $::CQ_DEF_DB, @::CQ_DB_LST);
    }
    else {
       dprint("perf", "# bypassing CQ for CR authorization!\n");
       return  CQ_VALID_CR;  ## implied success
    }
}

###########
sub mkbrtype_SPCFVerificationForCR {
  my $crnumber = shift;
    
  if ($::CQCC_INTEGRATION_ENABLED) 
  {
	dprint("crnumber = $crnumber\n");  	 
	my ($rc, $CRSPCF) = GetSPCFforCR($crnumber);

	if($rc)
	{
	    display_msg("Invalid Database name in the cr number: $crnumber\n");
	    exit(1);
	}
	
	my $VOBSPCF = getVOBSPCF();  
	    
    if ((defined($VOBSPCF) && ($VOBSPCF ne "") && ($CRSPCF ne "") && ($CRSPCF ne $VOBSPCF)))
    {
        display_msg("CR $crnumber SPCF \"$CRSPCF\" differs from VOB SPCF \"$VOBSPCF\".\n");
		exit(1);
    }
    else
    {
        return  CQ_VALID_CR;  ## implied success
    }
  }
  else
  {
    dprint("perf", "# bypassing CQ for CR $crnumber SPCF verification!\n");
    return  CQ_VALID_CR;  ## implied success
  }
}

###########
sub mkbrtype_AuthorizedCR {
	
	my $crid = shift;
	if ($::CQCC_INTEGRATION_ENABLED) {
		my %query_results =();
		my ($rc, $cquser, $cqpwd) = GetLogonParms();
		if ( ($rc = comm_AuthorizedCR ( $crid, $cquser, \%query_results )) == CQ_VALID_CR ) {
			#check the result
			foreach (keys %query_results ) {
				dprint("query_results	$_=$query_results{$_}\n");
			}
			if($query_results{'State'} !~ m/Assigned/i ) {
                                display_msg("Error: CR($crid) is not in the \"Assigned\" state. It is in \"$query_results{'State'}\" state.\n");
				my ($rc, $message) = GetValidCRSet($::CQ_DEF_DB);

				if ($rc != CMBP_SUCCESS){
				  display_msg("Error: Query to get assigned CRs failed!!! \n", 1);
				}
				else {
				  display_msg("$message\n",3);
				}
				return 1;
			}
  
                        if($query_results{'Technical_Authority'} !~ m/$cquser~/) {
                                display_msg("Error: CR($crid) is not assigned to the user($cquser). Currently it is assigned to the user($query_results{'Technical_Authority'}).\n");

				my ($rc, $message) = GetValidCRSet($::CQ_DEF_DB);

				if ($rc != CMBP_SUCCESS){
				  display_msg("Error: Query to get assigned CRs failed!!! \n", 1);
				}
				else {
				  display_msg("$message\n",3);
				}
                                return 1;
                        }

			if ($query_results{'cc_change_set.objects'} =~ m/WORK_/ ) {
				display_msg("Error: You already have an active CR branch associated with this CR($crid). You can not create a new CR branch until this CR branch type is deleted or obsoleted.\n");
				return 1;
			}


			if($query_results{'Work_Product_ID'} ne "")
			{
			    display_msg("CR is already associated with DCML.\n");
			    return 1;
			}

		}
		else {
		  # The CR passed is not a valid one so get the CRs assgined 
		  # to current user

		  my ($rc, $message) = GetValidCRSet($::CQ_DEF_DB);


		  if ($rc != CMBP_SUCCESS){
		    display_msg("Error: Query to get assigned CRs failed!!! \n", 1);
		  }
		  else {
		    display_msg("$message\n",3);
		  }
		  return 1;
		}
	}
	else {
       		dprint("perf", "# bypassing CQ for CR authorization!\n");
       		return  CQ_VALID_CR;  ## implied success
    	}
}

##

sub postcheckout_AuthorizedCR {
	my $crid = shift;
        if ($::CQCC_INTEGRATION_ENABLED) {
                my %query_results =();
                my ($rc, $cquser, $cqpwd) = GetLogonParms();
                if ( ($rc = comm_AuthorizedCR ( $crid, $cquser, \%query_results )) == CQ_VALID_CR ) {
                        #check the result

			foreach (keys %query_results ) {
                                dprint("query_results   $_=$query_results{$_}\n");
                        }

                        if($query_results{'State'} !~ m/Assigned/i ) {
				display_msg( "Error: CR($crid)is not in the \"Assigned\" state. It is in \"$query_results{'State'}\" state.\n",1 );	
                                return 1;
                        }

                        if($query_results{'Technical_Authority'} !~ m/$cquser~/) {
				display_msg("Error: CR($crid) is not assigned to the user($cquser). It is assigned to the user($query_results{'Technical_Authority'}).\n",1); 
                                return 1;
                        }
                }
                else {
			return 1;
                }
        }
        else {
       		dprint("perf", "# bypassing CQ for CR authorization!\n");
       		return  CQ_VALID_CR;  ## implied success
    	}
}


sub cqccint_GetAssignedCR ($) {
   my $optsRef = shift;
   if ($::CQCC_INTEGRATION_ENABLED) {
      return  GetAssignedCR($optsRef, $::CQ_REC_TYPE,
                                      $::CQ_DEF_DB, @::CQ_DB_LST);
   }

   dprint("# bypassing CQ to prompt for assigned CR!\n");

   my %opts = %$optsRef;
   local $_ = (defined $opts{'-abort'} and $opts{'-abort'}) ? "Abort" : "Ignore";
   my $prompt = "Enter ClearQuest CR ID ('?'=help, 0 = $_): ";

   my $help_msg = "Enter the ID of the ClearQuest CR to associate with this ClearCase operation.\n" .
   "You may enter a full CR number or drop the leading zeros, like this: '<DBID>23'\n" .
   "If you do not specify <DBID>, it will default to $::CQ_DEF_DB.\n" .
  "Entering '?' will produce this message.\n";

   $_ = $opts{'-helpmsg'};
   $help_msg .= $_  if (length and ! /^\d+$/);

   my ($rc, $crid) = (0, '');
   my @buglist = ();

   while (!$crid  and  !$rc) {
      ($rc, $_) = get_text({'-name' => 'CRID'}, $prompt);
      $rc = CMBP_FAIL if ($rc != 0  and  $_ eq '0');
      last if ($rc != 0);

      length  or  display_msg("You did not enter a valid CR Id\n");
      next unless length;

      @buglist = split;
      if ($buglist[0] eq "0"){
         $rc = 1;
      }
      elsif ( $buglist[0] eq "?"){
         display_msg($help_msg,3);
      }
      elsif ( $buglist[0] eq "*"){
         display_msg("Invalid response '*' [CQ/CC integration is disabled]\n".
                     $help_msg);
      }
      elsif (@buglist > 1){
         display_msg("You cannot enter more than one CR number\n");
      }
      elsif ( $buglist[0] =~ m/^\s*([A-Za-z]{1,5})?(\d{1,8})\s*$/ ){
         my ($crnum, $db) = ($2,  $1 || $::CQ_DEF_DB);
        ($rc, $db, $crnum) = GenerateCrId($db, $crnum,$::CQ_DEF_DB, @::CQ_DB_LST);
         ($rc, $crid) = (0, $db.$crnum);
      }
      else {
         display_msg("You have entered an invalid CR number. " .
                     "CR number should be of the form: \n");
         display_msg($help_msg, 3);
      }
   }

   return ($rc, $crid);
}

##########################################################################

=head1 NAME

cqcc_int.pl -- ClearQuest-ClearCase integration trigger
function.  The function is called on post-checkout, pre-checkin,
pre-uncheckout and postop mktype -brtype operations.

=head1 SYNOPSIS

  cqcc_int.pl

=head1 INSTALLATION COMMANDS

See "trigger_install.pl" for installation commands.

=head1 PRE-REQUISITES

=over 3

=item 1.

The $UNIX_INSTALL_DIR and $NT_INSTALL_DIR should have the following sub-directories:

=over 5

=item *

bin -  Containing standalone scripts

=item *

triggers - Containing trigger scripts and libraries

=item *

config - Containing 'site.cfg' and I<PROD>_triggers.cfg' files

=back

=item 2.

'CrmRequest' hyperlink type should exist in the VOB.  A 'CrmRequest' hyperlink instance signifies the ClearQuest CR associated with the ClearCase operation.

=item 3.

'OriginatingCR' attribute type should exist in the VOB.  'OriginatingCR' attribute signifies the ClearQuest CR which caused the creation of the file element.

=back

=head1 DESCRIPTION

=over 3

=cut

###############################################################
my $MustWrite_OpCache = 0;

sub cqcc_int {

  local $SIG{INT} = 'IGNORE';

  my $op = $ENV{CLEARCASE_OP_KIND};
  my $pn = qq#"$ENV{CLEARCASE_PN}"#;  # get pathname of ClearCase object
  my $xpn = qq#$ENV{CLEARCASE_XPN}"#; # extended path
  # branch type of ClearCase object
  my $brtype = $ENV{CLEARCASE_BRTYPE} . "@" . $ENV{CLEARCASE_VOB_PN};


  my $rc;

  if ($op eq 'mktype'){
      $rc = preMkbrtype($brtype); 
  }
  elsif ($op eq 'checkout'){
      $rc = postCheckout($brtype, $pn);
  }
  elsif ($op eq 'checkin'){
      $rc = preCheckin($pn, $xpn);
  }
  elsif ($op eq 'uncheckout'){
      $rc = preUncheckout($pn);
  }

  finalize_opcache($MustWrite_OpCache );

  $SIG{INT} = 'DEFAULT';

  return $rc;

}


###############################################################


=item B<preMkbrtype>

 1.  Parse the branch type name.
 2.  If the branch type name follows the naming convention,
     2.1.  Get the ClearQuest CRID from the branch name
     2.2.  Check if the user is authorized to work on the CR

           2.2.1. If the user is authorized to work on the CR, then
                  a.  Attach attribute, "OriginatingCR=<CRID>", to
                      the branch type, where <CRID> is the ClearQuest
                      CR ID.
                  b.  If $::PER_CO_AUTH_REQD is set in the
                      $PROD_trigger.cfg file, lock the branch type
                      for everybody except the TA and the VOBADMs.
                  c.  Change the owner and group of the branch
                      type to that of the VOB.
                  d.  If $::CQCC_CSET_LOGGING_ENABLED flag in
                      $PROD_trigger.cfg set to 1, log the
                      ClearCase change set in ClearQuest.

           2.2.2. If the user is not authorized to work on the CR,
                  and if the $::PROMPT_ON_CR_MISMATCH flag is
                  set in the config file then,
                   a. Give error message to user CR is not assigned to user then exit 1.

 3.  If the branch type name does not follow the naming convention,
     3.1.  Give error message to user branch name is not part of 
           naming convention then exit 1.



=cut

###############################################################

sub preMkbrtype {
	
  my $brtype = shift @_;

  my $tmpbt = $brtype;
  $tmpbt =~ s/\@.*$//;
  $tmpbt =~ s/^.*://;
  if ( $tmpbt =~ m/[A-Z]/ ) {
	display_msg("($tmpbt) part of branch name ($brtype) can not contain upper-case letter!",1);
	return 1;
  }
	
  return 0 if ( ! $::CQCC_INTEGRATION_ENABLED );
  
  # check to see if the brtype exist in the admin vob. If so exit gracefully.
  if(isBrtypeInAdminVob($brtype) == 1)
  {
      exit 0;
  } else {

	##error out if there is admin vob and not creating in admin vob
  	my $aVob = $NT ? $::CC_NT_ADMINVOB : $::CC_UNIX_ADMINVOB;
	my $inVob = $ENV{CLEARCASE_VOB_PN};
	my $aVobLink = (grep { m/->\s+vob:/ }  qx{$CLEARTOOL describe -short -ahlink AdminVOB vob:$inVob})[0];
	$aVobLink =~ s/^\s*->\s*vob://;
	chomp($aVobLink);

	dprint("aVob($aVob) inVob($inVob) aVobLink($aVobLink)");
	##aVob comes from site.cfg and may not in formal format
	if ( $aVob && $aVobLink && ( $inVob ne $aVob ) && ($inVob ne $aVobLink) ) {
		display_msg(qq(Brtype must be made in admin vob using the following command: \ncleartool mkbrtype -replace -global -acquire $tmpbt\@$aVob));
		exit 1;
	}

  }

  my ($rc, $crid, $new_crid);
  my $env_crid = $ENV{CMBP_CRID};
  my $crid_verified = $ENV{CMBP_CRID_VERIFIED};
  if(length $env_crid){
	# This part of the code is required to Create the CR ID in correct format if user does not have it in correct format
	my($env_cqdb, $env_crnum);
	($rc, $env_cqdb, $env_crnum) = ParseCrId($env_crid);
	unless($rc){
		my $cnt = $env_crnum =~ tr/0-9//;
		if($cnt < 8) {
			($rc, $env_cqdb, $env_crnum) = GenerateCrId($env_cqdb,$env_crnum,$::CQ_DEF_DB, @::CQ_DB_LST);
			$env_crid = $env_cqdb.$env_crnum unless($rc);
		}
	}
  }

  my %retval = ParseBrtypeName($ENV{CLEARCASE_BRTYPE},1);

  if ($retval{ERROR} == 0){
      return  0 if ($retval{IS_SANDBOX_USAGE});

      ##if int/rel branch, nothing need to be done

      if (  $retval{IS_INT_USAGE} || $retval{USAGE_TAG} =~ m/^(bld|int|main)$/ ) {
	  return 0;
      }
		
	  #for xxx-main alternate mainline branch
	  return 0 if ( $ENV{CLEARCASE_BRTYPE} =~ m/-main$/ );

      # if the brtype has the CR in the name.
      my ($cqdb,$crnum);
      ($rc, $cqdb, $crnum) = GenerateCrId($retval{ORIG_CQDB},
					  $retval{ORIG_DBID},
					  $::CQ_DEF_DB, @::CQ_DB_LST);
      if ($rc){
	  display_msg("Ambiguous database name in brtype:$ENV{CLEARCASE_BRTYPE}", 1);
	  return 1;
      }
      $crid = $cqdb . $crnum;
    
      if(!(($crid eq $env_crid ) and $crid_verified==1))
      {
	     if(($rc  =mkbrtype_SPCFVerificationForCR($crnum)) != CQ_VALID_CR)
	     {
	       display_msg("Error: SPCF for $brtype is not equal to vob SPCF.\n",1);
	       return 1;
         }

	  if(($rc = mkbrtype_AuthorizedCR($crid)) != CQ_VALID_CR)
	  {
	      display_msg("Error: Branch type creation for $brtype failed due to the previous error message.\n",1);
	      return 1;
	  }
      }

     # Dev-Int branches must have CR Usage=Dev-Integration
     if($retval{IS_DEVINT_USAGE}) {
         dprint (1,"Checking CR_Usage for Dev-Int CR...\n");
          my ($rc, $cr_rel, $cr_loadline, $cr_target_type, $cr_usage)=('','','','','');
          ($rc, $cr_rel, $cr_loadline, $cr_target_type, $cr_usage) = GetRelLLTTCRUforCR($crid);

          if($rc == CQ_LOGIN_FAIL || $rc == CQ_QUERY_FAIL) {
	      display_msg("Error: Branch type creation for $brtype failed due to the error querying CQ CR record for CR_Usage.\n",1);
	      exit 1;
          }

          unless($cr_usage =~ /Dev-Integration/) {
              display_msg("Error: Branch type name $brtype cannot be specified as a Dev-Int unless the CQ CR has a CR_Usage value of Dev-Integration.\nYour CR $crid currently has a CR_Usage=$cr_usage\n",1);
              exit 1;
          }

          # Give Error if TT=Dev-Build AND CRU=Dev-Integration
          if(($cr_usage =~ /Dev-Integration/) and ($cr_target_type =~ /Dev-Build/)) {
              display_msg("Error:The CQ CR_Usage value [$cr_usage] AND Target_Type value [$cr_target_type]\ncannot be set to both of these values.  The CR_Usage may be set\n to Dev-Integration OR the CR Target_Type may be set to Dev-Build, but not both.\n",1);
               exit 1;
          }
     }
               
     # If release is not on Dev-CR branch, then need to validate release from CQ
     # If release is not on Dev-CR branch, then Target Type must be Dev-Build

     if($retval{IS_DEV_USAGE}) {
         # If release part of branch name, release/loadline checks already done in ParseComCMName
	my @brname_segments = (split /\Q$::NAME_SEGMENT_DELIMITER\E+/, $ENV{CLEARCASE_BRTYPE});

        # No Release part in Dev-CR branch name
	unless(length $brname_segments[-2]) {
            dprint (1,"Checking Target_Type for Dev-CR with no release in branch...\n");
            my ($rc, $cr_rel, $cr_loadline, $cr_target_type, $cr_usage)=('','','','','');
            ($rc, $cr_rel, $cr_loadline, $cr_target_type, $cr_usage) = GetRelLLTTCRUforCR($crid);

            if($rc == CQ_LOGIN_FAIL || $rc == CQ_QUERY_FAIL) {
                display_msg("Error: Branch type creation for $brtype failed due to the error querying CQ CR record for CR_Usage.\n",1);
                exit 1;
            }

            if($cr_target_type =~ /Dev-Build/) {
                my $validrelease = getReleaseIDs();
                unless(grep{$_ =~ /$cr_rel$/} keys %$validrelease){
	            display_msg("Error: The 2nd to last segment:$brname_segments[-2] of $ENV{CLEARCASE_BRTYPE}\n must contain a valid Release ID",1);
	            exit 1;
                }
            } else {
	        display_msg("Error: Branch type creation for $brtype failed!\nThe CR Release is required in the 2nd to last segment of the branch name.\n",1);
	        exit 1;
            }

          # Give Error if TT=Dev-Build AND CRU=Dev-Integration
          if(($cr_usage =~ /Dev-Integration/) and ($cr_target_type =~ /Dev-Build/)) {
              display_msg("Error:The CQ CR_Usage value [$cr_usage] AND Target_Type value [$cr_target_type]\ncannot be set to both of these values.  The CR_Usage may be set\n to Dev-Integration OR the CR Target_Type may be set to Dev-Build, but not both.\n",1);
               exit 1;
          }
          # For regular dev-CR branches, CR_Usage cannot be Dev-Integration
          if( $cr_usage =~ /Dev-Integration/ ) {
              display_msg("Error:The CQ CR_Usage value [$cr_usage] defines this CR for Dev-Integration purposes.\nYou must use Dev-Int usage tags such as devint rather than dev.\nOtherwise, the CQ CR_Usage field should be changed to something else.\n",1);
               exit 1;
          }
        }
     }

      if($::DEPENDENCY)
      {
	  my $rc;
	  #
	  # Dependency is turned on ... Will verify if the CR has any dependent on another CR. If so will verify the dependent or dependent-upon
	  # CR is in the same VOB family.
	  #
	  dprint("DEPENDENCY turned on ... \n");

	  # First will see if the CR has any Child Linked CRs....
	  my @childCRs = GetLinkedCRs($crid,\$rc);
	  if($rc)
	  {
	      display_msg("Failed to obtain the child CRs for CR: $crid\n");
	      return 1;
	  }
	  
	  # Now will see if the CR has an Parent Linked CRs.
	  my @parentCRs = GetParentLinkedCRs($crid,\$rc);
	  if($rc)
	  {
	      display_msg("Failed to obtain the child CRs for CR: $crid\n");
	      return 1;
	  }
	  
	  
	  # will obtain the current uuid of the vob family.
	  
	  my $adminvob = $::NT ? $::CC_NT_ADMINVOB :  $::CC_UNIX_ADMINVOB;

	  # For some reason, GetUidOid() requires two parameters if called in mkbrtype. The function does not 
	  # do anything with the second argument. Hence why $adminvob is being used as a dummy var.
	  my ($rc, $uuid) = GetUidOid($adminvob,$adminvob);
	  if($rc)
	  {
	      display_msg("Failed to obtain the uid for vob:$adminvob \n");
	      return 1;
	  }
	  dprint ("rc=$rc uuid=$uuid\n");
	  
	  my $rc;
	  
	  my @allDepCR = (@parentCRs,@childCRs);
	  my $lcrs; # each linked CRs
	  foreach $lcrs (@allDepCR)
	  {
	      my $cruuid = getuuidfromCQ($lcrs,\$rc);
	      if($rc)
	      {
		  display_msg("Failed to obtain the uuid of CR $lcrs\n");
		  return 1;
	      }

	      if($cruuid && $uuid ne $cruuid)
	      {
		  dprint("currentuuid = $uuid .. cruid=$cruuid... \n");
		  display_msg("CR $crid has a dependent/dependent-upon CR $lcrs which has a brtype in a different vob family ($cruuid).\n");
		  return 1;
	      }
	  }
      }

  } # end for if($retval{ERROR} == 0) 
  else {
      my $errMsg = $retval{'ERRMSG'};
      display_msg($errMsg,1) if(length $errMsg);
      return 1;
  }
  return 0;
}


#########################################################################

=item B<postCheckout>

This function is called during the post operation of the co
command, co command expects a CR ID to be provided for the
command to succeed. Before prompting the user to enter the
CR ID, it is tried to determine the CR ID from the CMBP_CRID
Environment variable or the branch type or the view tag
name. The logic and the order used for determining CR ID is
explained in detailed later. If more than one files are being
checked out during the same command and if the CR ID cannot
be retrived from the Environment variable or branch type a
opcache file is written in the view storage area to prevent
from prompting the user and authorizing the CR for every file
being checked out.  The writing of OpCache file will provide
considerable improvement in performance because Clearquest
now needs to be queried only once to authorize the CR ID. If
the CR ID is authorized it is written into the OpCache file
which will then be read during the co operation of the next file

Following is the order in which it is tried to determine the CR ID

1) If CMBP_CRID_VERIFIED Environment variable is set and
CMBP_CRID Environment variable is also set then CR ID in
CMBP_CRID Environment variable is used, CR ID determined in this
case is asumed to be valid because CMBP_CRID_VERIFIED is set
and will not be authorized, OpCache file will not be written.

2)CR ID will tried to be determined from the Branch type in the
following order

     a) check for CRID on the MergeLock hyperlink on the branchtype
     b) check for CRID on the OriginatingCR attribute on the branchtype

If CR ID is determined from any of the above the it will be used without
authorizing and OpCache file will not be written.

3)If the OpCache file exists in the View storage area and the
information in the file is relevant to the current command
then the CR ID in OpCache file will be used

4) CR ID will be tried to be determined form the view tag
name, If the CR ID is retrieved then the CR ID is authorized to
verify that CR is in the assigned state and the person taking
the action is the assigned TA. If the CR is authorized then CR
ID will be used and the information is written in the OpCache
file if it is writeable

5) If CMBP_CRID_VERIFIED Environment variable is not set and
CMBP_CRID Environment variable is set then CR ID in CMBP_CRID
Environment variable is used and authorized to  verify that
CR is in the assigned state and the person taking the action
is the assigned TA. If the CR is authorized then CR ID will
be used and the information is written in the OpCache file if
it is writeable.

6) IF the CR ID cannot be determined from any of the above
the user is prompted to enter a CR ID, the CR ID entered is
authorized to verify that CR is in the assigned state and
the person taking the action is the assigned TA. If the CR
is authorized then CR ID will be used and the information is
written in the OpCache file if it is writeable.

If a valid CR ID is retrieved from any of the above then
the following steps are followed

 a. Create an instance of I<CrmRequest> text hyperlink
    "$::CQ_REC_TYPE -> CRID" on the checked out file

 b. If $::CQCC_CSET_LOGGING_ENABLED flag in the config file is
    set to 1, log the ClearCase change set in ClearQuest.

 c. If the file being checked out is the last file being checked-out
 for the current command then it is tried to delete the opcache
 file if it is deletable.

  Note: The OpCache file will not be deleted on Unix because
  the CLEARCASE_END_SERIES variable is not set.

 e.  Exit with success status.

else If an authorized CR ID cannot be retrived from any of
the above or the user enters '0' or clicks 'Cancel' remove
the checked out file and exit with fail status.

=cut

######################################################################


sub postCheckout {
  my ($brtype, $pn) = @_;
  my $viewtag = $ENV{'CLEARCASE_VIEW_TAG'};

  dprint("mtype is :$ENV{CLEARCASE_MTYPE}: and brtype on which the checkout is taking place is :$brtype: \n");

	return 0 if ( ! $::CQCC_INTEGRATION_ENABLED);
	my %brinfo = ParseBrtypeName($brtype);

	##no CQCC integration for non-dev branch
	return 0 if ( $brinfo{ERROR} == 0 && ((not $brinfo{IS_DEV_USAGE}) || $brinfo{IS_INT_USAGE} ) );

  my ($rc, $crid, $crid_origin);
  my %retval = ();

  $MustWrite_OpCache = 0;

  # This is to verify and get the CR ID from the environment variable
  # if it is set and if it has been verified
  if (length $ENV{'CMBP_CRID'}  and  $ENV{'CMBP_CRID_VERIFIED'}) {
    $crid = $ENV{'CMBP_CRID'};
    $crid_origin = $ENV{'CMBP_CRID_ORIGIN'};
    ($rc, $crid) = FormatCrId($crid);
    $crid = $crid_origin = ""  if($rc);
  }

	my $help_msg = "You must associate the checkout with a CR number.  If you do not enter a valid CR number, you will not be allowed to checkout the file";
	if ( $brinfo{IS_DEV_USAGE} ) {
		my $btvob = $brtype;
		$btvob .= qq(\@$ENV{CLEARCASE_VOB_PN}) if ( $btvob !~ m/\@/ );
		($rc,$crid) = GetCrAttr(qq(brtype:$btvob));
		unless ($crid) {
			($rc, $crid) = cqccint_GetAssignedCR({-helpmsg => $help_msg, -abort => 1});
			dprint ("After getting  CR id by prompting user crid is :$crid: \n");
			if ($rc) {
				DoUnco();
				return 1;
			}
			my $mtype_save = $ENV{CLEARCASE_MTYPE};
			$ENV{CLEARCASE_MTYPE} = 'branch type';
			MakeOrigCrAttr("brtype:$brtype", $crid);

			# Check if OriginatingCR needs to be on brtype in AdminVOB
			if (isBrtypeInAdminVob($btvob)) {
				my $admvob = $NT ? $::CC_NT_ADMINVOB : $::CC_UNIX_ADMINVOB;
				my $btadmvob = $brtype;
				$btadmvob =~ s/\@.*$//;
				$btadmvob .= "\@$admvob";
				
				if ( $btvob ne $btadmvob ) {
					if($ENV{CQCC_DEBUG}) {
						print "\nAttaching OriginatingCR attribute to global branch type in Admin VOB...\n";
						print "\$btvob=$btvob...\$btadmvob=$btadmvob\n";
					}
					MakeOrigCrAttr("brtype:$btadmvob", $crid);
				}
			}

			$ENV{CLEARCASE_MTYPE} = $mtype_save;
			MVCsetLog($brtype, $crid,'WORK_STARTED') 
		}
	}

  unless ($crid) {
    ($crid, $crid_origin, %retval) = GetCrFromCCEntName( {'-mergelock_lookup' => 1, '-opcache_lookup' => 1},
                                               'BRTYPE',$brtype );
    return 0 if ($crid_origin eq 'sandbox');

    ## Make sure we write this to the opcache.
    ##!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    ## NOTE that this assumes we want all subsequent version
    ## checkouts of this same command-invocation to use the
    ## CR-ID we just now obtained, even if the subsequent
    ## versions are on different branches and/or VOBs
    ##!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    ($crid  and  $crid_origin ne 'brname')  and  $MustWrite_OpCache = 1;
  }

  if ($crid) {
    dprint ("After getting CR id from env variable or brtype when it is verified crid is :$crid:\n");
  }
  unless ($crid) {
    $OpCache_ref = fetch_opcache($viewtag);
    ($crid, $crid_origin) = @$OpCache_ref{'CRID','CRID_ORIGIN'};
    dprint ("After getting CR id from Query Opcache crid is :$crid\n");
    unless ($crid) {
      ($crid,$crid_origin,%retval)  = GetCrFromCCEntName('VWTAG', $ENV{'CLEARCASE_VIEW_TAG'});
      dprint ("After getting  CR id from GetCrFromCCEntName crid is :$crid: \n");
      $crid_origin = $crid ? "viewtag" : "";
      unless($crid && (postcheckout_AuthorizedCR($crid) == CQ_VALID_CR)) {
        # This part of the code is required to Create the CR ID in
        # correct format if user does not have it in correct format
        ($rc, $crid) = FormatCrId($ENV{'CMBP_CRID'});
        dprint ("After getting CR id from ENV variable when crid not verified is :$crid: \n");
        unless($crid && (postcheckout_AuthorizedCR($crid) == CQ_VALID_CR)) {
          ($rc, $crid) = cqccint_GetAssignedCR({-helpmsg => $help_msg, -abort => 1});
          dprint ("After getting  CR id by prompting user crid is :$crid: \n");
          if ($rc) {
            DoUnco();
            return 1;
          }#End of if for CRID retrieved after prompting the user
          else {
            $MustWrite_OpCache = 1;

			##When the logic reaches here
			##it must be dev branch and
			##no OriginatingCR attribute on brtype, otherwise it will 
			##be found by GetCrFromCCEntName

			##the CR has been validated in cqccint_AuthorizedCR

			my $mtype_save = $ENV{CLEARCASE_MTYPE};
			$ENV{CLEARCASE_MTYPE} = 'branch type';
			MakeOrigCrAttr("brtype:$brtype", $crid);

			# Check if OriginatingCR needs to be on brtype in AdminVOB
			if (isBrtypeInAdminVob($brtype)) {
				my $admvob = $NT ? $::CC_NT_ADMINVOB : $::CC_UNIX_ADMINVOB;
				my $btadmvob = $brtype;
				$btadmvob =~ s/\@.*$//;
				$btadmvob .= "\@$admvob";
				
				if ( $brtype ne $btadmvob ) {
					if($ENV{CQCC_DEBUG}) {
						print "\nAttaching OriginatingCR attribute to global branch type in Admin VOB...\n";
						print "\$brtype=$brtype...\$btadmvob=$btadmvob\n";
					}
					MakeOrigCrAttr("brtype:$btadmvob", $crid);
				}
			}

			$ENV{CLEARCASE_MTYPE} = $mtype_save;
			MVCsetLog($brtype, $crid,'WORK_STARTED') 
          }

        }#End of unless for CR ID after getting it from the Env var
         #when the Env var is not verified
        else{
          $MustWrite_OpCache = 1;
        }#End of else for CR ID after getting it from environment variable

      }#End of unless for valid CR ID from view tag
      else{
        $MustWrite_OpCache = 1;
      }#End of else for valid CR ID from view tag

    }#End of unless for Query Op cache

  }#End of unless for $crid retrieved fron env variable or branch-type

  # If the file did not exist or if the information in the file
  # is not latest then write the new info in the opcache file

  if ($MustWrite_OpCache) {
	@$OpCache_ref{'CRID','CRID_ORIGIN'} = ($crid, $crid_origin);
  }

}


##############################################################

=item B<preCheckin>

  1. Get the CRID associated with the checked out file.
  2. If $::CQCC_CSET_LOGGING_ENABLED flag is set to 1, replace the
     checked out entry with the check-in entry in the ClearCase
     change set in ClearQuest.

=cut

##############################################################

sub preCheckin {
   return  0  unless $::CQCC_CSET_LOGGING_ENABLED;

   my ($pn, $xpn) = @_;

   my %retval = ParseBrtypeName($ENV{CLEARCASE_BRTYPE});
   return 0  if ($retval{ERROR} == 0  and  $retval{IS_SANDBOX_USAGE});
   return 0  if ($retval{ERROR} == 0  and  $retval{IS_INT_USAGE});
   return 0  if ($retval{ERROR} == 0  and  $retval{IS_MAIN_USAGE});

   my ($rc, $crid, $crid_origin) = (0, '', '');
   my $env_crid = $ENV{CMBP_CRID} || "";
   my $crid_verified = $ENV{CMBP_CRID_VERIFIED} || "";
   if ($env_crid and $crid_verified) {
      $crid = $env_crid;
      $crid_origin = $ENV{CMBP_CRID_ORIGIN} || "";
   }
   unless ($crid) {
	  $OpCache_ref = fetch_opcache();
	  ($crid, $crid_origin) = @$OpCache_ref{'CRID','CRID_ORIGIN'};
   }
   if ($crid) {
      ($rc, $crid) = FormatCrId($crid);
      $crid = $crid_origin = ""  if ($rc);
   }
   unless ($crid) {
      ($rc, $crid) = GetCrHlink($pn);
      if ($rc){
         display_msg("Warning: $pn has bad CR hyperlinks; " .
             "we cannot associate ClearQuest CRs.",2);
         return 0;
      }
   }
   ($crid  and  $crid_origin ne 'brname')  and  $MustWrite_OpCache = 1;

   if ($crid){
      LogCset($xpn, $crid);
      if ($MustWrite_OpCache) {
		@$OpCache_ref{'CRID','CRID_ORIGIN'} = ($crid, $crid_origin);
      }
   }
   else {
      display_msg("Warning: $pn has no CR hyperlinks; " .
                  "we cannot associate ClearQuest CRs.\n",2);
   }
   return 0;
}

################################################################

=item B<preUncheckout>

  1.  Get the CRID associated with the checked out file
  2.  If $::CQCC_CSET_LOGGING_ENABLED flag in the config file is
      set to 1, remove the checked-out entry in the ClearCase
      change set in ClearQuest


=back

=head1 RETURN VALUES

  0 on success
  1 on failure


=cut

################################################################

sub preUncheckout {
   return  0  unless $::CQCC_CSET_LOGGING_ENABLED;

   my $pn = shift @_;

   my %retval = ParseBrtypeName($ENV{CLEARCASE_BRTYPE});
   return 0  if ($retval{ERROR} == 0  and  $retval{IS_SANDBOX_USAGE});
   return 0  if ($retval{ERROR} == 0  and  $retval{IS_INT_USAGE});
   return 0  if ($retval{ERROR} == 0  and  $retval{IS_MAIN_USAGE});

   my ($rc, $crid, $crid_origin) = (0, '', '');
   my $env_crid = $ENV{CMBP_CRID} || "";
   my $crid_verified = $ENV{CMBP_CRID_VERIFIED} || "";
   if ($env_crid and $crid_verified) {
      $crid = $env_crid;
      $crid_origin = $ENV{CMBP_CRID_ORIGIN} || "";
   }
   unless ($crid) {
      $OpCache_ref = fetch_opcache();
      ($crid, $crid_origin) = @$OpCache_ref{'CRID','CRID_ORIGIN'};
   }
   if ($crid) {
      ($rc, $crid) = FormatCrId($crid);
      $crid = $crid_origin = ""  if ($rc);
   }
   unless ($crid) {
      ($rc, $crid) = GetCrHlink($pn);
      $crid = ""  if ($rc);
   }
   ($crid  and  $crid_origin ne 'brname')  and  $MustWrite_OpCache = 1;

   if ($crid) {
      UnLogCset($pn, $crid);
      if ($MustWrite_OpCache) {
		@$OpCache_ref{'CRID','CRID_ORIGIN'} = ($crid, $crid_origin);

      }
   }
   return 0;
}

#################################################################

=head1 NAME

DoUnco -- Do an uncheckout of $ENV{CLEARCASE_PN}.

=head1 SYNOPSIS

  DoUnco()

=head1 DESCRIPTION

This function is called by 'cqcc_int.pl' trigger script when the postCheckout trigger fails.  It does an an uncheckout of $ENV{CLEARCASE_PN}.

=head1 RETURN VALUES

NONE

=cut

#################################################################
sub DoUnco {
   display_msg("Error:  The post-checkout trigger failed; " .
          "will attempt to cancel the checkout." .
          "(ClearCase may display some error messages after this; " .
          "they are expected and can be ignored).",1);
   my $cmd = "$CLEARTOOL unco -rm \"$ENV{CLEARCASE_PN}\"";
   prep_cmd(\$cmd);
   `$cmd`;
}



#################################################################



1;

