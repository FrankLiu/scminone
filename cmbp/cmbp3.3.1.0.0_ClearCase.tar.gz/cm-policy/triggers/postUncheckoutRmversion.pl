#VERSION CMBP 2.2
#
###############################################################################
##
## Program: postUncheckoutRmversion
##
## Summary: trigger fired after checkout and rmver operation
##
## Description:
##
##       Remove the branch if -                                      
##       - it is not a main branch
##       - if the 0th version is the LATEST version and 
##         there are no sub-branches
##
##
###############################################################################

package PostUncheckoutRmver;

use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(postuncheckoutrmver);

BEGIN {
	use File::Basename;
	my $SCRIPT_ROOT = dirname $0;
	push(@INC, "$SCRIPT_ROOT/../lib");
}

use CMBlueprint;
use CMBlueprint::Branch;

use vars qw($CLEARTOOL);

################## ACE TRIGGER ###########################################

=head1 NAME

postUncheckoutRmversion -- trigger function called on post-op of 'cleartool uncheckout and rmver' command.  
Removes the branch if it's not '/main' branch and if the branch does not have versions or sub-branches.

=head1 SYNOPSIS

 postUncheckout()

=head1 INSTALLATION COMMAND

 Create trigger type using the following command:

 cleartool mktrtype -elem -all -postop uncheckout  \
   -execunix $UNIX_PERL "$UNIX_INSTALL_DIR/triggers/triggerMain.pl -t postUncheckout" \
   -execwin  $NT_PERL "$NT_INSTALL_DIR\triggers\triggerMain.pl -t postUncheckout" \
 postUncheckout

 cleartool mktrtype -elem -all -postop rmver  \
   -execunix $UNIX_PERL "$UNIX_INSTALL_DIR/triggers/triggerMain.pl -t postRmversion" \
   -execwin  $NT_PERL "$NT_INSTALL_DIR\triggers\triggerMain.pl -t postRmversion" \
 postRmversion



=head1 DESCRIPTION

=over 3

=item 1.

$ENV{'CLEARCASE_BRTYPE'} contains the name of the branch type involved
in the uncheckout operation.  If the branch type is "main", then exit.

=item 2.

If the branch does not have versions or sub-branches, then remove the
branch.

=back

=head1 RETURN_VALUES

 0

=cut

##########################################################################

sub postuncheckoutrmver {

   if ( $ENV{'CLEARCASE_BRTYPE'} eq "main" ){
      return 0;
   }

   if ( $ENV{'CLEARCASE_XPN'} =~ m#^(.*)[/|\\][^/|\\]+$#o ){
      my $branch = $1;
      if (not has_vers_subbranches($branch)){
         my $cmd = "$CLEARTOOL rmbranch -force \"$branch\"";
         prep_cmd(\$cmd);
         `$cmd`;
      }
   }

   return 0;
}

1;
