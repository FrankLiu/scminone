#VERSION CMBP 2.2
#
## Need the following variables from the main:: package
###############################################
# Use variables from site.cfg                 #
###############################################
use vars qw($CQ_REC_TYPE @CC_VOBADM_LST);

###############################################
# Use variables from $PROD_trigger.cfg        #
###############################################
use vars qw(@CQ_DB_LST $CQ_DEF_DB $OPCACHE_TIMEOUT $UNIX_VIEWSTORE
            $PROMPT_ON_CR_MISMATCH
            $PER_CO_AUTH_REQD
            $CQCC_INTEGRATION_ENABLED
            $CQCC_CSET_LOGGING_ENABLED);


package PostMkBrtype;

use strict;

use Socket;
use vars qw(@ISA @EXPORT @EXPORT_OK);

use Exporter;
@ISA = qw(Exporter);

###############################################
# Use variables from CMBlueprint.pm             #
###############################################
use vars qw(%CQ_QUERY_FILTER $CLEARTOOL
            %CQ_WEB_PARAMS   $CQCC_HLTYPE
            $DEVINT_MERGELIST_ATTYPE
            $TMPDIR          $CQCC_ATTYPE);



BEGIN {
  use File::Basename;
  my $dirname = dirname($0);
  unshift(@INC, "$dirname/../lib");
  unshift(@INC, "$dirname/../config");
};


use CMBlueprint;
use CMBlueprint::ClearQuest;
use CMBlueprint::ViewCache;
use CMBlueprint::Branch;
use CMBlueprint::MetaData;
use CMBlueprint::NamingPolicy;
use CMBlueprint::UI;
use CMBlueprint::Vob;

sub postMkbrtype {
    my $brtype = $ENV{CLEARCASE_BRTYPE} . "@" . $ENV{CLEARCASE_VOB_PN};
    my ($rc, $crid, $new_crid);
    my %retval = ParseBrtypeName($ENV{CLEARCASE_BRTYPE});

    if ($retval{ERROR} == 0){
		return  0 if ($retval{IS_SANDBOX_USAGE});

		##if it's int/rel branch, no CR ID needed
		##if it's dev branch, write CQ cc_change_set 'WORK_STARTED'
		my $cvalue='WORK_STARTED';

		##if int/rel branch, nothing need to be done
		if (  $retval{IS_INT_USAGE} || $retval{USAGE_TAG} =~ m/^(bld|int|main)$/ ) {
			return 0;
		}

		#for xxx-main alternate mainline branch
		return 0 if ( $ENV{CLEARCASE_BRTYPE} =~ m/-main$/ );

		if (length($retval{ORIG_DBID})){
			my ($cqdb,$crnum);
			($rc, $cqdb, $crnum) = GenerateCrId($retval{ORIG_CQDB},
							$retval{ORIG_DBID},
							$::CQ_DEF_DB, @::CQ_DB_LST);
			if ($rc){
			display_msg("Ambiguous database name in brtype:$ENV{CLEARCASE_BRTYPE}", 1);
			RmBrtype($brtype);
			return 1;
			}
			$crid = $cqdb . $crnum;

			# Don't need to verify since the branch is checked at the pretrigger.
			attach_branch_metadata($brtype, $crid);

			# Automatically Lock Dev CR branches except for current Assigned TA and VOB admins
			if ($::PER_CO_AUTH_REQD and $ENV{'SHARE_BR'} != 1 and $retval{IS_DEV_USAGE} and (isBRTypePropToLocalVobs($brtype) == 0)) {
				LockBrtype($brtype);
			}


			# Attach Dev-Int branch types metadata
			#   1. FeatureID hyperlink
			#   2. devint-merge-list-required attribute
			# If failed to create either metadata, still continue
			if ($retval{IS_DEVINT_USAGE}) {
				$rc = AddFeatureidHlink($brtype, $crid);
				if ($rc) {
					display_msg("Failed to create initial FeatureID hyperlink on brtype:$ENV{CLEARCASE_BRTYPE}", 2);
				}
				$rc = AddDevintMergeListAttr($brtype);
				if ($rc) {
					display_msg("Failed to create initial $DEVINT_MERGELIST_ATTYPE attribute on brtype:$ENV{CLEARCASE_BRTYPE}", 2);
				}
			}
			if ( ($retval{IS_DEV_USAGE} || $retval{IS_DEVINT_USAGE}) and $::CQCC_INTEGRATION_ENABLED) {
			
				# if there is currently something written in the CC changeset in CQ, do not write, it will
				# stomp over the current changeset.

				my $adminvob = $NT ? $::CC_NT_ADMINVOB : $::CC_UNIX_ADMINVOB;
				my $branch = $ENV{CLEARCASE_BRTYPE};

				$ENV{CLEARCASE_VOB_PN} = $adminvob;

		                my ($rc, $uuid, $oid) = GetUidOid($branch, $adminvob);
		                if($rc)
		                {
		                        display_msg("Failed to obtain the vob_family uid from branch $brtype.\n");
		                        return 1;
	        	        }

				# placing the last arg so it won't try
				# to relink the ccchangeset vob object since at times it expects the ccchangeset to be empty.

	                	my ($rc, $status,$originatingCR) = getVobObjectNameFromCQ($uuid,$branch,$adminvob,1); 
				dprint "status ---> ;$status;\n";			


				if($status eq "" || $status eq "BRTYPE_DELETED")
				{
					dprint("NO VALUE IN THE STATUS ID\n");
					MVCsetLog($brtype,$crid,$cvalue);
				}  
				else
				{
					dprint("THERE IS A VALUE ($status) ... NOTHING WRITTEN \n");
				}
			} # end if
		}
    }
}

sub attach_branch_metadata($ $ ; $) {
  my $brtype = shift;
  my $crid   = shift;
  my $rc     = shift || 0;

  MakeOrigCrAttr("brtype:$brtype", $crid);

  LogCset($brtype, $crid)    if ($::CQCC_CSET_LOGGING_ENABLED);

  dprint ("RETUNING RC = $rc from attach_branch_metadata\n");
  return $rc;
}


################################################################
# Function isBRTypePropToLocalVob will do a describe on the brtype
# and see if the GlobalDefinition hyperlink exist.
################################################################

sub isBRTypePropToLocalVobs($)
{
    my $bt = shift @_;
    my $brtypecmd = "$CLEARTOOL describe -ahlink GlobalDefinition brtype:$bt 2>$ERRNULL";  # the vob location already passed into the function call.

    dprint (1,"command = $brtypecmd\n");

    my @broutput = qx($brtypecmd);
    return 0 if($?); # branch does not exist

    my $hyperlinkexist=0;
    foreach (@broutput)
    {
        if(m/GlobalDefinition/i)
        {
            $hyperlinkexist=1;
            last;
        }
    }
    dprint (1,"hyperlinkexist = $hyperlinkexist");
    return $hyperlinkexist;
}


1;


